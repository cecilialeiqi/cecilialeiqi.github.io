#include "mainWindow.h"
#include <QFileDialog>
#include <QPainter>
#include <QMouseEvent>
#include <iostream>

MainWindow *MainWindow::_mainWindow = NULL;

MainWindow::MainWindow () 
{
	setupUi(this);

	createAction();
	createMenus();
	createToolBar();

	m_pressed = false;
	m_pressedIndex = 0;

//	m_imgLabel->setGeometry(0,0,frameSize().width(),frameSize().height());

	connect(treeWidget,SIGNAL(itemClicked(QTreeWidgetItem *, int)),this,SLOT(treeItemClicked(QTreeWidgetItem *, int)));
	loadTemp();
}

MainWindow::~MainWindow() 
{
}

void MainWindow::mousePressEvent(QMouseEvent * en)
{
	if(en->button() == Qt::LeftButton)		// move a region
	{
		m_pressedPos = QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height());
		m_pressed = true;
		QRgb clr = m_idxImg.pixel(m_pressedPos);
		m_pressedIndex = qRed(clr)*256*256 + qGreen(clr)*256 + qBlue(clr);
		std::cout << "Region " << m_pressedIndex << " is selected!" << std::endl;

		//treeWidget->childAt()->setSelected(true);
		//m_pressedIndex = findRegionIndex(m_pressedPos);
	}
	else if (en->button() == Qt::RightButton)  // group regions
	{
		m_pressed = true;
		m_pressedPos = QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height());
		QRgb clr = m_idxImg.pixel(m_pressedPos);
		m_pressedIndex = qRed(clr)*256*256 + qGreen(clr)*256 + qBlue(clr);
		
		m_vGroupIndex.clear();
		m_vGroupIndex.push_back(m_pressedIndex);
		std::cout << "Region " << m_pressedIndex << " is selected!" << std::endl;
	}
}

void MainWindow::mouseMoveEvent(QMouseEvent * en)
{
	if ((en->buttons() & Qt::LeftButton) && m_pressed)
	{
	//	QPainter painter(&m_showImg);
	//	painter.setPen(QPen(qRgb(255,0,0)));
	//	painter.drawLine(m_pressedPos,QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height()));
	//	m_imgLabel->setPixmap(QPixmap::fromImage(m_showImg));
	}
	else if (en->buttons() & Qt::RightButton && m_pressed)  // group regions
	{
		m_pressedPos = QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height());
		QRgb clr = m_idxImg.pixel(m_pressedPos);
		m_pressedIndex = qRed(clr)*256*256 + qGreen(clr)*256 + qBlue(clr);

		if(m_pressedIndex>1)
		{
			bool existed = false;
			for (int k=m_vGroupIndex.size()-1; k>=0; k--)
			{
				if(m_vGroupIndex[k]==m_pressedIndex)
				{
					existed=true;
					break;
				}
			}
			if(existed==false)
			{
				m_vGroupIndex.push_back(m_pressedIndex);
				std::cout << "Region " << m_pressedIndex << " is selected!" << std::endl;
			}
		}
	}
		
}

void MainWindow::mouseReleaseEvent(QMouseEvent * en)
{
	if (en->button() == Qt::LeftButton && m_pressed && m_pressedIndex>0 && m_pressedIndex<pcut.m_boundary.size()) 
	{
		QPoint releasePos = QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height());
		pcut.regionShift(m_pressedIndex-1,releasePos-m_pressedPos);
		for (int k=0; k<pcut.m_tree.size(); k++)
		{
			if(pcut.m_tree[k]==pcut.m_tree[m_pressedIndex] && 
				pcut.m_tree[m_pressedIndex]!=0 && k!=m_pressedIndex)
				pcut.regionShift(k-1,releasePos-m_pressedPos);
		}
		
		m_idxImg = pcut.renderToIndexImage();
		updateShowImage(m_idxImg);
		m_imgLabel->setPixmap(QPixmap::fromImage(m_showImg));

		m_pressed = false;
	}
	else if(en->button()==Qt::RightButton && m_pressed)
	{
		m_pressedPos = QPoint(en->x()-m_imgLabel->x(),en->y()-fileMenu->height()-fileToolBar->height());
		QRgb clr = m_idxImg.pixel(m_pressedPos);
		m_pressedIndex = qRed(clr)*256*256 + qGreen(clr)*256 + qBlue(clr);

		if(m_pressedIndex>1)
		{
			bool existed = false;
			for (int k=m_vGroupIndex.size()-1; k>=0; k--)
			{
				if(m_vGroupIndex[k]==m_pressedIndex)
				{
					existed=true;
					break;
				}
			}
			if(existed==false)
			{
				m_vGroupIndex.push_back(m_pressedIndex);
				std::cout << "Region " << m_pressedIndex << " is selected!" << std::endl;
			}
		}

		m_pressed = false;
		pcut.regionGroup(m_vGroupIndex);
		updateTreeWidget();
	}
}

void MainWindow::createAction()
{
	/// load image
	loadImageAct = new QAction(QIcon("./img/open.png"), tr("&Load Image"), this);
	loadImageAct->setShortcut(tr("Ctrl+L"));
	loadImageAct->setStatusTip(tr("Load an image"));
	connect(loadImageAct,SIGNAL(triggered()),this,SLOT(loadImage()));

	/// save image
	saveImageAct = new QAction(QIcon("./img/save.png"), tr("&Save Image"), this);
	saveImageAct->setShortcut(tr("Ctrl+S"));
	saveImageAct->setStatusTip(tr("Save to image"));
	connect(saveImageAct,SIGNAL(triggered()),this,SLOT(saveImage()));
}
void MainWindow::createMenus()
{
	/// load image
	fileMenu = menuBar()->addMenu(tr("&File"));
	fileMenu->addAction(loadImageAct);
	fileMenu->addAction(saveImageAct);

	editMenu =  menuBar()->addMenu(tr("&Edit"));

	helpMenu =  menuBar()->addMenu(tr("&Help"));
}

void MainWindow::createToolBar()
{
	/// create toolbar
	fileToolBar = addToolBar(tr("File"));
	fileToolBar->addAction(loadImageAct);
	fileToolBar->addAction(saveImageAct);
}

void MainWindow::loadImage()
{
	QString filename = QFileDialog::getOpenFileName(this,"Load Image",
		"F:/data/image", tr("Images (*.png *.jpg *.bmp)") );
	if(filename.isNull())
		return;

	m_srcImg = QImage(filename);
	m_imgLabel->resize(m_srcImg.width(),m_srcImg.height());
	m_imgLabel->setPixmap(QPixmap::fromImage(m_srcImg));
}

void MainWindow::saveImage()
{
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
		"F:/data/snapshot",
		tr("Images (*.png *.jpg *.bmp)"));

	m_showImg.save(fileName);
}
void MainWindow::treeItemClicked(QTreeWidgetItem * item, int column)
{
	QString txt = item->text(column);
	QStringList strl = txt.split(QString("#"));
	int idx = strl.last().toInt();

	int fdadf =0;
}
void MainWindow::updateTreeWidget()
{
	treeWidget->clear();
	treeWidget->setColumnCount(1);
	treeWidget->setHeaderLabel(tr("Hierarchy Structure"));

	QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(treeWidget,QStringList(QString("Silhouette")));
	QTreeWidgetItem *imageItem2 = new QTreeWidgetItem(treeWidget,QStringList(QString("Others")));
	std::vector<bool>  record(pcut.m_boundary.size(),false);
	for(int k=1; k<pcut.m_boundary.size(); k++)
	{
		if(record[k]==true)
			continue;

		if(pcut.m_tree[k]==0)
		{
			QTreeWidgetItem *imageItem2_1 = new QTreeWidgetItem(imageItem2,QStringList(QString("Pattern #%1").arg(k)));
			record[k]=true;
		}
		else 
		{
			const int idx= pcut.m_tree[k];
			QTreeWidgetItem *imageItem2_1 = new QTreeWidgetItem(imageItem2,QStringList(QString("Group #%1").arg(idx)));
			for(int j=0; j<pcut.m_boundary.size(); j++)
			{
				if(pcut.m_tree[j]==idx)
				{
					QTreeWidgetItem *imageItem2_2 = new QTreeWidgetItem(imageItem2_1,QStringList(QString("Pattern #%1").arg(j)));
					record[j]=true;
				}
			}
		}
	}

	treeWidget->expandAll();

	//ui->treeWidget->setColumnCount(1); //��������
	//ui->treeWidget->setHeaderLabel(tr("ͼ��ѡ��")); //����ͷ�ı���

	//QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("ͼ��1")));
	//imageItem1->setIcon(0,QIcon("xxx.png"));
	//QTreeWidgetItem *imageItem1_1 = new QTreeWidgetItem(imageItem1,QStringList(QString("Band1"))); //�ӽڵ�1
	//imageItem1->addChild(imageItem1_1); //�����ӽڵ�

	//QTreeWidgetItem *imageItem2 = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("ͼ��2")));
	//QTreeWidgetItem *imageItem2_1 = new QTreeWidgetItem(imageItem2,QStringList(QString("Band1"))); //�ӽڵ�1
	//QTreeWidgetItem *imageItem2_2 = new QTreeWidgetItem(imageItem2,QStringList(QString("Band2"))); //�ӽڵ�2
	//imageItem2->addChild(imageItem2_1);  //�����ӽڵ�
	//imageItem2->addChild(imageItem2_2);

	//ui->treeWidget->expandAll(); //���ȫ��չ��
}
void MainWindow::updateShowImage(const QImage &indexImg)
{
	m_showImg = indexImg;
	for (int yi=0; yi<indexImg.height(); yi++)
	{
		for (int xi=0; xi<indexImg.width(); xi++)
		{
			QRgb c = indexImg.pixel(xi,yi);
			int idx = qRed(c)*256*256 + qGreen(c)*256 + qBlue(c);
			if(idx==1)
				m_showImg.setPixel(xi,yi,qRgb(255,0,0));
			else
				m_showImg.setPixel(xi,yi,qRgb(idx*20,255,255));
		}
	}
}
void MainWindow::loadTemp()
{
	QImage tmp("./img/pig.jpg");

	pcut.convertFromImage(tmp);
	updateTreeWidget();

	m_idxImg = pcut.renderToIndexImage();
	updateShowImage(m_idxImg);
	m_imgLabel->resize(m_showImg.width(),m_showImg.height());
	m_imgLabel->setPixmap(QPixmap::fromImage(m_showImg));
}