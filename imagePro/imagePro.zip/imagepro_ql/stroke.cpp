#include "stroke.h"
#include <glew.h>

void Stroke::computeNormal()
{
	int bsz = _vBrush.size(); 
	if(bsz==1)
		_vBrush[0].setDirection(0.0,0.0);
	else 
	{
		vector<Vec2f>	lineDirt;
		lineDirt.resize(bsz-1);

		for(int k=0; k<bsz-1; k++)
		{
			Vec2f path = Vec2f(_vBrush[k]._y-_vBrush[k+1]._y,_vBrush[k+1]._x-_vBrush[k]._x);
			float len = path.length();
			lineDirt[k] = len==0.0 ? path:path/len;
		}

		for(int k=0; k<bsz; k++)
		{
			if(k==0)			/// first brush
				_vBrush[k].setDirection(lineDirt[k].x(),lineDirt[k].y());
			else if(k==bsz-1)	/// last brush
				_vBrush[k].setDirection(lineDirt[bsz-2].x(),lineDirt[bsz-2].y());
			else				/// in-between brushes
			{
				Vec2f pathn = lineDirt[k-1] + lineDirt[k];
				float len = pathn.length();
				pathn = len==0.0 ? pathn:pathn/len;
				_vBrush[k].setDirection(pathn.x(),pathn.y());
			}
		}
	}	
}

void Stroke::drawPoint()
{
	glDisable(GL_TEXTURE_2D);
	glPointSize(1.5);
	glColor3f(0.8f,0.8f,0.8f);
	glBegin(GL_POINTS);
	for(unsigned int k=0; k<_vBrush.size(); k++)
		glVertex3f(_vBrush[k]._x, _vBrush[k]._y, _dep);
	glEnd();
	glColor3f(1,1,1);
	glEnable(GL_TEXTURE_2D);
}

void Stroke::drawPath()
{
	glDisable(GL_TEXTURE_2D);
	glLineWidth(1.0);
	glColor3f(1,0,0);
	glBegin(GL_LINE_STRIP);
	for(unsigned int k=0; k<_vBrush.size(); k++)
	{
		Brush *b = &_vBrush[k];
		glVertex3f(b->_x, b->_y, _dep);
	}	
	glEnd();
	glColor3f(1,1,1);
	glEnable(GL_TEXTURE_2D);
}

void Stroke::drawNormal()
{
	float lnw = 5.0;
	glDisable(GL_TEXTURE_2D);
	glLineWidth(1.0);
	if(_valid)	glColor3f(0.67f,0.0f,0.0f);
	else		glColor3f(0.33f,0.0f,0.0f);
	glDisable(GL_LINE_STIPPLE);
	glBegin(GL_LINES);
	for(unsigned int k=0; k<_vBrush.size(); k++)
	{
		Brush *b = &_vBrush[k];
		/// horizontal reverse
		glVertex3f(b->_x-b->_gx*lnw, b->_y-b->_gy*lnw, _dep);
		glVertex3f(b->_x+b->_gx*lnw, b->_y+b->_gy*lnw, _dep);
	}	
	glEnd();
	glColor3f(1,1,1);
	glEnable(GL_TEXTURE_2D);
}

void Stroke::drawProjection()
{
	glDisable(GL_TEXTURE_2D);

	/// draw the projecting lines
/*	glLineWidth(1.0);
	if(_valid)	glColor3f(0,0.67,0);
	else		glColor3f(0,0.33,0);
	glDisable(GL_LINE_STIPPLE);
	glBegin(GL_LINES);
	for(int k=0; k<_vBrush.size(); k++)
	{
		Brush *b = &_vBrush[k];
		/// horizontal reverse
		glVertex3f(b->_x, b->_y, _dep);
		glVertex3f(b->_x+b->_px, b->_y+b->_py, _dep);
	}	
	glEnd();*/

	glEnable( GL_POINT_SMOOTH );
	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	/// draw the projected points
	glColor3f(0,0,0);
	glPointSize(1.5f);
	glBegin(GL_POINTS);
	for(unsigned int k=0; k<_vBrush.size(); k++)
	{
		//glPointSize(max(_vBrush[k]._rad,1.0f));
		glVertex3f(_vBrush[k]._x+_vBrush[k]._px, _vBrush[k]._y+_vBrush[k]._py, _dep);
	}
	glEnd();
	


	glColor3f(1,1,1);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_POINT_SMOOTH);
	glDisable(GL_BLEND);
}