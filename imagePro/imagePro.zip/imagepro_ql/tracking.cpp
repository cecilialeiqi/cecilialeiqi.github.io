#include "tracking.h"
#include <math.h>

namespace tracking{

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float _clampf(float vmin, float vmax, float v)
{
	return min(max(v,vmin), vmax);
}
bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void flipDirection(float prevx, float prevy, float tangx, float tangy, float &nx, float &ny)
{
	float tangsign = tangx*prevx + tangy*prevy;
	if(tangsign<0.0)
	{
		nx = -tangx;
		ny = -tangy;
	}
	else
	{
		nx = tangx;
		ny = tangy;
	}
}
void getDirection(int w, int h, int cn, const float*flow,  float prevx, float prevy,
				  float px, float py, float &tx, float &ty, int interp)
{
	float gx, gy;
	if(interp==0)		/// nearest interpolation
	{
		const float *f = flow + _clamp(0,h-1,int(py+0.5))*w*cn + _clamp(0,w-1,int(px+0.5))*cn;
		flipDirection(prevx,prevy,f[1],-f[0],tx,ty);
	}
	else if(interp==1)	/// bilinear interpolation
	{
		float xc = _clampf(0.0f,float(w-1),px);
		float yc = _clampf(0.0f,float(h-1),py);
		float xcf = floor(xc);
		float ycf = floor(yc);
		const float *f1 = flow + _clamp(0,h-1,int(ycf))*w*cn + _clamp(0,w-1,int(xcf))*cn;
		int shiftx = xc==xcf?0:cn;
		int shifty = yc==ycf?0:(w*cn);
		const float *f2 = f1 + shiftx;
		const float *f3 = f1 + shifty;
		const float *f4 = f3 + shiftx;
		float tx1, ty1, tx2, ty2, tx3, ty3, tx4, ty4;
		flipDirection(prevx,prevy,f1[1],-f1[0],tx1,ty1);
		flipDirection(prevx,prevy,f2[1],-f2[0],tx2,ty2);
		flipDirection(prevx,prevy,f3[1],-f3[0],tx3,ty3);
		flipDirection(prevx,prevy,f4[1],-f4[0],tx4,ty4);
		tx = (xcf+1.0-xc)*(ycf+1.0-yc)*tx1 + (xc-xcf)*(ycf+1.0-yc)*tx2
			+ (xcf+1.0-xc)*(yc-ycf)*tx3 + (xc-xcf)*(yc-ycf)*tx4;
		ty = (xcf+1.0-xc)*(ycf+1.0-yc)*ty1 + (xc-xcf)*(ycf+1.0-yc)*ty2 
			+ (xcf+1.0-xc)*(yc-ycf)*ty3 + (xc-xcf)*(yc-ycf)*ty4;
	}
}
void getDirectionRungeKutta(int w, int h, int cn, const float*flow, float prevx, float prevy,
							float px, float py, float &gx, float &gy, int interp)
{
	float pxx, pyy;
	getDirection(w,h,cn,flow,prevx,prevy,px,py,pxx,pyy,interp);
	float npx = px + 0.5*pxx;
	float npy = py + 0.5*pyy;
	getDirection(w,h,cn,flow,prevx,prevy,npx,npy,gx,gy,interp);
}
void rotateDirection(float &dx, float &dy, float angle)
{
	float px = dx, py=dy;
	dx = cos(angle)*px - sin(angle)*py;
	dy = sin(angle)*px + cos(angle)*py;
}
////////////////////////////////////////////////////////////////////////// streamline stopping at low confidence (high curvature)
vector<Pot3f> streamlineEular(float px, float py, int w, int h, int cn, float *flow, 
						 int interp,  int maxLen)
{
	vector<Pot3f> pos1, pos2;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	float bgnTangx, bgnTangy;
	getDirection(w,h,cn,flow,0.0,0.0,px,py,bgnTangx,bgnTangy, interp);
	float prevTangx = bgnTangx;
	float prevTangy = bgnTangy;

	pos1.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx, tangy;
		getDirection(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx; 
		seedy += tangy; 

		pos1.push_back(Pot3f(seedx,seedy,atan2(tangx,tangy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	cnt = 0;
	seedx = float(px);
	seedy = float(py);
	prevTangx = -bgnTangx;
	prevTangy = -bgnTangy;

	pos2.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx,tangy;
		getDirection(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx;
		seedy += tangy;

		pos2.push_back(Pot3f(seedx,seedy,atan2(tangx,tangy)));

		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));
	return pos1;
}

vector<Pot3f> streamlineRungeKutta(float px, float py, int w, int h, int cn, float *flow, 
							  int interp,  int maxLen)
{
	vector<Pot3f> pos1, pos2;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	float bgnTangx, bgnTangy;
	getDirectionRungeKutta(w,h,cn,flow,0.0,0.0,px,py,bgnTangx,bgnTangy, interp);
	float prevTangx = bgnTangx;
	float prevTangy = bgnTangy;

	pos1.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx, tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx; 
		seedy += tangy; 

		pos1.push_back(Pot3f(seedx,seedy,atan2(tangx,tangy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	cnt = 0;
	seedx = float(px);
	seedy = float(py);
	prevTangx = -bgnTangx;
	prevTangy = -bgnTangy;

	pos2.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx,tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx;
		seedy += tangy;

		pos2.push_back(Pot3f(seedx,seedy,atan2(tangx,tangy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));
	return pos1;
}
Pot3f tracingRefine(Pot3f pos, int w, int h, int cn, float *flow, float *proj)
{
	//const float *f = flow + _clamp(0,h-1,int(pos.y+0.5))*w*cn + _clamp(0,w-1,int(pos.x+0.5))*cn;
	float stepPos[8];
	const int proWidth = 6;
	tracking::findStepPosition(stepPos,pos.x,pos.y,w,h,proWidth, flow);
	return Pot3f((stepPos[0]+stepPos[4])*0.5, (stepPos[1]+stepPos[5])*0.5, pos.ang );
}
vector<Pot3f> trackingStep(float px, float py, int w, int h, int cn, float *flow, float *proj,
						   int interp, int maxLen)
{
#if 0
	vector<Pot3f> pos1;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	const float *pProj = flow + _clamp(0,h-1,py)*w*cn + _clamp(0,w-1,px)*cn;
	float pxNew = pProj[0]*pProj[2]+px;
	float pyNew = pProj[1]*pProj[2]+py;

	return streamlineEular(pxNew, pyNew, w, h, cn, flow, interp, maxLen);
#else
	/////////////////////////////////////////////////////////////
	// codes above have to be rewritten, using pull-back mechanism
	/////////////////////////////////////////////////////////////
	vector<Pot3f> pos1, pos2;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	float bgnTangx, bgnTangy;
	getDirectionRungeKutta(w,h,cn,flow,0.0,0.0,px,py,bgnTangx,bgnTangy, interp);
	float prevTangx = bgnTangx;
	float prevTangy = bgnTangy;

	pos1.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx, tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx; 
		seedy += tangy; 

		Pot3f refined = tracingRefine(Pot3f(seedx,seedy,atan2(tangx,tangy)),w,h,cn,flow,proj);
		pos1.push_back(refined);
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	cnt = 0;
	seedx = float(px);
	seedy = float(py);
	prevTangx = -bgnTangx;
	prevTangy = -bgnTangy;

	pos2.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx,tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx;
		seedy += tangy;

		Pot3f refined = tracingRefine(Pot3f(seedx,seedy,atan2(tangx,tangy)),w,h,cn,flow,proj);
		pos2.push_back(refined);
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));
	return pos1;
#endif
}
Pot3f projection(Pot3f pos, int w, int h, int cn, float *flow, float *proj)
{
	//const float *f = flow + _clamp(0,h-1,int(pos.y+0.5))*w*cn + _clamp(0,w-1,int(pos.x+0.5))*cn;
	const float *f = proj + _clamp(0,h-1,int(pos.y+0.5))*w*cn + _clamp(0,w-1,int(pos.x+0.5))*cn;
	return Pot3f(pos.x+f[0]*f[2], pos.y+f[1]*f[2], pos.ang);
}
vector<Pot3f> pathSmooth(const vector<Pot3f> &pnt)
{
	const int sz1 = int(pnt[pnt.size()-1].x);
	const int sz2 = int(pnt[pnt.size()-1].y);

	vector<Pot3f> pos2;
	pos2 = pnt;
	const int gap = 2;
	for(int i=gap; i<sz1-gap; i++)
	{
		pos2[i] = Pot3f(0.0,0.0,0.0);
		for(int g=-gap; g<=gap; g++)
			pos2[i] = Pot3f(pos2[i].x+pnt[i+g].x,pos2[i].y+pnt[i+g].y,0.0);
	}
	for(int i=gap; i<sz1-gap; i++)
		pos2[i] = Pot3f(pos2[i].x/float(gap*2+1),pos2[i].y/float(gap*2+1),pnt[i].ang);

	for(int i=sz1+gap; i<sz1+sz2-gap; i++)
	{
		pos2[i] = Pot3f(0.0,0.0,0.0);
		for(int g=-gap; g<=gap; g++)
			pos2[i] = Pot3f(pos2[i].x+pnt[i+g].x,pos2[i].y+pnt[i+g].y,0.0);
	}
	for(int i=sz1+gap; i<sz1+sz2-gap; i++)
		pos2[i] = Pot3f(pos2[i].x/float(gap*2+1),pos2[i].y/float(gap*2+1),pnt[i].ang);


	return pos2;
}
vector<Pot3f> trackingProj(float px, float py, int w, int h, int cn, float *flow, float *proj,
						   int interp, int maxLen)
{
#if 0
	vector<Pot3f> pos1;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	const float *pProj = flow + _clamp(0,h-1,py)*w*cn + _clamp(0,w-1,px)*cn;
	float pxNew = pProj[0]*pProj[2]+px;
	float pyNew = pProj[1]*pProj[2]+py;

	return streamlineEular(pxNew, pyNew, w, h, cn, flow, interp, maxLen);
#else
	/////////////////////////////////////////////////////////////
	// codes above have to be rewritten, using pull-back mechanism
	/////////////////////////////////////////////////////////////
	vector<Pot3f> pos1, pos2;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	float bgnTangx, bgnTangy;
	getDirectionRungeKutta(w,h,cn,flow,0.0,0.0,px,py,bgnTangx,bgnTangy, interp);
	float prevTangx = bgnTangx;
	float prevTangy = bgnTangy;

	pos1.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx, tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx; 
		seedy += tangy; 

		Pot3f refined = projection(Pot3f(seedx,seedy,atan2(tangx,tangy)),w,h,cn,flow,proj);
		pos1.push_back(refined);
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	cnt = 0;
	seedx = float(px);
	seedy = float(py);
	prevTangx = -bgnTangx;
	prevTangy = -bgnTangy;

	pos2.push_back(Pot3f(float(px),float(py),atan2(prevTangx,prevTangy)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		float tangx,tangy;
		getDirectionRungeKutta(w,h,cn,flow,prevTangx,prevTangy,seedx,seedy,tangx,tangy, interp);
		seedx += tangx;
		seedy += tangy;

		Pot3f refined = projection(Pot3f(seedx,seedy,atan2(tangx,tangy)),w,h,cn,flow,proj);
		pos2.push_back(refined);
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));
	//pathSmooth(pos1);
	return pathSmooth(pos1);
#endif
}

//vector<Pot3f> trackingProj(Pot2 pos, Pot2 wsz, int cn, float *flow, float *proj,
//						   float angle, int maxLen)
//{
//	return trackingProj(pos.x, pos.y, wsz.x, wsz.y, cn, flow, proj, angle, maxLen);
//}

void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = k;
			magMax = mag;
		}
	}

	stepPos[0] = float(distMax)*pGS[0]+float(pxi);
	stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	stepPos[2] = float(distMax);
	stepPos[3] = magMax;
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = -k;
			magMax = mag;
		}
	}
	stepPos[4] = float(distMax)*pGS[0]+float(pxi);
	stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	stepPos[6] = float(distMax);
	stepPos[7] = magMax;
}

} // namespace