#pragma once

#include <QPoint>
#include <QImage>
#include "tracking.h"
#include <vector>
#include <fstream>
using namespace std;

namespace skeleton{

class Edge
{
public:
	vector<QPointF> m_vPoint;
	//vector<Spline> m_vSpline;
    Edge::Edge(void)
	{
	}
	Edge::Edge(QPointF startPos)
	{
		m_vPoint.push_back(startPos);
	}
	Edge::Edge(vector<QPointF> vPoint)
	{
		m_vPoint = vPoint;
	}
	Edge::Edge(const Edge &e)
	{
		m_vPoint = e.m_vPoint;
	}
	Edge::Edge(vector<tracking::Pot3f> pnt)
	{
		for (int i=0;i<pnt.size()-1;i++)
		{
			m_vPoint.push_back(QPointF(pnt[i].x,pnt[i].y));
		}
	}
	Edge& Edge::operator +(QPointF pos)
	{
		for(int i=0;i<this->m_vPoint.size();i++)
		{
			this->m_vPoint[i]=QPointF(this->m_vPoint[i].x()+pos.x(),this->m_vPoint[i].y()+pos.y());
		}
		return *this;
	}

	friend std::ostream &operator<<(std::ostream &stream, const Edge &s);
	friend std::istream &operator>>(std::istream &stream, Edge &s);
};

class Vertex
{
public:
	QPointF			m_pos;

	QPointF			m_prevPos;

	bool			m_bJunction;

	float		    m_width;

	int			    m_k;

	QPointF		    m_direction[10];

	int				m_index[10];

	bool            m_smooth[10][10];

	Edge			m_boundary[5];

	bool            m_boundSmooth[5];

	Vertex::Vertex(void)
	{
		m_pos=QPointF(0,0);
		m_bJunction=false;
	}
	Vertex::Vertex(QPoint pos,bool bJunction, float width=8, int k=1)
	{
		m_pos=QPointF(float(pos.x()),float(pos.y()));
		m_bJunction=bJunction;
		m_width=width;
		m_k=k;
		for (int i=0;i<10;i++)
			m_index[i]=-1;

	}
	Vertex::Vertex(QPointF pos,bool bJunction,float width=8, int k=1)
	{
		m_pos=pos;
		m_bJunction=bJunction;
		m_width=width;
		m_k=k;
		for (int i=0;i<10;i++)
			m_index[i]=-1;
	}
};

class SkeletonGraph
{
public:
	vector<Vertex>			m_vVertex;
	
	vector<Edge>			m_vEdge;				

	vector<int>				m_vVertex42edge;		// 2*sizeof(edge)

	int						m_angleSmooth;

	int						m_maxWidth;

	int						m_minLuminance;

public:
	/// ������ƺ���д�����drawStreamline�ĺ�벿��
	//void drawOpenGL(float height, float offx=0, float offy=0, float zoom=1.0);
	int indexVertex(QPointF m_pos, int minDist);
	void clear();
	void smoothEdge();
	void deleteSingleEdge(int recordedge);
	void deleteEdge(QImage & m_image);
	void addEdge(vector<QPointF> interEdge);
	void junctionAdjust();
	void smoothSet(bool original, int w, int h, float *flow, QImage & m_image);
	void smoothSet2(int w, int h, float *flow, QImage & m_image);
	void smoothAdjust();
	int  edgeIndex(int indexVertex, Edge &pos);
	int  edgeIndex(int indexVertex, float tangx, float tangy);
	void globalRecord(QImage &m_record, int width);
	void correction();
	void smoothAdjust3_1(int i, int index1,int index2);
	void vertexAdjust3_1(int i, int index1, int index2);
	void smoothAdjust3_2(int i,int index, int index1, int index2);
	void smoothAdjust4_1(int i,int index1, int index2);
	void vertexAdjust4_1(int i,int index);
	void deleteVertex(int i);
	void moveVertex(int i,QPointF seed);

	friend std::ostream &operator<<(std::ostream &stream, const SkeletonGraph &s);
	friend std::istream &operator>>(std::istream &stream, SkeletonGraph &s);
	void splitEdge(int indexVertex, int indexEdge, QPointF seed);
};

QPoint getStartingPoint(const QImage &img);

//void computeSkeletonGraph(SkeletonGraph &sktGraph);

} // mamespace