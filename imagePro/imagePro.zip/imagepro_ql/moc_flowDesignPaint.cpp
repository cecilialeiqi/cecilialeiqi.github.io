/****************************************************************************
** Meta object code from reading C++ file 'flowDesignPaint.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../flowDesignPaint.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'flowDesignPaint.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ImagePaint[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      31,   14, // methods
       5,  169, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      33,   11,   11,   11, 0x05,
      56,   11,   11,   11, 0x05,
      79,   11,   11,   11, 0x05,
      99,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     131,  125,   11,   11, 0x0a,
     154,  148,   11,   11, 0x0a,
     173,  148,   11,   11, 0x0a,
     192,  148,   11,   11, 0x0a,
     208,  148,   11,   11, 0x0a,
     230,   11,   11,   11, 0x0a,
     239,   11,   11,   11, 0x0a,
     249,   11,   11,   11, 0x0a,
     257,   11,   11,   11, 0x0a,
     264,   11,   11,   11, 0x0a,
     273,   11,   11,   11, 0x0a,
     280,   11,   11,   11, 0x0a,
     296,   11,   11,   11, 0x0a,
     321,  316,   11,   11, 0x0a,
     338,   11,   11,   11, 0x2a,
     348,  316,   11,   11, 0x0a,
     368,   11,   11,   11, 0x2a,
     381,   11,   11,   11, 0x0a,
     397,   11,   11,   11, 0x0a,
     414,   11,   11,   11, 0x0a,
     434,  431,   11,   11, 0x0a,
     454,  431,   11,   11, 0x0a,
     474,   11,   11,   11, 0x0a,
     493,  490,   11,   11, 0x0a,
     535,  524,   11,   11, 0x0a,
     564,   11,   11,   11, 0x0a,

 // properties: name, type, flags
     125,  587, 0x46495103,
     601,  594, 0x06495103,
     606,  594, 0x06495103,
     617,  594, 0x06495103,
     625,  594, 0x06495103,

 // properties: notify_signal_id
       0,
       3,
       4,
       1,
       2,

       0        // eod
};

static const char qt_meta_stringdata_ImagePaint[] = {
    "ImagePaint\0\0imageChanged(QImage)\0"
    "originXChanged(double)\0originYChanged(double)\0"
    "zoomChanged(double)\0resolutionChanged(double)\0"
    "image\0setImage(QImage)\0value\0"
    "setOriginX(double)\0setOriginY(double)\0"
    "setZoom(double)\0setResolution(double)\0"
    "zoomIn()\0zoomOut()\0reset()\0hold()\0"
    "toggle()\0copy()\0reloadShaders()\0"
    "onIndexChanged(int)\0text\0savePNG(QString)\0"
    "savePNG()\0saveAllPNG(QString)\0"
    "saveAllPNG()\0clearAllDrawn()\0"
    "loadSplineFile()\0saveSplineFile()\0ck\0"
    "displaySpline(bool)\0editingSpline(bool)\0"
    "setBackground()\0sm\0smoothMethodCombocChanged(int)\0"
    "smoothSize\0smoothSizeCombocChanged(int)\0"
    "smoothComputeClicked()\0QImage\0double\0"
    "zoom\0resolution\0originX\0originY\0"
};

void ImagePaint::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ImagePaint *_t = static_cast<ImagePaint *>(_o);
        switch (_id) {
        case 0: _t->imageChanged((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 1: _t->originXChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->originYChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->zoomChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->resolutionChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->setImage((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 6: _t->setOriginX((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->setOriginY((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: _t->setZoom((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: _t->setResolution((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 10: _t->zoomIn(); break;
        case 11: _t->zoomOut(); break;
        case 12: _t->reset(); break;
        case 13: _t->hold(); break;
        case 14: _t->toggle(); break;
        case 15: _t->copy(); break;
        case 16: _t->reloadShaders(); break;
        case 17: _t->onIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->savePNG((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->savePNG(); break;
        case 20: _t->saveAllPNG((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->saveAllPNG(); break;
        case 22: _t->clearAllDrawn(); break;
        case 23: _t->loadSplineFile(); break;
        case 24: _t->saveSplineFile(); break;
        case 25: _t->displaySpline((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->editingSpline((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->setBackground(); break;
        case 28: _t->smoothMethodCombocChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->smoothSizeCombocChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->smoothComputeClicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ImagePaint::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ImagePaint::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_ImagePaint,
      qt_meta_data_ImagePaint, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ImagePaint::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ImagePaint::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ImagePaint::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ImagePaint))
        return static_cast<void*>(const_cast< ImagePaint*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int ImagePaint::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 31)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 31;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QImage*>(_v) = image(); break;
        case 1: *reinterpret_cast< double*>(_v) = zoom(); break;
        case 2: *reinterpret_cast< double*>(_v) = resolution(); break;
        case 3: *reinterpret_cast< double*>(_v) = originX(); break;
        case 4: *reinterpret_cast< double*>(_v) = originY(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setImage(*reinterpret_cast< QImage*>(_v)); break;
        case 1: setZoom(*reinterpret_cast< double*>(_v)); break;
        case 2: setResolution(*reinterpret_cast< double*>(_v)); break;
        case 3: setOriginX(*reinterpret_cast< double*>(_v)); break;
        case 4: setOriginY(*reinterpret_cast< double*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ImagePaint::imageChanged(const QImage & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ImagePaint::originXChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ImagePaint::originYChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ImagePaint::zoomChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void ImagePaint::resolutionChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
