#include "vectorize.h"

Papercut::Papercut()
{
}
Papercut::~Papercut()
{
	//if(!m_boundary.empty())
	//{
	//	for (int k=0; k<m_boundary.size(); k++)
	//	{
	//		if(!m_boundary[k].empty())
	//			m_boundary[k].clear();
	//	}
	//	m_boundary.clear();
	//}
}
////////////////////////////// convert from image //////////////////////
void Papercut::getEdge(const QImage &src, QImage &dest, int thresVal)
{
	uchar *ffs = dest.bits()+dest.bytesPerLine();
	for (int yi=1; yi<src.height()-1; yi++,ffs+=dest.bytesPerLine())
	{
		uchar *fs = ffs+1;
		for (int xi=1; xi<src.width()-1; xi++,fs++)
		{
			QRgb clr = src.pixel(xi,yi);
	//		dest.setPixel(xi,yi,qRgb(255,255,255));
			if(qBlue(clr)>=thresVal)
			{
				if(qBlue(src.pixel(xi-1,yi))<thresVal || 
					qBlue(src.pixel(xi,yi-1))<thresVal || 
					qBlue(src.pixel(xi+1,yi))<thresVal || 
					qBlue(src.pixel(xi,yi+1))<thresVal )
					//dest.setPixel(xi,yi,qRgb(0,0,0));
					fs[0] = 255;
			}
		}
	}
}
QPoint findStartPoint(const QImage &src)
{
	const uchar *ffs = src.bits();
	for (int yi=0; yi<src.height(); yi++,ffs+=src.bytesPerLine())
	{
		const uchar *fs = ffs;
		for (int xi=0; xi<src.width(); xi++,fs++)
		{
			if(fs[0]==255)
				return QPoint(xi,yi);
		}
	}
	return QPoint(0,0);
}
QPoint Papercut::nextPoint(QPoint &pn, const QImage &src)
{
	for (int i=-1;i<=1;i++)
		for (int j=-1;j<=1;j++)
			if ( (i!=0)||(j!=0))
			{
				if( qBlue(src.pixel(i+pn.x(),j+pn.y())) == 255 )
					return QPoint(pn.x()+i,pn.y()+j);
			}
	return QPoint(0,0);
}
void Papercut::getBoundary(QPoint &startPnt, QImage &src, std::vector<QPoint> &vPnt)
{
	QPoint currPnt = startPnt;
	vPnt.push_back(currPnt);	
	src.setPixel(currPnt.x(),currPnt.y(),127);
	int cnt = 0;
	while(cnt<10000)
	{
		QPoint pn = nextPoint(currPnt,src);
		
		if(pn!=QPoint(0,0))
		{
			currPnt = pn;
			vPnt.push_back(currPnt);
			src.setPixel(currPnt.x(),currPnt.y(),127);
		}
		else if(cnt >5)
		{
			int minDist = 10;
			const int checksz = int(vPnt.size())<5 ? int(vPnt.size()) : 5;
			for(int k=0; k<checksz; k++)
			{
				int dist = abs(currPnt.x()-vPnt[k].x())+abs(currPnt.y()-vPnt[k].y());
				minDist = dist < minDist ? dist : minDist;
			}
				
			if(minDist>3)
			{
				QPoint tmp = vPnt[vPnt.size()-1];
				vPnt.pop_back();			
				if(!vPnt.empty())
					currPnt = vPnt[vPnt.size()-1];
				else
					break;
			}
			else
				break;
		}
		else
			break;
		cnt++;
	}
}
void Papercut::convertFromImage(const QImage &src)
{
	/// ��ȡ��������
	m_width = src.width();
	m_height = src.height();
	QImage edgeImg = QImage(src.width(),src.height(),QImage::Format_Indexed8);
	edgeImg.fill(0);
	edgeImg.setColor(127,qRgb(255,255,0));
	edgeImg.setColor(255,qRgb(255,0,255));
	getEdge(src,edgeImg,128);

	/// ������������
	QPoint startPnt = findStartPoint(edgeImg);
	int cRegion = 0;
	while (startPnt!=QPoint(0,0) && cRegion<300)
	{
		std::vector<QPoint> vPnt;
		getBoundary(startPnt,edgeImg,vPnt);
		if(vPnt.size()>10)
			m_boundary.push_back(vPnt);

		startPnt = findStartPoint(edgeImg);
		cRegion ++;
	}

	m_tree.clear();
	m_tree.resize(m_boundary.size(),0);

	/// ʸ������spline��ϱ߽�
}

////////////////////////////// render to image //////////////////////
QPoint Papercut::findSeed(const QImage &edge, const std::vector<QPoint> &vpn)
{
	QPoint sum = QPoint(0,0);
	for (int k=0; k<vpn.size(); k++)
		sum += vpn[k];
	sum = QPoint(int(sum.x()/int(vpn.size())), int(sum.y()/int(vpn.size())));

	int seg[4];
	int cnt = 0;
	// check horizontally
	QPoint diffSum = QPoint(0,0);
	for(int xi=0; xi<edge.width()-1; xi++)
	{
		int diff = qRed(edge.pixel(xi,sum.y()))-qBlue(edge.pixel(xi+1,sum.y()));
		if(diff!=0)
		{
			diffSum = diff<0 ? (diffSum+QPoint(1,0)) : (diffSum+QPoint(0,1));
			if(cnt<=3)
				seg[cnt++] = xi;
		}
	}
	if(diffSum == QPoint(2,2))
		return QPoint(int(seg[1]+seg[2])/2,sum.y());

	// check vertically
	diffSum = QPoint(0,0);
	cnt=0;
	for(int yi=0; yi<edge.height()-1; yi++)
	{
		int diff = qRed(edge.pixel(sum.x(),yi))-qBlue(edge.pixel(sum.x(),yi+1));
		if(diff!=0)
		{
			diffSum = diff<0 ? (diffSum+QPoint(1,0)) : (diffSum+QPoint(0,1));
			if(cnt<=3)
				seg[cnt++] = yi;
		}
	}
	if(diffSum == QPoint(2,2))
		return QPoint(sum.x(),int(seg[1]+seg[2])/2);

	return QPoint(0,0);
}
void Papercut::fillRegion(const QImage &edgeImg, QImage &region, QPoint seed, int curcnt)
{
	/// edge -> region, using seede
	//edge.setColor(curcnt,qRgb(curcnt, curcnt, curcnt));
	const int w = edgeImg.width();
	const int h = edgeImg.height();
	bool spanNeedFill;
	int xl,xr,x,y;
	//�����ɫ

	typedef std::vector<QPoint> Stack;
	Stack myStack;
	myStack.clear();
	myStack.push_back(seed);
	while(!myStack.empty())
	{
		seed=myStack.back();
		myStack.pop_back();
		y=seed.y();
		x=seed.x();
		while(region.pixelIndex(x,y)==0)
		{
			region.setPixel(x,y,curcnt);
			x++;
		}
		xr=x-1;
		x=seed.x()-1;
		while(region.pixelIndex(x,y)==0)
		{
			region.setPixel(x,y,curcnt);
			x--;
		}
		xl=x+1;
		//��������һ��ɨ����
		x=xl;
		y=y+1;
		while(x<xr)
		{
			spanNeedFill=FALSE;
			while(region.pixelIndex(x,y)==0)
			{
				spanNeedFill=TRUE;
				x++;
			}
			if (spanNeedFill)
			{
				seed.setX(x-1);
				seed.setY(y);
				myStack.push_back(seed);
				spanNeedFill=FALSE;

			}
			while(region.pixelIndex(x,y)!=0 && x<xr) x++;
		}
		x=xl;
		y=y-2;
		while(x<xr)
		{
			spanNeedFill=FALSE;
			while (region.pixelIndex(x,y)==0)
			{
				spanNeedFill=TRUE;
				x++;
			}
			if (spanNeedFill)
			{
				seed.setX(x-1);
				seed.setY(y);
				myStack.push_back(seed);
				spanNeedFill=FALSE;

			}
			while(region.pixelIndex(x,y)!=0 && x<xr) x++;
		}
	}

	//uchar *pFill = region.bits();
	//const uchar *pEdge = edge.bits();
	//for(int yi=0; yi<h; yi++,pFill+=region.bytesPerLine(),pEdge+=edge.bytesPerLine())
	//{
	//	uchar *pF = pFill;
	//	const uchar *pE = pEdge;
	//	for (int xi=0; xi<w; xi++,pF++,pE++)	
	//	{
	//		if(pE[0]==0 && pF[0]==curcnt) pF[0] = 0;
	//		else if(pE[0]!=0) pF[0] = pE[0];
	//	}
	//}
}

QImage Papercut::renderToIndexImage()
{
	/// index fill to region
	QImage edge=QImage(m_width,m_height,QImage::Format_Indexed8);
	edge.fill(0);
	edge.setColor(255,qRgb(255,0,255));
	edge.setColor(128,qRgb(255,0,0));
	QImage dest = QImage(m_width,m_height,QImage::Format_RGB888);
	dest.fill(0);

	for(int k=0; k<m_boundary.size(); k++)
	{
		edge.fill(0);
		for (int j=0; j<m_boundary[k].size(); j++)
			edge.setPixel(m_boundary[k][j].x(),m_boundary[k][j].y(),255);

		QImage region = edge;
		QPoint seed = findSeed(edge,m_boundary[k]);
		fillRegion(edge,region,seed, k==0?255:128);

		int kk = k+1;
		QRgb clr = qRgb(kk/(256*256),(kk%(256*256))/256,kk%256);
		//int test = 13*256*256 + 4*256 + 47;
		//QRgb clrtest = qRgb(test/(256*256),(test%(256*256))/256,test%256);
		//int rr = qRed(clrtest);
		//int gg = qGreen(clrtest);
		//int bb = qBlue(clrtest);

		for (int yi=0; yi<dest.height(); yi++)
		{
			for(int xi=0; xi<dest.width(); xi++)
			{
				if(region.pixelIndex(xi,yi)==128 || 
					(edge.pixelIndex(xi,yi)==255 && k!=0) )
					dest.setPixel(xi,yi,clr);
				else if(region.pixelIndex(xi,yi)==255)
					dest.setPixel(xi,yi,clr);
			}
		}
	}
	return dest;
}

void Papercut::regionShift(int idx, QPoint sft)
{
	// need to rewrite
	if(idx<m_boundary.size())
		for (int k=0; k<m_boundary[idx].size(); k++)
			m_boundary[idx][k] += sft;
}

void Papercut::regionGroup(const std::vector<int> &group)
{
	const int newNode = m_tree.size();
	m_tree.push_back(0);

	for(int k=0; k<group.size(); k++)
	{
		m_tree[group[k]] = newNode;
	}
}