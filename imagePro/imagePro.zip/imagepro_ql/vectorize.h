#pragma once

#include <QImage>
#include <vector>
#include <QPoint>

//class region
//{
//public:
//	std::vector<QPoint> m_boundary;
//	int					fatherID;
//};

class Papercut
{
	// data structure
private:
	//QImage tmpImg;
	int		m_width;
	int		m_height;

public:
	std::vector<std::vector<QPoint> > m_boundary;	

	std::vector<int>	m_tree;

	// member functions
private:
	void getEdge(const QImage &src, QImage &dest, int thresVal);
	QPoint nextPoint(QPoint &pn, const QImage &src);
	void getBoundary(QPoint &startPnt, QImage &src, std::vector<QPoint> &vPnt);

	QPoint findSeed(const QImage &edge, const std::vector<QPoint> &vpn);
	void fillRegion(const QImage &edge, QImage &dest, QPoint seed, int curcnt);

public:
	Papercut();
	~Papercut();

	void convertFromImage(const QImage &src);
	QImage renderToIndexImage();

	void regionShift(int idx, QPoint sft);
	void regionGroup(const std::vector<int> &group);
};

