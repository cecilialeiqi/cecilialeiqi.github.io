#pragma once
#include "skeleton.h"
#include "vectorizationPaint.h"
#include <vectorizationWindow.h>
#include <fstream>

namespace skeleton{

void SkeletonGraph::clear()
{
	for(int k=0; k<m_vVertex.size();k++)
		for (int i=0; i<5; i++)
			m_vVertex[k].m_boundary[i].m_vPoint.clear();
	m_vVertex.clear();
	
	for(int k=0; k<m_vEdge.size(); k++)
		m_vEdge[k].m_vPoint.clear();
	m_vEdge.clear();
	
/*	for(int k=0; k<m_vvEdge42vertex.size(); k++)
		m_vvEdge42vertex[k].clear();
	m_vvEdge42vertex.clear();

	for(int k=0; k<m_vvEdgeContinuity.size(); k++)
		m_vvEdgeContinuity[k].clear();
	m_vvEdgeContinuity.clear();*/

	m_vVertex42edge.clear();
}

float Dist(float x1,float y1,float x2,float y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}

float Dist(QPointF a, QPointF b)
{
	return sqrt((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y()));
}

float Dist(QPointF a, Edge pos)
{
	float minDist=100;
	for (int i=0;i<pos.m_vPoint.size();i++)
	{
		if (Dist(a,pos.m_vPoint[i])<minDist)
		{
			minDist=Dist(a,pos.m_vPoint[i]);
		}
	}
	return minDist;
}
int SkeletonGraph::indexVertex(QPointF m_vertex,int minDist)
{
	int index=-1;
	for (int i=0;i<m_vVertex.size();i++)
	{
		if (Dist(m_vertex.x(),m_vertex.y(),m_vVertex[i].m_pos.x(),m_vVertex[i].m_pos.y())<minDist)
		{
			minDist=Dist(m_vertex.x(),m_vertex.y(),m_vVertex[i].m_pos.x(),m_vVertex[i].m_pos.y());
			index=i;
		}
	}
	return index;
}

float pixelValue(Edge &pos, QImage & m_image)
{
	int totalValue=0;
	for (int i=0;i<pos.m_vPoint.size();i++)
	{
		totalValue+=qRed(m_image.pixel(pos.m_vPoint[i].x(),pos.m_vPoint[i].y()));
	}
	return float(totalValue)/pos.m_vPoint.size();
}

Edge backwards(const Edge &pos)
{
	Edge newPos;
	for (int i=pos.m_vPoint.size()-1;i>=0;i--)
	{
		newPos.m_vPoint.push_back(pos.m_vPoint[i]);
	}
	return newPos;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}

void SkeletonGraph::globalRecord(QImage &m_record, int width)
{
	for (int j=0;j<m_vEdge.size();j++)
	{
		Edge pos=m_vEdge[j];
        for (int i=0;i<pos.m_vPoint.size();i++)
		{
			float px=pos.m_vPoint[i].x();
			float py=pos.m_vPoint[i].y();
			for (int xx=int(-width/2-0.5);xx<width/2+0.6;xx++)
				for (int yy=int(-width/2-0.5);yy<width/2+0.6;yy++)
					if (xx*xx+yy*yy<=width*width/4 && isInImage(int(px+xx+0.5),int(py+yy+0.5),m_record.width(),m_record.height()))
					{
						m_record.setPixel(int(px+xx+0.5),int(py+yy+0.5),0);
					}
		} 
	}
}
void smoothsingleEdge2(Edge &pos)
{
	int step=ceil(pos.m_vPoint.size()/20.0);
	int head=0;
	Edge newPos;
	for (int i=0;i<step;i++)
	{
	    double l=(pos.m_vPoint.size()-head-1)/(step-i);
		double a0,a1,a2;
		double b0,b1,b2;
		a0=pos.m_vPoint[head].x();		b0=pos.m_vPoint[head].y();
		if (head+l<pos.m_vPoint.size()-2)
		{
			a2=(pos.m_vPoint[head+l].x()+pos.m_vPoint[head+l-1].x()+pos.m_vPoint[int(head+l+1)].x())/3;
			b2=(pos.m_vPoint[head+l].y()+pos.m_vPoint[head+l-1].y()+pos.m_vPoint[head+l+1].y())/3;
		}else
		{
			a2=pos.m_vPoint[pos.m_vPoint.size()-1].x();
			b2=pos.m_vPoint[pos.m_vPoint.size()-1].y();
		}
		double dena,denb,numa,numb;
		numa=numb=dena=denb=0;
		for (int j=0;j<=l;j++)
		{
			numa+=j/l*(1-j/l)*(a0*pow(1-j/l,2)+a2*pow(j/l,2)-pos.m_vPoint[head+j].x());
			numb+=j/l*(1-j/l)*(b0*pow(1-j/l,2)+b2*pow(j/l,2)-pos.m_vPoint[head+j].y());
			dena+=pow(j/l,2)*pow(1-j/l,2);
		}
		a1=-numa/dena;
		b1=-numb/dena;
		l+=5;
		for (int j=0;j<l;j++)
		{
			newPos.m_vPoint.push_back(QPointF(a0*pow(1-j/l,2)+a1*(1-j/l)*j/l+a2*pow(j/l,2),b0*pow(1-j/l,2)+b1*(1-j/l)*j/l+b2*pow(j/l,2)));
		}
		l-=5;
		head=head+l;
	}
	newPos.m_vPoint.push_back(pos.m_vPoint[pos.m_vPoint.size()-1]);
	pos=newPos;
}
void SkeletonGraph::deleteEdge(QImage &m_image)
{
	/////////////////////////////////////////////////////////////////
	/////����˼·������������յ���ͬ��ɾ��һ��ƫ��
	/////////////////////////////////////////////////////////////////
	for (int i=0;i<m_vEdge.size();i++)
	{
		int index1=m_vVertex42edge[i*2];
		int index2=m_vVertex42edge[i*2+1];
		if (index1==index2)
		{
			vector<QPointF> tmpEdge=m_vEdge[i].m_vPoint;
			float tangx1=tmpEdge[6].x()-tmpEdge[0].x();
			float tangy1=tmpEdge[6].y()-tmpEdge[0].y();
			float tangx2=tmpEdge[tmpEdge.size()-7].x()-tmpEdge[tmpEdge.size()-1].x();
			float tangy2=tmpEdge[tmpEdge.size()-7].y()-tmpEdge[tmpEdge.size()-1].y();
			if ((tangx1*tangx2+tangy1*tangy2)/Dist(tangx1,tangy1,0,0)/Dist(tangx2,tangy2,0,0)>cos(60.0*3.14/180.0))
			{
				//find fareast point
				float maxDist=0;
				int recordP;
				for (int p=1;p<tmpEdge.size()-1;p++)
					if (Dist(tmpEdge[0],tmpEdge[p])>maxDist)
					{
						maxDist=Dist(tmpEdge[0],tmpEdge[p]);
						recordP=p;
					}
				while (tmpEdge.size()>recordP+1)
					tmpEdge.pop_back();
				m_vEdge[i].m_vPoint=tmpEdge;
				smoothsingleEdge2(m_vEdge[i]);
				m_vVertex.push_back(skeleton::Vertex(tmpEdge[tmpEdge.size()-1],false));
				m_vVertex[m_vVertex.size()-1].m_index[0]=i;
				m_vVertex[m_vVertex.size()-1].m_direction[0]=QPointF(tangx1,tangy1);
			}
		}

		for (int j=i+1;j<m_vEdge.size();j++)
		{
			if (m_vVertex42edge[i*2]==m_vVertex42edge[j*2] && m_vVertex42edge[i*2+1]==m_vVertex42edge[j*2+1])
			{
				int head=m_vVertex42edge[i*2];
				int tail=m_vVertex42edge[i*2+1];
				//�����߶˵�һ��,����ж����ǱȽ��غ��أ�
				int cnt=0;
				int cnt_i=0;
				int cnt_j=0;
				float dist=0;
				while(cnt_i<m_vEdge[i].m_vPoint.size()-1 && cnt_j<m_vEdge[j].m_vPoint.size()-1)
				{
					cnt++;
					dist+=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y());
					cnt_i++;
					if (cnt_j>=m_vEdge[j].m_vPoint.size()-1)
						break;
					while (Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y())
						>=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j+1].x(),m_vEdge[j].m_vPoint[cnt_j+1].y()))
					{
						cnt_j++;
     					if (cnt_j>=m_vEdge[j].m_vPoint.size()-1)
							break;
					}
				}
				dist/=cnt;
				if (dist<3)//ƽ������С���������أ�������ͬһ���߰�
				{
					//ɾȥһ���Ƚ�ƫ�ģ�ɾȥ̫�鷳����������ֲ��࣬�Ѳ��õ������ĳ�һ���ĺ���
					float value1=pixelValue(m_vEdge[i],m_image);
					float value2=pixelValue(m_vEdge[j],m_image);
					int recordedge=i;
					if (value1>value2)//��i���߱ȽϺã�
					{
						recordedge=j;
					}
					deleteSingleEdge(recordedge);
				}
			}
			if (m_vVertex42edge[i*2+1]==m_vVertex42edge[j*2] && m_vVertex42edge[i*2]==m_vVertex42edge[j*2+1])
			{
				int head=m_vVertex42edge[i*2];
				int tail=m_vVertex42edge[i*2+1];
				//�����߶˵�һ��,����ж����ǱȽ��غ��أ�
				int cnt=0;
				int cnt_i=0;
				int cnt_j=m_vEdge[j].m_vPoint.size()-1;
				float dist=0;
				while(cnt_i<m_vEdge[i].m_vPoint.size()-1 && cnt_j>1)
				{
					cnt++;
					dist+=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y());
					cnt_i++;
					if (cnt_j<=1)
						break;
					while (Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y())
						>=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j-1].x(),m_vEdge[j].m_vPoint[cnt_j-1].y()))
					{
						cnt_j--;
     					if (cnt_j<=1)
							break;
					}
				}
				dist/=cnt;
				if (dist<3)//ƽ������С���������أ�������ͬһ���߰�
				{
					//ɾȥһ���Ƚ�ƫ�ģ�ɾȥ̫�鷳����������ֲ��࣬�Ѳ��õ������ĳ�һ���ĺ���
					float value1=pixelValue(m_vEdge[i],m_image);
					float value2=pixelValue(m_vEdge[j],m_image);
					int recordedge=i;
					if (value1>value2)//��i���߱ȽϺã�
					{
						recordedge=j;
					}
					deleteSingleEdge(recordedge);
				}
			}
		}
	}

	for (int i=0;i<m_vEdge.size();i++)
	{
		if (m_vEdge[i].m_vPoint.size()<8)
		{
			deleteSingleEdge(i);
		}
		if (m_vEdge[i].m_vPoint.size()<25)
		{
			int index1=m_vVertex42edge[i*2];
			int index2=m_vVertex42edge[i*2+1];
			if (m_vVertex[index1].m_k==1 && m_vVertex[index2].m_k==1)
				deleteSingleEdge(i);
		}
	}
}

void SkeletonGraph::deleteSingleEdge(int recordedge)//index[0],[1]�Ƕ����ţ�recordedge�Ǳߵı��
{
	float index[2];
	index[0]=m_vVertex42edge[recordedge*2];
	index[1]=m_vVertex42edge[recordedge*2+1];
	for (int p=0;p<2;p++)
	{
		for (int k=0;k<m_vVertex[index[p]].m_k;k++)
		{
			if (m_vVertex[index[p]].m_index[k]==recordedge)
			{
				for (int t=k;t<m_vVertex[index[p]].m_k-1;t++)
				{
					m_vVertex[index[p]].m_index[t]=m_vVertex[index[p]].m_index[t+1];
					m_vVertex[index[p]].m_direction[t]=m_vVertex[index[p]].m_direction[t+1];
					for (int s=0;s<5;s++)
					{
						m_vVertex[index[p]].m_smooth[t][s]=m_vVertex[index[p]].m_smooth[t+1][s];
						m_vVertex[index[p]].m_smooth[s][t]=m_vVertex[index[p]].m_smooth[s][t+1];
					}
				}
				m_vVertex[index[p]].m_k--;//������һ��Ȧ��
			}
		}
	}
	m_vEdge[recordedge].m_vPoint.clear();
}

void SkeletonGraph::addEdge(vector<QPointF> interEdge)
{
	if (interEdge.size()<2)
		return;
	int index1=indexVertex(interEdge[0],m_maxWidth);
	int index2=indexVertex(interEdge[interEdge.size()-1],m_maxWidth);
	int k=0;
	if (index1>-1)
	{
		interEdge[0]=m_vVertex[index1].m_pos;
		k=m_vVertex[index1].m_k;
		m_vVertex[index1].m_k++;
	}
	else
	{
		index1=m_vVertex.size();
		m_vVertex.push_back(Vertex(interEdge[0],false));
	}
	float tangx=interEdge[2].x()-interEdge[0].x();
	float tangy=interEdge[2].y()-interEdge[0].y();
	float dist=Dist(tangx,tangy,0,0);
	m_vVertex[index1].m_direction[k]=QPointF(tangx*m_vVertex[index1].m_width/8/dist,tangy*m_vVertex[index1].m_width/8/dist);
	m_vVertex[m_vVertex.size()-1].m_index[k]=m_vEdge.size();
	k=0;
	if (index2>-1)
	{
		if (interEdge.size()%2==1)
			interEdge[interEdge.size()-1]=m_vVertex[index2].m_pos;
		else
			interEdge.push_back(m_vVertex[index2].m_pos);

		k=m_vVertex[index2].m_k;
		m_vVertex[index2].m_k++;
	}
	else
	{
		if (interEdge.size()%2==0)
		{
			interEdge.push_back(interEdge[interEdge.size()-1]);
		}
		index2=m_vVertex.size();
		m_vVertex.push_back(Vertex(interEdge[interEdge.size()-1],false));
	}
	tangx=interEdge[interEdge.size()-3].x()-interEdge[interEdge.size()-1].x();
	tangy=interEdge[interEdge.size()-3].y()-interEdge[interEdge.size()-1].y();
	dist=Dist(tangx,tangy,0,0);
	m_vVertex[index2].m_direction[k]=QPointF(tangx*m_vVertex[index2].m_width/8/dist,tangy*m_vVertex[index2].m_width/8/dist);
	m_vVertex[m_vVertex.size()-1].m_index[k]=m_vEdge.size();

	Edge pos;
	for (int i=0;i<interEdge.size()-1;i+=2)
	{
		int l=Dist(interEdge[i+2],interEdge[i])+0.5;
		float x1=interEdge[i].x();
		float y1=interEdge[i].y();
		float x2=interEdge[i+2].x();
		float y2=interEdge[i+2].y();
		float a1=x1;
		float c1=x2;
		float a2=y1;
		float c2=y2;
		float b1=interEdge[i+1].x();
		float b2=interEdge[i+1].y();
		for (int k=0;k<=l;k++)
		{
			float t=float(k)/l;
			pos.m_vPoint.push_back(QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t));
		}
		
	}
	m_vEdge.push_back(pos);
	m_vVertex42edge.push_back(index1);
	m_vVertex42edge.push_back(index2);

}
void SkeletonGraph::junctionAdjust()
{
	for (int i=0;i<m_vVertex.size();i++)
	{
		for (int j=0;j<m_vVertex[i].m_k;j++)
		{
			cout<<i<<':'<<m_vVertex[i].m_pos.x()<<','<<m_vVertex[i].m_pos.y()<<'-'
				<<m_vVertex[i].m_direction[j].x()<<','<<m_vVertex[i].m_direction[j].y()<<'-'<<m_vVertex[i].m_index[j]<<endl;
			for (int k=j+1;k<m_vVertex[i].m_k;k++)
			{
				if (m_vVertex[i].m_smooth[j][k])
				{
					cout<<m_vVertex[i].m_index[j]<<','<<m_vVertex[i].m_index[k]<<endl;
				}
			}
		}
		cout<<endl;
	}
}

bool checkSmooth(QPointF tang1, QPointF tang2, int angle)
{
	return (tang1.x()*tang2.x()+tang1.y()*tang2.y())/Dist(tang1.x(),tang1.y(),0,0)/Dist(tang2.x(),tang2.y(),0,0)<cos(3.14*angle/180);//�нǴ���150��
}

bool findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS, QImage &m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(xx-tangy+0.5),int(yy+tangx+0.5))))
			{
				distMax = k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)//
			break;
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����������Ӧ��ͨ���ж�����֤��ʱ�����ұ߽粻��ʹ��
	{
		return false;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
		if (qRed(m_image.pixel(stepPos[0]-2*tangy,stepPos[1]+2*tangx))>50)///////˵���߽绹����Щ����ɣ��п�����������·���һ������
			flag=true;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(0.5+xx+tangy),int(0.5+yy-tangx))))
			{
				distMax = -k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)
			break;
	}
	if (flag)
	{
		return false;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
		if (qRed(m_image.pixel(stepPos[4]+2*tangy,stepPos[5]-2*tangx))>50)
			return false;
	}
	return true;
}
int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

void bilinear(float &tangx, float &tangy, float seedx, float seedy, int w, int h,float * flow)
{
	float prevTangx=tangx;
	float prevTangy=tangy;
	int x1=floor(seedx);
	int x2=ceil(seedx);
	int y1=floor(seedy);
	int y2=ceil(seedy);
	float x=seedx-x1;
	float y=seedy-y1;
	const float *fseed0 = getDirection(w,h,4,flow,x1,y1);
	float tangx1=fseed0[1];
	float tangy1=-fseed0[0];
	float dist=sqrt(tangx1*tangx1+tangy1*tangy1);
	tangx1=tangx1/dist;
	tangy1=tangy1/dist;
	const float *fseed1=getDirection(w,h,4,flow,x2,y1);
	float tangx2=fseed1[1];
	float tangy2=-fseed1[0];
	dist=sqrt(tangx2*tangx2+tangy2*tangy2);
	tangx2/=dist;
	tangy2/=dist;
	const float *fseed2=getDirection(w,h,4,flow,x1,y2);
	float tangx3=fseed2[1];
	float tangy3=-fseed2[0];
	dist=sqrt(tangx3*tangx3+tangy3*tangy3);
	tangx3/=dist;
	tangy3/=dist;
	const float *fseed3=getDirection(w,h,4,flow,x2,y2);
	float tangx4=fseed3[1];
	float tangy4=-fseed3[0];
	//��ԭ����һ�£���Ҫ�㷴��
	if (tangx1*prevTangx + tangy1*prevTangy<0.0)
	{
		tangx1 = -tangx1;
		tangy1 = -tangy1;
	}
	if (tangx2*prevTangx + tangy2*prevTangy<0.0)
	{
		tangx2 = -tangx2;
		tangy2 = -tangy2;
	}
	if (tangx3*prevTangx + tangy3*prevTangy<0.0)
	{
		tangx3 = -tangx3;
		tangy3 = -tangy3;
	}
	if (tangx4*prevTangx + tangy4*prevTangy<0.0)
	{
		tangx4 = -tangx4;
		tangy4 = -tangy4;
	}
	tangx=tangx1*(1-x)*(1-y)+tangx2*x*(1-y)+tangx3*(1-x)*y+tangx4*x*y;
	tangy=tangy1*(1-x)*(1-y)+tangy2*x*(1-y)+tangy3*(1-x)*y+tangy4*x*y;
}

void rongeDirection(float &seedx,float &seedy, float &prevTangx, float &prevTangy, int w, int h, float * flow)
{
	bilinear(prevTangx,prevTangy,seedx,seedy,w,h,flow);
	float dist=Dist(prevTangx,prevTangy,0,0);
	prevTangx/=dist;
	prevTangy/=dist;
	bilinear(prevTangx,prevTangy,seedx+prevTangx/2,seedy+prevTangy/2,w,h,flow);
	dist=Dist(prevTangx,prevTangy,0,0);
	prevTangx/=dist;
	prevTangy/=dist;
	seedx+=prevTangx;
	seedy+=prevTangy;
}

void smoothsingleEdge(Edge &pos)
{
	vector<QPointF> tmpEdge=pos.m_vPoint;
	pos.m_vPoint[1]=QPointF((tmpEdge[0].x()+tmpEdge[1].x()+tmpEdge[2].x())/3,
		(tmpEdge[0].y()+tmpEdge[1].y()+tmpEdge[2].y())/3);
	for (int j=2;j<pos.m_vPoint.size()-2;j++)
	{
		if (j<15||j>pos.m_vPoint.size()-16)
		pos.m_vPoint[j]=QPointF((tmpEdge[j-2].x()+tmpEdge[j-1].x()+tmpEdge[j].x()+tmpEdge[j+1].x()+tmpEdge[j+2].x())/5,
			(tmpEdge[j-2].y()+tmpEdge[j-1].y()+tmpEdge[j].y()+tmpEdge[j+1].y()+tmpEdge[j+2].y())/5);
		else
			pos.m_vPoint[j]=tmpEdge[j];
	}
	pos.m_vPoint[tmpEdge.size()-2]=QPointF((tmpEdge[tmpEdge.size()-3].x()+tmpEdge[tmpEdge.size()-2].x()+tmpEdge[tmpEdge.size()-1].x())/3,
		(tmpEdge[tmpEdge.size()-3].y()+tmpEdge[tmpEdge.size()-2].y()+tmpEdge[tmpEdge.size()-1].y())/3);
	tmpEdge.clear();
	tmpEdge.push_back(pos.m_vPoint[0]);
	for (int j=1;j<pos.m_vPoint.size();j++)
	{
		while(Dist(pos.m_vPoint[j],tmpEdge[tmpEdge.size()-1])<0.6 && j<pos.m_vPoint.size()-1)
			j++;
		tmpEdge.push_back(pos.m_vPoint[j]);
	}
	tmpEdge.push_back(pos.m_vPoint[pos.m_vPoint.size()-1]);
	pos.m_vPoint=tmpEdge;
}


bool judgeSmooth(Edge pos,int angle, int w,int h, QPointF seed, float *flow, QImage &m_image)
{
	smoothsingleEdge2(pos);
	float maxcos[10];
	float a11,a12,a21,a22,b1,b2;
	a11=a12=a21=a22=b1=b2=0;
	int recordI=0;
	float minDist=100;
	for (int i=0;i<pos.m_vPoint.size();i++)
	{
		if (Dist(pos.m_vPoint[i],seed)<minDist)
		{
			recordI=i;
			minDist=Dist(pos.m_vPoint[i],seed);
		}
	}
	if (recordI<2||recordI>pos.m_vPoint.size()-3)
		return false;
	for (int t=5;t<min(14,pos.m_vPoint.size()/2-1);t++)/////////////////////////////////////
	{
		a11+=t*t;
		a12+=t;
		a22++;
		//maxcos[t-3]=-1;
		//for (int j=0;j<pos.m_vPoint.size()-t*2;j++)
		{
			float x1=pos.m_vPoint[recordI+2].x()-pos.m_vPoint[min(recordI+t,pos.m_vPoint.size()-1)].x();
			float y1=pos.m_vPoint[recordI+2].y()-pos.m_vPoint[min(recordI+t,pos.m_vPoint.size()-1)].y();
			float x2=pos.m_vPoint[recordI-2].x()-pos.m_vPoint[max(0,recordI-t)].x();
			float y2=pos.m_vPoint[recordI-2].y()-pos.m_vPoint[max(0,recordI-t)].y();
			float cosine=(x1*x2+y1*y2)/Dist(x1,y1,0,0)/Dist(x2,y2,0,0);
			//if (cosine>maxcos[t-3])
				maxcos[t-5]=cosine;
		}
		
		b1+=float(t)*maxcos[t-5];
		b2+=maxcos[t-5];
	}
	a21=a12;
	float det=a11*a22-a12*a21;
	float a=(a22*b1-a12*b2)/det;
	float b=(-a12*b1+a11*b2)/det;
	if (a*4+b<cos(3.14*angle/180))
	{
		return true;
	}else
	{
		return false;
	}

}

////////////////////true�����ǵķ�����false��ԭ���׵ķ���
void SkeletonGraph::smoothSet(bool original,int w, int h, float *flow, QImage & m_image)
{
	
	for (int i=0;i<m_vVertex.size();i++)///ÿ���㷢�����߶�֮���������
	{
		if (original)
		{
			/////������
			for (int k=0;k<m_vVertex[i].m_k;k++)
			{
				for (int j=k+1;j<m_vVertex[i].m_k;j++)
				{
					m_vVertex[i].m_smooth[k][j]=false;
					m_vVertex[i].m_smooth[j][k]=false;
					if (atan2(m_vVertex[i].m_direction[k].y(),m_vVertex[i].m_direction[k].x())
						<atan2(m_vVertex[i].m_direction[j].y(),m_vVertex[i].m_direction[j].x()))
					{
						float tmp=m_vVertex[i].m_index[k];
						m_vVertex[i].m_index[k]=m_vVertex[i].m_index[j];
						m_vVertex[i].m_index[j]=tmp;
						QPointF tmpPos=m_vVertex[i].m_direction[k];
						m_vVertex[i].m_direction[k]=m_vVertex[i].m_direction[j];
						m_vVertex[i].m_direction[j]=tmpPos;
					}
				}
			}
			switch(m_vVertex[i].m_k)
			{
			case 2:
				{
					Edge pos0=m_vEdge[m_vVertex[i].m_index[0]];
					if (pos0.m_vPoint.size()<6) 
						continue;
					if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos0=backwards(pos0);
					}
					float seedx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].x();
					float seedy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].y();
					float tangx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].x()-seedx;
					float tangy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].y()-seedy;
					float dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					float leftx=seedx-3*tangy;
					float lefty=seedy+3*tangx;
					Edge pos;
					for (int t=0;t<min(13,pos0.m_vPoint.size()-1)+10;t++)
					{
						rongeDirection(leftx,lefty,tangx,tangy,w,h,flow);
						pos.m_vPoint.push_back(QPointF(leftx,lefty));
						if (!isInImage(leftx+tangx,lefty+tangy,w,h))
							break;
					}
					m_vVertex[i].m_smooth[0][1]=judgeSmooth(pos,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
					m_vVertex[i].m_smooth[1][0]=m_vVertex[i].m_smooth[0][1];
					m_vVertex[i].m_boundary[0]=pos;
					break;
				}

			case 3:
				{
					Edge pos0=m_vEdge[m_vVertex[i].m_index[0]];
					Edge pos1=m_vEdge[m_vVertex[i].m_index[1]];
					Edge pos2=m_vEdge[m_vVertex[i].m_index[2]];
					if (pos0.m_vPoint.size()<6) 
						continue;
					if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos0=backwards(pos0);
					}
					if (pos1.m_vPoint.size()<6) 
						continue;
					if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos1=backwards(pos1);
					}
					if (pos2.m_vPoint.size()<6) 
						continue;
					if (Dist(pos2.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos2=backwards(pos2);
					}
					int l0=min(max(15,pos0.m_vPoint.size()/2+2),pos0.m_vPoint.size()-1);
					float seedx=pos0.m_vPoint[l0].x();
					float seedy=pos0.m_vPoint[l0].y();
					float tangx=pos0.m_vPoint[l0-2].x()-seedx;
					float tangy=pos0.m_vPoint[l0-2].y()-seedy;
					float dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					float leftx=seedx-3*tangy;
					float lefty=seedy+3*tangx;
					float rightx=seedx+3*tangy;
					float righty=seedy-3*tangx;
					Edge posl,posr;
					for (int t=0;t<l0+10;t++)
					{
						rongeDirection(leftx,lefty,tangx,tangy,w,h,flow);
						posl.m_vPoint.push_back(QPointF(leftx,lefty));
						if (!isInImage(leftx+tangx,lefty+tangy,w,h))
							break;
					}
					tangx=pos0.m_vPoint[l0-2].x()-seedx;
					tangy=pos0.m_vPoint[l0-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					for (int t=0;t<l0+10;t++)
					{
						rongeDirection(rightx,righty,tangx,tangy,w,h,flow);
						posr.m_vPoint.push_back(QPointF(rightx,righty));
						if (!isInImage(rightx+tangx,righty+tangy,w,h))
							break;
					}
					
					if (Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos1.m_vPoint[7])<
						Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos2.m_vPoint[7]))
					{
						m_vVertex[i].m_smooth[0][1]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][0]=m_vVertex[i].m_smooth[0][1];
						m_vVertex[i].m_boundSmooth[0]=m_vVertex[i].m_smooth[0][1];
						m_vVertex[i].m_smooth[0][2]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[2][0]=m_vVertex[i].m_smooth[0][2];
						m_vVertex[i].m_boundary[0]=posl;
						m_vVertex[i].m_boundary[2]=posr;
					}else
					{
						m_vVertex[i].m_smooth[0][2]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[2][0]=m_vVertex[i].m_smooth[0][2];
						m_vVertex[i].m_smooth[0][1]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][0]=m_vVertex[i].m_smooth[0][1];
						m_vVertex[i].m_boundary[2]=posl;
						m_vVertex[i].m_boundary[0]=posr;
					}
					int l1=min(max(15,pos1.m_vPoint.size()/2+2),pos1.m_vPoint.size()-1);
					seedx=pos1.m_vPoint[l1].x();
					seedy=pos1.m_vPoint[l1].y();
					tangx=pos1.m_vPoint[l1-2].x()-seedx;
					tangy=pos1.m_vPoint[l1-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					posl.m_vPoint.clear();
					leftx=seedx-3*tangy;
					lefty=seedy+3*tangx;
					rightx=seedx+3*tangy;
					righty=seedy-3*tangx;
					for (int t=0;t<l1+10;t++)
					{
						rongeDirection(leftx,lefty,tangx,tangy,w,h,flow);
						posl.m_vPoint.push_back(QPointF(leftx,lefty));
						if (!isInImage(leftx+tangx,lefty+tangy,w,h))
							break;
					}
					if (Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos2.m_vPoint[7])>
						Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos0.m_vPoint[7]))
					{
						posl.m_vPoint.clear();
						tangx=pos1.m_vPoint[l1-2].x()-seedx;
						tangy=pos1.m_vPoint[l1-2].y()-seedy;
						float dist=Dist(tangx,tangy,0,0);
						tangx/=dist;
						tangy/=dist;
						for (int t=0;t<l1+10;t++)
						{
							rongeDirection(rightx,righty,tangx,tangy,w,h,flow);
							posl.m_vPoint.push_back(QPointF(rightx,righty));
							if (!isInImage(rightx+tangx,righty+tangy,w,h))
								break;
						}
					}
					m_vVertex[i].m_boundary[1]=posl;
					tangx=pos1.m_vPoint[l1-2].x()-seedx;
					tangy=pos1.m_vPoint[l1-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					m_vVertex[i].m_smooth[1][2]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
					m_vVertex[i].m_smooth[2][1]=m_vVertex[i].m_smooth[1][2];
					m_vVertex[i].m_boundSmooth[2]=m_vVertex[i].m_smooth[1][2];
					break;
				}
			case 4:
				{

					///�����������ֱ�������������߽��߿��������ж�
					Edge pos0=m_vEdge[m_vVertex[i].m_index[0]];
					Edge pos1=m_vEdge[m_vVertex[i].m_index[1]];
					Edge pos2=m_vEdge[m_vVertex[i].m_index[2]];
					Edge pos3=m_vEdge[m_vVertex[i].m_index[3]];
					if (pos0.m_vPoint.size()<6) 
						continue;
					if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos0=backwards(pos0);
					}
					if (pos1.m_vPoint.size()<6) 
						continue;					
					if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos1=backwards(pos1);
					}
					if (pos2.m_vPoint.size()<6) 
						continue;
					if (Dist(pos2.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos2=backwards(pos2);
					}
					if (pos3.m_vPoint.size()<6) 
						continue;
					if (Dist(pos3.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos3.m_vPoint[pos3.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos3=backwards(pos3);
					}


					////////////////////////////////////////////////////////////////////////////
					Edge pos;/////���ж϶��������ߵĹ⻬��
					for (int j=min(13,pos0.m_vPoint.size()-1);j>=0;j--)
						pos.m_vPoint.push_back(pos0.m_vPoint[j]);
					for (int j=0;j<min(13,pos2.m_vPoint.size()-1);j++)
						pos.m_vPoint.push_back(pos2.m_vPoint[j]);
					float tangx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].x()-pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].x();
					float tangy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].y()-pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].y();
					float dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					m_vVertex[i].m_smooth[0][2]=judgeSmooth(pos,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
					m_vVertex[i].m_smooth[2][0]=m_vVertex[i].m_smooth[0][2];

					pos.m_vPoint.clear();
					for (int j=min(13,pos1.m_vPoint.size()-1);j>=0;j--)
						pos.m_vPoint.push_back(pos1.m_vPoint[j]);
					for (int j=1;j<min(13,pos3.m_vPoint.size()-1);j++)
						pos.m_vPoint.push_back(pos3.m_vPoint[j]);
					tangx=pos1.m_vPoint[min(13,pos1.m_vPoint.size()-1)-2].x()-pos1.m_vPoint[min(13,pos1.m_vPoint.size()-1)].x();
					tangy=pos1.m_vPoint[min(13,pos1.m_vPoint.size()-1)-2].y()-pos1.m_vPoint[min(13,pos1.m_vPoint.size()-1)].y();
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					m_vVertex[i].m_smooth[1][3]=judgeSmooth(pos,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
					m_vVertex[i].m_smooth[3][1]=m_vVertex[i].m_smooth[1][3];
					///////////////////////////////////////////////////////////////////////////////

					float seedx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].x();
					float seedy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)].y();
					tangx=pos0.m_vPoint[min(13,pos1.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos0.m_vPoint[min(13,pos1.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					Edge posl,posr;
					float leftx=seedx-tangy*3;
					float lefty=seedy+tangx*3;
					float rightx=seedx+tangy*3;
					float righty=seedy-tangx*3;
					for (int t=0;t<min(13,pos0.m_vPoint.size()-1)+10;t++)
					{
						rongeDirection(leftx,lefty,tangx,tangy,w,h,flow);
						posl.m_vPoint.push_back(QPointF(leftx,lefty));
						if (!isInImage(leftx+tangx,lefty+tangy,w,h))
							break;
					}
					tangx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					for (int t=0;t<min(13,pos0.m_vPoint.size()-1)+10;t++)
					{
						rongeDirection(rightx,righty,tangx,tangy,w,h,flow);
						posr.m_vPoint.push_back(QPointF(rightx,righty));
						if (!isInImage(rightx+tangx,righty+tangy,w,h))
							break;
					}
					
					tangx=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos0.m_vPoint[min(13,pos0.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					if (Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos1.m_vPoint[7])
						<Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos3.m_vPoint[7]))
					{
						m_vVertex[i].m_smooth[0][1]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][0]=m_vVertex[i].m_smooth[0][1];
						m_vVertex[i].m_smooth[0][3]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[3][0]=m_vVertex[i].m_smooth[0][3];
						m_vVertex[i].m_boundary[0]=posl;
						m_vVertex[i].m_boundary[3]=posr;
					}else
					{
						m_vVertex[i].m_smooth[0][3]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[3][0]=m_vVertex[i].m_smooth[0][3];
						m_vVertex[i].m_smooth[0][1]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][0]=m_vVertex[i].m_smooth[0][1];
						m_vVertex[i].m_boundary[3]=posl;
						m_vVertex[i].m_boundary[0]=posr;
					}

					/////////////////////////////////////////////////////////////////////////////////
					seedx=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)].x();
					seedy=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)].y();
					tangx=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					posl.m_vPoint.clear();
					leftx=seedx-tangy*3;
					lefty=seedy+tangx*3;
					rightx=seedx+tangy*3;
					righty=seedy-tangx*3;
					for (int t=0;t<min(13,pos2.m_vPoint.size()-1)+10;t++)
					{
						rongeDirection(leftx,lefty,tangx,tangy,w,h,flow);
						posl.m_vPoint.push_back(QPointF(leftx,lefty));
						if (!isInImage(leftx+tangx,lefty+tangy,w,h))
							break;
					}
					tangx=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					posr.m_vPoint.clear();
					for (int t=0;t<min(13,pos2.m_vPoint.size()-1)+10;t++)
					{
						rongeDirection(rightx,righty,tangx,tangy,w,h,flow);
						posr.m_vPoint.push_back(QPointF(rightx,righty));
						if (!isInImage(rightx+tangx,righty+tangy,w,h))
							break;
					}
					

					tangx=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].x()-seedx;
					tangy=pos2.m_vPoint[min(13,pos2.m_vPoint.size()-1)-2].y()-seedy;
					dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;

					if (Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos1.m_vPoint[7])
						<Dist(posl.m_vPoint[posl.m_vPoint.size()-1],pos3.m_vPoint[7]))
					{
						m_vVertex[i].m_smooth[2][1]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][2]=m_vVertex[i].m_smooth[2][1];
						m_vVertex[i].m_smooth[2][3]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[3][2]=m_vVertex[i].m_smooth[2][3];
						m_vVertex[i].m_boundary[1]=posl;
						m_vVertex[i].m_boundary[2]=posr;
					}else
					{
						m_vVertex[i].m_smooth[2][3]=judgeSmooth(posl,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[3][2]=m_vVertex[i].m_smooth[2][3];
						m_vVertex[i].m_smooth[2][1]=judgeSmooth(posr,m_angleSmooth,w,h,m_vVertex[i].m_pos,flow,m_image);
						m_vVertex[i].m_smooth[1][2]=m_vVertex[i].m_smooth[2][1];
						m_vVertex[i].m_boundary[2]=posl;
						m_vVertex[i].m_boundary[1]=posr;
					}
					
					break;
				}
			default:
				break;
			}
			for (int j=0;j<m_vVertex[i].m_k-1;j++)
			{
				for (int k=j+1;k<m_vVertex[i].m_k;k++)
				{
					Edge pos;
					Edge pos0=m_vEdge[m_vVertex[i].m_index[j]];
					Edge pos1=m_vEdge[m_vVertex[i].m_index[k]];
					if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos0=backwards(pos0);
					}
					if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)
						>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
					{
						pos1=backwards(pos1);
					}
					for (int t=8;t>=0;t--)
						pos.m_vPoint.push_back(pos0.m_vPoint[t]);
					for (int t=1;t<9;t++)
						pos.m_vPoint.push_back(pos1.m_vPoint[t]);
					float tangx=-m_vVertex[i].m_direction[j].x();
					float tangy=-m_vVertex[i].m_direction[j].y();
					m_vVertex[i].m_smooth[j][k]=m_vVertex[i].m_smooth[j][k]&&judgeSmooth(pos,120,w,h,m_vVertex[i].m_pos,flow,m_image);
					m_vVertex[i].m_smooth[k][j]=m_vVertex[i].m_smooth[j][k];
				}
			}
			for (int j=0;j<m_vVertex[i].m_k;j++)
				m_vVertex[i].m_boundSmooth[j]=m_vVertex[i].m_smooth[j][(j+1)%m_vVertex[i].m_k];
		}
		else///ԭ���׵ķ���
		{
			for (int j=0;j<m_vVertex[i].m_k-1;j++)
			{
				m_vVertex[i].m_smooth[j][j]=false;
				for (int k=j+1;k<m_vVertex[i].m_k;k++)
				{
					m_vVertex[i].m_smooth[j][k]=checkSmooth(m_vVertex[i].m_direction[j],m_vVertex[i].m_direction[k],m_angleSmooth);
					m_vVertex[i].m_smooth[k][j]=m_vVertex[i].m_smooth[j][k];
				}
			}
		}
	}
}

void local2lineSmooth(Edge & pos0,Edge & pos1)//Bezier�������
{
	if (pos0.m_vPoint.size()<9||pos1.m_vPoint.size()<9)
		return;
	float x1=pos0.m_vPoint[8].x();
	float y1=pos0.m_vPoint[8].y();
	float x2=pos1.m_vPoint[8].x();
	float y2=pos1.m_vPoint[8].y();
	float a1=x1;
	float c1=x2;
	float a2=y1;
	float c2=y2;
	float b1=pos0.m_vPoint[0].x();
	float b2=pos0.m_vPoint[0].y();
	Edge newPos;
	float mindist=100;
	for (int i=0;i<18;i++)
	{
		float t=float(i)/17;
		newPos.m_vPoint.push_back(QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t));
	}
	for (int i=0;i<=8;i++)
	{
		pos0.m_vPoint[i]=newPos.m_vPoint[8-i];
		pos1.m_vPoint[i]=newPos.m_vPoint[8+i];
	}

}

void SkeletonGraph::smoothAdjust3_1(int i, int index1,int index2)//
{
	Edge pos0=m_vEdge[m_vVertex[i].m_index[index1]];
	if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
		>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos0=backwards(pos0);
	}
	Edge pos1=m_vEdge[m_vVertex[i].m_index[index2]];
	if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)
		>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos1=backwards(pos1);
	}
	local2lineSmooth(pos0,pos1);
	m_vEdge[m_vVertex[i].m_index[index1]]=pos0;
	m_vEdge[m_vVertex[i].m_index[index2]]=pos1;

}

void SkeletonGraph::smoothAdjust3_2(int i,int index, int index1, int index2)
{
	Edge pos0=m_vEdge[m_vVertex[i].m_index[index1]];
	Edge pos1=m_vEdge[m_vVertex[i].m_index[index2]];
	Edge pos=m_vEdge[m_vVertex[i].m_index[index]];
	if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)
		>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos0=backwards(pos0);
	}
	if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)
		>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos1=backwards(pos1);
	}
	if (Dist(pos.m_vPoint[0],m_vVertex[i].m_pos)
		>Dist(pos.m_vPoint[pos.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos=backwards(pos);
	}
	if (pos0.m_vPoint.size()<9||pos1.m_vPoint.size()<9||pos.m_vPoint.size()<7)
		return;
	float x1=pos0.m_vPoint[8].x();
	float y1=pos0.m_vPoint[8].y();
	float x2=pos.m_vPoint[6].x();
	float y2=pos.m_vPoint[6].y();
	m_vVertex[i].m_pos=pos.m_vPoint[6];
	float a1=x1;
	float c1=x2;
	float a2=y1;
	float c2=y2;
	float b1=pos0.m_vPoint[0].x();
	float b2=pos0.m_vPoint[0].y();
	pos0=backwards(pos0);
	for (int k=0;k<13;k++)
	{
		float t=float(k)/12;
		if (k<8)
			pos0.m_vPoint[pos0.m_vPoint.size()-8+k]=QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t);
		else
			pos0.m_vPoint.push_back(QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t));
	}
	x1=pos1.m_vPoint[8].x();
	y1=pos1.m_vPoint[8].y();
	a1=x1;
	c1=x2;
	a2=y1;
	c2=y2;
	b1=pos1.m_vPoint[0].x();
	b2=pos1.m_vPoint[0].y();
	pos1=backwards(pos1);
	for (int k=0;k<13;k++)
	{
		float t=float(k)/12;
		if (k<8)
			pos1.m_vPoint[pos1.m_vPoint.size()-8+k]=QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t);
		else
			pos1.m_vPoint.push_back(QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t));
	}
	
	pos=backwards(pos);
	for (int k=0;k<6;k++)
		pos.m_vPoint.pop_back();
	smoothsingleEdge2(pos0);
	smoothsingleEdge2(pos1);
	smoothsingleEdge2(pos);
	m_vEdge[m_vVertex[i].m_index[index1]]=pos0;
	m_vEdge[m_vVertex[i].m_index[index2]]=pos1;
	m_vEdge[m_vVertex[i].m_index[index]]=pos;
}

void SkeletonGraph::vertexAdjust3_1(int i, int index1, int index2)
{
	Edge pos0=m_vEdge[m_vVertex[i].m_index[index1]];
	Edge pos1=m_vEdge[m_vVertex[i].m_index[index2]];
	int index3=3-index1-index2;
	Edge pos2=m_vEdge[m_vVertex[i].m_index[index3]];
	Edge pos;
	for (int j=8;j>=0;j--)
		pos.m_vPoint.push_back(pos0.m_vPoint[j]);
	for (int j=1;j<=8;j++)
		pos.m_vPoint.push_back(pos1.m_vPoint[j]);
	float minDist=100;
	int num1=0;////index3
	int num2=0;////--index2 or index1
	bool ind1=true;
	float dist1=Dist(pos2.m_vPoint[0],pos);
	float dist2=Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],pos);
	if (dist1<dist2)
		pos2=backwards(pos2);
	for (int k=0;k<8;k++)
		pos2.m_vPoint.pop_back();
	float tangx=pos2.m_vPoint[pos2.m_vPoint.size()-1].x()-pos2.m_vPoint[pos2.m_vPoint.size()-3].x();
	float tangy=pos2.m_vPoint[pos2.m_vPoint.size()-1].y()-pos2.m_vPoint[pos2.m_vPoint.size()-3].y();
	float dist=Dist(tangx,tangy,0,0);
	tangx/=dist;
	tangy/=dist;
	for (int j=0;j<max(dist*2,9.1);j++)
	{
		pos2.m_vPoint.push_back(QPointF(pos2.m_vPoint[pos2.m_vPoint.size()-1].x()+tangx,
		pos2.m_vPoint[pos2.m_vPoint.size()-1].y()+tangy));

	}
	/*while(Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],pos)<
		Dist(pos2.m_vPoint[pos2.m_vPoint.size()-2],pos))
	{
		pos2.m_vPoint.push_back(QPointF(pos2.m_vPoint[pos2.m_vPoint.size()-1].x()+tangx,
		pos2.m_vPoint[pos2.m_vPoint.size()-1].y()+tangy));
	}*/
	//pos2.m_vPoint.pop_back();
	while (Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],pos)>
		Dist(pos2.m_vPoint[pos2.m_vPoint.size()-2],pos))
		pos2.m_vPoint.pop_back();

	/*while(Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],pos)>0.55)
	{
		pos2.m_vPoint.push_back(QPointF(pos2.m_vPoint[pos2.m_vPoint.size()-1].x()+tangx,
		pos2.m_vPoint[pos2.m_vPoint.size()-1].y()+tangy));
	}*/
	
	int recnt=0;
	float mindist=100;
	for (int j=0;j<pos.m_vPoint.size();j++)
	{
		if (Dist(pos.m_vPoint[j],m_vVertex[i].m_pos)<mindist)
		{
			mindist=Dist(pos.m_vPoint[j],m_vVertex[i].m_pos);
			recnt=j;
		}
	}
	pos0=backwards(pos0);
	pos1=backwards(pos1);
	if (recnt<8)//����pos0�У�pop pos0��push pos1
	{
		for (int j=recnt;j<8;j++)
		{
			pos1.m_vPoint.push_back(pos0.m_vPoint[pos0.m_vPoint.size()-1]);
			pos0.m_vPoint.pop_back();
		}
	}else if (recnt>8)
	{
		for (int j=recnt;j>8;j--)
		{
			pos0.m_vPoint.push_back(pos1.m_vPoint[pos1.m_vPoint.size()-1]);
			pos1.m_vPoint.pop_back();
		}
	}
	m_vVertex[i].m_pos=pos0.m_vPoint[pos0.m_vPoint.size()-1];
	pos1.m_vPoint[pos1.m_vPoint.size()-1]=m_vVertex[i].m_pos;
	pos2.m_vPoint[pos2.m_vPoint.size()-1]=m_vVertex[i].m_pos;
	m_vEdge[m_vVertex[i].m_index[index3]]=pos2;
	m_vEdge[m_vVertex[i].m_index[index1]]=pos0;
	m_vEdge[m_vVertex[i].m_index[index2]]=pos1;
}

void SkeletonGraph::smoothAdjust4_1(int i, int index1, int index2)
{
	Edge pos0=m_vEdge[m_vVertex[i].m_index[index1]];
	Edge pos1=m_vEdge[m_vVertex[i].m_index[index2]];
	if (Dist(pos0.m_vPoint[0],m_vVertex[i].m_pos)>Dist(pos0.m_vPoint[pos0.m_vPoint.size()-1],m_vVertex[i].m_pos))
		pos0=backwards(pos0);
	if (Dist(pos1.m_vPoint[0],m_vVertex[i].m_pos)>Dist(pos1.m_vPoint[pos1.m_vPoint.size()-1],m_vVertex[i].m_pos))
		pos1=backwards(pos1);
	local2lineSmooth(pos0,pos1);
	m_vEdge[m_vVertex[i].m_index[index1]]=pos0;
	m_vEdge[m_vVertex[i].m_index[index2]]=pos1;
}

void SkeletonGraph::vertexAdjust4_1(int i, int index1)
{
	int index2=(index1+1)%4;//1,2���Ѿ���Ϻ��˵ģ�3,4��Ҫ������
	int index3=(index1+2)%4;
	int index4=(index1+3)%4;
	Edge pos0=m_vEdge[m_vVertex[i].m_index[index1]];
	Edge pos1=m_vEdge[m_vVertex[i].m_index[index2]];
	Edge pos2=m_vEdge[m_vVertex[i].m_index[index3]];
	Edge pos3=m_vEdge[m_vVertex[i].m_index[index4]];
	if (Dist(pos2.m_vPoint[2],m_vVertex[i].m_pos)<Dist(pos2.m_vPoint[pos2.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos2=backwards(pos2);
	}
	if (Dist(pos3.m_vPoint[0],m_vVertex[i].m_pos)<Dist(pos3.m_vPoint[pos3.m_vPoint.size()-1],m_vVertex[i].m_pos))
	{
		pos3=backwards(pos3);
	}
	float mindist=100;
	float x2,y2;
	for (int j=0;j<pos0.m_vPoint.size();j++)
	{
		if (Dist(pos0.m_vPoint[j],pos2.m_vPoint[pos2.m_vPoint.size()-1])<mindist)
		{
			mindist=Dist(pos0.m_vPoint[j],pos2.m_vPoint[pos2.m_vPoint.size()-1]);
			x2=pos0.m_vPoint[j].x();
			y2=pos0.m_vPoint[j].y();
		}
	}
	for (int j=0;j<pos1.m_vPoint.size();j++)
	{
		if (Dist(pos1.m_vPoint[j],pos2.m_vPoint[pos2.m_vPoint.size()-1])<mindist)
		{
			mindist=Dist(pos1.m_vPoint[j],pos2.m_vPoint[pos2.m_vPoint.size()-1]);
			x2=pos1.m_vPoint[j].x();
			y2=pos1.m_vPoint[j].y();
		}
	}
	m_vVertex[i].m_pos=QPointF(x2,y2);
	float x1=pos2.m_vPoint[pos2.m_vPoint.size()-10].x();
	float y1=pos2.m_vPoint[pos2.m_vPoint.size()-10].y();
	float a1=x1;
	float c1=x2;
	float a2=y1;
	float c2=y2;
	float b1=pos2.m_vPoint[pos2.m_vPoint.size()-1].x();
	float b2=pos2.m_vPoint[pos2.m_vPoint.size()-1].y();
	for (int k=0;k<10;k++)
	{
		float t=float(k)/9;
		pos2.m_vPoint[pos2.m_vPoint.size()-10+k]=QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t);
	}
	x1=pos3.m_vPoint[pos3.m_vPoint.size()-10].x();
	y1=pos3.m_vPoint[pos3.m_vPoint.size()-10].y();
	a1=x1;
	c1=x2;
	a2=y1;
	c2=y2;
	b1=pos3.m_vPoint[pos3.m_vPoint.size()-1].x();
	b2=pos3.m_vPoint[pos3.m_vPoint.size()-1].y();
	for (int k=0;k<10;k++)
	{
		float t=float(k)/9;
		pos3.m_vPoint[pos3.m_vPoint.size()-10+k]=QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t);
	}
	m_vEdge[m_vVertex[i].m_index[index3]]=pos2;
	m_vEdge[m_vVertex[i].m_index[index4]]=pos3;
}
///////////////////////////////////////////////////////////////////////////////////////////
///������Ҫ��ʼsmooth��
//////////////////////////////////////////////////////////////////////////////////////////
void SkeletonGraph::smoothAdjust()
{
	for (int i=0;i<m_vVertex.size();i++)
	{
		switch(m_vVertex[i].m_k)
		{
		case 2:
			{
				if (m_vVertex[i].m_smooth[0][1])
				{
					smoothAdjust3_1(i,0,1);
					m_vVertex[i].m_pos=m_vEdge[m_vVertex[i].m_index[0]].m_vPoint[0];
					m_vVertex[i].m_width=0;
					m_vVertex[i].m_k=2;
				}
				break;
			}
		case 3:
			{
				int a=m_vVertex[i].m_smooth[0][1]?1:0;
				a+=m_vVertex[i].m_smooth[0][2]?1:0;
				a+=m_vVertex[i].m_smooth[2][1]?1:0;
				if (a==1)
				{
					if (m_vVertex[i].m_smooth[0][1])
					{
						smoothAdjust3_1(i,0,1);
						vertexAdjust3_1(i,0,1);
					}
					if (m_vVertex[i].m_smooth[0][2])
					{
						smoothAdjust3_1(i,0,2);
						vertexAdjust3_1(i,0,2);
					}
					if (m_vVertex[i].m_smooth[1][2])
					{
						smoothAdjust3_1(i,1,2);
						vertexAdjust3_1(i,1,2);
					}

				}
				if (a==2)
				{
					if (!m_vVertex[i].m_smooth[0][1])
					{	
						smoothAdjust3_2(i,2,0,1);
					}
					else
					{
						if (!m_vVertex[i].m_smooth[0][2])
						{
							smoothAdjust3_2(i,1,2,0);
						}else
						{
							smoothAdjust3_2(i,0,1,2);
						}
					}
				}
				
				break;
			}
		case 4:
			{
				///Ӧ���Ѿ��ź����˵�
				int a=m_vVertex[i].m_smooth[0][1]?1:0;
				a+=m_vVertex[i].m_smooth[0][3]?1:0;
				a+=m_vVertex[i].m_smooth[1][2]?1:0;
				a+=m_vVertex[i].m_smooth[2][3]?1:0;
				switch (a)
				{
				case 0:
					{
						for (int j=0;j<2;j++)
						{
							if (m_vVertex[i].m_smooth[j][(j+2)%4])
								smoothAdjust4_1(i,j,(j+2)%4);
						}
						break;
					}
				case 1:
					{
						//*��������ڵ������ߣ�bezier�����������Ϊһ����Ȼ���ҵ�����ĵ㣬��bezier��ֵ����������
						for (int j=0;j<4;j++)
						{
							if (m_vVertex[i].m_smooth[j][(j+1)%4])
							{
								smoothAdjust4_1(i,j,(j+1)%4);
								vertexAdjust4_1(i,j);
							}
						}
					}
				case 2:
					{
						//*��ͬһ�������ģ���3-2һ������һ������΢����һ�¾���

						//*��Եģ��ֱ�bezier��Ͼͺ�

						//�������ڱ�--�ֱ�bezier��Ͼͺã���Ҫ����һ��ɾ��...�����Ȳ�д��Ϊ��û���������������
					}
				case 3:///̫���ӡ����Ȳ����˰�..
					{
						//����ͬһ���ߣ��ֱ�bezier��Ͼͺ�

						//
					}
				default:
					break;
				}

				
				break;
			}
		default:

			break;

		}
	}
}

void SkeletonGraph::smoothEdge()///��Ϊ����Ҫ���õ�����smooth...
{
	for (int i=0;i<m_vEdge.size();i++)
	{
		smoothsingleEdge2(m_vEdge[i]);///////////////////////////////
	}
}

QPoint getStartingPoint(const QImage &img)
{
	const int imin = 140;
	int yi = 0;
	int ymax=0;
	int xmax = 0;
	for(yi=0; yi<img.height(); yi++)
	{
		int imax = 0;
		xmax = 0;
		for(int xi=0; xi<img.width(); xi++)
		{
			int itensity = qRed(img.pixel(xi,yi));
			if(itensity>imax)
			{
				imax = itensity;
				xmax = xi;
			}
		}
		if(imax>imin)
		{
			///�����¼��������Ҹ�������
			ymax=yi;
			int recy=0;
			for (int dy=0;dy<8;dy++)
			{
				if (isInImage(xmax,yi+dy,img.width(),img.height()) && qRed(img.pixel(xmax,yi+dy))>imax)
				{
					ymax=yi+dy;
					imax=qRed(img.pixel(xmax,yi+dy));
				}
			}
			yi=ymax;
			int cnt=0;
			for (int dx=-8;dx<=8;dx++)
			for (int dy=-8;dy<=8;dy++)
			{
				if (isInImage(xmax+dx,yi+dy,img.width(),img.height()) && qRed(img.pixel(xmax+dx,yi+dy))>90)
					cnt++;
			}
			if (cnt>40)
			{
				break;
			}
		}
	}
	return QPoint(xmax,ymax);
}

int SkeletonGraph::edgeIndex(int indexVertex, Edge &pos)
{
	float tangx=pos.m_vPoint[min(6,pos.m_vPoint.size()-1)].x()-pos.m_vPoint[0].x();
	float tangy=pos.m_vPoint[min(6,pos.m_vPoint.size()-1)].y()-pos.m_vPoint[0].y();
	float dist=Dist(tangx,tangy,0,0);
	tangx/=dist;
	tangy/=dist;
	int maxcosine=0;
	int index=0;
	for (int i=0;i<m_vVertex[indexVertex].m_k;i++)
	{
		float cosine=m_vVertex[indexVertex].m_direction[i].x()*tangx+m_vVertex[indexVertex].m_direction[i].y()*tangy;
		if (cosine>maxcosine)
		{
			maxcosine=cosine;
			index=i;
		}
	}
    if (maxcosine<cos(3.14/9)||m_vVertex[indexVertex].m_index[index]>-1)//˵��֮ǰ�ٷ������������,����˵�����ҵ����Ǹ������Ѿ���ռ����
	{
		index=m_vVertex[indexVertex].m_k;
		m_vVertex[indexVertex].m_k++;
		m_vVertex[indexVertex].m_direction[index]=QPointF(m_vVertex[indexVertex].m_width*tangx/8,m_vVertex[indexVertex].m_width*tangy/8);
	}
	return index;
}

int SkeletonGraph::edgeIndex(int indexVertex, float tangx, float tangy)
{
	float dist=Dist(tangx,tangy,0,0);
	tangx/=dist;
	tangy/=dist;
	int maxcosine=0;
	int index=0;
	for (int i=0;i<m_vVertex[indexVertex].m_k;i++)
	{
		float cosine=m_vVertex[indexVertex].m_direction[i].x()*tangx+m_vVertex[indexVertex].m_direction[i].y()*tangy;
		if (cosine>maxcosine)
		{
			maxcosine=cosine;
			index=i;
		}
	}
    if (maxcosine<cos(3.14/9)||m_vVertex[indexVertex].m_index[index]>-1)//˵��֮ǰ�ٷ������������,����˵�����ҵ����Ǹ������Ѿ���ռ����
	{
		index=m_vVertex[indexVertex].m_k;
		m_vVertex[indexVertex].m_k++;
		m_vVertex[indexVertex].m_direction[index]=QPointF(m_vVertex[indexVertex].m_width*tangx/8,m_vVertex[indexVertex].m_width*tangy/8);
	}
	return index;
}

void SkeletonGraph::correction()
{
	for (int i=0;i<m_vVertex.size();i++)
	{
		for (int j=m_vVertex[i].m_k-1;j>=0;j--)
		{
			if (m_vVertex[i].m_index[j]==-1)
			{
				for (int k=j;k<m_vVertex[i].m_k-1;k++)
				{
					m_vVertex[i].m_index[k]=m_vVertex[i].m_index[k+1];
					m_vVertex[i].m_direction[k]=m_vVertex[i].m_direction[k+1];
				}
				m_vVertex[i].m_k--;//�ѿյģ�û�ж�Ӧ�������ķ���ɾȥ
			}
		}
		if (m_vVertex[i].m_k==0)
			m_vVertex[i]=m_vVertex[0];
	}
}

void SkeletonGraph::deleteVertex(int i)
{
	for (int j=0;j<m_vVertex[i].m_k;j++)//delete adjacent edges
	{
		deleteSingleEdge(m_vVertex[i].m_index[j]);
	}
	/////�㻹�ǲ��ܶ�����Ϊ��¼�����ǵ�index����,���Ըĳɵ�һ����� ��Ϊ��һ����һ�㲻���ٱ�ɾ��
	m_vVertex[i]=m_vVertex[0];
}
void moveSingleEdge(Edge & pos, float x2, float y2)
{
	int l=min(16,max(min(8,pos.m_vPoint.size()-1),pos.m_vPoint.size()/2));
	float x1=pos.m_vPoint[l].x();
	float y1=pos.m_vPoint[l].y();
	float a1=x1;
	float c1=x2;
	float a2=y1;
	float c2=y2;
	float b1=pos.m_vPoint[int(l/2)].x();
	float b2=pos.m_vPoint[int(l/2)].y();
	for (int k=0;k<=l;k++)
	{
		float t=float(k)/l;
		pos.m_vPoint[l-k]=QPointF(a1*(1-t)*(1-t)+2*b1*(1-t)*t+c1*t*t,a2*(1-t)*(1-t)+2*b2*(1-t)*t+c2*t*t);
	}
}

void SkeletonGraph::moveVertex(int i, QPointF seed)
{
	
	float x2=m_vVertex[i].m_pos.x()+seed.x();
	float y2=m_vVertex[i].m_pos.y()+seed.y();
	for (int j=0;j<m_vVertex[i].m_k;j++)
	{
		Edge pos=m_vEdge[m_vVertex[i].m_index[j]];
		if (Dist(pos.m_vPoint[0],m_vVertex[i].m_pos)>Dist(pos.m_vPoint[pos.m_vPoint.size()-1],m_vVertex[i].m_pos))
			pos=backwards(pos);
		if (pos.m_vPoint.size()<6)
			continue;
		moveSingleEdge(pos, x2,y2);
		m_vEdge[m_vVertex[i].m_index[j]]=pos;
	}
	m_vVertex[i].m_pos=QPointF(x2,y2);
}

void SkeletonGraph::splitEdge(int indexVertex, int indexEdge, QPointF seed)
{
	float x2=seed.x();
	float y2=seed.y();
	Edge pos=m_vEdge[m_vVertex[indexVertex].m_index[indexEdge]];
	if (Dist(pos.m_vPoint[0],m_vVertex[indexVertex].m_pos)>Dist(pos.m_vPoint[pos.m_vPoint.size()-1],m_vVertex[indexVertex].m_pos))
		pos=backwards(pos);
	if (pos.m_vPoint.size()<=6)
		return;
	moveSingleEdge(pos, x2,y2);
	m_vEdge[m_vVertex[indexVertex].m_index[indexEdge]]=pos;
	m_vVertex.push_back(Vertex(seed,false));
	m_vVertex[m_vVertex.size()-1].m_direction[0]=QPointF(pos.m_vPoint[6].x()/6,pos.m_vPoint[6].y()/6);
	m_vEdge.push_back(pos);
	m_vVertex42edge.push_back(m_vVertex.size()-1);//�������µĶ���
	m_vVertex42edge.push_back(this->indexVertex(pos.m_vPoint[pos.m_vPoint.size()-1],m_maxWidth));//��һ�߻��ǲ����
	m_vVertex[m_vVertex.size()-1].m_index[0]=m_vEdge.size()-1;///�������µı�
	deleteSingleEdge(m_vVertex[indexVertex].m_index[indexEdge]);//ɾȥԭ���ı�
}

////////////////////////////////////////////////////////////////////////// load @ save
istream &operator>>(istream &stream, SkeletonGraph &s) 
{
	s.clear();

	string str;
	float vf1, vf2;
	int sz,vi;
	////////////////////////////////////////// vertex
	stream >> str >> sz;
	s.m_vVertex.resize(sz);

	for(int k=0; k<s.m_vVertex.size(); k++)
	{
		stream >> str >> vf1 >> vf2;
		s.m_vVertex[k].m_pos = QPointF(vf1,vf2);		//m_pos

		stream >> str >> vf1 >> vf2;
		s.m_vVertex[k].m_prevPos = QPointF(vf1,vf2);	//m_prevPos

		stream >> str >> vi;
		s.m_vVertex[k].m_bJunction = (vi==0?false:true);//m_bJunction

		stream >> str >> vf1;
		s.m_vVertex[k].m_width = vf1;					//m_width

		stream >> str >> vi;
		s.m_vVertex[k].m_k = vi;						// m_k

		stream >> str >> vi;
		for(int i=0; i<10; i++)
		{
			stream >> vf1 >> vf2;
			s.m_vVertex[k].m_direction[i] = QPointF(vf1,vf2);	//m_direction[10]
		}

		stream >> str >> vi;
		for(int i=0; i<10; i++)
		{
			stream >> vi;
			s.m_vVertex[k].m_index[i] = vi;			//m_index[10]
		}

		stream >> str >> vi;
		for(int i=0; i<10; i++)
			for(int j=0; j<10; j++)
			{
				stream >> vi;						//m_smooth[10][10]
				s.m_vVertex[k].m_smooth[i][j] = (vi==0?false:true);
			}

		stream >> str >> vi;
		for(int i=0; i<5; i++)
			stream >> s.m_vVertex[k].m_boundary[i];	//m_boundary[5]

		stream >> str >> vi;
		for(int i=0; i<5; i++)
		{
			stream >> vi;							//m_boundSmooth[5]
			s.m_vVertex[k].m_boundSmooth[i] = (vi==0?false:true);
		}
	}

	////////////////////////////////////////// edge
	stream >> str >> vi;
	s.m_vEdge.resize(vi);
	for (int i=0; i<s.m_vEdge.size(); i++)
		stream >> s.m_vEdge[i];

	////////////////////////////////////////// edge
	stream >> str >> vi;
	s.m_vVertex42edge.resize(vi);
	for (int i=0; i<s.m_vVertex42edge.size(); i++)
		stream >> s.m_vVertex42edge[i];
	
	return stream;
}
ostream &operator<<(ostream &stream, const SkeletonGraph &s) 
{
	stream << "===m_vVertex=== "  << s.m_vVertex.size() <<endl;
	for (int k=0; k<s.m_vVertex.size(); k++)
	{
		stream << "m_pos " << s.m_vVertex[k].m_pos.x() << " " << s.m_vVertex[k].m_pos.y() << endl;

		stream << "m_prevPos " << s.m_vVertex[k].m_prevPos.x() << " " << s.m_vVertex[k].m_prevPos.y() << endl;

		stream << "m_bJunction " << s.m_vVertex[k].m_bJunction << endl;

		stream << "m_width " << s.m_vVertex[k].m_width << endl;

		stream << "m_k " << s.m_vVertex[k].m_k << endl;

		stream << "m_direction " << 10 <<endl;
		for(int i=0; i<10; i++)
			stream << s.m_vVertex[k].m_direction[i].x() << " " << s.m_vVertex[k].m_direction[i].y() << " ";
		stream << endl;

		stream << "m_index " << 10 <<endl;
		for(int i=0; i<10; i++)
			stream << s.m_vVertex[k].m_index[i] << " ";
		stream << endl;

		stream << "m_smooth " << 100 <<endl;
		for(int i=0; i<10; i++)
		{
			for(int j=0; j<10; j++)
				stream << s.m_vVertex[k].m_smooth[i][j] << " ";
			stream << endl;
		}

		stream << "m_boundary " << 5 <<endl;
		for(int i=0; i<5; i++)
		{
			stream << s.m_vVertex[k].m_boundary[i] << endl;
		}

		stream << "m_boundSmooth " << 5 <<endl;
		for(int i=0; i<5; i++)
			stream << s.m_vVertex[k].m_boundSmooth[i] << " ";	

		stream << endl;
	}

	stream << "===m_vEdge=== "  << s.m_vEdge.size() << endl;
	for (int k=0; k<s.m_vEdge.size(); k++)
	{
		stream << s.m_vEdge[k] << endl;		
	}

	stream << "===m_vVertex42edge=== "  << s.m_vVertex42edge.size() <<endl;
	for (int k=0; k<s.m_vVertex42edge.size(); k++)
	{
		stream << s.m_vVertex42edge[k]  <<endl;
	}
	return stream;
}
istream &operator>>(istream &stream, Edge &s) 
{
	string str;
	float vf1, vf2;
	int vi;
	stream >> str >> vi;
	s.m_vPoint.clear();
	if(vi>0)
	{
		s.m_vPoint.resize(vi);
		for (int k=0; k<s.m_vPoint.size(); k++)
		{
			stream >> vf1 >> vf2;
			s.m_vPoint[k] = QPointF(vf1,vf2);
		}
	}	
	return stream;
}
ostream &operator<<(ostream &stream, const Edge &e) 
{
	stream << "===edge=== " << e.m_vPoint.size() << endl;
	for(int i=0; i<e.m_vPoint.size(); i++)
	{
		stream << e.m_vPoint[i].x() << " " << e.m_vPoint[i].y() << endl;
	}
	return stream;
}
//////////////////////////////////////////////////////////////////////////

} // mamespace