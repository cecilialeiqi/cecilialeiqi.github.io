
#pragma once

#include "ui_mainwindow.h"
#include "vectorizationPaint.h"
#include "videoplayer.h"

const QStringList displayList = (QStringList()
								 << "Skeleton"	
								 << "Gradient"
								 << "GradientSmooth"	
								 << "Magnitude"
								 << "Profile"
								 << "Input"
								 << "Record"		);

class MainWindow : public QMainWindow, protected Ui_MainWindow {
    Q_OBJECT
public:
    MainWindow();
    ~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

    void restoreSettings();
    void closeEvent(QCloseEvent *e);

    const QImage& image() const { return m_result; }
	QString fileName() { return m_player->filename(); }
 
	/// status bar
	void setStatusMessage(const QString &txt) {statusBar()->showMessage(txt);}
	void setStatusMouse(const QString& txt) {m_statusMouseLabel->setText(txt);}
	void setStatusZoom(const QString& txt) {m_statusZoomLabel->setText(txt);}

protected slots:
    void on_actionOpen_triggered();
    void on_actionAbout_triggered();
    void on_actionRecord_triggered();
	void setFullScreen();

    void setDirty();
    void process();
    
    void onVideoChanged(int nframes);

	void setMoveMode(bool isok);
	void setDeleteMode(bool isok);
	void setSplitMode(bool isok);
	void setDrawMode(bool isok);

signals:
    void imageChanged(const QImage&);

protected:
    virtual void draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image);

    VideoPlayer *m_player;
    QImage m_result;
    bool m_dirty;

private:
	static MainWindow*	_mainWindow;

	QToolBar   *m_interactionToolBar;
	QLabel		*m_statusMouseLabel;
	QLabel		*m_statusZoomLabel;

	QLabel		*m_profileLabel;
	QPushButton	*m_computeSkeletonPB;

public:
	void setProfileLabel(const QImage &img);
	int	 getBranchIndex(){return branchComboBox->currentIndex();}
	void launchBranchWidget();
	void setComputeSkeletonPB(bool isok) {m_computeSkeletonPB->setChecked(isok);}
};
