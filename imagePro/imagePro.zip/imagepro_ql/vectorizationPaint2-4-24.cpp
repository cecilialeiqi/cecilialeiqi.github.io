#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);
	
	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	recordPoint=QImage::QImage(m_imgSize.width(),m_imgSize.height(),QImage::Format_Indexed8);
	cout<<m_imgSize.width()<<','<<m_imgSize.height()<<endl;
	recordPoint.fill(0);
	for (int i=0;i<m_trackingLength;i++)
	{
		recordPoint.setColor(i+1,qRgb(int(i/326),int((i%326)/16),i%16));	///range should be 0-255, û��ѽ...	
	}
	ImagePaint::tracking(sktGraph, m_imgSize.width(),m_imgSize.height(),4,pGradS,m_trackingLength);
	//////smooth
	for (int i=0;i<5;i++)
		sktGraph.smoothEdge();
	/////delete redundant edges
	sktGraph.deleteEdge();
	sktGraph.addEdge();
	sktGraph.junctionAdjust();
	sktGraph.smoothAdjust();

	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}

float Dist(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}

bool judgeJunctionArea(float *leftPos,float *rightPos)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0&&rightPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];///��ʵӦ�������������ֿ����ǵ�junction point,�ӽ��Ļ������ڵ�end point
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)
		if (Dist(leftPos[i],leftPos[i+1],rightPos[i],rightPos[i+1])<Dist(leftPos[8],leftPos[9],rightPos[8],rightPos[9]))//cos30
	{
		return true;//directions we got from left and right boundaries are too different ==> junction area
	}
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>=magMax)
			{
				distMax = k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>=magMax)
			{
				distMax = -k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

void ImagePaint::centerDirection(float* tang, int w, int h, int cn, float px, float py, float *flow)
{
	float stepPos[8];
	const int proWidth = 8;
	findStepPosition(stepPos,px,py,w,h,proWidth, flow);
	float fleftx,flefty,frightx,frighty;
	if (isInImage(stepPos[0],stepPos[1],w,h))
	{
	    const float *fleft = getDirection(w, h, cn,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	    fleftx=fleft[1];
	    flefty=-fleft[0];
	}else
	{
		const float *fleft = getDirection(w, h, cn,flow,int(px+0.5),int(py+0.5));
		fleftx=fleft[1];
	    flefty=-fleft[0];

	}
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	if (isInImage(stepPos[4],stepPos[5],w,h))
	{
		const float *fright = getDirection(w,h, 4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}else
	{
		const float *fright = getDirection(w,h, 4,flow,int(px+0.5),int(py+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	//float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	//return tang;
}

void ImagePaint::Record_point(float px,float py, float radius, int w, int h, int index)
{
	for (int xx=int(-radius-0.5);xx<=int(radius+0.5);xx++)
			for (int yy=int(-radius-0.5);yy<=int(radius+0.5);yy++)
				if (xx*xx+yy*yy<=radius*radius && isInImage(int(px+xx+0.5),int(py+yy+0.5),w,h))
				{
					recordPoint.setPixel(int(px+xx+0.5),int(py+yy+0.5),index);
				}
}

bool judgeJunctionArea(float leftx,float lefty,float rightx,float righty,float seedx,float seedy)
{
	float dist1=Dist(leftx,lefty,seedx,seedy);
    float dist2=Dist(rightx,righty,seedx,seedy);
	if (dist1>7.5 && dist1>2*dist2 || dist2>7.5 && dist2>2*dist1)
		return true;
	if (((leftx-seedx)*(rightx-seedx)+(lefty-seedy)*(righty-seedy))/Dist(leftx-seedx,lefty-seedy,0,0)/Dist(rightx-seedx,righty-seedy,0,0)>0)//�н�С��90��
		return true;
	return false;
}
bool judgeJunctionArea(float fleftx,float flefty,float frightx,float frighty)
{
	float cosine=(fleftx*frightx+flefty*frighty)/Dist(fleftx,flefty,0,0)/Dist(frightx,frighty,0,0);
	if (cosine>=cos(3.1415/9))
		return false;
	return true;//��junctionArea��
}
//////////////////////////////////////////////////////////////////////////
/// �������ҵ��ڵ�(px,py)����(tangy,-tangx)�ϵ�����������λ�ã��������ߣ�
/// �����stepPos[8]
//////////////////////////////////////////////////////////////////////////
bool findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(xx-tangy+0.5),int(yy+tangx+0.5))))
			{
				distMax = k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)//
			break;
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����������Ӧ��ͨ���ж�����֤��ʱ�����ұ߽粻��ʹ��
	{
		return false;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
		if (qRed(m_image.pixel(stepPos[0]-2*tangy,stepPos[1]+2*tangx))>50)///////˵���߽绹����Щ����ɣ��п�����������·���һ������
			flag=true;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(0.5+xx+tangy),int(0.5+yy-tangx))))
			{
				distMax = -k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)
			break;
	}
	if (flag)
	{
		return false;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
		if (qRed(m_image.pixel(stepPos[4]+2*tangy,stepPos[5]-2*tangx))>50)
			return false;
	}
	return true;
}

bool judgeEdgeEnd(float px,float py, float tangx, float tangy, int w,int h, int radius,QImage m_image)
{
	if (!isInImage(px+tangx*radius,py+tangy*radius,w,h)||qRed(m_image.pixel(px+tangx*radius,py+tangy*radius))==0)
		return true;
	return false;
}


void ImagePaint::tracking(skeleton::SkeletonGraph &sktGraph, int w, int h, int cn, float *flow, int maxLength)
{
	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<QPointF> vertexStack,vertexRecord;//second one means angle
    vector<QPointF> angleStack,angleRecord;
	/// get the original direction
	//QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	float tang[2];
	m_record=m_image;/////

	centerDirection(tang, m_imgSize.width(),m_imgSize.height(),4,sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y(),flow);
	vertexStack.push_back(sktGraph.m_vVertex[0].m_pos);
	angleStack.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexStack.push_back(sktGraph.m_vVertex[0].m_pos);
	angleStack.push_back(QPointF(tang[0],tang[1]));
	sktGraph.m_vVertex[sktGraph.m_vVertex.size()-1].m_k=2;
	sktGraph.m_vVertex[sktGraph.m_vVertex.size()-1].direction[0]=QPointF(-tang[0],-tang[1]);
	sktGraph.m_vVertex[sktGraph.m_vVertex.size()-1].direction[1]=QPointF(tang[0],tang[1]);
	int cnt=0;
	while(!vertexStack.empty()&&cnt<=maxLength)//////////////////////
	{
		cnt++;
		//cout<<cnt<<"     ";
		///��ջ
		vertexRecord.push_back(vertexStack[vertexStack.size()-1]);
		QPointF vertex=vertexStack[vertexStack.size()-1];
		vertexStack.pop_back();
		angleRecord.push_back(angleStack[angleStack.size()-1]);
		QPointF angle=angleStack[angleStack.size()-1];
		angleStack.pop_back();
		//skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGradS,vertexStack,angleStack, vertexRecord, angleRecord);

		float seedx=vertex.x();
		float seedy=vertex.y();
		float tangx=angle.x();
		float tangy=angle.y();
		skeleton::Edge pos;//(QPointF(px,py));
		if(seedx<0 || seedy<0 || seedx>=w || seedy>=h)
		{
			cout << "seed should not out of the image." << endl;
			continue;
		}

		float prevTangx = tangx;
		float prevTangy = tangy;
		float stepPos[8];
		const int proWidth = 8;

		////first step: get out of the junction area, Ӧ���ȸ�������ĳһ������
		float direction[12];
		direction[0]=tangx;
		direction[1]=tangy;
//<<<<<<< .mine
		if (ImagePaint::trackingEdge(sktGraph,pos,w,h,direction,seedx,seedy,cn,flow))///meet a junction point
		{//record the two possible vectors
			//junction�Լ�������ջ��
			///////////////////////////////////���һ��ÿ��junction��Χ������
			if (pos.m_vPoint.size()>3)
			{
				int index1=sktGraph.indexVertex(pos.m_vPoint[0]);
				int pointSz=pos.m_vPoint.size();
				QPointF m_jPoint=pos.m_vPoint[pointSz-1];//����Ǹ�����junction point
				int index=sktGraph.edgeIndex(index1,pos);
				sktGraph.m_vVertex[index1].index[index]=sktGraph.m_vEdge.size();//��������ķ����indexΪ��ǰ�����ı��
				int index2=sktGraph.indexVertex(m_jPoint);
				////////////////////��Ҫԭ���ĵ���µĵ�֮����ͨ·����
				if (index2>=0 && 
					Dist(m_jPoint.x(),m_jPoint.y(),sktGraph.m_vVertex[index2].m_pos.x(),sktGraph.m_vVertex[index2].m_pos.y())>4)
				{
					float tangx1=m_jPoint.x()-sktGraph.m_vVertex[index2].m_pos.x();
					float tangy1=m_jPoint.y()-sktGraph.m_vVertex[index2].m_pos.y();
					float tangx2=m_jPoint.x()-pos.m_vPoint[pointSz-4].x();
					float tangy2=m_jPoint.y()-pos.m_vPoint[pointSz-4].y();
					float dist=Dist(tangx1,tangy1,0,0);
					tangx1/=dist;
					tangy1/=dist;
					dist=Dist(tangx2,tangy2,0,0);
					tangx2/=dist;
					tangy2/=dist;
					if (abs(tangx1*tangx2+tangy1*tangy2)<cos(3.14/6))/////��Ҫ�жϺϲ��Ƿ������������ϲ��ĵ��������ǰ�������ϾͿ����ǲ��е������ϵĵ�����	
					{
						index2=-1;
					}
				}
				int k=0;
				if (index2==-1)//�µĵ������
				{
					sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));					
					index2=sktGraph.m_vVertex.size()-1;
					while(direction[2*k]!=0)
					{
						int cases=0;
						tangx=direction[2*k];
						tangy=direction[2*k+1];
						vertexStack.push_back(QPointF(pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y()));
						Record_point(m_jPoint.x(),m_jPoint.y(),5,w,h,sktGraph.m_vVertex.size());
						angleStack.push_back(QPointF(tangx,tangy));
				//		cout<<vertexStack[vertexStack.size()-1].x()<<','<<vertexStack[vertexStack.size()-1].y()<<endl;
				//		cout<<angleStack[angleStack.size()-1].x()<<' '<<angleStack[angleStack.size()-1].y()<<endl;
						k++;
					}
					sktGraph.m_vVertex[index2].m_k=k+1;
					sktGraph.m_vVertex[index2].m_width=direction[2*k+1];
					int a=8;
					while (pos.m_vPoint.size()-a<0)
						a--;
					float tangx=pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-a].x();
					float tangy=pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-a].y();
					float dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					sktGraph.m_vVertex[index2].direction[0]=QPointF(-tangx*direction[2*k+1]/8,-tangy*direction[2*k+1]/8);
					sktGraph.m_vVertex[index2].index[0]=sktGraph.m_vEdge.size();
					for (int j=0;j<k;j++)
					{
						sktGraph.m_vVertex[index2].direction[j+1]=QPointF(direction[2*j],direction[2*j+1]);				   
					}
				}else//��֮ǰ�Ѿ���¼���Ķ��㣬���Բ���Ҫ���¼�¼��
				{
					QPointF tmpPos=sktGraph.m_vVertex[index2].m_pos;
					float tmpTangx=tmpPos.x()-m_jPoint.x();
					float tmpTangy=tmpPos.y()-m_jPoint.y();
					float dist=Dist(tmpTangx,tmpTangy,0,0);
					tmpTangx/=dist;
					tmpTangy/=dist;
					if (dist>3)
					for (int j=1;j<dist;j+=3)
					{
						pos.m_vPoint.push_back(QPointF(m_jPoint.x()+tmpTangx*j,m_jPoint.y()+tmpTangy*j));
					}
					pos.m_vPoint.push_back(tmpPos);
					Record(pos,8,w,h);
					/////////////��Ӧ�ð�֮ǰ�ķ���ɾ�ˡ���
					for (int j=0;j<vertexStack.size();j++)
					{
						if (Dist(vertexStack[j].x(),vertexStack[j].y(),m_jPoint.x(),m_jPoint.y())<1
							&& (-tangx*angleStack[j].x()-tangy*angleStack[j].y())/Dist(angleStack[j].x(),angleStack[j].y(),0,0)>cos(3.14/9))
						{
							m_record.setPixel(vertexStack[j].x()+angleStack[j].x()*8,vertexStack[j].y()+angleStack[j].y()*8,0);
						}
					}
				}
				sktGraph.m_vVertex42edge.push_back(index1);
				sktGraph.m_vVertex42edge.push_back(index2);
				sktGraph.m_vEdge.push_back(pos);
			}
		}
		else if (pos.m_vPoint.size()>3)
		{
			int pointSz=pos.m_vPoint.size();
			QPointF m_jPoint=pos.m_vPoint[pointSz-1];//����Ǹ�����junction point
			int index1=sktGraph.indexVertex(pos.m_vPoint[0]);
			int index=sktGraph.edgeIndex(index1,pos);
			sktGraph.m_vVertex[index1].index[index]=sktGraph.m_vEdge.size();
			int index2=sktGraph.indexVertex(m_jPoint);
			if (index2>=0 && 
				Dist(m_jPoint.x(),m_jPoint.y(),sktGraph.m_vVertex[index2].m_pos.x(),sktGraph.m_vVertex[index2].m_pos.y())>4)
			{
				float tangx1=m_jPoint.x()-sktGraph.m_vVertex[index2].m_pos.x();
				float tangy1=m_jPoint.y()-sktGraph.m_vVertex[index2].m_pos.y();
				float tangx2=m_jPoint.x()-pos.m_vPoint[pointSz-4].x();
				float tangy2=m_jPoint.y()-pos.m_vPoint[pointSz-4].y();
				float dist=Dist(tangx1,tangy1,0,0);
				tangx1/=dist;
				tangy1/=dist;
				dist=Dist(tangx2,tangy2,0,0);
				tangx2/=dist;
				tangy2/=dist;
				if (abs(tangx1*tangx2+tangy1*tangy2)<cos(3.14/6))/////��Ҫ�жϺϲ��Ƿ������������ϲ��ĵ��������ǰ�������ϾͿ����ǲ��е������ϵĵ�����	
				{
					index2=-1;
				}
			}
			if (index2==-1)
			{
				sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,false));
				index2=sktGraph.m_vVertex.size()-1;
				int a=7;
				while (pos.m_vPoint.size()-a<0)
					a--;
				float tangx=pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-a].x();
				float tangy=pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-a].y();
				float dist=Dist(tangx,tangy,0,0);
				tangx/=dist;
				tangy/=dist;
				sktGraph.m_vVertex[index2].direction[0]=QPointF(tangx,tangy);	
			}else
			{
				QPointF tmpPos=sktGraph.m_vVertex[index2].m_pos;
				float tmpTangx=tmpPos.x()-m_jPoint.x();
				float tmpTangy=tmpPos.y()-m_jPoint.y();
				float dist=Dist(tmpTangx,tmpTangy,0,0);
     			if (dist>3)//
				for (int j=1;j<dist;j+=3)
				{
					pos.m_vPoint.push_back(QPointF(m_jPoint.x()+tmpTangx/dist*j,m_jPoint.y()+tmpTangy/dist*j));
				}
				pos.m_vPoint.push_back(tmpPos);
				Record(pos,8,w,h);///Сһ�㣬֮ǰ�Ѿ���¼���˵�
				//pos.m_vPoint[pointSz-1]=sktGraph.m_vVertex[index2].m_pos;
			}
			sktGraph.m_vVertex42edge.push_back(index1);
			sktGraph.m_vVertex42edge.push_back(index2);
			sktGraph.m_vEdge.push_back(pos);
		}
	}
}

bool leftWay(vector<tracking::Pot3f> &leftPos, vector<tracking::Pot3f> &rightPos, int recordCnt)
{
	float left=0;
	float right=0;
	for (int i=recordCnt+1;i<leftPos.size();i++)
	{
		if (abs(leftPos[i].ang-leftPos[i-1].ang)>3)
		   left+=abs(-3.1415*2+abs(leftPos[i].ang-leftPos[i-1].ang));
		else
    		left+=abs(leftPos[i].ang-leftPos[i-1].ang);
		if (abs(rightPos[i].ang-rightPos[i-1].ang)>3)
			right+=abs(-3.1415*2+abs(rightPos[i].ang-rightPos[i-1].ang));
		else
    		right+=abs(rightPos[i].ang-rightPos[i-1].ang);
	}
	if (left<right)
		return true;
	return false;
}

void ImagePaint::Record(skeleton::Edge &pos, float width, int w, int h)
{
	if (width>8) width=8;
	if (pos.m_vPoint.size()>3)
	for (int i=width/2+2;i<pos.m_vPoint.size()-width/2-2;i++)
	{
		float px=pos.m_vPoint[i].x();
		float py=pos.m_vPoint[i].y();
		//float tmpwidth=width;
		if (i>=pos.m_vPoint.size()-width)
		{
			width--;
		}
		for (int xx=int(-width/2-0.5);xx<width/2+0.6;xx++)
			for (int yy=int(-width/2-0.5);yy<width/2+0.6;yy++)
				if (xx*xx+yy*yy<=width*width/4 && isInImage(int(px+xx+0.5),int(py+yy+0.5),w,h))
				{
					m_record.setPixel(int(px+xx+0.5),int(py+yy+0.5),0);
				}
		//width=tmpwidth;
	}
}

int ImagePaint::dirJunction(float *direction, int seedx,int seedy,int w,int h,int width)
{
	int red100[100];
	int k=0;
	if (width<5)
		width=5;
	k=0;
	for (int i=0;i<100;i++)///��i�����Ӧ�ĽǶ���i/100*2*pi
	{
		float tmpx=seedx+cos(2*3.14*i/100)*(width+5);
		float tmpy=seedy+sin(2*3.14*i/100)*(width+5);
		if (!isInImage(tmpx,tmpy,w,h))
		{
			red100[i]=0;
			continue;
		}
		red100[i]=qRed(m_image.pixel(tmpx,tmpy));
	}
	while(k<=4)
	{
		//�������ĵ�;
		float maxRed=0;
		float maxI=0;
		for (int i=0;i<100;i++)
		{
			if (red100[i]>maxRed)
			{
				maxRed=red100[i];
				maxI=i;
			}
		}
		float tangx=cos(maxI*2*3.1415/100);
		float tangy=sin(maxI*2*3.1415/100);
		if (maxRed<100)
		{
			break;
		}
		int tmpI=maxI;
		int cnt=0;
		bool flag=true;
		while(red100[tmpI]>90 || cnt<8)
		{
			red100[tmpI]=0;
			tmpI--;cnt++;
			if (tmpI<0) tmpI=99;
		}
		tmpI=maxI+1;
		cnt=0;
		if (tmpI==100)	tmpI=0;
		while(red100[tmpI]>90 || cnt<8)
		{
			cnt++;
			red100[tmpI]=0;
			tmpI++;
			if (tmpI==100) tmpI=0;
		}
		flag=true;
		for (int a=1;a<width+3;a++)
			if (qRed(m_image.pixel(seedx+tangx*a,seedy+tangy*a))<maxRed/2)
				flag=false;
		if (flag)
		{
			direction[k*2]=tangx;
			direction[k*2+1]=tangy;
			k++;
		}

	}
	direction[2*k]=0;
	direction[2*k+1]=0;
	return k;
}

void bilinear(float &tangx, float &tangy, float seedx, float seedy, int w, int h,float * flow)
{
	float prevTangx=tangx;
	float prevTangy=tangy;
	int x1=floor(seedx);
	int x2=ceil(seedx);
	int y1=floor(seedy);
	int y2=ceil(seedy);
	float x=seedx-x1;
	float y=seedy-y1;
	const float *fseed0 = getDirection(w,h,4,flow,x1,y1);
	float tangx1=fseed0[1];
	float tangy1=-fseed0[0];
	float dist=sqrt(tangx1*tangx1+tangy1*tangy1);
	tangx1=tangx1/dist;
	tangy1=tangy1/dist;
	const float *fseed1=getDirection(w,h,4,flow,x2,y1);
	float tangx2=fseed1[1];
	float tangy2=-fseed1[0];
	dist=sqrt(tangx2*tangx2+tangy2*tangy2);
	tangx2/=dist;
	tangy2/=dist;
	const float *fseed2=getDirection(w,h,4,flow,x1,y2);
	float tangx3=fseed2[1];
	float tangy3=-fseed2[0];
	dist=sqrt(tangx3*tangx3+tangy3*tangy3);
	tangx3/=dist;
	tangy3/=dist;
	const float *fseed3=getDirection(w,h,4,flow,x2,y2);
	float tangx4=fseed3[1];
	float tangy4=-fseed3[0];
	//��ԭ����һ�£���Ҫ�㷴��
	if (tangx1*prevTangx + tangy1*prevTangy<0.0)
	{
		tangx1 = -tangx1;
		tangy1 = -tangy1;
	}
	if (tangx2*prevTangx + tangy2*prevTangy<0.0)
	{
		tangx2 = -tangx2;
		tangy2 = -tangy2;
	}
	if (tangx3*prevTangx + tangy3*prevTangy<0.0)
	{
		tangx3 = -tangx3;
		tangy3 = -tangy3;
	}
	if (tangx4*prevTangx + tangy4*prevTangy<0.0)
	{
		tangx4 = -tangx4;
		tangy4 = -tangy4;
	}
	tangx=tangx1*(1-x)*(1-y)+tangx2*x*(1-y)+tangx3*(1-x)*y+tangx4*x*y;
	tangy=tangy1*(1-x)*(1-y)+tangy2*x*(1-y)+tangy3*(1-x)*y+tangy4*x*y;
}

void rongeDirection(float &seedx,float &seedy, float &prevTangx, float &prevTangy, int w, int h, float * flow)
{
	bilinear(prevTangx,prevTangy,seedx,seedy,w,h,flow);
	float dist=Dist(prevTangx,prevTangy,0,0);
	prevTangx/=dist;
	prevTangy/=dist;
	bilinear(prevTangx,prevTangy,seedx+prevTangx/2,seedy+prevTangy/2,w,h,flow);
	dist=Dist(prevTangx,prevTangy,0,0);
	prevTangx/=dist;
	prevTangy/=dist;
	seedx+=prevTangx;
	seedy+=prevTangy;
}

void ImagePaint::adjustPos(float & seedx, float &seedy, float anglex, float angley, int w,int h, float * flow)
{
	float midx,midy;
	float max=0;	
	for (int d=-1;d<=1;d++)
	{
		int tmpx=int(seedx+anglex*d+0.5);
		int tmpy=int(seedy+angley*d+0.5);

	    if (isInImage(tmpx,tmpy,w,h))
		{
			float mag = flow[4*(tmpy*w+tmpx)+3];
			if (mag>max)
			{ 
				max=mag;
				midx=seedx+anglex*d;
				midy=seedy+angley*d;
			}
		}
	}
	seedx=midx;
	seedy=midy;//�������߽�λ��*/
}

bool ImagePaint::trackingEdge(skeleton::SkeletonGraph & sktGraph, skeleton::Edge &pos, int w, int h, float *direction, float px, float py, int cn, float *flow)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return false;
	}
	float tangx=direction[0];
	float tangy=direction[1];
	if (qRed(m_record.pixel(int(0.5+px+tangx*8),int(0.5+py+tangy*8)))==0)
	{
		return false;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float stepPos[8];
 	float fleftx,flefty,frightx,frighty;
	float width=0;
	pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	float dist=Dist(tangx,tangy,0,0);
	seedx+=tangx*8;
	seedy+=tangy*8;
	for (int i=1;i<=dist*8;i++)
		pos.m_vPoint.push_back(QPointF(px+tangx*i/dist,py+tangy*i/dist));
	if (pos.m_vPoint.size()<3)
		cout<<pos.m_vPoint.size()<<' '<<tangx<<' '<<tangy<<endl;
	tangx=tangx/dist;
	tangy=tangy/dist;
	//cout<<seedx<<','<<seedy<<endl;         
	float prevTangx=tangx;
	float prevTangy=tangy;
	bool nearJunction=true;
	seedx-=tangx;
	seedy-=tangy;
	while(cnt<1 || judgeJunctionArea(fleftx,flefty,frightx,frighty) 
		|| judgeJunctionArea(stepPos[0],stepPos[1],stepPos[4],stepPos[5],seedx,seedy))//ǰ4�����أ�����һЩ����boundary���жϣ��߳�junctionArea
	{	
		//ǰ4�����أ�����һЩ����boundary���жϣ��߳�junctionArea
		rongeDirection(seedx,seedy,prevTangx,prevTangy,w,h,flow);
		if (cnt>2)
		{
			int k=dirJunction(direction,seedx,seedy,w,h,5);
			if (k>2)
			{
				nearJunction=false;
				break;
			}
		}
		//�ж��Ƿ�����������ĩ��
		if  (qRed(m_record.pixel(int(seedx+tangx+0.5),int(seedy+tangy+0.5))<50)||!isInImage(seedx+prevTangx,seedy+prevTangy,w,h))
		{
			// TODO by jzchen: ������ĩ��ʱ���ʵ��ӳ�ĩ��λ�ã���Ȼ�����ʽ�˵��һ��
			Record(pos,8,w,h);
			return false;//���Ƿֲ棬����Ҫ�����ߣ�Ҳ����Ҫ��Junction��ջ
		}
		
		if (!findBoundary(stepPos,seedx,seedy,w,h,prevTangx,prevTangy,8,flow,m_image))//����ֱ����ǰ��������û�м�¼
		{
			//seedx=(stepPos[0]+stepPos[4])/2;
			//seedy=(stepPos[1]+stepPos[5])/2;
			pos.m_vPoint.push_back(QPointF(seedx,seedy));
			continue;
		}
		//�������ұ߽����ǶԵ��ˣ�����ʹ�ñ߽��ϵķ�����
	    const float *fseed = getDirection(w,h,4,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
		fleftx = fseed[1];
		flefty = -fseed[0];
		if (fleftx*prevTangx+flefty*prevTangy<0)
		{
			fleftx=-fleftx;
			flefty=-flefty;
		}
		const float *fseed2 = getDirection(w,h,4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		frightx = fseed2[1];
		frighty = -fseed2[0];
		if (frightx*prevTangx+frighty*prevTangy<0)
		{
			frightx=-frightx;
			frighty=-frighty;
		}
		pos.m_vPoint.push_back(QPointF(float(seedx),float(seedy)));
		cnt ++;

		/*if (recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))>0)
		{
			int index=recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))-1;
			QPointF tmpPos=sktGraph.m_vVertex[index].m_pos;
			float tangx0=tmpPos.x()-seedx;
			float tangy0=tmpPos.y()-seedy;
			dist=Dist(tangx0,tangy0,0,0);
			tangx0/=dist;
			tangy0/=dist;
			if (tangx0*prevTangx+tangy0*prevTangy>cos(3.14/9))
			{
				bool flag=true;
				for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
					if (qRed(m_image.pixel(seedx+tangx*j,seedy+tangy*j))<90)
					{
						flag=false;
						break;
					}
				if (flag)
				{
					for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
     					pos.m_vPoint.push_back(QPointF(seedx+tangx*j,seedy+tangy*j));
					pos.m_vPoint.push_back(tmpPos);
					Record(pos,8,w,h);
					return false;
				}
			}
		}*/
	}
	//////////////////////////////////////////////////////////////////////////
	/// ǰ����һ���ֵ����������߳�junction����Χ��������������һ����п��ܳ���
	/// ��������junction����
	//////////////////////////////////////////////////////////////////////////
	//�ҳ�������Ϣ
	float prevx = prevTangx;
	float prevy = prevTangy;
	vector<tracking::Pot3f> leftPos, rightPos;
	
	float leftx=stepPos[0];
	float lefty=stepPos[1];
	float rightx=stepPos[4];
	float righty=stepPos[5];
	///��ʱ�����ҽ���Ϣ�ǿ��������ġ�����ǰ�����Ƶأ�������ǰ��
	//seedx=(leftx+rightx)/2.0;
	//seedy=(lefty+righty)/2.0;
	//pos.m_vPoint.push_back(QPointF(seedx,seedy));
	float angle=atan2(prevTangx,prevTangy);
	leftPos.push_back(tracking::Pot3f(leftx,lefty,angle));
	rightPos.push_back(tracking::Pot3f(rightx,righty,angle));
	width=Dist(leftx,lefty,rightx,righty);
	bool flag=false;
	int recordCnt=0;
	cnt=0;
	float prevmidx=prevTangx;
	float prevmidy=prevTangy;
	int k=0;
	if (!nearJunction)
	{
		cnt=10;
		if (width<3)
			width=3;
		if (width>8)
			width=9;
		tangx=prevTangx;
		tangy=prevTangy;
	}
	else
	{
	while(cnt<300)
	{
		rongeDirection(leftx,lefty,prevTangx,prevTangy,w,h,flow);		
		//��һ��Ҳ��֮ǰ��
		rongeDirection(rightx,righty,prevx,prevy,w,h,flow);
		/*if (cnt>10 && recordCnt==0 && cnt%5==1)
		{
			adjustPos(leftx,lefty,-prevTangy,prevTangx,w,h,flow);
			adjustPos(rightx,righty,-prevy,prevx,w,h,flow);
		}*/
		rongeDirection(seedx,seedy,prevmidx,prevmidy,w,h,flow);
		/////////////////////////////////////////������ұ߽����һ�����ˣ�����������		
		if (!flag && (Dist(leftx,lefty,rightx,righty)<2.5 || judgeJunctionArea(leftx,lefty,rightx,righty,seedx,seedy)))
		{
			if (!findBoundary(stepPos,seedx,seedy,w,h,prevmidx,prevmidy,8,flow,m_image)) continue;
			if (Dist(leftx,lefty,stepPos[0],stepPos[1])<Dist(rightx,righty,stepPos[0],stepPos[1]))
			{
				leftx=stepPos[0];
				lefty=stepPos[1];
				rightx=stepPos[4];
				righty=stepPos[5];
			}else
			{
				rightx=stepPos[0];
				righty=stepPos[1];
				prevTangx=prevmidx;
				prevTangy=prevmidy;
				prevx=prevmidx;
				prevy=prevmidy;
				leftx=stepPos[4];
				lefty=stepPos[5];
			}
			seedx=(leftx+rightx)/2;
			seedy=(lefty+righty)/2;
			width=Dist(leftx,lefty,rightx,righty);
			if (!isInImage(seedx+prevTangx,seedy+prevTangy,w,h))
			{
				Record(pos,width,w,h);
				return false;
			}
			continue;
		}
		///////////////////////////////
		/////ʹ�������߱���ͬ��������
		for(int i=1;i<3;i++)
		{
			float tmpleftx=leftx;
			float tmplefty=lefty;
			rongeDirection(tmpleftx,tmplefty,prevTangx,prevTangy,w,h,flow);
			if (Dist(tmpleftx,tmplefty,rightx,righty)<Dist(leftx,lefty,rightx,righty))
			{
				leftx=tmpleftx;
			    lefty=tmplefty;
			}else
			{
				float tmprightx=rightx;
				float tmprighty=righty;
				rongeDirection(tmprightx,tmprighty,prevx,prevy,w,h,flow);
				if (Dist(tmprightx,tmprighty,leftx,lefty)<Dist(rightx,righty,leftx,lefty))
				{
					rightx=tmprightx;
					righty=tmprighty;
				}else///���Ҷ������ƶ��ˣ���ǰλ����ѣ����Կ���������
					break;
			}
		}
		float angle1=atan2(prevTangy,prevTangx);
		float angle2=atan2(prevx,prevy);
		leftPos.push_back(tracking::Pot3f(leftx,lefty,angle1));
		rightPos.push_back(tracking::Pot3f(rightx,righty,angle2));
		//////////////�������ҵ���ͬ���ˣ������������ұ߽�ľ������ж��Ƿ�ֿ���
		
		///�ж��Ƿ����junction
		cnt++;
		//cout<<leftx<<','<<lefty<<"    "<<(leftx+rightx)/2<<','<<(lefty+righty)/2<<"      "<<rightx<<','<<righty<<endl;
		if (!flag && cnt>3)
		{
			////���������һ���ǵ��߶�ĩβ�ˣ�һ�������߷ֿ���
			float fleftx=(leftPos[leftPos.size()-1].x-leftPos[leftPos.size()-4].x)/3;
			float flefty=(leftPos[leftPos.size()-1].y-leftPos[leftPos.size()-4].y)/3;
			float frightx=(rightPos[rightPos.size()-1].x-rightPos[rightPos.size()-4].x)/3;
			float frighty=(rightPos[rightPos.size()-1].y-rightPos[rightPos.size()-4].y)/3;
		    if (qRed(m_image.pixel((leftx+rightx)/2,(righty+righty)/2))>0)
			{
				seedx=(leftx+rightx)/2;////
				seedy=(lefty+righty)/2;////
			}
			//pos.m_vPoint.push_back(QPointF(seedx,seedy));
			if (judgeJunctionArea(fleftx,flefty,frightx,frighty))///���߷ֿ�30�������
			{
				flag=true;
				recordCnt=cnt;
			}
			width=Dist(leftx,lefty,rightx,righty);///�����������������Щ�仯����Ҫ��ʱ����
			if (/*judgeEdgeEnd(seedx,seedy,prevTangx,prevTangy,w,h,3,m_image) 
				|| judgeEdgeEnd(seedx,seedy,prevx,prevy,w,h,3,m_image)
				||*/judgeEdgeEnd(seedx,seedy,prevTangx,prevTangy,w,h,2,m_record) 
				|| judgeEdgeEnd(seedx,seedy,prevx,prevy,w,h,2,m_record)
				)
			{
				///��һ�䲻�ܷ������棬�����ڷֲ��·��Ҳ�ᱻ�жϳ�edgeEnd
				pos.m_vPoint.push_back(QPointF(seedx+prevmidx*2,seedy+prevmidy*2));
				Record(pos,width,w,h);
				return false;
			}

		}
		if (/*cnt>3 && */!flag)
		{
			pos.m_vPoint.push_back(QPointF(seedx,seedy));
			if (cnt%3==0)
			{
				k=dirJunction(direction,seedx,seedy,w,h,width);
				if (k>2)
				{
					flag=true;
					recordCnt=cnt;
				}
			}
			//seedx=(leftx+rightx)/2;
			//seedy=(lefty+righty)/2;
		}
		///����֮���Ѿ����ֹ��ˣ�
		if (flag && (Dist(leftx,lefty,rightx,righty)>3*width && Dist(leftx,lefty,rightx,righty>15) || cnt-recordCnt>=15))///������ֿ���һ��û����ģ����淽���Ǵӿ�ʼ�б仯֮���ٿ�ʼ��
		{
			break;
		}
		if (!isInImage(leftx+prevTangx,lefty+prevTangy,w,h) || !isInImage(rightx+prevx,righty+prevy,w,h))
		{
			if (!flag)//��û��Junction�������ˣ�˵����������ĩβ
			{
				Record(pos,width,w,h);
			}else//�Ѿ�����junction������Ҫ����ȥѰ�Һ�����Junctionλ��
			{
				break;
			}
		}
		if (!isInImage(seedx+prevmidx,seedy+prevmidy,w,h))
		{
			Record(pos,width,w,h);
			return false;
		}
		if (cnt>=5 && qRed(m_record.pixel(pos.m_vPoint[pos.m_vPoint.size()-4].x(),pos.m_vPoint[pos.m_vPoint.size()-4].y()))==0)
		{
			Record(pos,width,w,h);
			return false;
		}
		//cout<<seedx<<','<<seedy;
		if (recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))>0)
		{
			int index=recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))-1;
			QPointF tmpPos=sktGraph.m_vVertex[index].m_pos;
			float tangx0=tmpPos.x()-seedx;
			float tangy0=tmpPos.y()-seedy;
			dist=Dist(tangx0,tangy0,0,0);
			tangx0/=dist;
			tangy0/=dist;
			if (tangx0*prevTangx+tangy0*prevTangy>cos(3.14/6))
			{
				bool flag=true;
				for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
					if (qRed(m_image.pixel(seedx+tangx0*j,seedy+tangy0*j))<90)
					{
						flag=false;
						break;
					}
			}
				if (flag||Dist(tmpPos.x(),tmpPos.y(),seedx,seedy)<3)
				{
					float tmpx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
					float tmpy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
					prevmidx=tmpx-pos.m_vPoint[pos.m_vPoint.size()-2].x();
					prevmidy=tmpy-pos.m_vPoint[pos.m_vPoint.size()-2].y();
					if (recordCnt>0)
					for (int j=1;j<cnt-recordCnt;j++)
					{
						rongeDirection(tmpx,tmpy,prevmidx,prevmidy,w,h,flow);
     					pos.m_vPoint.push_back(QPointF(tmpx,tmpy));
					}

					for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
     					pos.m_vPoint.push_back(QPointF(seedx+tangx0*j,seedy+tangy0*j));
					pos.m_vPoint.push_back(tmpPos);
					Record(pos,width,w,h);
					return false;
				}
		}
	}
	
	/////////////////////////////////////////////////
	seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
	seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
	tangx=seedx-pos.m_vPoint[pos.m_vPoint.size()-3].x();
	tangy=seedy-pos.m_vPoint[pos.m_vPoint.size()-3].y();
	dist=Dist(0,0,tangx,tangy);
	tangx/=dist;
	tangy/=dist;
	}
	for (int i=recordCnt;i<cnt;i++)
	{
		seedx+=tangx;
		seedy+=tangy;
		float anglex=tangy;
		float angley=-tangx;
		float max=0;
		float midx=seedx;
		float midy=seedy;
		for (int d=-1;d<=1;d++)
		{
			int tmpx=int(seedx+anglex*d+0.5);
			int tmpy=int(seedy+angley*d+0.5);
		    if (isInImage(tmpx,tmpy,w,h))
			{
				if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{ 
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=seedx+anglex*d;
					midy=seedy+angley*d;
				}
			}
		}
		seedx=midx;
		seedy=midy;
        if (!isInImage(seedx,seedy,w,h))
		{
			Record(pos,width,w,h);
			return false;
		}
		if (recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))>0)
		{
			int index=recordPoint.pixelIndex(int(0.5+seedx),int(0.5+seedy))-1;
			QPointF tmpPos=sktGraph.m_vVertex[index].m_pos;
			float tangx0=tmpPos.x()-seedx;
			float tangy0=tmpPos.y()-seedy;
			dist=Dist(tangx0,tangy0,0,0);
			tangx0/=dist;
			tangy0/=dist;
			if (tangx0*prevTangx+tangy0*prevTangy>cos(3.14/6))//30��
			{
				bool flag=true;
				for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
					if (qRed(m_image.pixel(seedx+tangx0*j,seedy+tangy0*j))<90)
					{
						flag=false;
						break;
					}
			}
				if (flag||Dist(tmpPos.x(),tmpPos.y(),seedx,seedy)<3)
				{
					for (int j=1;j<Dist(tmpPos.x(),tmpPos.y(),seedx,seedy);j++)
     					pos.m_vPoint.push_back(QPointF(seedx+tangx0*j,seedy+tangy0*j));
					pos.m_vPoint.push_back(tmpPos);
					Record(pos,width,w,h);
					return false;
				}
		}

		pos.m_vPoint.push_back(QPointF(seedx,seedy));
		tangx=seedx-pos.m_vPoint[pos.m_vPoint.size()-3].x();
		tangy=seedy-pos.m_vPoint[pos.m_vPoint.size()-3].y();
		dist=Dist(tangx,tangy,0,0);
		tangx/=dist;
		tangy/=dist;
		if (qRed(m_image.pixel(seedx+tangx,seedy+tangy))<90)
		{
			cnt=i;
			break;
		}
	}
	/*seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
	seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
	for (int i=recordCnt;i<cnt+3;i++)
	{
		rongeDirection(seedx,seedy,tangx,tangy,w,h,flow);
		float midx=seedx;
		float midy=seedy;
		float max=0;
		for (int d=-1;d<=1;d++)
		{
			int tmpx=int(seedx-tangy*d+0.5);
			int tmpy=int(seedy+tangx*d+0.5);
		    if (isInImage(tmpx,tmpy,w,h))
			{
				if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{ 
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=seedx-tangy*d;
					midy=seedy+tangx*d;
				}
			}
		}
		seedx=midx;
		seedy=midy;
		pos.m_vPoint.push_back(QPointF(seedx,seedy));
	}*/
	/////////////////////////////////////////////////
	int recordI=pos.m_vPoint.size()-cnt+recordCnt+3;
	int maxK=2;
	int maxRed=0;
	prevTangx=tangx;
	prevTangy=tangy;
	if (width<5) width=5;

	for (int i=max(1,pos.m_vPoint.size()-cnt+recordCnt);i<pos.m_vPoint.size();i++)
	{
		float tmpx=pos.m_vPoint[i].x();
		float tmpy=pos.m_vPoint[i].y();
		k=dirJunction(direction,tmpx,tmpy,w,h,width);
		int red=0;
		for (int j=0;j<k;j++)
		{
			for (int t=0;t<width+4;t++)
			{
				red+=qRed(m_image.pixel(tmpx+t*direction[j*2],tmpy+t*direction[j*2+1]));
			}
		}

		if (k>maxK || k==maxK && red>maxRed)
		{
			recordI=i;
			seedx=pos.m_vPoint[i].x();
			seedy=pos.m_vPoint[i].y();
			prevTangx=pos.m_vPoint[i].x()-pos.m_vPoint[i-4].x();
			prevTangy=pos.m_vPoint[i].y()-pos.m_vPoint[i-4].y();
			dist=Dist(prevTangx,prevTangy,0,0);
			prevTangx/=dist;
			prevTangy/=dist;
			maxK=k;
			maxRed=red;
		}
	}
	k=dirJunction(direction,seedx,seedy,w,h,width);
	
	////�Ѽ�����·��λ�ö��Һ��ˣ�������������junction�����ģ�������ǰ�ķ���
	
	for (int i=pos.m_vPoint.size()-1;i>recordI;i--)
		pos.m_vPoint.pop_back();
	
	direction[2*k]==0;
	direction[2*k+1]=width+3;

	for (int i=0;i<k;i++)
	{
		flag=true;
		/*for (int a=3;a<width+2;a++)
    		if (qRed(m_record.pixel(seedx+direction[i*2]*a,seedy+direction[i*2+1]*a))<90)//���������õ���record,����Ϊ�˱��ⲻ��Ҫ�ķ�֧
				flag=false;*/
		if (flag && -direction[i*2]*prevTangx-direction[i*2+1]*prevTangy<=cos(3.14/10))
		{

		}else
		{
			for (int j=i;j<k;j++)
			{
				direction[i*2]=direction[i*2+2];
				direction[i*2+1]=direction[i*2+3];
			}
			k--;
			i--;
		}
	}
	for (int i=0;i<k;i++)
	{
		direction[i*2]*=(width+3)/8;
		direction[i*2+1]*=(width+3)/8;
	}
	//��¼
	Record(pos,width,w,h);
	return true;
}
