#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);
	
	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	ImagePaint::tracking(sktGraph, m_imgSize.width(),m_imgSize.height(),4,pGradS,m_trackingLength);
	
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}

float Dist(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}

bool judgeJunctionArea(float *leftPos,float *rightPos)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0&&rightPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];///��ʵӦ�������������ֿ����ǵ�junction point,�ӽ��Ļ������ڵ�end point
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)
		if (Dist(leftPos[i],leftPos[i+1],rightPos[i],rightPos[i+1])<Dist(leftPos[8],leftPos[9],rightPos[8],rightPos[9]))//cos30
	{
		return true;//directions we got from left and right boundaries are too different ==> junction area
	}
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>=magMax)
			{
				distMax = k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>=magMax)
			{
				distMax = -k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

void ImagePaint::centerDirection(float* tang, int w, int h, int cn, float px, float py, float *flow)
{
	float stepPos[8];
	const int proWidth = 8;
	findStepPosition(stepPos,px,py,w,h,proWidth, flow);
	float fleftx,flefty,frightx,frighty;
	if (isInImage(stepPos[0],stepPos[1],w,h))
	{
	    const float *fleft = getDirection(w, h, cn,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	    fleftx=fleft[1];
	    flefty=-fleft[0];
	}else
	{
		const float *fleft = getDirection(w, h, cn,flow,int(px+0.5),int(py+0.5));
		fleftx=fleft[1];
	    flefty=-fleft[0];

	}
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	if (isInImage(stepPos[4],stepPos[5],w,h))
	{
		const float *fright = getDirection(w,h, 4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}else
	{
		const float *fright = getDirection(w,h, 4,flow,int(px+0.5),int(py+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	//float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	//return tang;
}

bool judgeJunctionArea(float leftx,float lefty,float rightx,float righty,float seedx,float seedy)
{
	float dist1=Dist(leftx,lefty,seedx,seedy);
    float dist2=Dist(rightx,righty,seedx,seedy);
	if (dist1>10 && dist1>2*dist2 || dist2>10 && dist2>2*dist1)
		return true;
	return false;
}
bool judgeJunctionArea(float fleftx,float flefty,float frightx,float frighty)
{
	float cosine=(fleftx*frightx+flefty*frighty)/Dist(fleftx,flefty,0,0)/Dist(frightx,frighty,0,0);
	if (cosine>=cos(3.1415/6))
		return false;
	return true;//��junctionArea��
}
bool findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(xx-tangy+0.5),int(yy+tangx+0.5))))
			{
				distMax = k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)//
			break;
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����������Ӧ��ͨ���ж�����֤��ʱ�����ұ߽粻��ʹ��
	{
		return false;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
		if (qRed(m_image.pixel(stepPos[0]-2*tangy,stepPos[1]+2*tangx))>50)///////˵���߽绹����Щ����ɣ��п�����������·���һ������
			flag=true;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>=magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(int(0.5+xx+tangy),int(0.5+yy-tangx))))
			{
				distMax = -k;
				magMax = abs(mag);
			}else
			{
				if (distMax>5)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<10)
			break;
	}
	if (flag)
	{
		return false;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
		if (qRed(m_image.pixel(stepPos[4]+2*tangy,stepPos[5]-2*tangx))>50)
			return false;
	}
	return true;
}

bool judgeEdgeEnd(float px,float py, float tangx, float tangy, int w,int h, int radius,QImage m_image)
{
	if (!isInImage(px+tangx*radius,py+tangy*radius,w,h)||qRed(m_image.pixel(px+tangx*radius,py+tangy*radius))==0)
		return true;
	return false;
}


void ImagePaint::tracking(skeleton::SkeletonGraph &sktGraph, int w, int h, int cn, float *flow, int maxLength)
{
	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<QPointF> vertexStack,vertexRecord;//second one means angle
    vector<QPointF> angleStack,angleRecord;
	vector<int> angleLabel;/////����Ǽ�¼��������ڶ����еı��

	/// get the original direction
	//QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	float tang[2];
	m_record=m_image;/////

	centerDirection(tang, m_imgSize.width(),m_imgSize.height(),4,sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y(),flow);
	vertexStack.push_back(sktGraph.m_vVertex[0].m_pos);
	angleStack.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexStack.push_back(sktGraph.m_vVertex[0].m_pos);
	angleStack.push_back(QPointF(tang[0],tang[1]));
	angleLabel.push_back(0);
	angleLabel.push_back(1);
	sktGraph.m_vVertexProperty.push_back(skeleton::VertexCircle(0,2));
	sktGraph.m_vVertexProperty[sktGraph.m_vVertexProperty.size()-1].direction[0]=QPointF(-tang[0],-tang[1]);
	sktGraph.m_vVertexProperty[sktGraph.m_vVertexProperty.size()-1].direction[0]=QPointF(tang[0],tang[1]);
	int cnt=0;
	while(!vertexStack.empty()&&cnt<=maxLength)//////////////////////
	{
		cnt++;
		//cout<<cnt<<"     ";
		///��ջ
		vertexRecord.push_back(vertexStack[vertexStack.size()-1]);
		QPointF vertex=vertexStack[vertexStack.size()-1];
		vertexStack.pop_back();
		angleRecord.push_back(angleStack[angleStack.size()-1]);
		QPointF angle=angleStack[angleStack.size()-1];
		angleStack.pop_back();
		int index=angleLabel[angleLabel.size()-1];
		angleLabel.pop_back();
		//skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGradS,vertexStack,angleStack, vertexRecord, angleRecord);

		float seedx=vertex.x();
		float seedy=vertex.y();
		float tangx=angle.x();
		float tangy=angle.y();
		skeleton::Edge pos;//(QPointF(px,py));
		if(seedx<0 || seedy<0 || seedx>=w || seedy>=h)
		{
			cout << "seed should not out of the image." << endl;
			continue;
		}

		float prevTangx = tangx;
		float prevTangy = tangy;
		float stepPos[8];
		const int proWidth = 8;

		////first step: get out of the junction area, Ӧ���ȸ�������ĳһ������
		float direction[12];
		direction[0]=tangx;
		direction[1]=tangy;
		if (!ImagePaint::trackingEdge(pos,w,h,direction,seedx,seedy,cn,flow))///meet a junction point
		//seedx,seedy,startx,starty���ĸ������������������������ķ���
		{//record the two possible vectors
			//junction�Լ�������ջ��
			///////////////////////////////////���һ��ÿ��junction��Χ������
			int index1=sktGraph.indexVertex(pos.m_vPoint[0]);

			if (pos.m_vPoint.size()>3)
			{
				int pointSz=pos.m_vPoint.size();
				QPointF m_jPoint=pos.m_vPoint[pointSz-1];//����Ǹ�����junction point
				sktGraph.m_vVertexProperty[index1].index[index]=sktGraph.m_vEdge.size();
				int index2=sktGraph.indexVertex(m_jPoint);
				////////////////////��Ҫԭ���ĵ���µĵ�֮����ͨ·����
				if (index2>=0 && 
					Dist(m_jPoint.x(),m_jPoint.y(),sktGraph.m_vVertex[index2].m_pos.x(),sktGraph.m_vVertex[index2].m_pos.y())>5)
				{
					float tangx1=m_jPoint.x()-sktGraph.m_vVertex[index2].m_pos.x();
					float tangy1=m_jPoint.y()-sktGraph.m_vVertex[index2].m_pos.y();
					float tangx2=m_jPoint.x()-pos.m_vPoint[pointSz-4].x();
					float tangy2=m_jPoint.y()-pos.m_vPoint[pointSz-4].y();
					float dist=Dist(tangx1,tangy1,0,0);
					tangx1/=dist;
					tangy1/=dist;
					dist=Dist(tangx2,tangy2,0,0);
					tangx2/=dist;
					tangy2/=dist;
					if (abs(tangx1*tangx2+tangy1*tangy2)<cos(3.14/6))/////��Ҫ�жϺϲ��Ƿ������������ϲ��ĵ��������ǰ�������ϾͿ����ǲ��е������ϵĵ�����	
					{
						index2=-1;
					}
				}
				int k=0;
				if (index2==-1)//�µĵ������
				{
					sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));					
					index2=sktGraph.m_vVertex.size()-1;
					while(direction[2*k]!=0)
					{
						int cases=0;
						tangx=direction[2*k];
						tangy=direction[2*k+1];
						vertexStack.push_back(QPointF(pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y()));
						angleStack.push_back(QPointF(tangx,tangy));
						angleLabel.push_back(k);
				//		cout<<vertexStack[vertexStack.size()-1].x()<<','<<vertexStack[vertexStack.size()-1].y()<<endl;
				//		cout<<angleStack[angleStack.size()-1].x()<<' '<<angleStack[angleStack.size()-1].y()<<endl;
						k++;
					}
					sktGraph.m_vVertexProperty.push_back(skeleton::VertexCircle(direction[2*k+1],k+1));//m_width��m_k
					int propSz=sktGraph.m_vVertexProperty.size();
					float tangx=(pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-4].x())/3;
					float tangy=(pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-4].y())/3;
					float dist=Dist(tangx,tangy,0,0);
					tangx/=dist;
					tangy/=dist;
					sktGraph.m_vVertexProperty[propSz-1].direction[0]=QPointF(tangx,tangy);
					sktGraph.m_vVertexProperty[propSz-1].index[0]=sktGraph.m_vEdge.size();
					for (int j=0;j<k;j++)
						sktGraph.m_vVertexProperty[sktGraph.m_vVertexProperty.size()-1].direction[j+1]=QPointF(direction[2*j],direction[2*j+1]);
								
				}else//��֮ǰ�Ѿ���¼���Ķ��㣬���Բ���Ҫ���¼�¼��
				{
					pos.m_vPoint[pointSz-1]=sktGraph.m_vVertex[index2].m_pos;
					
				}
				sktGraph.m_vVertex42edge.push_back(index1);
				sktGraph.m_vVertex42edge.push_back(index2);
				sktGraph.m_vEdge.push_back(pos);
			}
		}
		else if (pos.m_vPoint.size()>3)
		{
			int pointSz=pos.m_vPoint.size();
			QPointF m_jPoint=pos.m_vPoint[pointSz-1];//����Ǹ�����junction point
			int index1=sktGraph.indexVertex(pos.m_vPoint[0]);
			sktGraph.m_vVertexProperty[index1].index[index]=sktGraph.m_vEdge.size();
			int index2=sktGraph.indexVertex(m_jPoint);
			if (index2>=0 && 
				Dist(m_jPoint.x(),m_jPoint.y(),sktGraph.m_vVertex[index2].m_pos.x(),sktGraph.m_vVertex[index2].m_pos.y())>5)
			{
				float tangx1=m_jPoint.x()-sktGraph.m_vVertex[index2].m_pos.x();
				float tangy1=m_jPoint.y()-sktGraph.m_vVertex[index2].m_pos.y();
				float tangx2=m_jPoint.x()-pos.m_vPoint[pointSz-4].x();
				float tangy2=m_jPoint.y()-pos.m_vPoint[pointSz-4].y();
				float dist=Dist(tangx1,tangy1,0,0);
				tangx1/=dist;
				tangy1/=dist;
				dist=Dist(tangx2,tangy2,0,0);
				tangx2/=dist;
				tangy2/=dist;
				if (abs(tangx1*tangx2+tangy1*tangy2)<cos(3.14/6))/////��Ҫ�жϺϲ��Ƿ������������ϲ��ĵ��������ǰ�������ϾͿ����ǲ��е������ϵĵ�����	
				{
					index2=-1;
				}
			}
			if (index2==-1)
			{
				sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,false));
				index2=sktGraph.m_vVertex.size()-1;
				//sktGraph.m_direction.push_back(direction);
				sktGraph.m_vVertexProperty.push_back(skeleton::VertexCircle(0,1));//m_width��m_k
				int propSz=sktGraph.m_vVertexProperty.size();
				float tangx=(pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-4].x())/3;
				float tangy=(pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-4].y())/3;
				float dist=Dist(tangx,tangy,0,0);
				tangx/=dist;
				tangy/=dist;
				sktGraph.m_vVertexProperty[propSz-1].direction[0]=QPointF(tangx,tangy);			
			}else
			{
				pos.m_vPoint[pointSz-1]=sktGraph.m_vVertex[index2].m_pos;
			}
			sktGraph.m_vVertex42edge.push_back(index1);
			sktGraph.m_vVertex42edge.push_back(index2);
			sktGraph.m_vEdge.push_back(pos);
		}
	}
}

bool leftWay(vector<tracking::Pot3f> &leftPos, vector<tracking::Pot3f> &rightPos, int recordCnt)
{
	float left=0;
	float right=0;
	for (int i=recordCnt+1;i<leftPos.size();i++)
	{
		if (abs(leftPos[i].ang-leftPos[i-1].ang)>3)
		   left+=abs(-3.1415*2+abs(leftPos[i].ang-leftPos[i-1].ang));
		else
    		left+=abs(leftPos[i].ang-leftPos[i-1].ang);
		if (abs(rightPos[i].ang-rightPos[i-1].ang)>3)
			right+=abs(-3.1415*2+abs(rightPos[i].ang-rightPos[i-1].ang));
		else
    		right+=abs(rightPos[i].ang-rightPos[i-1].ang);
	}
	if (left<right)
		return true;
	return false;
}

void ImagePaint::Record(skeleton::Edge &pos, float width, int w, int h)
{
	if (width>8) width=8;
	if (pos.m_vPoint.size()>3)
	for (int i=1;i<pos.m_vPoint.size()-width;i++)
	{
		float px=pos.m_vPoint[i].x();
		float py=pos.m_vPoint[i].y();
		for (int xx=int(-width/2-0.5);xx<width/2+0.6;xx++)
			for (int yy=int(-width/2-0.5);yy<width/2+0.6;yy++)
				if (xx*xx+yy*yy<=width*width/4 && isInImage(int(px+xx+0.5),int(py+yy+0.5),w,h))
				{
					m_record.setPixel(int(px+xx+0.5),int(py+yy+0.5),0);
				}
	}
}

int ImagePaint::dirJunction(float *direction, int seedx,int seedy,int w,int h,int width)
{
	int red100[100];
	int k=0;
	if (width<5)
		width=5;
	int recordk=0;
	for (int i=0;i<100;i++)///��i�����Ӧ�ĽǶ���i/100*2*pi
	{
		float tmpx=seedx+cos(2*3.14*i/100)*(width+5);
		float tmpy=seedy+sin(2*3.14*i/100)*(width+5);
		if (!isInImage(tmpx,tmpy,w,h))
		{
			red100[i]=0;
			continue;
		}
		red100[i]=qRed(m_image.pixel(tmpx,tmpy));
	}
	while(k<=4)
	{
		recordk++;
		//�������ĵ�;
		float maxRed=0;
		float maxI=0;
		for (int i=0;i<100;i++)
		{
			if (red100[i]>maxRed)
			{
				maxRed=red100[i];
				maxI=i;
			}
		}
		float tangx=cos(maxI*2*3.1415/100);
		float tangy=sin(maxI*2*3.1415/100);
		if (maxRed<100)
		{
			break;
		}
		int tmpI=maxI;
		int cnt=0;
		bool flag=true;
		while(red100[tmpI]>90 || cnt<3)
		{
			red100[tmpI]=0;
			tmpI--;cnt++;
			if (tmpI<0) tmpI=99;
		}
		tmpI=maxI+1;
		cnt=0;
		if (tmpI==100)	tmpI=0;
		while(red100[tmpI]>90 || cnt<3)
		{
			cnt++;
			red100[tmpI]=0;
			tmpI++;
			if (tmpI==100) tmpI=0;
		}
		flag=true;
		for (int a=0;a<width+5;a++)
			if (qRed(m_image.pixel(seedx+tangx*a,seedy+tangy*a))<90)
				flag=false;
		if (flag)
		{
			direction[k*2]=tangx;
			direction[k*2+1]=tangy;
			k++;
		}

	}
	direction[2*k]=0;
	direction[2*k+1]=0;
	if (recordk==1)
		return 1;
	return max(k,2);
}

bool ImagePaint::trackingEdge(skeleton::Edge &pos, int w, int h, float *direction, float px, float py, int cn, float *flow)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return true;
		//return pos;
	}
	float tangx=direction[0];
	float tangy=direction[1];
	if (qRed(m_record.pixel(int(0.5+px+tangx*8),int(0.5+py+tangy*8)))==0 || qRed(m_record.pixel(int(0.5+px+tangx*4),int(0.5+py+tangy*4)))==0)
	{
		return true;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float stepPos[8];
 	float fleftx,flefty,frightx,frighty;
	float width=0;
	pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	seedx+=tangx*8;
	seedy+=tangy*8;
	float dist=sqrt(tangx*tangx+tangy*tangy);
	tangx=tangx/dist;
	tangy=tangy/dist;
	pos.m_vPoint.push_back(QPointF(seedx,seedy));//ֱ���߳���
	//cout<<seedx<<','<<seedy<<endl;         
	float prevmidx=tangx;
	float prevmidy=tangy;
	int k=0;
	bool flag=false;
	int recordCnt=0;
	findBoundary(stepPos,seedx,seedy,w,h,tangx,tangy,8,flow,m_image);
	width=Dist(stepPos[0],stepPos[1],stepPos[4],stepPos[5]);
	while(cnt<300)
	{
		const float *fseed0 = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		tangx = fseed0[1];
		tangy = -fseed0[0];
		dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;
		//��ԭ����һ�£���Ҫ�㷴��
		float tangsign = tangx*prevmidx + tangy*prevmidy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		seedx += tangx;
		seedy += tangy;
		prevmidx = tangx;
		prevmidy = tangy;
		//////////////�������ҵ���ͬ���ˣ������������ұ߽�ľ������ж��Ƿ�ֿ���
		
		///�ж��Ƿ����junction
		cnt++;
		if (!flag)
		{
			k=dirJunction(direction,seedx,seedy,w,h,width);
			pos.m_vPoint.push_back(QPointF(seedx,seedy));
			if (isInImage(seedx-width-5,seedy-width-5,w-2*width-10,h-2*width-10) && k<=1)
			{
				Record(pos,width,w,h);
				return true;
			}
		}

		if (cnt>3 && !flag)
		{
			if (k>2)
			{
				flag=true;
				recordCnt=cnt;
			}
		}
		if (!isInImage(seedx+tangx*2,seedy+tangy*2,w,h))
		{
			Record(pos,width,w,h);
			return true;
		}

		///����֮���Ѿ����ֹ��ˣ�
		if (flag && cnt-recordCnt>10)
			break;

	}
	
	/////////////////////////////////////////////////
	seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
	seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
	tangx=seedx-pos.m_vPoint[pos.m_vPoint.size()-3].x();
	tangy=seedy-pos.m_vPoint[pos.m_vPoint.size()-3].y();
	dist=Dist(0,0,tangx,tangy);
	tangx/=dist;
	tangy/=dist;
	for (int i=recordCnt;i<cnt;i++)
	{
		seedx+=tangx;
		seedy+=tangy;
        float anglex=tangy;
		float angley=-tangx;
		float max=0;
		/*float midx=seedx;
		float midy=seedy;
		for (int d=-1;d<1;d++)
		{
			int tmpx=int(seedx+anglex*d+0.5);
			int tmpy=int(seedy+angley*d+0.5);
		    if (isInImage(tmpx,tmpy,w,h))
			{
				if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{ 
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=seedx+anglex*d;
					midy=seedy+angley*d;
				}
			}
		}
		seedx=midx;
		seedy=midy;*/
		pos.m_vPoint.push_back(QPointF(seedx,seedy));
		/*tangx=seedx-pos.m_vPoint[pos.m_vPoint.size()-3].x();
		tangy=seedy-pos.m_vPoint[pos.m_vPoint.size()-3].y();
		dist=Dist(tangx,tangy,0,0);
		tangx/=dist;
		tangy/=dist;*/
		if (qRed(m_image.pixel(seedx+tangx,seedy+tangy))<50)
		{
			cnt=i;
			break;
		}
	}
	/////////////////////////////////////////////////
	int recordI=pos.m_vPoint.size()-cnt+recordCnt+3;
	int maxK=2;
	int maxRed=0;
	float prevTangx=tangx;
	float prevTangy=tangy;
	for (int i=max(1,pos.m_vPoint.size()-cnt+recordCnt);i<pos.m_vPoint.size();i+=2)
	{
		float tmpx=pos.m_vPoint[i].x();
		float tmpy=pos.m_vPoint[i].y();
		k=dirJunction(direction,tmpx,tmpy,w,h,width);
		float position[10];
		for (int j=0;j<k;j++)
		{
			position[2*j]=seedx+direction[2*j]*(width+5);
			position[2*j+1]=seedy+direction[2*j+1]*(width+5);
		}
		int red=0;
		for (int j=0;j<k;j++)
		{
			float xx=position[j*2];
			float yy=position[j*2+1];
			red+=qRed(m_image.pixel((tmpx+3*xx)/4,(tmpy+3*yy)/4))+qRed(m_image.pixel((tmpx+xx)/2,(tmpy+yy)/2));
			red+=qRed(m_image.pixel((tmpx*3+xx)/4,(tmpy*3+yy)/4))+qRed(m_image.pixel(tmpx,tmpy));
		}

		if (k>maxK || k==maxK && red>maxRed)
		{
			recordI=i;
			seedx=pos.m_vPoint[i].x();
			seedy=pos.m_vPoint[i].y();
			prevTangx=pos.m_vPoint[i].x()-pos.m_vPoint[i-1].x();
			prevTangy=pos.m_vPoint[i].y()-pos.m_vPoint[i-1].y();
			maxK=k;
			maxRed=red;
		}
	}
	//k=dirJunction(direction,seedx,seedy,w,h,width);
	
	////�Ѽ�����·��λ�ö��Һ��ˣ�������������junction�����ģ�������ǰ�ķ���
	
	for (int i=pos.m_vPoint.size()-1;i>recordI;i--)
		pos.m_vPoint.pop_back();
	
	///���¶�λ����
	int red100[100];
	k=0;
	if (width<3) width=3;
	int recordk=0;
	while (recordk<maxK && width<12)
	{
		recordk=0;
		for (int i=0;i<100;i++)///��i�����Ӧ�ĽǶ���i/100*2*pi
		{
			float tmpx=seedx+cos(2*3.14*i/100)*(width+5);
			float tmpy=seedy+sin(2*3.14*i/100)*(width+5);
			if (!isInImage(tmpx,tmpy,w,h))
			{
				red100[i]=0;
				continue;
			}
			red100[i]=qRed(m_image.pixel(tmpx,tmpy));//����Ҫȡԭ���ģ���Ϊrecord���ܰ�һ���߷ֳ������룬Ȼ��ͻ�������Ҫ�ķ�֧
		}
		while(k<=4)
		{
			//�������ĵ�;
	 		float maxRed=0;
			float maxI=0;
			for (int i=0;i<100;i++)
	 		{
				if (red100[i]>maxRed)
				{
					maxRed=red100[i];
					maxI=i;
				}
			}
			float tangx=cos(maxI*2*3.1415/100);
			float tangy=sin(maxI*2*3.1415/100);
			if (maxRed<100)
			{
				break;
			}
			recordk++;
			//if (-tangx*recordx-tangy*recordy<=cos(3.14/12)&&m_record.pixel(int(0.5+seedx+tangx*width),int(0.5+seedy+tangy*width))>20)
			bool flag=true;
			for (int a=0;a<width+4;a++)
				if (qRed(m_record.pixel(seedx+tangx*a,seedy+tangy*a))<90)//���������õ���record,����Ϊ�˱��ⲻ��Ҫ�ķ�֧
					flag=false;
			if (flag && -tangx*prevTangx-tangy*prevTangy<=cos(3.14/12))
			//	if (m_record.pixel(int(0.5+seedx+tangx*width/3),int(0.5+seedy+tangy*width/3))>20 && m_record.pixel(int(0.5+seedx+tangx*2*width/3),int(0.5+seedy+tangy*2*width/3))>20)
			{
				direction[k*2]=tangx*(width+4)/8;
				direction[k*2+1]=tangy*(width+4)/8;
				k++;
			}
			int tmpI=maxI;
			cnt=0;
			while(red100[tmpI]>90 || cnt<5)
			{
				red100[tmpI]=0;
				tmpI--;cnt++;
				if (tmpI<0) tmpI=99;
			}
			tmpI=maxI+1;
			if (tmpI==100)	tmpI=0;
			cnt=0;
			while(red100[tmpI]>90 || cnt<5)
			{
				cnt++;
				red100[tmpI]=0;
				tmpI++;
				if (tmpI==100) tmpI=0;
			}
		}
		width+=2;
	}
	direction[2*k]=0;
	direction[2*k+1]=width+1;////������������������ȴ�������
	//k=dirJunction(direction, seedx, seedy,w,h,width,recordx,recordy);
	//��¼
	Record(pos,width,w,h);
	return false;
}
