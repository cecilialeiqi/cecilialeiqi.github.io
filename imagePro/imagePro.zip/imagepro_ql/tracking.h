#pragma once 

#include <vector>
#include <iostream>
using namespace std;

namespace tracking
{
	struct Pot3
	{
		int		x;
		int		y;
		float	ang;
		Pot3(int xx=0,int yy=0, float a=0.0):x(xx),y(yy),ang(a){};
	};

	struct Pot3f
	{
		float		x;
		float		y;
		float		ang;
		Pot3f(float xx=0.0,float yy=0.0, float a=0.0):x(xx),y(yy),ang(a){};
	};

	struct Pot2
	{
		int x;
		int y;
		Pot2(int xx=0,int yy=0):x(xx),y(yy){};
	};

	struct Pot2f
	{
		float x;
		float y;
		Pot2f(float xx=0.0,float yy=0.0):x(xx),y(yy){};
	};

	#define MAX_STREAM_SIZE 3000

	vector<Pot3f> streamlineEular(float px, float py, int w, int h, int cn, float *flow, 
		 int interp=0, int maxLen=MAX_STREAM_SIZE);

	vector<Pot3f> streamlineRungeKutta(float px, float py, int w, int h, int cn, float *flow, 
		 int interp=0,  int maxLen=MAX_STREAM_SIZE);

	vector<Pot3f> trackingStep(float px, float py, int w, int h, int cn, float *flow, float *proj,
		int interp=0, int maxLen=MAX_STREAM_SIZE);

	vector<Pot3f> trackingProj(float px, float py, int w, int h, int cn, float *flow, float *proj,
		 int interp=0, int maxLen=MAX_STREAM_SIZE);

	//vector<Pot3f> trackingProj(Pot2 pos, Pot2 wsz, int cn, float *flow, float *proj,
	//	float angle=0.0, int maxLen=MAX_STREAM_SIZE);

	void findStepPosition(float *stepPos, float px, float py,  int w, int h,
		int proWidth, const float *pGradS);

	Pot3f tracingRefine();

}