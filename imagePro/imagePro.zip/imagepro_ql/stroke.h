#ifndef STROKE_H
#define STROKE_H

#include <vec2.h>
#include <vector>
#include <iostream>

using namespace  math;
using namespace std;

//////////////////////////////////////////////// brush
class Brush
{
public:
	// position
	float		_x;
	float		_y;
	// gradient
	float		_gx;
	float		_gy;
	// projected position
	float		_px;
	float		_py;
	// radius
	float		_rad;
public:
	Brush(float x=-100000, float y=-100000, float gx=0.0, float gy=0.0, float px=0.0, float py=0.0,
		float rad=0.0):
	  _x(x),_y(y),_gx(gx),_gy(gy),_px(px),_py(py),_rad(rad){};

	  Brush& operator = (const Brush& br)
	  {
		  _x = br._x;
		  _y = br._y;
		  _gx = br._gx;
		  _gy = br._gy;
		  _px = br._px;
		  _py = br._py;
		  _rad = br._rad;
		  return *this;
	  };

	  void setDirection(float dx, float dy) {
		  _gx = dx;
		  _gy = dy;
	  };

	  void setPosition(float dx, float dy) {
		  _x = dx;
		  _y = dy;
	  };

	  void setProjection(float px, float py) {
		  _px = px;
		  _py = py;
	  }

	  friend std::ostream &operator<<(std::ostream &stream,const Brush &br);
	  friend std::istream &operator>>(std::istream &stream,Brush &br);
};

class BoundingBox
{
public:	/// Bounding box
	float			_minx;
	float			_miny;
	float			_maxx;
	float			_maxy;

public:
	BoundingBox(float minx = 10000.0, float miny = 10000.0, float maxx = -10000.0, float maxy = -10000.0) {
		_minx = minx;
		_miny = miny;
		_maxx = maxx;
		_maxy = maxy;
	}
	void unite(const BoundingBox & br)	{
		_minx = br._minx < _minx ? br._minx : _minx;
		_miny = br._miny < _miny ? br._miny : _miny;
		_maxx = br._maxx > _maxx ? br._maxx : _maxx;
		_maxy = br._maxy > _maxy ? br._maxy : _maxy;
	}
	void unite(float x, float y)	{
		_minx = x < _minx ? x : _minx;
		_miny = y < _miny ? y : _miny;
		_maxx = x > _maxx ? x : _maxx;
		_maxy = y > _maxy ? y : _maxy;
	}
	BoundingBox& operator = (const BoundingBox & bb)	{
		_minx = bb._minx;
		_miny = bb._miny;
		_maxx = bb._maxx;
		_maxy = bb._maxy;
		return *this;
	}
};

//////////////////////////////////////////////// stroke
class Stroke
{
private:
	float	_dep;
public:
	vector<Brush>	_vBrush;
	bool			_valid;
	int			    _keyframeid;
	BoundingBox		_box;


public:
	Stroke(bool va=true, int kf=0):_valid(va),_keyframeid(kf){
		_dep = 0.001f;
	};

	Stroke& operator = (const Stroke & sk)
	{
		_vBrush.clear();
		_vBrush = sk._vBrush;
		//for(unsigned int i=0; i<sk._vBrush.size(); i++)
		//	_vBrush.push_back(sk._vBrush[i]);
		_valid = sk._valid;
		_keyframeid = sk._keyframeid;
		_box = sk._box;
		return *this;
	};

	friend std::ostream &operator<<(std::ostream &stream,const Stroke &st);
	friend std::istream &operator>>(std::istream &stream,Stroke &st);

	void setValid(bool v) {
		_valid = v;
	};

	void setKeyframeID(int kf) {
		_keyframeid = kf;
	}

	void setBoundingBox(float mnx, float mny, float mxx, float mxy)
	{
		_box._maxx = mnx;
		_box._miny = mny;
		_box._maxx = mxx;
		_box._maxy = mxy;
	}	

	void setBoundingBox(const BoundingBox &bb) {
		_box = bb;
	}

	/// mush be called before draw normals
	void computeNormal();

	void drawPoint();
	void drawPath();
	void drawNormal();
	void drawProjection();
};

#endif // STROKE_H