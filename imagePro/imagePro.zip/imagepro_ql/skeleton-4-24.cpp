#pragma once
#include "skeleton.h"
#include "vectorizationPaint.h"
#include <vectorizationWindow.h>
#include <fstream>

namespace skeleton{

void SkeletonGraph::clear()
{
	m_vVertex.clear();
	
	for(int k=0; k<m_vEdge.size(); k++)
		m_vEdge[k].m_vPoint.clear();
	m_vEdge.clear();
	
	for(int k=0; k<m_vvEdge42vertex.size(); k++)
		m_vvEdge42vertex[k].clear();
	m_vvEdge42vertex.clear();

	for(int k=0; k<m_vvEdgeContinuity.size(); k++)
		m_vvEdgeContinuity[k].clear();
	m_vvEdgeContinuity.clear();

	m_vVertex42edge.clear();
}

float Dist(float x1,float y1,float x2,float y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}

int SkeletonGraph::indexVertex(QPointF m_vertex)
{
	for (int i=0;i<m_vVertex.size();i++)
	{
		if (Dist(m_vertex.x(),m_vertex.y(),m_vVertex[i].m_pos.x(),m_vVertex[i].m_pos.y())<10)
		{
			return i;
		}
	}
	return -1;
}

float pixelValue(Edge &pos, QImage & m_image)
{
	int totalValue=0;
	for (int i=0;i<pos.m_vPoint.size();i++)
	{
		totalValue+=qRed(m_image.pixel(pos.m_vPoint[i].x(),pos.m_vPoint[i].y()));
	}
	return float(totalValue)/pos.m_vPoint.size();
}

Edge backwards(const Edge &pos)
{
	Edge newPos;
	for (int i=pos.m_vPoint.size()-1;i>=0;i--)
	{
		newPos.m_vPoint.push_back(pos.m_vPoint[i]);
	}
	return newPos;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}

void SkeletonGraph::globalRecord(QImage &m_record)
{
	float width=10;
	for (int j=0;j<m_vEdge.size();j++)
	{
		Edge pos=m_vEdge[j];
        for (int i=0;i<pos.m_vPoint.size();i++)
		{
			float px=pos.m_vPoint[i].x();
			float py=pos.m_vPoint[i].y();
			for (int xx=int(-width/2-0.5);xx<width/2+0.6;xx++)
				for (int yy=int(-width/2-0.5);yy<width/2+0.6;yy++)
					if (xx*xx+yy*yy<=width*width/4 && isInImage(int(px+xx+0.5),int(py+yy+0.5),m_record.width(),m_record.height()))
					{
						m_record.setPixel(int(px+xx+0.5),int(py+yy+0.5),0);
					}
		} 
	}
}

void SkeletonGraph::deleteEdge(QImage &m_image)
{
	//����˼·������������յ���ͬ��ɾ��һ��ƫ��
	for (int i=0;i<m_vEdge.size();i++)
	{
		for (int j=i+1;j<m_vEdge.size();j++)
		{
			if (m_vVertex42edge[i*2]==m_vVertex42edge[j*2] && m_vVertex42edge[i*2+1]==m_vVertex42edge[j*2+1])
			{
				int head=m_vVertex42edge[i*2];
				int tail=m_vVertex42edge[i*2+1];
				//�����߶˵�һ��,����ж����ǱȽ��غ��أ�
				int cnt=0;
				int cnt_i=0;
				int cnt_j=0;
				float dist=0;
				while(cnt_i<m_vEdge[i].m_vPoint.size()-1 && cnt_j<m_vEdge[j].m_vPoint.size()-1)
				{
					cnt++;
					dist+=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y());
					cnt_i++;
					if (cnt_j>=m_vEdge[j].m_vPoint.size()-1)
						break;
					while (Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y())
						>Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j+1].x(),m_vEdge[j].m_vPoint[cnt_j+1].y()))
					{
						cnt_j++;
     					if (cnt_j>=m_vEdge[j].m_vPoint.size()-1)
							break;
					}
				}
				dist/=cnt;
				if (dist<3)//ƽ������С���������أ�������ͬһ���߰�
				{
					//ɾȥһ���Ƚ�ƫ�ģ�ɾȥ̫�鷳����������ֲ��࣬�Ѳ��õ������ĳ�һ���ĺ���
					float value1=pixelValue(m_vEdge[i],m_image);
					float value2=pixelValue(m_vEdge[j],m_image);
					if (i>j)//��i���߱ȽϺã�
						m_vEdge[j]=m_vEdge[i];
					else
						m_vEdge[i]=m_vEdge[j];
				}
			}
			if (m_vVertex42edge[i*2+1]==m_vVertex42edge[j*2] && m_vVertex42edge[i*2]==m_vVertex42edge[j*2+1])
			{
				int head=m_vVertex42edge[i*2];
				int tail=m_vVertex42edge[i*2+1];
				//�����߶˵�һ��,����ж����ǱȽ��غ��أ�
				int cnt=0;
				int cnt_i=0;
				int cnt_j=m_vEdge[j].m_vPoint.size()-1;
				float dist=0;
				while(cnt_i<m_vEdge[i].m_vPoint.size()-1 && cnt_j>1)
				{
					cnt++;
					dist+=Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y());
					cnt_i++;
					if (cnt_j<=1)
						break;
					while (Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j].x(),m_vEdge[j].m_vPoint[cnt_j].y())
						>Dist(m_vEdge[i].m_vPoint[cnt_i].x(),m_vEdge[i].m_vPoint[cnt_i].y(),m_vEdge[j].m_vPoint[cnt_j-1].x(),m_vEdge[j].m_vPoint[cnt_j-1].y()))
					{
						cnt_j--;
     					if (cnt_j<=1)
							break;
					}
				}
				dist/=cnt;
				if (dist<3)//ƽ������С���������أ�������ͬһ���߰�
				{
					//ɾȥһ���Ƚ�ƫ�ģ�ɾȥ̫�鷳����������ֲ��࣬�Ѳ��õ������ĳ�һ���ĺ���
					float value1=pixelValue(m_vEdge[i],m_image);
					float value2=pixelValue(m_vEdge[j],m_image);
					if (i>j)//��i���߱ȽϺã�
						m_vEdge[j]=backwards(m_vEdge[i]);
					else
						m_vEdge[i]=backwards(m_vEdge[j]);
				}

			}
		}
	}

}

void SkeletonGraph::addEdge()
{

}
void SkeletonGraph::junctionAdjust()
{
	for (int i=0;i<m_vVertex.size();i++)
	{
		for (int j=0;j<m_vVertex[i].m_k;j++)
		{
			cout<<i<<':'<<m_vVertex[i].m_pos.x()<<','<<m_vVertex[i].m_pos.y()<<'-'
<<<<<<< .mine
				<<m_vVertex[i].direction[j].x()<<','<<m_vVertex[i].direction[j].y()<<'-'<<m_vVertex[i].index[j]<<endl;
=======
				<<m_vVertex[i].m_direction[j].x()<<','<<m_vVertex[i].m_direction[j].y()<<'-'<<m_vVertex[i].m_index[j]<<endl;
>>>>>>> .r68
		}
		cout<<endl;
	}
}

void SkeletonGraph::continuousAdjust()
{

}

void SkeletonGraph::smoothEdge()
{
	for (int i=0;i<m_vEdge.size();i++)
	{
		vector<QPointF> tmpEdge=m_vEdge[i].m_vPoint;
		m_vEdge[i].m_vPoint[1]=QPointF((tmpEdge[0].x()+tmpEdge[1].x()+tmpEdge[2].x())/3,
			(tmpEdge[0].y()+tmpEdge[1].y()+tmpEdge[2].y())/3);
		for (int j=2;j<m_vEdge[i].m_vPoint.size()-2;j++)
		{
			m_vEdge[i].m_vPoint[j]=QPointF((tmpEdge[j-2].x()+tmpEdge[j-1].x()+tmpEdge[j].x()+tmpEdge[j+1].x()+tmpEdge[j+2].x())/5,
				(tmpEdge[j-2].y()+tmpEdge[j-1].y()+tmpEdge[j].y()+tmpEdge[j+1].y()+tmpEdge[j+2].y())/5);
		}
		m_vEdge[i].m_vPoint[tmpEdge.size()-2]=QPointF((tmpEdge[tmpEdge.size()-3].x()+tmpEdge[tmpEdge.size()-2].x()+tmpEdge[tmpEdge.size()-1].x())/3,
			(tmpEdge[tmpEdge.size()-3].y()+tmpEdge[tmpEdge.size()-2].y()+tmpEdge[tmpEdge.size()-1].y())/3);
	}
}
QPoint getStartingPoint(const QImage &img)
{
	const int imin = 20;
	int yi = 0;
	int xmax = 0;
	for(yi=0; yi<img.height(); yi++)
	{
		int imax = 0;
		xmax = 0;
		for(int xi=0; xi<img.width(); xi++)
		{
			int itensity = qRed(img.pixel(xi,yi));
			if(itensity>imax)
			{
				imax = itensity;
				xmax = xi;
			}
		}
		if(imax>imin)
			break;
	}
	return QPoint(xmax,yi);
}
int SkeletonGraph::edgeIndex(int indexVertex, Edge &pos)
{
	float tangx=pos.m_vPoint[6].x()-pos.m_vPoint[0].x();
	float tangy=pos.m_vPoint[6].y()-pos.m_vPoint[0].y();
	float dist=Dist(tangx,tangy,0,0);
	tangx/=dist;
	tangy/=dist;
	int maxcosine=0;
	int index=0;
	for (int i=0;i<m_vVertex[indexVertex].m_k;i++)
	{
		float cosine=m_vVertex[indexVertex].m_direction[i].x()*tangx+m_vVertex[indexVertex].m_direction[i].y()*tangy;
		if (cosine>maxcosine)
		{
			maxcosine=cosine;
			index=i;
		}
	}
	return index;
}


} // mamespace