#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);
	
	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<skeleton::Vertex> vertexRecord;//second one means angle
    vector<QPointF> angleRecord;

	/// get the original direction
	QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	float tang[2];
	m_record=m_image;
	centerDirection(tang, m_imgSize.width(),m_imgSize.height(),4,startPos.x(),startPos.y(),pGradS);
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(tang[0],tang[1]));
	int cnt=0;
	while(!vertexRecord.empty()&&cnt<=5)//////////////////////
	{
		cnt++;
		///��ջ
		QPointF pos=vertexRecord[vertexRecord.size()-1].m_pos;
		vertexRecord.pop_back();
		QPointF angle=angleRecord[angleRecord.size()-1];
		angleRecord.pop_back();
		
		skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGradS,vertexRecord,angleRecord);
		if (m_edge.m_vPoint.size()>1)
		{
			sktGraph.m_vEdge.push_back(m_edge);
			int edgeSz=sktGraph.m_vEdge.size();
			int pointSz=sktGraph.m_vEdge[edgeSz-1].m_vPoint.size();
			QPointF m_jPoint=sktGraph.m_vEdge[edgeSz-1].m_vPoint[pointSz-1];
			sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));

		}

	}

	
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}

float Dist(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}

bool judgeJunctionArea(float *leftPos,float *rightPos)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0&&rightPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];///��ʵӦ�������������ֿ����ǵ�junction point,�ӽ��Ļ������ڵ�end point
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)
		if (Dist(leftPos[i],leftPos[i+1],rightPos[i],rightPos[i+1])<Dist(leftPos[8],leftPos[9],rightPos[8],rightPos[9]))//cos30
	{/*
		for (i=0;i<=8;i+=2)
		{
			cout<<leftPos[i]<<' '<<leftPos[i+1]<<endl;
		}
		for (i=0;i<=8;i+=2)
		{
			cout<<rightPos[i]<<' '<<rightPos[i+1]<<endl;
		}
		*/
		return true;//directions we got from left and right boundaries are too different ==> junction area
	}
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = -k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

void ImagePaint::centerDirection(float* tang, int w, int h, int cn, float px, float py, float *flow)
{
	float stepPos[8];
	const int proWidth = 12;
	findStepPosition(stepPos,px,py,w,h,proWidth, flow);
	float fleftx,flefty,frightx,frighty;
	if (isInImage(stepPos[0],stepPos[1],w,h))
	{
	    const float *fleft = getDirection(w, h, cn,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	    fleftx=fleft[1];
	    flefty=-fleft[0];
	}else
	{
		const float *fleft = getDirection(w, h, cn,flow,int(px+0.5),int(py+0.5));
		fleftx=fleft[1];
	    flefty=-fleft[0];

	}
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	if (isInImage(stepPos[4],stepPos[5],w,h))
	{
		const float *fright = getDirection(w,h, 4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}else
	{
		const float *fright = getDirection(w,h, 4,flow,int(px+0.5),int(py+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	//float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	//return tang;
}

void findBoundary(float *stepPos, float px, float py, float lastlx, float lastly, float lastrx, float lastry, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image) //���أ��������Ǹ���ͬ�������߽߱���Ҫ����һ�μ������ȽϽӽ���Ϊ���ų����㵽������֧�ı߽���ȥ�����Σ�
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax && Dist(lastlx,lastly,xx,yy)<3)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx-tangy,yy+tangx)))
			{
				distMax = k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
	stepPos[0] = -float(distMax)*tangy+float(pxi);
	stepPos[1] = float(distMax)*tangx+float(pyi);
	stepPos[2] = float(distMax);
	stepPos[3] = magMax;
	}
	flag=false;
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax && Dist(lastrx,lastry,xx,yy)<3)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx+tangy,yy-tangx)))
			{
				distMax = -k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
	stepPos[4] = -float(distMax)*tangy+float(pxi);
	stepPos[5] = float(distMax)*tangx+float(pyi);
	stepPos[6] = float(distMax);
	stepPos[7] = magMax;
	}
}
bool judgeJunctionArea(float leftx,float lefty,float rightx,float righty,float seedx,float seedy)
{
	float dist1=Dist(leftx,lefty,seedx,seedy);
    float dist2=Dist(rightx,righty,seedx,seedy);
	if (dist1>10 && dist1>2*dist2 || dist2>10 && dist2>2*dist1)
		return true;
	return false;
}
bool judgeJunctionArea(float fleftx,float flefty,float frightx,float frighty)
{
	float cosine=(fleftx*frightx+flefty*frighty)/Dist(fleftx,flefty,0,0)/Dist(frightx,frighty,0,0);
	if (cosine>=sqrt(3)/2)
		return true;
	return false;
}
void findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx-tangy,yy+tangx)))
			{
				distMax = k;
				magMax = abs(mag);
			}
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����ʹ��ԭ�����м�����=>ʹ��retract��Ч
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx+tangy,yy-tangx)))
			{
				distMax = -k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
	}
}

bool judgeEdgeEnd(float px,float py, float tangx, float tangy, int w,int h, int radius,QImage m_image)
{
	if (qRed(m_image.pixel(px+tangx*2,py+tangy*2))==0 || !isInImage(px+tangx*2,py+tangy*2,w,h))
		return true;
	return false;

}


skeleton::Edge ImagePaint::tracking(float px, float py,float tangx, float tangy, int w, int h, int cn, float *flow, vector<skeleton::Vertex> &vertexRecord,vector<QPointF> &angleRecord)
{
	bool stop=false;
	skeleton::Edge pos;//(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos;
	}

	int cnt = 0;
	float seedx = px;
	float seedy = py;
	float prevTangx = tangx;
	float prevTangy = tangy;
	float stepPos[8];
	const int proWidth = 8;

	////first step: get out of the junction area, Ӧ���ȸ�������ĳһ������
	
	bool flag;
	flag=ImagePaint::trackingEdge(pos,w,h,seedx,seedy,cn,tangx,tangy,flow);//seedx,seedy,startx,starty���ĸ������������������������ķ���

	if (!flag)///meet a junction point
	{//record the two possible vectors
		//junction�Լ�������ջ��
		vertexRecord.push_back(skeleton::Vertex::Vertex(QPointF(pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y()),true));
		angleRecord.push_back(QPointF(seedx,seedy));
		if ((seedx*tangx+seedy*tangy)/Dist(seedx,seedy,0,0)/Dist(tangx,tangy,0,0)<sqrt(3)/2)
		{
			vertexRecord.push_back(vertexRecord[vertexRecord.size()-1]);
			angleRecord.push_back(QPointF(tangx,tangy));
		}
		///////////////////////////////////���һ��ÿ��junction��Χ������
		cout<<vertexRecord[vertexRecord.size()-1].m_pos.x()<<','<<vertexRecord[vertexRecord.size()-1].m_pos.y()<<endl;
		cout<<angleRecord[angleRecord.size()-1].x()<<' '<<angleRecord[angleRecord.size()-1].y()<<endl;
		cout<<angleRecord[angleRecord.size()-2].x()<<' '<<angleRecord[angleRecord.size()-2].y()<<endl;
	}

	return pos;
}

bool ImagePaint::trackingEdge(skeleton::Edge &pos, int w, int h, float &px, float &py,int cn, float &tangx, float &tangy, float *flow)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		//return pos;
	}
	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float stepPos[8];
 	float dist=sqrt(tangx*tangx+tangy*tangy);
	tangx=tangx/dist;
	tangy=tangy/dist;
	float fleftx,flefty,frightx,frighty;
	pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	///��ʼ��һ�ν����������߽���ϢҲ�������ݶ���Ϣ������һ��ʼ��junction�������ܻ��������
	while(cnt<10 || !judgeJunctionArea(fleftx,flefty,frightx,frighty))//ǰ7������
	{
		if (cnt>5)
		{
			findBoundary(stepPos,seedx,seedy,w,h,tangx,tangy,8,flow,m_image);
		    const float *fseed = getDirection(w,h,4,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
			fleftx = fseed[1];
			flefty = -fseed[0];
			if (fleftx*tangx+flefty*tangy<0)
			{
				fleftx=-fleftx;
				flefty=-flefty;
			}
			const float *fseed2 = getDirection(w,h,4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
			frightx = fseed2[1];
			frighty = -fseed2[0];
			if (frightx*tangx+frighty*tangy<0)
			{
				frightx=-frightx;
				frighty=-frighty;
			}
		}
		//���ݼ�����ķ���track
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
		float anglex=-tangy;
		float angley=tangx;
		int max=0;
		float midx=seedx;
		float midy=seedy;
        /*for (int d=-2;d<2;d++)
		{
			int tmpx=int(seedx+anglex/2*d+0.5);
			int tmpy=int(seedy+angley/2*d+0.5);
		    if (isInImage(tmpx,tmpy,w,h))
			{
				if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{ 
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=seedx+anglex/2*d;
					midy=seedy+angley/2*d;
				}
			}
		}*/
		seedx=midx;
		seedy=midy;
		pos.m_vPoint.push_back(QPointF(float(seedx),float(seedy)));
		/*if (cnt>=4)
		{
			tangx=pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-4].x();
			tangy=pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-4].y();
			float dist=sqrt(tangx*tangx+tangy*tangy);
			tangx=tangx/dist;
			tangy=tangy/dist;
		}*/
		cout<<seedx<<','<<seedy<<endl; 
        cnt ++;

		//�ж��Ƿ�����������ĩ��
		if  ((cnt>=6 && qRed(m_image.pixel(int(seedx+0.5),int(seedy+0.5))==0))||!isInImage(midx+tangx,midy+tangy,w,h))
		{
			return true;//���Ƿֲ棬����Ҫ�����ߣ�Ҳ����Ҫ��Junction��ջ
		}
	}
	///ǰ����һ���ֵ����������߳�junction����Χ��������������һ����п��ܳ���
	float max=0;
	float midx=seedx;
	float midy=seedy;
	for (int d=-8;d<8;d++)
	{
		int tmpx=int(seedx-tangy/2*d+0.5);
		int tmpy=int(seedy+tangx/2*d+0.5);
	    if (isInImage(tmpx,tmpy,w,h))
		{
			if (qRed(m_image.pixel(tmpx,tmpy))>max)
			{ 
				max=qRed(m_image.pixel(tmpx,tmpy));
				midx=seedx-tangy/2*d;
				midy=seedy+tangx/2*d;
			}
		}
	}
	seedx=midx;
	seedy=midy;


	//�ҳ�������Ϣ
	float prevTangx = tangx;
	float prevTangy = tangy;
	findBoundary(stepPos,seedx,seedy,w,h,prevTangx,prevTangy,10,flow,m_image);
	float leftx=stepPos[0];
	float lefty=stepPos[1];
	float rightx=stepPos[4];
	float righty=stepPos[5];
	float prevx = tangx;
	float prevy = tangy;
	///��ǰ�����Ƶأ�������ǰ��
	cnt=0;
	while( ((cnt<6)||!judgeJunctionArea(leftx,lefty,rightx,righty,seedx,seedy)) && cnt<200)
	{
		///��������
		const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
		float dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;
		//��ԭ����һ�£���Ҫ�㷴��
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		leftx += tangx;
		lefty += tangy;
		/*float magMax=0;
		int distMax=0;
		for(int k=-1; k<=1; k++)
     	{
			int xx = int(float(leftx)+float(k)*fseed[0]/2.0);
			int yy = int(float(lefty)+float(k)*fseed[1]/2.0);
			if (isInImage(xx,yy,w,h))
			{
				float mag = flow[4*(yy*w+xx)+3];
				if(abs(mag)>magMax)
				{
					distMax = k;
					magMax = abs(mag);
				}
			}
	    }
		leftx = float(distMax)*fseed[0]/2.0+float(leftx);
		lefty = float(distMax)*fseed[1]/2.0+float(lefty);*/
        prevTangx = tangx;
		prevTangy = tangy;
		//seedx += float(distMax)*fseed[0]+tangx;
		//seedy += float(distMax)*fseed[1]+tangy;
		seedx+=tangx;
		seedy+=tangy;

		//ȡ�Ļ������߷���
		float tangx2=pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-4].x();
		float tangy2=pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-4].y();
		dist=sqrt(tangx2*tangx2+tangy2*tangy2);
		tangx2=tangx2/dist;
		tangy2=tangy2/dist;
	    if (tangx2*prevTangx+tangy2*prevTangy>tangx*prevTangx+tangy*prevTangy)
		{
			tangx=tangx2;
			tangy=tangy2;
		}
		
//////////////////////////////////////////////
		//�ҳ��������߾���ʼ���������
		    float x1=seedx-leftx;
			float y1=seedy-lefty;
			float anglex=tangy;
			float angley=-tangx;
			if (x1*anglex+y1*angley<0)
			{
				anglex=-anglex;
				angley=-angley;
			}
		    int max=0;
            for (int d=0;d<10;d++)
			{
				int tmpx=int(leftx+anglex/2*d+0.5);
				int tmpy=int(lefty+angley/2*d+0.5);
			    if (qRed(m_image.pixel(tmpx,tmpy))>=max)
				{
					max=qRed(m_image.pixel(tmpx,tmpy));
					seedx=leftx+anglex/2*d;
					seedy=lefty+angley/2*d;
				}
			}
			if (max<100)//��ʱ���ǲ��ų�����㷴�˵����
			{
				for (int d=0;d>-10;d--)
				{
					int tmpx=int(leftx+anglex/2*d+0.5);
					int tmpy=int(lefty+angley/2*d+0.5);
					if (qRed(m_image.pixel(tmpx,tmpy))>=max)
					{
						max=qRed(m_image.pixel(tmpx,tmpy));
						seedx=leftx+anglex/2*d;
						seedy=lefty+angley/2*d;
					}else
					{
						break;
					}
				}
			}

		//////////////////////////////////////////////
		if (cnt>=6 && Dist(seedx,seedy,pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y())>4)
		{
			seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
			seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
			break;
		}
		pos.m_vPoint.push_back(QPointF(float(seedx),float(seedy)));
		
		
		//��һ��Ҳ��֮ǰ��
		const float *f = getDirection(w,h,cn,flow,int(rightx+0.5),int(righty+0.5));
		tangx=f[1];
		tangy=-f[0];
		if (tangx*prevx+tangy*prevy<0)
		{
			tangx=-tangx;
			tangy=-tangy;
		}
		prevx=tangx;prevy=tangy;
		rightx+=tangx;
		righty+=tangy;
		float distMax = 0;
		float magMax = 0.0;
		for (int d=0;d<10;d++)
		{
			int tmpx=int(seedx+anglex/2*d+0.5);
			int tmpy=int(seedy+angley/2*d+0.5);
	        if (isInImage(tmpx,tmpy,w,h))
			{
				float mag = flow[4*(tmpy*w+tmpx)+3];
			    if(mag>magMax && qRed(m_image.pixel(tmpx,tmpy))>qRed(m_image.pixel(int(0.5+tmpx+anglex),int(0.5+tmpy+angley))))
				{
					distMax = d;
					magMax = mag;
				}
			}
		}
		if (Dist(float(distMax)*anglex/2+seedx,float(distMax)*angley/2+seedy,rightx,righty)>5)
			break;
		rightx=float(distMax)*anglex/2+seedx;
		righty=float(distMax)*angley/2+seedy;
			
		///�ж��Ƿ�������ĩ��
 		if  ((cnt>=6 && judgeEdgeEnd(seedx,seedy,tangx,tangy, w,h,12,this->m_image))||!isInImage(seedx+prevTangx,seedy+prevTangy,w,h))
		{
			return true;//���Ƿֲ�
		}
		if ((prevx*prevTangx+prevy*prevTangy)<0.5*Dist(prevx,prevy,0,0)*Dist(prevTangx,prevTangy,0,0))
		{
			break;
		}
		cout<<cnt<<"    "<<leftx<<','<<lefty<<"   "<<seedx<<','<<seedy<<"    "<<rightx<<','<<righty<<endl; 
		cnt ++;
		
	}
	
	///�ѷ��򴫵ݻ�ȥ
	///�߽����ȶ���ǰ��һ�㣬���㷽�򣻷�����ʵ����̫������
	float tmpleftx=leftx;
	float tmplefty=lefty;
	for (int i=0;i<=10;i++)
	{
		const float *fseed = getDirection(w,h,4,flow,int(tmpleftx+0.5),int(tmplefty+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;

		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		//���ݼ�����ķ���track
		tmpleftx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		tmplefty += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
	    prevTangx=tangx;
		prevTangy=tangy;
	}
	px=prevTangx;//�����յķ���
	py=prevTangy;

	float tmprightx=rightx;
	float tmprighty=righty;
	for (int i=0;i<=10;i++)
	{
		const float *fseed = getDirection(w,h,4,flow,int(tmprightx+0.5),int(tmprighty+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;

		float tangsign = tangx*prevx + tangy*prevy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		//���ݼ�����ķ���track
		tmprightx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		tmprighty += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
	    prevx=tangx;
		prevy=tangy;
	}
	
	tangx=prevx;//��һ��ķ���
	tangy=prevy;
	
	//�����ؼ����λ�ã�Ҫô����Ҫôǰ��
	//���ˣ�
	bool flag=false;
	for (int i=0;i<10;i++)
	{
		int tmpx=pos.m_vPoint[pos.m_vPoint.size()-2].x();
		int tmpy=pos.m_vPoint[pos.m_vPoint.size()-2].y();
		if (qRed(m_image.pixel(tmpx+px*10,tmpy+py*10))>80 && qRed(m_image.pixel(tmpx+tangx*10,tmpy+tangy*10))>80)
		{
			pos.m_vPoint.pop_back();
			flag=true;
		}else
		{
			break;
		}
	}
	if (!flag)
	{
	for (int i=0;i<10;i++)
	{
		if (qRed(m_image.pixel(seedx+px*10,seedy+py*10))>80)
			if (qRed(m_image.pixel(seedx+tangx*10,seedy+tangy*10))>80)
				break;
		const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
		float tx = fseed[1];
		float ty = -fseed[0];
		float tangsign = tx*prevTangx + ty*prevTangy;
		if(tangsign<0.0)
		{
			tx = -tx;
			ty= -ty;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		leftx += tx;
		lefty += ty;
		float magMax=0;
		int distMax=0;
		for(int k=-1; k<=1; k++)
     	{
			int xx = int(float(leftx)+float(k)*fseed[0]);
			int yy = int(float(lefty)+float(k)*fseed[1]);
			if (isInImage(xx,yy,w,h))
			{
				float mag = flow[4*(yy*w+xx)+3];
				if(abs(mag)>magMax)
				{
					distMax = k;
					magMax = abs(mag);
				}
			}
	    }
		leftx = float(distMax)*fseed[0]+float(leftx);
		lefty = float(distMax)*fseed[1]+float(lefty);
        seedx += float(distMax)*fseed[0]+tangx;
		seedy += float(distMax)*fseed[1]+tangy;
			float x1=seedx-leftx;
			float y1=seedy-lefty;
			float anglex=tangy;
			float angley=-tangx;
			if (x1*anglex+y1*angley<0)
			{
				anglex=-anglex;
				angley=-angley;
			}
		    int max=0;
            for (int d=0;d<10;d++)
			{
				int tmpx=int(leftx+anglex*d);
				int tmpy=int(lefty+angley*d);
			    if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{
					max=qRed(m_image.pixel(tmpx,tmpy));
					seedx=tmpx;
					seedy=tmpy;
				}
			}
			if (max<100)//��ʱ���ǲ��ų�����㷴�˵����
			{
				for (int d=0;d>-10;d--)
				{
					int tmpx=int(leftx+anglex*d);
					int tmpy=int(lefty+angley*d);
					if (qRed(m_image.pixel(tmpx,tmpy))>max)
					{
						max=qRed(m_image.pixel(tmpx,tmpy));
						seedx=tmpx;
						seedy=tmpy;
					}else
					{
						break;
					}
				}
			}
	}
	pos.m_vPoint.push_back(QPointF(seedx,seedy));
	}
	return false;
}