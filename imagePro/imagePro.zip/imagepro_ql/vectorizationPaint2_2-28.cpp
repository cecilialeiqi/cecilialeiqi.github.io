#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);
	
	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<skeleton::Vertex> vertexRecord;//second one means angle
    vector<QPointF> angleRecord;

	/// get the original direction
	QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	float tang[2];
	m_record=m_image;
	centerDirection(tang, m_imgSize.width(),m_imgSize.height(),4,startPos.x(),startPos.y(),pGradS);
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(tang[0],tang[1]));
	int cnt=0;
	while(!vertexRecord.empty()&&cnt<=100)//////////////////////
	{
		cnt++;
		///��ջ
		QPointF pos=vertexRecord[vertexRecord.size()-1].m_pos;
		vertexRecord.pop_back();
		QPointF angle=angleRecord[angleRecord.size()-1];
		angleRecord.pop_back();
		
		skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGradS,vertexRecord,angleRecord);
		if (m_edge.m_vPoint.size()>1)
		{
			sktGraph.m_vEdge.push_back(m_edge);
			int edgeSz=sktGraph.m_vEdge.size();
			int pointSz=sktGraph.m_vEdge[edgeSz-1].m_vPoint.size();
			QPointF m_jPoint=sktGraph.m_vEdge[edgeSz-1].m_vPoint[pointSz-1];
			sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));

		}

	}

	
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}

float dist(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}

bool judgeJunctionArea(float *leftPos,float *rightPos,int cnt)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0&&rightPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];///��ʵӦ�������������ֿ����ǵ�junction point,�ӽ��Ļ������ڵ�end point
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)
		if (dist(leftPos[i],leftPos[i+1],rightPos[i],rightPos[i+1])<dist(leftPos[8],leftPos[9],rightPos[8],rightPos[9]))//cos30
	{/*
		for (i=0;i<=8;i+=2)
		{
			cout<<leftPos[i]<<' '<<leftPos[i+1]<<endl;
		}
		for (i=0;i<=8;i+=2)
		{
			cout<<rightPos[i]<<' '<<rightPos[i+1]<<endl;
		}
		*/
		return true;//directions we got from left and right boundaries are too different ==> junction area
	}
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = -k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

void ImagePaint::centerDirection(float* tang, int w, int h, int cn, float px, float py, float *flow)
{
	float stepPos[8];
	const int proWidth = 12;
	findStepPosition(stepPos,px,py,w,h,proWidth, flow);
	float fleftx,flefty,frightx,frighty;
	if (isInImage(stepPos[0],stepPos[1],w,h))
	{
	    const float *fleft = getDirection(w, h, 4,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	    fleftx=fleft[1];
	    flefty=-fleft[0];
	}else
	{
		const float *fleft = getDirection(w, h, 4,flow,int(px+0.5),int(py+0.5));
		fleftx=fleft[1];
	    flefty=-fleft[0];

	}
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	if (isInImage(stepPos[4],stepPos[5],w,h))
	{
		const float *fright = getDirection(w,h, 4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		float frightx=fright[1];
		float frighty=-fright[0];
	}else
	{
		const float *fright = getDirection(w,h, 4,flow,int(px+0.5),int(py+0.5));
		float frightx=fright[1];
		float frighty=-fright[0];
	}
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	//float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	//return tang;
}

void findBoundary(float *stepPos, float px, float py, float lastlx, float lastly, float lastrx, float lastry, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image) //���أ��������Ǹ���ͬ�������߽߱���Ҫ����һ�μ������ȽϽӽ���Ϊ���ų����㵽������֧�ı߽���ȥ�����Σ�
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax && dist(lastlx,lastly,xx,yy)<3)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx-tangy,yy+tangx)))
			{
				distMax = k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
	stepPos[0] = -float(distMax)*tangy+float(pxi);
	stepPos[1] = float(distMax)*tangx+float(pyi);
	stepPos[2] = float(distMax);
	stepPos[3] = magMax;
	}
	flag=false;
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax && dist(lastrx,lastry,xx,yy)<3)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx+tangy,yy-tangx)))
			{
				distMax = -k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
	stepPos[4] = -float(distMax)*tangy+float(pxi);
	stepPos[5] = float(distMax)*tangx+float(pyi);
	stepPos[6] = float(distMax);
	stepPos[7] = magMax;
	}
}

void findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx-tangy,yy+tangx)))
			{
				distMax = k;
				magMax = abs(mag);
			}
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����ʹ��ԭ�����м�����=>ʹ��retract��Ч
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>qRed(m_image.pixel(xx+tangy,yy-tangx)))
			{
				distMax = -k;
				magMax = abs(mag);
			}
	}
	if (flag)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
	}
}

bool judgeEdgeEnd(float px,float py, float tangx, float tangy, int w,int h, int radius,QImage m_image)
{
	///
	/*
	int totalPixel=0;
	int darkPixel=0;
	for (float angle=0;angle<2*3.14159;angle+=0.1)
	{
		int x=int(px+radius*sin(angle)+0.5);
		int y=int(py+radius*cos(angle)+0.5);
		//cout<<grad[]
		if (isInImage(x,y,w,h))
		{
			totalPixel++;
			if (qRed(m_image.pixel(x,y))<50) darkPixel++;//that is in the lines
		    
		}
		//cout<<x<<' '<<y<<endl;
		//cout<<qRed(m_image.pixel(x,y))<<' ';
	}
	cout<<px<<' '<<py<<endl;
	cout<<float(darkPixel)/float(totalPixel)<<endl;
	if (totalPixel<56)//too many points are out of the image, it is possible that it is heading the other way
		return false;
	if (float(darkPixel)/float(totalPixel)<0.7) return false;
	return true;*/

	if (qRed(m_image.pixel(px+tangx*2,py+tangy*2))==0 || !isInImage(px+tangx*2,py+tangy*2,w,h))
		return true;
	return false;

}


skeleton::Edge ImagePaint::tracking(float px, float py,float tangx, float tangy, int w, int h, int cn, float *flow, vector<skeleton::Vertex> &vertexRecord,vector<QPointF> &angleRecord)
{
	bool stop=false;
	skeleton::Edge pos;//(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos;
	}

	int cnt = 0;
	float seedx = px;
	float seedy = py;
	float prevTangx = tangx;
	float prevTangy = tangy;
	float stepPos[8];
	const int proWidth = 8;

	////first step: get out of the junction area, Ӧ���ȸ�������ĳһ������
	findBoundary(stepPos,px,py,w,h,tangx,tangy,proWidth,flow,m_image);
	const float *fleft = getDirection(w, h, 4,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	const float *fright = getDirection(w,h, 4,flow,int(0.5+stepPos[4]),int(0.5+stepPos[5]));
	float fleftx=fleft[1];
	float flefty=-fleft[0];
	
	//������Ϊ��������������ѡһ������������ķ���
	float lcos=(fleftx*tangx+flefty*tangy)/module(fleftx,flefty)/module(tangx,tangy);
	if (lcos<0)
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	float frightx=fright[1];
	float frighty=-fright[0];
	float rcos=(frightx*tangx+frighty*tangy)/module(frightx,frighty)/module(tangx,tangy);
	if (rcos<0)
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	bool flag;
	float startx,starty;
	float anglex,angley;
	if (lcos<rcos||!isInImage(stepPos[0],stepPos[1],w,h))//right way is better
	{
		/// trace starting from right side
		startx=stepPos[4];
		starty=stepPos[5];
		anglex=frightx;
		angley=frighty;
	}else
	{
		/// trace starting from left side
		startx=stepPos[0];
		starty=stepPos[1];
		anglex=fleftx;
		angley=flefty;
	}//����ʱ���������������
	flag=ImagePaint::trackingEdge(pos,w,h,seedx,seedy,startx,starty,cn,anglex,angley,flow);//seedx,seedy,startx,starty���ĸ������������������������ķ���

	if (!flag)///meet a junction point
	{//record the two possible vectors
		vertexRecord.push_back(skeleton::Vertex::Vertex(QPointF(pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y()),true));
		angleRecord.push_back(QPointF(startx,starty));
		vertexRecord.push_back(vertexRecord[vertexRecord.size()-1]);
		angleRecord.push_back(QPointF(seedx,seedy));
		///////////////////////////////////���һ��ÿ��junction��Χ������
		cout<<vertexRecord[vertexRecord.size()-1].m_pos.x()<<','<<vertexRecord[vertexRecord.size()-1].m_pos.y()<<endl;
		cout<<angleRecord[angleRecord.size()-1].x()<<' '<<angleRecord[angleRecord.size()-1].y()<<endl;
		cout<<angleRecord[angleRecord.size()-2].x()<<' '<<angleRecord[angleRecord.size()-2].y()<<endl;
	}

	return pos;
}

bool ImagePaint::trackingEdge(skeleton::Edge &pos, int w, int h, float &midx, float &midy, float &px, float &py, int cn,float tangx, float tangy, float *flow)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		//return pos;
	}
	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float prevTangx = tangx;
	float prevTangy = tangy;
	float prevx = tangx;
	float prevy = tangy;
	float stepPos[8];
	float leftPos[20]={0};
	float rightPos[20]={0};
	
	pos.m_vPoint.push_back(QPointF(float(midx),float(midy)));
	///��ʼ��һ�ν�������һ�����Ϣ������һ��ʼ��junction�������ܻ��������
	while(cnt<7)//ǰ7�����أ�����һ��߽������track���ص��뿪junction����Χ(��һ���ǲ���Ҫ��һ��߽����Ϣ��)
	{
		//����֮ǰ��prevTang���򣬼���߽��ϵ�����
		const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		//���ݼ�����ķ���track
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
		float magMax=0;
		int distMax=0;
		for(int k=-3; k<=3; k++)//����Χ3����������������Ǳ߽�ĵ�
     	{
			int xx = int(float(seedx)+float(k)*fseed[0]);
			int yy = int(float(seedy)+float(k)*fseed[1]);
			if (isInImage(xx,yy,w,h))
			{
				float mag = flow[4*(yy*w+xx)+3];
				if(abs(mag)>magMax)
				{
					distMax = k;
					magMax = abs(mag);
				}
			}
	    }
		seedx = float(distMax)*fseed[0]+float(seedx);
		seedy = float(distMax)*fseed[1]+float(seedy);
		////�����ⲿ����Ϊ�˱���߽�ƫ��
        midx += float(distMax)*fseed[0]+tangx;
		midy += float(distMax)*fseed[1]+tangy;
		


		///use left and right boundary to retract the streamline  ���ַ�����junction�����Ǻ�������
		
		{//�ı����뷨���е�Ӧ�����ڱ߽紹ֱ�����������м�λ�õĵ�
			float x1=midx-seedx;
			float y1=midy-seedy;
			float anglex=tangy;
			float angley=-tangx;
			if (x1*anglex+y1*angley<0)
			{
				anglex=-anglex;
				angley=-angley;
			}
			int max=0;
            for (int d=0;d<10;d++)
			{
				int tmpx=int(seedx+anglex*d);
				int tmpy=int(seedy+angley*d);
			    if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=tmpx;
					midy=tmpy;
				}else
				{
					break;
				}
			}
			if (max<100)//��ʱ���ǲ��ų�����㷴�˵����
			{
				for (int d=0;d>-10;d--)
				{
					int tmpx=int(seedx+anglex*d);
					int tmpy=int(seedy+angley*d);
					if (qRed(m_image.pixel(tmpx,tmpy))>max)
					{
						max=qRed(m_image.pixel(tmpx,tmpy));
						midx=tmpx;
						midy=tmpy;
					}else
					{
						break;
					}
				}
			}
		}

		pos.m_vPoint.push_back(QPointF(float(midx),float(midy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;

		//�ж��Ƿ�����������ĩ��
		if  ((cnt>=6 && judgeEdgeEnd(midx,midy,tangx,tangy,w,h,12,this->m_image))||!isInImage(midx+prevTangx,midy+prevTangy,w,h))
		{
			px=prevTangx;
			py=prevTangy;
			return true;//���Ƿֲ棬����Ҫ�����ߣ�Ҳ����Ҫ��Junction��ջ
		}
	}
	///ǰ����һ���ֵ����������߳�junction����Χ��������������һ����п��ܳ���


	//�ҳ���һ����Ϣ
	float xx,yy;
	findBoundary(stepPos,midx,midy,w,h,prevTangx,prevTangy,10,flow,m_image);
	float dist1=pow(stepPos[0]-seedx,2)+pow(stepPos[1]-seedy,2);
	float dist2=pow(stepPos[4]-seedx,2)+pow(stepPos[5]-seedy,2);
	if (dist1<dist2)
	{
		xx=stepPos[4];yy=stepPos[5];
	}else
	{
		xx=stepPos[0];yy=stepPos[1];
	}

    ///��ǰ�����Ƶأ�������ǰ��
	cnt=0;
	while( ((cnt<6)||!judgeJunctionArea(leftPos,rightPos,cnt)) && cnt<200)
	{
		///��������
		const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
		float magMax=0;
		int distMax=0;
		for(int k=-3; k<=3; k++)
     	{
			int xx = int(float(seedx)+float(k)*fseed[0]);
			int yy = int(float(seedy)+float(k)*fseed[1]);
			if (isInImage(xx,yy,w,h))
			{
				float mag = flow[4*(yy*w+xx)+3];
				if(abs(mag)>magMax)
				{
					distMax = k;
					magMax = abs(mag);
				}
			}
	    }
		seedx = float(distMax)*fseed[0]+float(seedx);
		seedy = float(distMax)*fseed[1]+float(seedy);
        midx += float(distMax)*fseed[0]+tangx;
		midy += float(distMax)*fseed[1]+tangy;
		
		///use left and right boundary to retract the streamline
		
		if(cnt==0 || stepPos[0]==stepPos[4]&&stepPos[1]==stepPos[5]) //ʹ��findBoundary������Ľ����֮ǰ�����еĵ㳬��ҳ��ʱ������ʵ�߽磬�������ﲻ������֮ǰ�Ľ����߽�
			findBoundary(stepPos,midx,midy,w,h,tangx,tangy,12, flow,m_image);
		else
			findBoundary(stepPos,midx,midy,stepPos[0],stepPos[1],stepPos[4],stepPos[5],w,h,tangx,tangy,12,flow,m_image);
		/*
		if (isInImage(stepPos[0],stepPos[1],w,h)&&isInImage(stepPos[4],stepPos[5],w,h))
		{
			midx=(stepPos[0]+stepPos[4])/2.0;
			midy=(stepPos[1]+stepPos[5])/2.0;
		}*/
		
//////////////////////////////////////////////
		{
			float dist1=dist(stepPos[0],stepPos[1],stepPos[4],stepPos[5]);
			float x1=midx-seedx;
			float y1=midy-seedy;
			float anglex=tangy;
			float angley=-tangx;
			if (x1*anglex+y1*angley<0)
			{
				anglex=-anglex;
				angley=-angley;
			}
		    midx=seedx+dist1/2.0*anglex;
			midy=seedy+dist1/2.0*angley;
			///
			int max=0;
            for (int d=0;d<16;d++)
			{
				int tmpx=int(seedx+anglex*d);
				int tmpy=int(seedy+angley*d);
			    if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=tmpx;
					midy=tmpy;
				}else
				{
					break;//��ʼ������·�ˣ�˵���������ȳ��ֵĸ߷�
				}
			}
			if (max<100)//��ʱ���ǲ��ų�����㷴�˵����
			{
				for (int d=0;d>-10;d--)
				{
					int tmpx=int(seedx+anglex*d);
					int tmpy=int(seedy+angley*d);
					if (qRed(m_image.pixel(tmpx,tmpy))>max)
					{
						max=qRed(m_image.pixel(tmpx,tmpy));
						midx=tmpx;
						midy=tmpy;
					}else
					{
						break;
					}
				}
			}

		}
		//////////////////////////////////////////////

		pos.m_vPoint.push_back(QPointF(float(midx),float(midy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
		
		
		//��һ��Ҳ��֮ǰ�������ڹ����б����±��ε�����
		const float *f = getDirection(w,h,cn,flow,xx,yy);
		tangx=f[1];
		tangy=-f[0];
		if (tangx*prevx+tangy*prevy<0)
		{
			tangx=-tangx;
			tangy=-tangy;
		}
		prevx=tangx;prevy=tangy;
		xx+=tangx;
		yy+=tangy;
		
		///���ҵı߽���Ϣ���������Ա��ж�junction
		for (int i=1;i<=4;i++)
		{
			leftPos[2*i-2]=leftPos[2*i];
			leftPos[2*i-1]=leftPos[2*i+1];
			rightPos[2*i-2]=rightPos[2*i];
			rightPos[2*i-1]=rightPos[2*i+1];
		}
		if (stepPos[0]!=stepPos[4] || stepPos[1]!=stepPos[5]) //real boundaries
		{
			leftPos[8]=seedx;
			leftPos[9]=seedy;			
			rightPos[8]=xx;
			rightPos[9]=yy;
		}
		
		///�ж��Ƿ�������ĩ��
 		if  ((cnt>=6 && judgeEdgeEnd(midx,midy,tangx,tangy, w,h,12,this->m_image))||!isInImage(midx+prevTangx,midy+prevTangy,w,h))
		{
			return true;//���Ƿֲ�
		}
	}
	int sz=pos.m_vPoint.size();
	pos.m_vPoint.push_back(QPointF(midx+pos.m_vPoint[sz-1].x()-pos.m_vPoint[sz-4].x(),midy+pos.m_vPoint[sz-1].y()-pos.m_vPoint[sz-4].y()));
	
	///�ѷ��򴫵ݻ�ȥ
	///�߽����ȶ���ǰ��һ�㣬���㷽�򣻷�����ʵ����̫������
	for (int i=0;i<=5;i++)
	{
		const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		//���ݼ�����ķ���track
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
	    prevTangx=tangx;
		prevTangy=tangy;
	}
	px=prevTangx;//�����յķ���
	py=prevTangy;

	for (int i=0;i<=5;i++)
	{
		const float *fseed = getDirection(w,h,4,flow,int(xx+0.5),int(yy+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float tangsign = tangx*prevx + tangy*prevy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		//���ݼ�����ķ���track
		xx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		yy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
	    prevx=tangx;
		prevy=tangy;
	}
	
	midx=prevx;//��һ��ķ���
	midy=prevy;
	return false;
}