
#pragma once

#include "ui_mainwindow.h"
#include <QToolBar>
#include "vectorize.h"
#include <vector>

class MainWindow : public QMainWindow, protected Ui_MainWindow 
{
	Q_OBJECT
public:
	MainWindow();
	~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

private slots:
	void loadImage();
	void saveImage();

	void treeItemClicked(QTreeWidgetItem * item, int column);

private:
	void createAction();
	void createMenus();
	void createToolBar();
	void updateTreeWidget();

	void loadTemp();
	void updateShowImage(const QImage &indexImg);

protected:
	void mouseMoveEvent ( QMouseEvent * en);
	void mousePressEvent ( QMouseEvent * en);
	void mouseReleaseEvent ( QMouseEvent * en);	

private:
	static MainWindow*	_mainWindow;

	QMenu *fileMenu;
	QToolBar *fileToolBar;
	QAction *loadImageAct;
	QAction *saveImageAct;

	QMenu *editMenu;
	QMenu *helpMenu;

	QToolBar *editToolBar;


	/// algorithm
	QImage  m_srcImg;
	QImage  m_idxImg;
	QImage  m_showImg;

	QPoint	m_pressedPos;
	bool	m_pressed;
	int		m_pressedIndex;
	std::vector<int> m_vGroupIndex;

	Papercut  pcut;
};