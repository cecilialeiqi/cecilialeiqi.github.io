#include <vector>
#include <QImage>
#include <QApplication>
#include <QIcon>
#include "mainWindow.h"

int main(int argc, char **argv)
{
	QApplication::setStyle("plastique");

	QApplication::setOrganizationDomain("Jiazhou");
	QApplication::setOrganizationName("Jiazhou");
	QApplication::setApplicationName("flowDesign");
	QApplication app(argc, argv);
	app.setWindowIcon(QIcon("./app.ico"));

	MainWindow *mw = MainWindow::getInstance();
	mw->showNormal();
	return app.exec();
}