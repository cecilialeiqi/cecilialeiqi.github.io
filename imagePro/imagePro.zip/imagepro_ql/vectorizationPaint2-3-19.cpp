#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);
	
	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	ImagePaint::tracking(sktGraph, m_imgSize.width(),m_imgSize.height(),4,pGradS,100);
		
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}

float Dist(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2));
}

bool judgeJunctionArea(float *leftPos,float *rightPos)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0&&rightPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];///��ʵӦ�������������ֿ����ǵ�junction point,�ӽ��Ļ������ڵ�end point
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)
		if (Dist(leftPos[i],leftPos[i+1],rightPos[i],rightPos[i+1])<Dist(leftPos[8],leftPos[9],rightPos[8],rightPos[9]))//cos30
	{/*
		for (i=0;i<=8;i+=2)
		{
			cout<<leftPos[i]<<' '<<leftPos[i+1]<<endl;
		}
		for (i=0;i<=8;i+=2)
		{
			cout<<rightPos[i]<<' '<<rightPos[i+1]<<endl;
		}
		*/
		return true;//directions we got from left and right boundaries are too different ==> junction area
	}
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(abs(mag)>magMax)
			{
				distMax = -k;
				magMax = abs(mag);
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

void ImagePaint::centerDirection(float* tang, int w, int h, int cn, float px, float py, float *flow)
{
	float stepPos[8];
	const int proWidth = 8;
	findStepPosition(stepPos,px,py,w,h,proWidth, flow);
	float fleftx,flefty,frightx,frighty;
	if (isInImage(stepPos[0],stepPos[1],w,h))
	{
	    const float *fleft = getDirection(w, h, cn,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
	    fleftx=fleft[1];
	    flefty=-fleft[0];
	}else
	{
		const float *fleft = getDirection(w, h, cn,flow,int(px+0.5),int(py+0.5));
		fleftx=fleft[1];
	    flefty=-fleft[0];

	}
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	if (isInImage(stepPos[4],stepPos[5],w,h))
	{
		const float *fright = getDirection(w,h, 4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}else
	{
		const float *fright = getDirection(w,h, 4,flow,int(px+0.5),int(py+0.5));
		frightx=fright[1];
		frighty=-fright[0];
	}
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	//float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	//return tang;
}
bool judgeJunctionArea(float leftx,float lefty,float rightx,float righty,float seedx,float seedy)
{
	float dist1=Dist(leftx,lefty,seedx,seedy);
    float dist2=Dist(rightx,righty,seedx,seedy);
	if (dist1>10 && dist1>2*dist2 || dist2>10 && dist2>2*dist1)
		return true;
	return false;
}
bool judgeJunctionArea(float fleftx,float flefty,float frightx,float frighty)
{
	float cosine=(fleftx*frightx+flefty*frighty)/Dist(fleftx,flefty,0,0)/Dist(frightx,frighty,0,0);
	if (cosine>=cos(3.1415/6))
		return false;
	return true;//��junctionArea��
}
bool findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS,QImage m_image)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(xx-tangy,yy+tangx)))
			{
				distMax = k;
				magMax = abs(mag);
			}else
			{
				if (distMax>3)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<30)
			break;
	}
	if (flag)//�������ˣ���ʱ����߽���ܲ�׼ȷ����ʹ��ԭ�����м�����=>ʹ��retract��Ч
	{
		return false;
	}else
	{
		stepPos[0] = -float(distMax)*tangy+float(pxi);
		stepPos[1] = float(distMax)*tangx+float(pyi);
		stepPos[2] = float(distMax);
		stepPos[3] = magMax;
	}
	distMax = 0;
	magMax = 0.0;
	flag=false;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(abs(mag)>magMax)
			if (qRed(m_image.pixel(xx,yy))>=qRed(m_image.pixel(xx+tangy,yy-tangx)))
			{
				distMax = -k;
				magMax = abs(mag);
			}else
			{
				if (distMax>3)//������ʼ�����ˣ�����ͷ��
				{
					break;
				}
			}
		if (distMax!=0 && qRed(m_image.pixel(xx,yy))<30)
			break;
	}
	if (flag)
	{
		return false;
	}else
	{
		stepPos[4] = -float(distMax)*tangy+float(pxi);
		stepPos[5] = float(distMax)*tangx+float(pyi);
		stepPos[6] = float(distMax);
		stepPos[7] = magMax;
	}
	return true;
}

void rotateDirection(float &dx, float &dy, float angle)
{
	float px = dx, py=dy;
	dx = cos(angle)*px - sin(angle)*py;
	dy = sin(angle)*px + cos(angle)*py;
}

bool judgeEdgeEnd(float px,float py, float tangx, float tangy, int w,int h, int radius,QImage m_image)
{

	if (!isInImage(px+tangx*radius,py+tangy*radius,w,h)||qRed(m_image.pixel(px+tangx*radius,py+tangy*radius))<=0)
	{
		rotateDirection(tangx,tangy,3.14/12);
		if (qRed(m_image.pixel(px+tangx*radius,py+tangy*radius))<=30)
		{
			rotateDirection(tangx,tangy,-3.14/6);
			if (qRed(m_image.pixel(px+tangx*radius,py+tangy*radius))<=30)
				return true;
		}
	}
	return false;

}


void ImagePaint::tracking(skeleton::SkeletonGraph &sktGraph, int w, int h, int cn, float *flow, int maxLength)
{
	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<skeleton::Vertex> vertexStack,vertexRecord;//second one means angle
    vector<QPointF> angleStack,angleRecord;
	
	/// get the original direction
	//QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	float tang[2];
	m_record=m_image;/////

	centerDirection(tang, m_imgSize.width(),m_imgSize.height(),4,sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y(),flow);
	vertexStack.push_back(sktGraph.m_vVertex[0]);
	angleStack.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexStack.push_back(sktGraph.m_vVertex[0]);
	angleStack.push_back(QPointF(tang[0],tang[1]));
	int cnt=0;
	while(!vertexStack.empty()&&cnt<=maxLength)//////////////////////
	{
		cnt++;
		///��ջ
		vertexRecord.push_back(vertexStack[vertexStack.size()-1]);
		QPointF vertex=vertexStack[vertexStack.size()-1].m_pos;
		vertexStack.pop_back();
		angleRecord.push_back(angleStack[angleStack.size()-1]);
		QPointF angle=angleStack[angleStack.size()-1];
		angleStack.pop_back();
		
		//skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGradS,vertexStack,angleStack, vertexRecord, angleRecord);

		float seedx=vertex.x();
		float seedy=vertex.y();
		float tangx=angle.x();
		float tangy=angle.y();
		skeleton::Edge pos;//(QPointF(px,py));
		if(seedx<0 || seedy<0 || seedx>=w || seedy>=h)
		{
			cout << "seed should not out of the image." << endl;
			continue;
		}

		int cnt = 0;
		float prevTangx = tangx;
		float prevTangy = tangy;
		float stepPos[8];
		const int proWidth = 8;

		////first step: get out of the junction area, Ӧ���ȸ�������ĳһ������
	
		if (!ImagePaint::trackingEdge(pos,w,h,seedx,seedy,cn,tangx,tangy,flow))///meet a junction point
		//seedx,seedy,startx,starty���ĸ������������������������ķ���
		{//record the two possible vectors
			//junction�Լ�������ջ��
			///////////////////////////////////���һ��ÿ��junction��Χ������
		    if (pos.m_vPoint.size()>1)
			{
				sktGraph.m_vEdge.push_back(pos);
				int edgeSz=sktGraph.m_vEdge.size();
				int pointSz=sktGraph.m_vEdge[edgeSz-1].m_vPoint.size();
				QPointF m_jPoint=sktGraph.m_vEdge[edgeSz-1].m_vPoint[pointSz-1];
				sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));

				///record��¼�����Ѿ����ٹ��ģ�stack�Ǵ�track��
				///����յ�ͷ������Ѿ����ٹ����غϣ�˵������һ��Ȧ��һ������������򲢲���¼��
				///����յ�ͷ������track���غϣ�����һ������·�ڣ�������򲢲���¼
				///���������Ѿ����ٹ����෴����Ҳ��һ�������⣬�Ȳ���
				///�������ʹ�track���෴����ԭ���ķ���ɾ��,��������������򲻼�¼������
				int cases=0;
				for (int i=0;i<vertexRecord.size();i++)
				{
					if (Dist(m_jPoint.x(),m_jPoint.y(),vertexRecord[i].m_pos.x(),vertexRecord[i].m_pos.y())<=10)
					{
						if ((seedx*angleRecord[i].x()+seedy*angleRecord[i].y())/Dist(seedx,seedy,0,0)/Dist(angleRecord[i].x(),angleRecord[i].y(),0,0)>cos(3.1415/12))
						{
							cases=2;
							break;
						}
						if ((seedx*angleRecord[i].x()+seedy*angleRecord[i].y())/Dist(seedx,seedy,0,0)/Dist(angleRecord[i].x(),angleRecord[i].y(),0,0)<-cos(3.1415/12))
						{
							cases=4;
							break;
						}
					}
				}
				for (int i=0;i<vertexStack.size();i++)
				{
					if (Dist(m_jPoint.x(),m_jPoint.y(),vertexStack[i].m_pos.x(),vertexStack[i].m_pos.y())<=10)
					{
						if ((tangx*angleStack[i].x()+tangy*angleStack[i].y())/Dist(tangx,tangy,0,0)/Dist(angleStack[i].x(),angleStack[i].y(),0,0)>cos(3.1415/12))
						{
							cases=1;
							break;
						}
						if ((tangx*angleStack[i].x()+tangy*angleStack[i].y())/Dist(tangx,tangy,0,0)/Dist(angleStack[i].x(),angleStack[i].y(),0,0)<-cos(3.1415/12))
						{
							cases=3;
							break;
						}
					}
				}
				if ((cases!=1)&&(cases!=2)&&(cases!=4))
				{
					vertexStack.push_back(skeleton::Vertex::Vertex(QPointF(pos.m_vPoint[pos.m_vPoint.size()-1].x(),pos.m_vPoint[pos.m_vPoint.size()-1].y()),true));
					angleStack.push_back(QPointF(seedx,seedy));
					cout<<vertexStack[vertexStack.size()-1].m_pos.x()<<','<<vertexStack[vertexStack.size()-1].m_pos.y()<<endl;
					cout<<angleStack[angleStack.size()-1].x()<<' '<<angleStack[angleStack.size()-1].y()<<endl;

					if ((seedx*tangx+seedy*tangy)/Dist(seedx,seedy,0,0)/Dist(tangx,tangy,0,0)<cos(3.1415/12))
					{
						vertexStack.push_back(vertexStack[vertexStack.size()-1]);
						angleStack.push_back(QPointF(tangx,tangy));		
    					cout<<angleStack[angleStack.size()-1].x()<<' '<<angleStack[angleStack.size()-1].y()<<endl;
					}
				}

			}
		
		}else if (pos.m_vPoint.size()>1)
		{
			sktGraph.m_vEdge.push_back(pos);
			int edgeSz=sktGraph.m_vEdge.size();
			int pointSz=sktGraph.m_vEdge[edgeSz-1].m_vPoint.size();
			QPointF m_jPoint=sktGraph.m_vEdge[edgeSz-1].m_vPoint[pointSz-1];
			sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,false));
		}
		
	}

}


bool leftWay(vector<tracking::Pot3f> &leftPos, vector<tracking::Pot3f> &rightPos)
{
	float left=0;
	float right=0;
	for (int i=1;i<leftPos.size();i++)
	{
		if (abs(leftPos[i].ang-leftPos[i-1].ang)>3)
		   left+=abs(-3.1415*2+abs(leftPos[i].ang-leftPos[i-1].ang));
		else
    		left+=abs(leftPos[i].ang-leftPos[i-1].ang);
		if (abs(rightPos[i].ang-rightPos[i-1].ang)>3)
			right+=abs(-3.1415*2+abs(rightPos[i].ang-rightPos[i-1].ang));
		else
    		right+=abs(rightPos[i].ang-rightPos[i-1].ang);
	}
	if (left<right)
		return true;
	return false;
}

void ImagePaint::Record(skeleton::Edge &pos, int recordCnt, float width)
{
	for (int i=1;i<=recordCnt;i++)
	{
		float px=int(0.5+pos.m_vPoint[pos.m_vPoint.size()-i].x());
		float py=int(0.5+pos.m_vPoint[pos.m_vPoint.size()-i].y());
		for (int xx=int(-width/2-0.5);xx<width/2+1;xx++)
			for (int yy=int(-width/2-0.5);yy<width/2+1;yy++)
				if (xx*xx+yy*yy<=width*width/4)
				{
					m_record.setPixel(px+xx,py+yy,0);
				}
	}
}

bool ImagePaint::trackingEdge(skeleton::Edge &pos, int w, int h, float &px, float &py,int cn, float &tangx, float &tangy, float *flow)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		//return pos;
	}
	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float stepPos[8];
 	float dist=sqrt(tangx*tangx+tangy*tangy);
	tangx=tangx/dist;
	tangy=tangy/dist;
	float fleftx,flefty,frightx,frighty;
	float width=0;
	pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	//cout<<seedx<<','<<seedy<<endl;         
	///��ʼ��һ�ν����������߽���ϢҲ�������ݶ���Ϣ������һ��ʼ��junction�������ܻ��������
	while(cnt<9 || judgeJunctionArea(fleftx,flefty,frightx,frighty))//ǰ9�����أ��߳�junctionArea
	{
		
		//���ݼ�����ķ���track
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
		float anglex=-tangy;
		float angley=tangx;
		int max=0;
		float midx=seedx;
		float midy=seedy;
		if (qRed(m_image.pixel(seedx,seedy))<100)
        for (int d=-2;d<2;d++)
		{
			int tmpx=int(seedx+anglex/2*d+0.5);
			int tmpy=int(seedy+angley/2*d+0.5);
		    if (isInImage(tmpx,tmpy,w,h))
			{
				if (qRed(m_image.pixel(tmpx,tmpy))>max)
				{ 
					max=qRed(m_image.pixel(tmpx,tmpy));
					midx=seedx+anglex/2*d;
					midy=seedy+angley/2*d;
				}
			}
		}//����϶�����Ҫ�ģ���Ȼһ���̶��ķ���϶���������ѽ
		seedx=midx;
		seedy=midy;
		if (cnt>8)
		{ 
			const float *fseed0 = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
			if (!findBoundary(stepPos,seedx,seedy,w,h,fseed0[1],-fseed0[0],8,flow,m_image))
				continue;

		    const float *fseed = getDirection(w,h,4,flow,int(stepPos[0]+0.5),int(stepPos[1]+0.5));
			fleftx = fseed[1];
			flefty = -fseed[0];
			if (fleftx*tangx+flefty*tangy<0)
			{
				fleftx=-fleftx;
				flefty=-flefty;
			}
			const float *fseed2 = getDirection(w,h,4,flow,int(stepPos[4]+0.5),int(stepPos[5]+0.5));
			frightx = fseed2[1];
			frighty = -fseed2[0];
			if (frightx*tangx+frighty*tangy<0)
			{
				frightx=-frightx;
				frighty=-frighty;
			}
		}
		//pos.m_vPoint.push_back(QPointF(float(seedx),float(seedy)));
		cnt ++;

		//�ж��Ƿ�����������ĩ��
		if  ((cnt>=6 && qRed(m_image.pixel(int(seedx+0.5),int(seedy+0.5))==0))||!isInImage(midx+tangx,midy+tangy,w,h))
		{
			return true;//���Ƿֲ棬����Ҫ�����ߣ�Ҳ����Ҫ��Junction��ջ
		}
	}
	///ǰ����һ���ֵ����������߳�junction����Χ��������������һ����п��ܳ���
	//�ҳ�������Ϣ
	//pos.m_vPoint.push_back(QPointF(seedx,seedy));////////
	float prevTangx = tangx;
	float prevTangy = tangy;
	float prevx = tangx;
	float prevy = tangy;

	//cout<<seedx<<','<<seedy<<endl;
	//float tmpx,tmpy;
    const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
	findBoundary(stepPos,seedx,seedy,w,h,fseed[1],-fseed[0],8,flow,m_image);
	float leftx=stepPos[0];
	float lefty=stepPos[1];
	float rightx=stepPos[4];
	float righty=stepPos[5];
	///��ʱ�����ҽ���Ϣ�ǿ��������ġ�����ǰ�����Ƶأ�������ǰ��
	seedx=(leftx+rightx)/2.0;
	seedy=(lefty+righty)/2.0;
	pos.m_vPoint.push_back(QPointF(seedx,seedy));

	width=Dist(leftx,lefty,rightx,righty);
	vector<tracking::Pot3f> leftPos, rightPos, pos1, pos2;

	cnt=0;
	int count=0;
	bool flag=false;
	int recordCnt;
	while(cnt<200)
	{
		///��������
		const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
		float dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;
		//��ԭ����һ�£���Ҫ�㷴��
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		leftx += tangx;
		lefty += tangy;
		prevTangx = tangx;
		prevTangy = tangy;
				
		//��һ��Ҳ��֮ǰ��
		const float *f = getDirection(w,h,cn,flow,int(rightx+0.5),int(righty+0.5));
		tangx=f[1];
		tangy=-f[0];
	 	if (tangx*prevx+tangy*prevy<0)
		{
			tangx=-tangx;
			tangy=-tangy;
		}
		prevx=tangx;prevy=tangy;
		rightx+=tangx;
		righty+=tangy;
		/////////////////////////////////////////
		if (Dist(leftx,lefty,rightx,righty)<3)
		{
			const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
			tangx = fseed[1];
			tangy = -fseed[0];
			//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
			float dist=sqrt(tangx*tangx+tangy*tangy);
			tangx=tangx/dist;
			tangy=tangy/dist;
			//��ԭ����һ�£���Ҫ�㷴��
			float tangsign = tangx*prevTangx + tangy*prevTangy;
			if(tangsign<0.0)
			{
	    		tangx = -tangx;
				tangy= -tangy;
			}		
			findBoundary(stepPos,seedx,seedy,w,h,tangx,tangy,8,flow,m_image);
			if (Dist(leftx,lefty,stepPos[0],stepPos[1])<Dist(rightx,righty,stepPos[0],stepPos[1]))
			{
				leftx=stepPos[0];
				lefty=stepPos[1];
				rightx=stepPos[4];
				righty=stepPos[5];
			}else
			{
				rightx=stepPos[0];
				righty=stepPos[1];
				leftx=stepPos[4];
				lefty=stepPos[5];
			}
		}
		///////////////////////////////
		/////ʹ�������߱���ͬ��������
		for(int i=1;i<3;i++)
		{
			const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
			tangx = fseed[1];
			tangy = -fseed[0];
			//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
			float dist=sqrt(tangx*tangx+tangy*tangy);
			tangx=tangx/dist;
			tangy=tangy/dist;
			//��ԭ����һ�£���Ҫ�㷴��
			float tangsign = tangx*prevTangx + tangy*prevTangy;
			if(tangsign<0.0)
			{
				tangx = -tangx;
				tangy= -tangy;
			}
			if (Dist(leftx+tangx,lefty+tangy,rightx,righty)<Dist(leftx,lefty,rightx,righty))
			{
				leftx+=tangx;
			    lefty+=tangy;
				prevTangx = tangx;
				prevTangy = tangy;			
			}else
			{
				const float *f = getDirection(w,h,cn,flow,int(rightx+0.5),int(righty+0.5));
				tangx=f[1];
				tangy=-f[0];
	 			if (tangx*prevx+tangy*prevy<0)
				{
					tangx=-tangx;
					tangy=-tangy;
				}
				if (Dist(rightx+tangx,righty+tangy,leftx,lefty)<Dist(rightx,righty,leftx,lefty))
				{
					prevx=tangx;prevy=tangy;
					rightx+=tangx;
					righty+=tangy;
				}else///���Ҷ������ƶ��ˣ���ǰλ����ѣ����Կ���������
					break;

			}

		}
		float angle1=atan2(prevTangy,prevTangx);
		float angle2=atan2(prevx,prevy);
		leftPos.push_back(tracking::Pot3f(leftx,lefty,angle1));
		rightPos.push_back(tracking::Pot3f(rightx,righty,angle2));

		//////////////�������ҵ���ͬ���ˣ������������ұ߽�ľ������ж��Ƿ�ֿ���
		
		///�ж��Ƿ����junction
		cnt++;
		if (!flag)
		{
			seedx=(leftx+rightx)/2;
			seedy=(lefty+righty)/2;
			pos.m_vPoint.push_back(QPointF(seedx,seedy));
			//cout<<leftx<<','<<lefty<<"    "<<(leftx+rightx)/2<<','<<(lefty+righty)/2<<"      "<<rightx<<','<<righty<<endl;


		}
		if (cnt>=6 && !flag)
		{
			////���������һ���ǵ��߶�ĩβ�ˣ�һ�������߷ֿ���
			float fleftx=(leftPos[leftPos.size()-1].x-leftPos[leftPos.size()-4].x)/3;
			float flefty=(leftPos[leftPos.size()-1].y-leftPos[leftPos.size()-4].y)/3;
			float frightx=(rightPos[rightPos.size()-1].x-rightPos[rightPos.size()-4].x)/3;
			float frighty=(rightPos[rightPos.size()-1].y-rightPos[rightPos.size()-4].y)/3;
			if (judgeJunctionArea(fleftx,flefty,frightx,frighty))///���߷ֿ�30�������
			{
				flag=true;
				recordCnt=cnt;
			}
			width=Dist(leftx,lefty,rightx,righty);///�����������������Щ�仯����Ҫ��ʱ����
			if (judgeEdgeEnd((leftx+rightx)/2,(lefty+righty)/2,fleftx,flefty,w,h,5,m_image) && judgeEdgeEnd((leftx+rightx)/2,(lefty+righty)/2,frightx,frighty,w,h,5,m_image))
			{
				return true;
			}
		}
		///����֮���Ѿ����ֹ��ˣ�
		if (flag && (Dist(leftx,lefty,rightx,righty)>2*width && Dist(leftx,lefty,rightx,righty>12) && cnt-recordCnt>10))///������ֿ���һ��û����ģ����淽���Ǵӿ�ʼ�б仯֮���ٿ�ʼ��
		{
			break;
		}
		if (!isInImage(leftx+3*prevTangx,lefty+3*prevTangy,w,h) || !isInImage(rightx+3*prevx,righty+3*prevy,w,h))
		{
			return true;
		}
	}
	Record(pos,recordCnt,width);
	float leftMax=0;
	float leftK=0;
	float rightMax=0;
	float rightK=0;
	for (int i=recordCnt;i<cnt-1;i++)
	{
		float langle=abs(leftPos[i+1].ang-leftPos[i].ang);
		if (langle>3.14)
			langle=abs(langle-2*3.1415);
		float rangle=abs(rightPos[i+1].ang-rightPos[i].ang);
		if (rangle>3.14)
			rangle=abs(rangle-2*3.1415);
		if (langle>leftMax)
		{
			leftMax=langle;
			leftK=i;
		}
		if (rangle>rightMax)
		{
			rightMax=rangle;
			rightK=i;
		}
	}
	while (leftK+4>=cnt || rightK+4>=cnt)
	{
		const float *fseed = getDirection(w,h,4,flow,int(leftx+0.5),int(lefty+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
		float dist=sqrt(tangx*tangx+tangy*tangy);
		tangx=tangx/dist;
		tangy=tangy/dist;
		//��ԭ����һ�£���Ҫ�㷴��
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		
		///��ǰ��һ��������Ѱ���������λ��
		leftx += tangx;
		lefty += tangy;
		prevTangx = tangx;
		prevTangy = tangy;
		
		//��һ��Ҳ��֮ǰ��
		const float *f = getDirection(w,h,cn,flow,int(rightx+0.5),int(righty+0.5));
		tangx=f[1];
		tangy=-f[0];
	 	if (tangx*prevx+tangy*prevy<0)
		{
			tangx=-tangx;
			tangy=-tangy;
		}
		prevx=tangx;prevy=tangy;
		rightx+=tangx;
		righty+=tangy;
		cnt++;
		float angle1=atan2(prevTangy,prevTangx);
		float angle2=atan2(prevx,prevy);
		leftPos.push_back(tracking::Pot3f(leftx,lefty,angle1));
		rightPos.push_back(tracking::Pot3f(rightx,righty,angle2));
	}
	px=(leftPos[leftK+4].x-leftPos[leftK+1].x)/3;//�����յķ���
	py=(leftPos[leftK+4].y-leftPos[leftK+1].y)/3;
	//cout<<'L'<<px<<','<<py<<endl;
	tangx=(rightPos[rightK+4].x-rightPos[rightK+1].x)/3;//��һ��ķ���
	tangy=(rightPos[rightK+4].y-rightPos[rightK+1].y)/3;
	//cout<<'R'<<tangx<<','<<tangy<<endl;
	///////////////////////�ⲿ����Ϊ���Һ��ʵ����Ҳ෽��

	//���жϸ���ߺû��Ǹ��ұߺ�
	float tmpx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
	float tmpy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
	seedx=tmpx;
	seedy=tmpy;

	prevx=pos.m_vPoint[pos.m_vPoint.size()-1].x()-pos.m_vPoint[pos.m_vPoint.size()-4].x();
	prevy=pos.m_vPoint[pos.m_vPoint.size()-1].y()-pos.m_vPoint[pos.m_vPoint.size()-4].y();
	float maxRed=qRed(m_image.pixel(int(tmpx+10*tangx+0.5),int(tmpy+10*tangy+0.5)))+qRed(m_image.pixel(int(tmpx+10*px+0.5),int(tmpy+10*py+0.5)))+qRed(m_image.pixel(int(tmpx+0.5),int(tmpy+0.5)));
    for (int i=0;i<cnt-recordCnt;i++)
	{
		const float *fseed = getDirection(w,h,4,flow,int(tmpx+0.5),int(tmpy+0.5));
		float flowx = fseed[1];
		float flowy = -fseed[0];
		//��һ����֪��Ϊʲô���ֺö඼û�й�һ��
		float dist=sqrt(flowx*flowx+flowy*flowy);
		flowx=flowx/dist;
		flowy=flowy/dist;
		//��ԭ����һ�£���Ҫ�㷴��
		float tangsign = flowx*prevx + flowy*prevy;
		if(tangsign<0.0)
		{
			flowx = -flowx;
			flowy = -flowy;
		}		
		tmpx+=flowx;
		tmpy+=flowy;
		float red=qRed(m_image.pixel(int(tmpx+10*tangx+0.5),int(tmpy+10*tangy+0.5)))+qRed(m_image.pixel(int(tmpx+10*px+0.5),int(tmpy+10*py+0.5)))+qRed(m_image.pixel(int(tmpx+0.5),int(tmpy+0.5)));
		//cout<<tmpx<<','<<tmpy<<"     "<<red<<endl;
		if (red>maxRed)
		{
			maxRed=red;
			seedx=tmpx;
			seedy=tmpy;
		}else
		{
			if (maxRed>600)
				break;
		}
	}
	pos.m_vPoint.push_back(QPointF(seedx,seedy));
	
	//��¼

	return false;
}
