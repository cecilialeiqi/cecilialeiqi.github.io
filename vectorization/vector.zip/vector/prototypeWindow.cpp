
#include "prototypeWindow.h"
#include "param.h"
#include "paramui.h"

MainWindow *MainWindow::_mainWindow = NULL;

MainWindow::MainWindow() {
    setupUi(this);
    m_dirty = false;
	addAction(actionQuit);
	addAction(actionToolBox);
	addAction(actionFullScreen);
	addAction(actionReloadShader);

	m_dockWidget->move(0,0);

    m_imagePaint->setFocus();

	m_selectitem->addItems(displayList);
	m_selectitem->setCurrentIndex(0);

	//////////////////////// set up the parameter part of the toolbox 
	/// add all the parameter units
	new ParamInt(this, "smoothSize", 5, 1, 100, 1, m_imagePaint->smoothSizePtr());

	QStringList paramList;
	paramList << QString("smoothSize") ;
	ParamUI *pui = new ParamUI(this, this, paramList);
	pui->setMinimumWidth(100);
	pui->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
	m_vboxTool->addWidget(pui);


	m_vboxTool->addStretch(100);

	/// examples
	//new ParamGroup(this, "T1", true);
	//new ParamBool(this, "T2", true);
	//new ParamString(this, "T3", QString("whT3"), true);
	//new ParamChoice(this, "T4", QString("wsT4"), QString("ws2T4|ws2T41|ws2T42|ws2T43"));
	//new ParamEnum(this, "T5", 3, QString("wssT5|wssT51|wssT52"));
	//new ParamImage(this, "T6", QString("test.png"));
    //new ParamInt   (this, "N", 5, 1, 100, 1, &m_N);
    //new ParamDouble(this, "sigma_d", 1.0, 0.0, 10.0, 0.05, &m_sigma_d);

	/////////////////////////////// connection building
    connect(m_selectitem, SIGNAL(currentIndexChanged(int)), m_imagePaint, SLOT(onIndexChanged(int)));

    m_player = new VideoPlayer(this, ":/test.png");
    connect(m_player, SIGNAL(videoChanged(int)), this, SLOT(onVideoChanged(int)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), this, SLOT(setDirty()));
    connect(m_player, SIGNAL(outputChanged(const QImage&)), m_imagePaint, SLOT(setImage(const QImage&)));
    connect(this, SIGNAL(imageChanged(const QImage&)), m_player, SLOT(setOutput(const QImage&)));

    m_videoControls->setFrameStyle(QFrame::NoFrame);
    m_videoControls->setAutoHide(true);
    connect(m_videoControls, SIGNAL(stepForward()), m_player, SLOT(stepForward()));
    connect(m_videoControls, SIGNAL(stepBack()), m_player, SLOT(stepBack()));
    connect(m_videoControls, SIGNAL(currentFrameTracked(int)), m_player, SLOT(setCurrentFrame(int)));
    connect(m_videoControls, SIGNAL(playbackChanged(bool)), m_player, SLOT(setPlayback(bool)));
    connect(m_videoControls, SIGNAL(trackingChanged(bool)), this, SLOT(setDirty()));

    connect(m_player, SIGNAL(videoChanged(int)), m_videoControls, SLOT(setFrameCount(int)));
    connect(m_player, SIGNAL(playbackChanged(bool)), m_videoControls, SLOT(setPlayback(bool)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), m_videoControls, SLOT(setCurrentFrame(int)));

	/// status bar
	statusBar()->showMessage(tr("WElCOME!"));

	m_statusMouseLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusMouseLabel);
	m_statusMouseLabel->setText("| Pos: (0,0)");

	m_statusZoomLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusZoomLabel);
	m_statusZoomLabel->setText("| Zoom: 100%");
}
   

MainWindow::~MainWindow() {
}

void MainWindow::restoreSettings() {
    QSettings settings;
    restoreGeometry(settings.value("mainWindow/geometry").toByteArray());
    restoreState(settings.value("mainWindow/windowState").toByteArray());

    settings.beginGroup("imagePaint");
    m_imagePaint->restoreSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::restoreSettings(settings, this);
    settings.endGroup();

    m_player->restoreSettings(settings);
}

void MainWindow::closeEvent(QCloseEvent *e) {
    QSettings settings;
    settings.setValue("mainWindow/geometry", saveGeometry());
    settings.setValue("mainWindow/windowState", saveState());

    settings.beginGroup("imageView");
    m_imagePaint->saveSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::saveSettings(settings, this);
    settings.endGroup();

    m_player->saveSettings(settings);

    QMainWindow::closeEvent(e);
} 

void MainWindow::on_actionOpen_triggered() {
	m_player->open();
}

void MainWindow::on_actionAbout_triggered() {
    QMessageBox msgBox;
    msgBox.setWindowTitle("About");
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText(
        "<html><body>" \
        "<p><b>Semantic-based LoD</b><br/><br/>" \
        "Author: Jiazhou CHEN <br/>" \
        "Date: " __DATE__ "</p>" \
        "<p>This program is free software: you can redistribute it and/or modify " \
        "it under the terms of the GNU General Public License as published by " \
        "the Free Software Foundation, either version 3 of the License, or " \
        "(at your option) any later version.</p>" \
        "<p>This program is distributed in the hope that it will be useful, " \
        "but WITHOUT ANY WARRANTY; without even the implied warranty of " \
        "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the " \
        "GNU General Public License for more details.</p>" \

		"Parts of the framework of this software are copied and modified " \
		"from the source code of the softwares developed by: <br/>" \
		" Jan Eric Kyprianidis &lt;" \
		"<a href='http://www.kyprianidis.com'>www.kyprianidis.com</a> &gt; & <br/>" \
		" Romain Vergn &lt;" \
		"<a href='http://romain.vergne.free.fr'>http://romain.vergne.free.fr</a>&gt;<br/>" \
        /*"Related Publications:" \
        "<ul>" \
        "<li>" \
        "Kyprianidis, J. E., &amp; Kang, H. (2011). " \
        "Image and Video Abstraction by Coherence-Enhancing Filtering. " \
        "<em>Computer Graphics Forum</em>, 30(2), 593-602. " \
        "(Proceedings Eurographics 2011)" \
        "</li>" \
        "</ul>" \
        "<p>Test image courtesy of Ivan Mlinar @ flickr.com.</p>" \*/
        "</body></html>"
    );
    msgBox.setStandardButtons(QMessageBox::Ok);
    msgBox.exec();
}

void MainWindow::on_actionRecord_triggered() {
    m_player->record();
}

void MainWindow::setFullScreen() {
	if(isFullScreen())
	{
		showNormal();
		m_menuBar->setVisible(true);
	}
	else
	{
		showFullScreen();
		m_menuBar->setVisible(false);
	}
}

void MainWindow::setDirty() {
    if (m_videoControls->isTracking()) {
        imageChanged(m_player->image());
    }
    else if (!m_dirty) {
        m_dirty = true;
        QMetaObject::invokeMethod(this, "process", Qt::QueuedConnection);
    }
}

void MainWindow::process() {
    m_dirty = false;
    QImage src = m_player->image();
	m_result = src;
    imageChanged(image());
}

void MainWindow::onVideoChanged(int nframes) {
//    gpu_cache_clear();
    window()->setWindowFilePath(m_player->filename());
    window()->setWindowTitle(m_player->filename() + "[*]"); 
    actionRecord->setEnabled(nframes > 1);
}

void MainWindow::draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image) {
  	view->draw(p,R,image);
 }