#include "mlabel.h"
#include <QColorDialog>

Mlabel::Mlabel(QWidget *parent,unsigned int len)
	: QLabel(parent)
{
	this->m_length=len;
	InitPoints();
	setFixedHeight(25);

	m_maxCnt = 6;
	
}
void Mlabel::InitPoints(){
	points.push_back(vetex(0,QColor(0,0,255)));
	points.push_back(vetex(1.0,QColor(255,0,0)));
	Tpoints[0].setY(10);
	Tpoints[1].setY(20);
	Tpoints[2].setY(20);

}
bool Mlabel::GetEffectivePoint(int & pos,const QMouseEvent *ev){
	int shortest=m_length;
	int temp;
	int id;
	for(vec_sz i=0;i<points.size();i++){
		temp=abs((int)(ev->x()-points[i].GetPosition()*m_length));
		if(temp<shortest){
			shortest=temp;
			id=i;
		}
	}
	if(shortest<10){
		pos=id;
		return true;
	}
	return false;
}
void Mlabel::mouseDoubleClickEvent(QMouseEvent *ev){
	float x=ev->x()*1.0/m_length;
	int pnode;
	if(!GetEffectivePoint(pnode,ev) && points.size()<m_maxCnt)
	{
		QColor randomClr = QColor(rand()%255,rand()%255,rand()%255);
		QColor clr = QColorDialog::getColor(randomClr,this);
		if(clr.isValid())
		{
			points.push_back(vetex(x,clr));
			for(vec_sz i=0;i<points.size();i++)
			{
				if(i!=points.size()-1)
					points[i].setActive(false);
				else
					points[i].setActive(true);
			}
		}
		pointSorting();
	}
	update();
	emit labelUpdated();
}
Mlabel::~Mlabel()
{
}
void Mlabel::pointSorting()
{
	for(int k=0; k<points.size(); k++)
	{
		for(int i=0; i<points.size()-k-1; i++)
		{
			if(points[i].GetPosition()>points[i+1].GetPosition())
			{
				float tp = points[i].GetPosition();
				QColor tc = points[i].GetColor();
				points[i].setPosition(points[i+1].GetPosition());
				points[i].setColor(points[i+1].GetColor());
				points[i+1].setPosition(tp);
				points[i+1].setColor(tc);
			}
		}
	}
}
void Mlabel::updateImage()
{
	vector<vetex> ps;
	ps = points;

	int len = m_length-10;
	uchar *pScan = new uchar[len*3];
	/// compute a gradient line
	for(int pi=0; pi<ps.size()-1; pi++)
	{
		int pnl = int(ps[pi].GetPosition()*len);
		int pnr = int(ps[pi+1].GetPosition()*len);
		for(int k=pnl; k<pnr; k++)
		{
			double alp = double(k-pnl)/double(pnr-pnl-1);
			double rf = (1.0-alp)*ps[pi].GetColor().redF()+alp*ps[pi+1].GetColor().redF();
			double gf = (1.0-alp)*ps[pi].GetColor().greenF()+alp*ps[pi+1].GetColor().greenF();
			double bf = (1.0-alp)*ps[pi].GetColor().blueF()+alp*ps[pi+1].GetColor().blueF();
			pScan[k*3] = int(rf*255.0);
			pScan[k*3+1] = int(gf*255.0);
			pScan[k*3+2] = int(bf*255.0);
		}
		pnl = int(ps[0].GetPosition()*len);
		for(int k=0; k<pnl; k++)
		{
			pScan[k*3] = ps[0].GetColor().red();
			pScan[k*3+1] = ps[0].GetColor().green();
			pScan[k*3+2] = ps[0].GetColor().blue();
		}
		int last = ps.size()-1;
		pnr = int(ps[last].GetPosition()*len);
		for(int k=pnr; k<len; k++)
		{
			pScan[k*3] = ps[last].GetColor().red();
			pScan[k*3+1] = ps[last].GetColor().green();
			pScan[k*3+2] = ps[last].GetColor().blue();
		}
	}

	/// construct gradient image
	int h = 10;
	m_img = QImage(len,h,QImage::Format_RGB888);
	for(int yi=0; yi<h; yi++)
	{
		uchar *pImg = m_img.scanLine(yi);
		memcpy(pImg,pScan,sizeof(uchar)*len*3);
	}
	delete []pScan;
}
void Mlabel::paintEvent(QPaintEvent *e){
	QPainter painter(this);
	painter.setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::MiterJoin)); 
	updateImage();
	painter.drawImage(QPoint(5,0),m_img); 
	for(vec_sz i=0;i !=points.size();i++){
		int absPosition=(int)(points[i].GetPosition()*m_length);
		absPosition=absPosition<5?5:absPosition;
		absPosition=absPosition>m_length-5?m_length-5:absPosition;
		Tpoints[0].setX(absPosition);
		Tpoints[1].setX(absPosition-5);
		Tpoints[2].setX(absPosition+5);
		/*if(points[i].GetActive()){painter.setBrush(QBrush(Qt::blue,Qt::SolidPattern)); }
		else{painter.setBrush(QBrush(Qt::white, Qt::SolidPattern)); }*/
		painter.setBrush(QBrush(points[i].GetColor(),Qt::SolidPattern));
		painter.drawPolygon(Tpoints,3);
	}
	emit finish_paint();
}
void Mlabel::mousePressEvent(QMouseEvent *ev){
	int pnode;
	if(GetEffectivePoint(pnode,ev)){
		for(vec_sz i=0;i<points.size();i++){
			points[i].setActive(false);
		}
		points[pnode].setActive(true);
	}
}
void Mlabel::mouseMoveEvent(QMouseEvent *ev){
	float x=(ev->x()*1.0-5.0)/(m_length-10.0);
	x = x<0.0 ? 0.0:x;
	for(vec_sz i=0;i<points.size();i++){
		if(points[i].GetActive()){
			points[i].setPosition(x>1.0?1.0:x);
			update();
			break;
		}
	}
	emit labelUpdated();
}
void Mlabel::changeColor(QColor color){
	for(vec_sz i=0;i<points.size();i++){
		if(points[i].GetActive()){
			points[i].setColor(color);
			break;
		}
	}
}

int Mlabel::getPointSize()
{
	return points.size();
}
QColor Mlabel::getColor(int i)
{
	if(i<points.size())
		return points[i].GetColor();
	else
		return QColor(0,0,0);
}
float Mlabel::getPosition(int i)
{
	if(i<points.size())
		return points[i].GetPosition();
	else 
		return 0.0f;
}