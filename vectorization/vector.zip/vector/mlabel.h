#ifndef MLABEL_H
#define MLABEL_H

#include <QLabel>
#include<QPainter>
#include<QtGui>
#include<QMouseEvent>
//#include<cmath>
#include<vector>
//#include"drawlabel.h"
//#include "vetex.h"

using namespace std;
class QColor;

class vetex
{
public:
	vetex(float x,QColor col) {
		this->x=x;
		color=col;
		active=false;
	}
	float GetPosition(){return x;}
	QColor GetColor(){return color;}
	bool     GetActive(){return active;}
	void    setPosition(float p){x=p;}
	void    setColor(const QColor &col){color=col;}
	void    setActive(bool act){active=act;}
private:
	float  x;
	QColor color;
	bool     active;
};

typedef vector <vetex>::size_type vec_sz;
class Mlabel : public QLabel
{
	Q_OBJECT
//	friend class DrawLabel;
public:
	Mlabel(QWidget *parent,unsigned int);
	~Mlabel();
	void InitPoints();
	void paintEvent(QPaintEvent *e);
	void mouseMoveEvent(QMouseEvent *ev);
	void mouseDoubleClickEvent(QMouseEvent *);
	void mousePressEvent(QMouseEvent *ev);
	bool GetEffectivePoint(int &,const QMouseEvent *);
	void changeColor(QColor color);
	void updateImage();
	
	vector<vetex> getVetex() const {return points;}	

	int getPointSize();
	QColor getColor(int i);
	float getPosition(int i);

signals:
	void finish_paint();
	void labelUpdated();
protected:
	vector <vetex>	points;
	unsigned int m_length;
	QPoint Tpoints[3];
	QImage m_img;

	int m_maxCnt;

private:
	void pointSorting();

};

#endif // MLABEL_H
