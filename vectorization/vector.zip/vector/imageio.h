#ifndef IMAGEIO_H
#define IMAGEIO_H

#include <image.h>
#include <string>
#include <vector>

namespace image {

  class IMAGE_API ImageIO {
  public:
    static Image *createImage(const std::string &filename);
    static bool   saveImage(const Image &img,const std::string &filename);
    static bool   error();

    static std::string extensionAvailable();
    static std::string lastDir();
 
  private:
    static std::string _extensions;
    static std::string _lastDir;

    static void computeLastDir(const std::string &filename);
    static bool extensionInside(const std::string &filename,std::vector<std::string> ext);
    static bool _noError;
  };

} // image namespace

#endif // IMAGEIO_H
