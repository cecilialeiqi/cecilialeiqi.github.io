#ifndef VERTEXBUFFER_OBJECT_H
#define VERTEXBUFFER_OBJECT_H

#include "gpuDLL.h"
#include <glew.h>
#include <gl.h>
#include <assert.h>
#include <vector>
#include <iostream>

struct BufferData 
{
  GLuint      id;
  GLsizeiptr  buffersize;
  GLint       attribsize;
  const void *data; 
  
  union 
  {
    GLenum   cap;   // used in common attrib
    GLuint   index; // used in user defined attrib
  } name;
  
  GLsizei    stride;
};


struct IndexData 
{
  GLuint        id;
  GLsizeiptr    buffersize;
  const GLvoid *data;
  GLenum        mode; 
  GLsizei       count;
};


namespace gpu {

  class GPU_API VertexbufferObject {

  public:
    VertexbufferObject(GLenum usage=GL_STATIC_DRAW);
    ~VertexbufferObject();

    inline void setPositions(GLsizeiptr buffersize,const void *data,GLint attribsize=3,GLsizei stride=0);
    inline void setColors   (GLsizeiptr buffersize,const void *data,GLint attribsize=4,GLsizei stride=0);
    inline void setTexcoords(GLsizeiptr buffersize,const void *data,GLint attribsize=2,GLsizei stride=0);
    inline void setAttrib   (GLsizeiptr buffersize,const void *data,GLuint index,GLint attribsize=4,GLsizei stride=0);
    inline void setNormals  (GLsizeiptr buffersize,const void *data,GLsizei stride=0);
    inline void setIndices  (GLsizeiptr buffersize,const void *data,GLsizei count,GLenum mode=GL_TRIANGLES);

    inline void removePositions();
    inline void removeNormals  ();
    inline void removeColors   ();
    inline void removeTexcoords();
    inline void removeIndices  ();
    inline void removeAttrib   (GLuint index);
    inline void clear          ();

    inline void bind();
    inline void enable();
    inline void disable();
    inline void draw();
    inline void draw(GLsizei count);
    inline void enableDrawAndDisable();

  private:
    GLenum _target;
    GLenum _type;
    GLenum _usage;
    GLenum _indexTarget;
    GLenum _indexType;

    BufferData *_positions;
    BufferData *_normals;
    BufferData *_colors;
    BufferData *_texcoords;
    IndexData  *_indices;

    std::vector<GLenum>       _commonAttribCaps;
    std::vector<BufferData *> _userAttribs;

    inline void removeBufferData(BufferData *&bd);
    inline void removeIndexData (IndexData  *&id);
  };

  inline void VertexbufferObject::bind() {
    if(_positions!=NULL) {
      glBindBuffer(_target,_positions->id);
      glVertexPointer(_positions->attribsize,_type,_positions->stride,0); 
    }
    
    if(_normals!=NULL) {
      glBindBuffer(_target,_normals->id);
      glNormalPointer(_type,_normals->stride,0);
    }

    if(_colors!=NULL) {
      glBindBuffer(_target,_colors->id);
      glColorPointer(_colors->attribsize,_type,_colors->stride,0);
    }

    if(_texcoords!=NULL) {
      glBindBuffer(_target,_texcoords->id);
      glTexCoordPointer(_texcoords->attribsize,_type,_texcoords->stride,0);
    }

    for(unsigned int i=0;i<_userAttribs.size();++i) {
      glBindBuffer(_target,_userAttribs[i]->id);
      glVertexAttribPointer(_userAttribs[i]->name.index,_userAttribs[i]->attribsize,_type,GL_FALSE,_userAttribs[i]->stride,0);
    }

    if(_indices!=NULL) {
      glBindBuffer(_indexTarget,_indices->id);
    }
  }

  inline void VertexbufferObject::enable() {
    for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
      glEnableClientState(_commonAttribCaps[i]);
    }
  
    for(unsigned int i=0;i<_userAttribs.size();++i) {
      glEnableVertexAttribArray(_userAttribs[i]->name.index);
    }
  }

  inline void VertexbufferObject::disable() {
    for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
      glDisableClientState(_commonAttribCaps[i]);
    }

    for(unsigned int i=0;i<_userAttribs.size();++i) {
      glDisableVertexAttribArray(_userAttribs[i]->name.index);
    }
  }

  inline void VertexbufferObject::draw() {
    assert(_indices!=NULL);

    glDrawElements(_indices->mode,_indices->count,_indexType,0);
  }

  inline void VertexbufferObject::draw(GLsizei count) {
    assert(_indices!=NULL);

	glDrawElements(_indices->mode,count,_indexType,0);
  }

  inline void VertexbufferObject::enableDrawAndDisable() {
    enable();
    draw();
    disable();
  }

  inline void VertexbufferObject::setPositions(GLsizeiptr buffersize,const void *data,GLint attribsize,GLsizei stride) {
    assert(data!=NULL);

    GLenum cap = GL_VERTEX_ARRAY;

    if(_positions==NULL) {
      _positions = new BufferData;
      glGenBuffers(1,&(_positions->id));
      _commonAttribCaps.push_back(cap);
    }

    _positions->buffersize = buffersize;
    _positions->attribsize = attribsize;
    _positions->data       = data;
    _positions->stride     = stride;
    _positions->name.cap   = cap;

    glBindBuffer(_target,_positions->id);
    glBufferData(_target,_positions->buffersize,_positions->data,_usage);
    glVertexPointer(_positions->attribsize,_type,_positions->stride,0);
  }

  inline void VertexbufferObject::setNormals(GLsizeiptr buffersize,const void *data,GLsizei stride) {
    assert(data!=NULL);

    GLenum cap = GL_NORMAL_ARRAY;

    if(_normals==NULL) {
      _normals = new BufferData;
      glGenBuffers(1,&(_normals->id));
      _commonAttribCaps.push_back(cap);
    }

    _normals->buffersize = buffersize;
    _normals->attribsize = 3;
    _normals->data       = data;
    _normals->stride     = stride;
    _normals->name.cap   = cap;

    glBindBuffer(_target,_normals->id);
    glBufferData(_target,_normals->buffersize,_normals->data,_usage);
    glNormalPointer(_type,_normals->stride,0);
  }

  inline void VertexbufferObject::setColors(GLsizeiptr buffersize,const void *data,GLint attribsize,GLsizei stride) {
    assert(data!=NULL);

    GLenum cap = GL_COLOR_ARRAY;

    if(_colors==NULL) {
      _colors = new BufferData;
      glGenBuffers(1,&(_colors->id));
      _commonAttribCaps.push_back(cap);
    }

    _colors->buffersize = buffersize;
    _colors->attribsize = attribsize;
    _colors->data       = data;
    _colors->stride     = stride;
    _colors->name.cap   = cap;

    glBindBuffer(_target,_colors->id);
    glBufferData(_target,_colors->buffersize,_colors->data,_usage);
    glColorPointer(_colors->attribsize,_type,_colors->stride,0);
  }

  inline void VertexbufferObject::setTexcoords(GLsizeiptr buffersize,const void *data,GLint attribsize,GLsizei stride) {
    assert(data!=NULL);

    GLenum cap = GL_TEXTURE_COORD_ARRAY;

    if(_texcoords==NULL) {
      _texcoords = new BufferData;
      glGenBuffers(1,&(_texcoords->id));
      _commonAttribCaps.push_back(cap);
    }

    _texcoords->buffersize = buffersize;
    _texcoords->attribsize = attribsize;
    _texcoords->data       = data;
    _texcoords->stride     = stride;
    _texcoords->name.cap   = cap;

    glBindBuffer(_target,_texcoords->id);
    glBufferData(_target,_texcoords->buffersize,_texcoords->data,_usage);
    glTexCoordPointer(_texcoords->attribsize,_type,_texcoords->stride,0);
  }

  inline void VertexbufferObject::setIndices(GLsizeiptr buffersize,const void *data,GLsizei count,GLenum mode) {
    assert(data!=NULL);

    if(_indices==NULL) {
      _indices = new IndexData;
      glGenBuffers(1,&(_indices->id));
    }

    _indices->buffersize = buffersize;
    _indices->data       = data;
    _indices->count      = count;
    _indices->mode       = mode;

    glBindBuffer(_indexTarget,_indices->id);
    glBufferData(_indexTarget,_indices->buffersize,_indices->data,_usage);
  }

  inline void VertexbufferObject::setAttrib(GLsizeiptr buffersize,const void *data,GLuint index,GLint attribsize,GLsizei stride) {
    assert(data!=NULL);

    BufferData *attrib = NULL;
    for(unsigned int i=0;i<_userAttribs.size();++i) {
      if(_userAttribs[i]->name.index==index) {
        attrib = _userAttribs[i];
        break;
      }
    }

    if(attrib==NULL) {
      attrib = new BufferData;
      glGenBuffers(1,&(attrib->id));
      attrib->name.index = index;
      _userAttribs.push_back(attrib);
    }

    attrib->buffersize = buffersize;
    attrib->attribsize = attribsize;
    attrib->data       = data;
    attrib->stride     = stride;

    glBindBuffer(_target,attrib->id);
    glBufferData(_target,attrib->buffersize,attrib->data,_usage);
    glVertexAttribPointer(attrib->name.index,attrib->attribsize,_type,GL_FALSE,attrib->stride,0);
  }

  inline void VertexbufferObject::removePositions() {
    if(_positions!=NULL) {
      removeBufferData(_positions);

      std::vector<GLenum> caps;
      for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
        if(_commonAttribCaps[i]!=GL_VERTEX_ARRAY)
          caps.push_back(_commonAttribCaps[i]);
      }
    
      _commonAttribCaps = caps;
    }
  }

  inline void VertexbufferObject::removeNormals() {
    if(_normals!=NULL) {
      removeBufferData(_normals);

      std::vector<GLenum> caps;
      for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
        if(_commonAttribCaps[i]!=GL_NORMAL_ARRAY)
          caps.push_back(_commonAttribCaps[i]);
      }
    
      _commonAttribCaps = caps;
    }
  }

  inline void VertexbufferObject::removeColors() {
    if(_colors!=NULL) {
      removeBufferData(_colors);

      std::vector<GLenum> caps;
      for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
        if(_commonAttribCaps[i]!=GL_COLOR_ARRAY)
          caps.push_back(_commonAttribCaps[i]);
      }
    
      _commonAttribCaps = caps;
    }
  }

  inline void VertexbufferObject::removeTexcoords() {
    if(_texcoords!=NULL) {
      removeBufferData(_texcoords);

      std::vector<GLenum> caps;
      for(unsigned int i=0;i<_commonAttribCaps.size();++i) {
        if(_commonAttribCaps[i]!=GL_TEXTURE_COORD_ARRAY)
          caps.push_back(_commonAttribCaps[i]);
      }
    
      _commonAttribCaps = caps;
    }
  }

  inline void VertexbufferObject::removeIndices() {
    if(_indices!=NULL)
      removeIndexData(_indices);
  }

  inline void VertexbufferObject::removeAttrib(GLuint index) {
    for(unsigned int i=0;i<_userAttribs.size();++i) {
      if(_userAttribs[i]->name.index==index) {
        removeBufferData(_userAttribs[i]);
        return;
      }
    }
  }

  inline void VertexbufferObject::clear() {
    if(_positions!=NULL)
      removeBufferData(_positions);

    if(_colors!=NULL)
      removeBufferData(_colors);

    if(_normals!=NULL)
      removeBufferData(_normals);

    if(_texcoords!=NULL)
      removeBufferData(_texcoords);

    if(_indices!=NULL)
      removeIndexData(_indices);    
  
    for(unsigned int i=0;i<_userAttribs.size();++i) {
      removeBufferData(_userAttribs[i]);
    }
  
    _userAttribs.clear();
    _commonAttribCaps.clear();
  }

  inline void VertexbufferObject::removeBufferData(BufferData *&bd) {
    glDeleteBuffers(1,&(bd->id));
    delete bd;
    bd = NULL;
  }

  inline void VertexbufferObject::removeIndexData(IndexData *&id) {
    glDeleteBuffers(1,&(id->id));
    delete id;
    id = NULL;
  }

} // gpu namespace 

#endif // VERTEXBUFFER_OBJECT_H
