#ifndef TEXTURE_1D_H
#define TEXTURE_1D_H

#include <glew.h>
#include <gl.h>
#include <glu.h>

#include <string>
#include <image.h>
#include <imageio.h>
#include <textureFormat.h>
#include <textureParams.h>

using namespace image;

namespace gpu {
  
  template<typename T = float> 
  class Texture1D 
  {
  public:

	  static const int LINE   = 0;
	  static const int COLUMN = 1;

	  Texture1D(const TextureFormat &tf=TextureFormat(),
				const TextureParams &tp=TextureParams(),
				T* map=NULL,
				int id=-1);



	  ~Texture1D();

	  inline GLuint        id    () const;
	  inline TextureFormat format() const;
	  inline TextureParams params() const;
	  inline void          bind  () const;

	  inline static Texture1D<float> *fromImage(const Image &img,
							const TextureFormat &tf=TextureFormat(GL_TEXTURE_1D),
							const TextureParams &tp=TextureParams(),
							unsigned int ind=0,int dir=LINE);
	  inline static Texture1D<float> *fromImage(const std::string &filename,
							const TextureFormat &tf=TextureFormat(GL_TEXTURE_1D),
							const TextureParams &tp=TextureParams(),
							unsigned int ind=0,int dir=LINE);

  protected:
	  GLuint        _id;
	  TextureFormat _format;
	  TextureParams _params;
  };

  template<typename T>
    inline GLuint Texture1D<T>::id() const {
    return _id;
  }

  template<typename T>
    inline TextureFormat Texture1D<T>::format() const {
    return _format;
  }

  template<typename T>
    inline TextureParams Texture1D<T>::params() const {
    return _params;
  }

  template<typename T>
    inline void Texture1D<T>::bind() const {

    // glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,_params.mode());
    glBindTexture(_format.target(),_id);

  }

  template<typename T>
    Texture1D<T>::Texture1D(const TextureFormat &tf,const TextureParams &tp,T* map,int id)
    : _id(id),
    _format(tf),
    _params(tp) {

    assert(_format.target()==GL_TEXTURE_1D);

    if(id<0 || glIsTexture(id)==GL_FALSE) {
      glGenTextures(1,&_id);
    } else {
      _id = id;
    }

    glBindTexture(_format.target(),_id);
    
    if(_format.mipmapmode()==TextureFormat::MIPMAP_GLU_AUTOM) {
      
      gluBuild1DMipmaps(_format.target(),
                        _format.internalformat(),
                        _format.width(),
                        _format.format(),
                        _format.type(),
                        (const GLvoid *)map);
    } else {
    
      glTexImage1D(_format.target(),
                   _format.level(),
                   _format.internalformat(),
                   _format.width(),
                   _format.border(),
                   _format.format(),
                   _format.type(),
                   (const GLvoid *)map);
   
      if(_format.mipmapmode()==TextureFormat::MIPMAP_FBO_AUTOM) {
        assert(map!=NULL && map!=0);
        glGenerateMipmapEXT(_format.target());
      }
    
    }
    glTexParameteri(_format.target(),GL_TEXTURE_MIN_FILTER,_params.minfilter());
    glTexParameteri(_format.target(),GL_TEXTURE_MAG_FILTER,_params.maxfilter()); 
    glTexParameteri(_format.target(),GL_TEXTURE_WRAP_S,_params.wraps());
    glTexParameteri(_format.target(),GL_TEXTURE_WRAP_T,_params.wrapt());

  }
  
  template<typename T>
    Texture1D<T>::~Texture1D() {	
    glDeleteTextures(1,&_id);
  }

  template<typename T>
    inline Texture1D<float> *Texture1D<T>::fromImage(const Image &img,const TextureFormat &tf,const TextureParams &tp,unsigned int ind,int dir) 
	{
	    
		assert(dir==LINE || dir==COLUMN);

		float *data = NULL;
		unsigned int size=0,j=0;
	   
		switch(dir) 
		{
		case LINE:
			  data = new float[img.getWidth()*img.pixelSize()];
			  size = img.getWidth();

			  for(unsigned int i=0;i<img.getWidth();++i) {
				for(unsigned int k=0;k<img.pixelSize();++k) {
				  data[j++] = img.getPix(i,ind,k);
				}
			  }
			  break;
		case COLUMN:
			  data = new float[img.getHeight()*img.pixelSize()];
			  size = img.getHeight();

			  for(unsigned int i=0;i<img.getHeight();++i) {
				for(unsigned int k=0;k<img.pixelSize();++k) {
				  data[j++] = img.getPix(ind,i,k);
				}
			  }
			  break;    
		default:
			  break;
		}

		TextureFormat texF = tf;    
		GLenum format = img.glFormat();
		texF.setTarget(GL_TEXTURE_1D);
		texF.setWidth(size);
		texF.setInternalformat(format);
		texF.setFormat(format);
		texF.setType(GL_FLOAT);

		Texture1D<float> *tex = new Texture1D<float>(texF,tp,data);
	    
		delete[] data;
	   
		return tex;
  }

  template<typename T>
    inline Texture1D<float> *Texture1D<T>::fromImage(const std::string &filename,const TextureFormat &tf,const TextureParams &tp,unsigned int ind,int dir) 
	{	    
		Image *img = ImageIO::createImage(filename);
	    
		assert(!ImageIO::error());
	    
		Texture1D<float> *tex = fromImage(*img,tf,tp,ind,dir);
	    
		delete img;
	    
		return tex;
  }

  typedef Texture1D<float>         FloatTexture1D;
  typedef Texture1D<unsigned char> UbyteTexture1D;
  typedef Texture1D<unsigned int>  UintTexture1D;

} // gpu namespace 

#endif // TEXTURE_1D_H
