#pragma once

#include <QPoint>
#include <QImage>
#include "tracking.h"
#include <vector>
using namespace std;

namespace skeleton{

class Edge
{
public:
	vector<QPointF> m_vPoint;
    Edge::Edge(void)
	{
	}
	Edge::Edge(QPointF startPos)
	{
		m_vPoint.push_back(startPos);
	}
	Edge::Edge(vector<tracking::Pot3f> pnt)
	{
		for (int i=0;i<pnt.size()-1;i++)
		{
			m_vPoint.push_back(QPointF(pnt[i].x,pnt[i].y));
		}
	}
	Edge& Edge::operator +(QPointF pos)
	{
		for(int i=0;i<this->m_vPoint.size();i++)
		{
			this->m_vPoint[i]=QPointF(this->m_vPoint[i].x()+pos.x(),this->m_vPoint[i].y()+pos.y());
		}
		return *this;
	}
};

class Vertex
{
public:
	QPointF			m_pos;

	bool			m_bJunction;

	Vertex::Vertex(QPoint m_pos,bool m_bJunction)
	{
		Vertex::m_pos=QPointF(float(m_pos.x()),float(m_pos.y()));
		Vertex::m_bJunction=m_bJunction;
	}
	Vertex::Vertex(QPointF m_pos,bool m_bJunction)
	{
		Vertex::m_pos=m_pos;
		Vertex::m_bJunction=m_bJunction;
	}
};

class SkeletonGraph
{
public:
	vector<Vertex>			m_vVertex;

	vector<Edge>			m_vEdge;

	vector<vector<int> >	m_vvEdge42vertex;		// => QMatrix

	vector<vector<bool>	>	m_vvEdgeContinuity;		// => QMatrix

	vector<int>				m_vVertex42edge;		// 2*sizeof(edge)

public:
	/// ������ƺ���д�����drawStreamline�ĺ�벿��
	void drawOpenGL(float height, float offx=0, float offy=0);

	void clear();

};

QPoint getStartingPoint(const QImage &img);

//void computeSkeletonGraph(SkeletonGraph &sktGraph);

} // mamespace