#include "flowDesignPaint.h"
#include <flowDesignWindow.h>
#include "streamline.h"
#include <vec3.h> 
#include "spline.h"

////////////////////////////////////////////////////////////////////////// system functions
ImagePaint::ImagePaint(QWidget *parent) : QGLWidget(parent) {

	//makeCurrent();

//	m_spacePressed = false;
//	m_mode = MODE_MOVE;
	m_index = 0;
	m_overlay = 0;
	m_zoom = m_resolution = 1;
	m_wndSize = QSize(0,0);
	m_imgLoaded = false;
	m_moveOriginKeep = QPointF(0.0,0.0);
	m_zoomOriginKeep = QPointF(0.0,0.0);

	m_repaintLevel = 0;
	m_bPressedKeypoint = false;

	m_regionIndex = 0;
	m_regionSize = 0;
	m_regionIncreasing = true;
	m_regionOverlap = true;

	m_bLeftButtonPainting = false;
	m_bSetBackground = false;
	m_bSettedBackground = false;

	m_bDisplaySpline = true;
	m_bMovingKeypoint = false;
	m_bEditingSpline = false;
	m_bInnerSpline = true;

	m_showOriginal = false;

	m_smoothSize = 0;
	m_smoothMethod = 0;

	setAutoFillBackground(true);
	QPalette p = palette();
	p.setBrush(QPalette::Base, p.mid());
	setPalette(p);
	setCursor(Qt::OpenHandCursor);

	setAutoFillBackground(false);
	qApp->installEventFilter(this);
}


ImagePaint::~ImagePaint() {
}


void ImagePaint::restoreSettings(QSettings& settings) {
	setZoom(settings.value("zoom", 1.0).toDouble());
	setResolution(settings.value("resolution", 1.0).toDouble());
	setOriginX(settings.value("originX", 0).toDouble());
	setOriginY(settings.value("originY", 0).toDouble());
}


void ImagePaint::saveSettings(QSettings& settings) {
	settings.setValue("zoom", m_zoom);
	settings.setValue("resolution", m_resolution);
	settings.setValue("originX", m_moveOrigin.x());
	settings.setValue("originY", m_moveOrigin.y());
}


QPointF ImagePaint::view2image(const QPointF& p) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	QPointF res = QPointF(
		(p.x() - m_moveOrigin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
		(p.y() - m_moveOrigin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	return res;
}

QPointF ImagePaint::image2zoom(const QPointF& p) const {
	return p;
	//QSize sz = size();
	//float z = m_zoom /** m_resolution*/;
	//QPointF res = QPointF(
	//	(p.x() - m_origin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
	//	(p.y() - m_origin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	//return res;
}

QPointF ImagePaint::image2view(const QPointF& q) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	return QPointF(
		(q.x() - m_imgSize.width() / 2) * z + m_moveOrigin.x() * z + sz.width() / 2,
		(q.y() - m_imgSize.height() / 2) * z + m_moveOrigin.y() * z + sz.height() / 2 );
}

QTransform ImagePaint::viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const {
	QTransform tr;
	tr.translate(sz.width()/2.0f, sz.height()/2.0f);
	tr.translate(origin.x() * zoom, origin.y() * zoom);
	tr.scale(zoom, zoom);
	tr.translate(-imageSize().width()/2.0f, -imageSize().height()/2.0f);
	return tr;
}

float ImagePaint::pt2px(float pt) const {
	return pt / (m_zoom /** m_resolution*/);
}

void ImagePaint::setOverlay(QWidget *overlay) {
	if (overlay) {
		setMouseTracking(true);
		m_overlay = overlay;
		m_overlay->setVisible(false);
	} else {
		setMouseTracking(false);
		if (m_overlay) m_overlay->setVisible(false);
		m_overlay = 0;
	}
}

void ImagePaint::onIndexChanged(int idx)
{
	m_index = idx;
	update();
}

void ImagePaint::setImage(const QImage& image) {
	m_images[0] = image;
	m_strokeImg = QImage(image.width(), image.height(), QImage::Format_Indexed8);
	m_strokeImg.fill(0);
	m_regionImg = QImage(image.width(), image.height(), QImage::Format_Indexed8);
	m_regionImg.fill(0);
	m_fillRegionImg = QImage(image.width(), image.height(), QImage::Format_Indexed8);;
	m_fillRegionImg.fill(0);
	m_joinImg = QImage(image.width(), image.height(), QImage::Format_Indexed8);
	m_joinImg.fill(0);

#ifdef _HACK
	QImage hackImg("F:\\data\\image\\flowDesign\\seg.png");
	
	if(image.height()==hackImg.height() && image.width()==hackImg.width())
	{
		//uchar *pImg = new uchar[image.width()*image.height()*4];
		//uchar *pII = pImg;
		//for(int yi=0; yi<image.height(); yi++, pII+=image.width()*4)
		//{
		//	uchar *pI = pII;
		//	for(int xi=0; xi<image.width(); xi++, pI+=4)
		//	{
		//		QRgb clr = image.pixel(xi,yi);
		//		QRgb clr2 = hackImg.pixel(xi,yi);
		//		pI[0] = qBlue(clr);
		//		pI[1] = qGreen(clr);
		//		pI[2] = qRed(clr);
		//		pI[3] = qRed(clr2);
		//	}
		//}
		//std::cout << "==== Hack image has been loaded! ===== " << std::endl;
		//m_geos.SetImage(pImg, image.width(), image.height(), image.width()*4, 4);
		//delete []pImg;
		m_geos.SetImage(hackImg.bits(), hackImg.width(), hackImg.height(), hackImg.bytesPerLine(), hackImg.depth()/8);	
	}
	else
		m_geos.SetImage(image.bits(), image.width(), image.height(), image.bytesPerLine(), image.depth()/8);	
#else
	m_geos.SetImage(image.bits(), image.width(), image.height(), image.bytesPerLine(), image.depth()/8);
#endif
	

	m_dist.SetImage(m_regionImg.bits(), m_regionImg.width(), m_regionImg.height(), m_regionImg.bytesPerLine(), m_regionImg.depth()/8, false);

	m_vUserStroke.clear();
	m_vSpline.clear();
	m_regionIndex=0;
	m_regionSize=0;
	m_regionIncreasing=true;
	m_bPressedKeypoint = false;
	MainWindow::getInstance()->clearRegionIndex();
	MainWindow::getInstance()->setRegionIncreasing(true);

	imageChanged(m_images[0]);
	m_imgSize = image.size();
	if(!m_imgLoaded)
		initGPU();
	m_imgLoaded = true;
	cleanFBO();
	initFBO();
	update();
}

void ImagePaint::setOriginX(double value) {
	double x = value;
	if (m_moveOrigin.x() != x) {
		m_moveOrigin.setX(x);
		originXChanged(x);
		update();
	}
}

void ImagePaint::setOriginY(double value) {
	double y = value;
	if (m_moveOrigin.y() != y) {
		m_moveOrigin.setY(y);
		originYChanged(y);
		update();
	}
}

void ImagePaint::setZoom(double value) {
	if (value != m_zoom) {
		m_zoom = value;
		zoomChanged(m_zoom);
		update();
	}
}

void ImagePaint::setResolution(double value) {
	if (value != m_resolution) {
		m_resolution = value;
		resolutionChanged(m_resolution);
		update();
	}
}

void ImagePaint::zoomIn() {
	setZoom(m_zoom * 2);
}

void ImagePaint::zoomOut() {
	setZoom(m_zoom / 2);
}

void ImagePaint::reset() {
	m_zoom = 1.0;
	m_resolution = 1.0;
	m_moveOrigin = QPoint(0, 0);
	m_zoomOrigin = QPoint(0, 0);
	m_moveOriginKeep = QPoint(0, 0);
	m_zoomOriginKeep = QPoint(0, 0);
	zoomChanged(1);
	resolutionChanged(1);
	originXChanged(0);
	originYChanged(0);
	update();
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
	MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
	MainWindow::getInstance()->setStatusResolution(QString("| Resl: %1%").arg(m_resolution*100.0));
}

void ImagePaint::hold() {
	m_images[1] = m_images[0];
	update();
}

void ImagePaint::toggle() {
	m_index = 1 - m_index;
	QString title = window()->windowTitle().replace(" -- hold", "");
	if (m_index)
		title += " -- hold";
	window()->setWindowTitle(title);
	update();
} 

void ImagePaint::copy() {
	QClipboard *clipboard = QApplication::clipboard();
	clipboard->setImage(image());
}

void ImagePaint::draw(QPainter& p, const QRectF& R, const QImage& image) {
	QRect aR = R.toAlignedRect();
	p.drawImage(aR.x(), aR.y(), image.copy(aR));
}


//////////////////////////////////////////////////////////////////////////// GPU
void ImagePaint::initGPU() {
	finalizeGPU();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_LIGHTING);

	initFBO();
	initShaders();
}
void ImagePaint::finalizeGPU() {
	cleanFBO();
	cleanShaders();
	//glPopAttrib();
}

void ImagePaint::cleanFBO() {
	for(int i=0; i<NB_FBO; i++)
	{
		delete _fbo[i];
		_fbo[i] = NULL;
	}
	for(int i=0;i<NB_TEX;++i) 
	{
		delete _tex[i];
		_tex[i] = NULL;
	}
}

void ImagePaint::cleanShaders() {
	for(int i=0;i<NB_PROG;++i) 
	{
		if(_prog[i]!=NULL) 
		{
			delete _prog[i];
			_prog[i] = NULL;
		}
	}
}
void ImagePaint::reloadShaders() {
	if(_prog[0]!=NULL)
	{
		for(int i=0; i<NB_PROG; i++)
			_prog[i]->reload();
		setShaderParameters();
		update();
		std::cout<< "Shaders have been successfully reloaded!" << std::endl;
	}
}

void ImagePaint::initializeGL() {
	/// glew initialization
	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
		fprintf(stderr, "Error: %s\n",glewGetErrorString(err));

	/// GPU initialization
	for(int i=0; i<NB_FBO; i++)
		_fbo[i] = NULL;
	for(int i=0; i<NB_TEX; i++)
		_tex[i] = NULL;
	for(int i=0; i<NB_PROG; i++)
		_prog[i] = NULL;

	if(m_imgLoaded)
		initGPU();

	/// opengl initialization
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_MULTISAMPLE);
	//glEnable(GL_DEPTH_TEST);
	glDisable(GL_DEPTH_TEST);

	QColor bc = palette().color(QPalette::Base);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void ImagePaint::loadTexture(int tex_id, const QImage &qimg)
{
	_tex[tex_id]->bind();
	if(qimg.format()!=QImage::Format_RGB32)
		qimg.convertToFormat(QImage::Format_RGB32);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, qimg.width(), qimg.height(), 0,
		GL_BGRA, GL_UNSIGNED_BYTE, qimg.bits());
}
void ImagePaint::loadHeightOpacity(int tex_id1, int tex_id2, const QString &file1, const QString &file2)
{
	QImage heiImg = QImage(file1);
	QImage opaImg = QImage(file2);
	const int heiCn = heiImg.bytesPerLine()/heiImg.width();
	const int opaCn = opaImg.bytesPerLine()/opaImg.width();
	int w = heiImg.width();
	int h = heiImg.height();
	if(opaImg.width()!=w || opaImg.height()!=h)
		opaImg = opaImg.scaled(w,h);

	m_brushTex = QImage(w,h,QImage::Format_ARGB32);
	for (int yi=0; yi<h; yi++)
	{
		uchar *pDest = m_brushTex.bits() + m_brushTex.bytesPerLine()*yi;
		const uchar *pHei = heiImg.bits() + heiImg.bytesPerLine() *(h-1-yi);
		const uchar *pOpa = opaImg.bits() + opaImg.bytesPerLine() *(h-1-yi);
		for (int xi=0; xi<w; xi++,pDest+=4,pHei+=heiCn,pOpa+=opaCn)
		{
			for(int k=0; k<3; k++)
				pDest[k] = pHei[0];
			pDest[3] = pOpa[0];
		}
	}

	_tex[tex_id1] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,w,h,
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_LINEAR,GL_LINEAR));
	_tex[tex_id1]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, w,h, 0, GL_BGRA, GL_UNSIGNED_BYTE, m_brushTex.bits());

	/// tempotial, should be replaced using the pixel color from the image
	_tex[tex_id2] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,w,h,
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_LINEAR,GL_LINEAR));
	_tex[tex_id2]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, w,h, 0, GL_BGRA, GL_UNSIGNED_BYTE, m_brushTex.bits());
}
void ImagePaint::initNoiseTex(int tex_id, const QSize &imgSize)
{
	int num = imgSize.width()*imgSize.height()*4;
	float *pNoise = new float[num];
	int maxsc = 3000;
	for (int i=0; i<num; i++)
	{		
		pNoise[i] = float((rand()%maxsc))/float(maxsc-1);
	}
	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,imgSize.width(),imgSize.height(),
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_LINEAR,GL_LINEAR),pNoise);
	delete []pNoise;
}
void ImagePaint::setTextureDefault(int tex_id, float val)
{
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*4];
	for(int i=0; i<m_imgSize.width()*m_imgSize.height()*4; i++)
		pData[i] = val;
	_tex[tex_id]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
		GL_BGRA, GL_FLOAT, pData);
	delete []pData;
}
void ImagePaint::initSeedImage(QVector<pair<int,pair<int,int> > >	*m_pointQueue, float thres)
{
	/// generate seed image for painterly rendering
	float *pNoise = new float[m_imgSize.width()*m_imgSize.height()*4];
	_tex[T_NOISE]->bind();
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pNoise);

	m_pointQueue[0].clear();
	m_pointQueue[1].clear();
	for (int yi=0; yi<m_imgSize.height(); yi++)
	{
		if(yi<=5 || yi>=m_imgSize.height()-6)
			continue;
		for (int xi=0; xi<m_imgSize.width(); xi++)
		{
			if(xi<=5 || xi>=m_imgSize.width()-6)
				continue;

			/// choose seed
			float *randomVal = pNoise+yi*m_imgSize.width()*4+xi*4;
			if(randomVal[0]>thres)
			{
				int sortDist = int((randomVal[0]-thres)*1000/(1.0-thres));
				pair<int,int> p1(xi,yi);
				pair<int,pair<int,int> > p2(sortDist,p1);
				m_pointQueue[0].push_back(p2);
			}
			if(randomVal[1]>thres)
			{
				int sortDist = int((randomVal[1]-thres)*1000/(1.0-thres));
				pair<int,int> p1(xi,yi);
				pair<int,pair<int,int> > p2(sortDist,p1);
				m_pointQueue[1].push_back(p2);
			}
		}
	}
	qSort(m_pointQueue[0]);
	qSort(m_pointQueue[1]);
	delete []pNoise;
}
static void _pre_smooth(const int smethod, float *dest, int fsize, int dcn, const uchar *src, int w, int h, int scn)
{
#define _SRCP(x,y)  ( src+(y)*(w)*(scn)+(x)*(scn) )

	/// compute the weights
	vector<vector<float> > vwet;
	float sigma2 = float(fsize*fsize)*2.0/9.0;
	float sumv = 0.0;
	for(int yi=-fsize; yi<=fsize; yi++)
	{
		float yival = exp(-float(yi*yi)/sigma2);
		vector<float> vw(fsize*2+1);
		for(int xi=-fsize; xi<=fsize; xi++)
		{
			vw[xi+fsize] = exp(-float(xi*xi)/sigma2)*yival;
			sumv += vw[xi+fsize];
		}
		vwet.push_back(vw);
	}
	/// normalization
	for(int yi=-fsize; yi<=fsize; yi++)
		for(int xi=-fsize; xi<=fsize; xi++)
			vwet[yi+fsize][xi+fsize] /= sumv;

	if(smethod==0)
	{
		// apply 2D Gauss filter
		float *fDest = dest;
		for (int yy=0; yy<h; yy++,fDest+=w*dcn)
		{
			float *fD = fDest;
			for (int xx=0; xx<w; xx++,fD+=dcn)
			{
				float val[3] = {0.0,0.0,0.0};
				for(int yi=-fsize; yi<=fsize; yi++)
				{
					const int ys = max(min(yy+yi,h-1),0);
					for(int xi=-fsize; xi<=fsize; xi++)
					{
						const int xs = max(min(xx+xi,w-1),0);
						const uchar *pS = _SRCP(xs,ys);
						for(int c=0; c<3; c++)
							val[c] += float(pS[c]) * vwet[yi+fsize][xi+fsize];
					}
				}
				for(int c=0; c<3; c++)
					fD[c] = max(min(val[c]/255.0,1.0),0.0);
			}
		}
	}
	else if(smethod==1)
	{
		// apply 2D bilateral filter
		const float sigma_bf = (255.0*255.0)/10.0;
		float *fDest = dest;
		for (int yy=0; yy<h; yy++,fDest+=w*dcn)
		{
			float *fD = fDest;
			for (int xx=0; xx<w; xx++,fD+=dcn)
			{
				float val[3] = {0.0,0.0,0.0};
				float sumw[3] = {0.0,0.0,0.0};
				const uchar *pN = _SRCP(xx,yy);
				for(int yi=-fsize; yi<=fsize; yi++)
				{
					const int ys = max(min(yy+yi,h-1),0);
					for(int xi=-fsize; xi<=fsize; xi++)
					{
						const int xs = max(min(xx+xi,w-1),0);
						const uchar *pS = _SRCP(xs,ys);
						float clrdiff = 0.0;
						for(int c=0; c<3; c++)
							clrdiff += float( (pN[c]-pS[c])*(pN[c]-pS[c]) );
						for(int c=0; c<3; c++)
						{
							float www = vwet[yi+fsize][xi+fsize] * exp(-clrdiff/sigma_bf);
							val[c] += float(pS[c]) * www;
							sumw[c] += www;
						}
					}
				}
				for(int c=0; c<3; c++)
					fD[c] = max(min(val[c]/(sumw[c]*255.0),1.0),0.0);
			}
		}
	}

#undef _SRCP
}
void ImagePaint::smoothComputeClicked()
{
	std::cout << "Waiting for pre-smoothing ....   ";
	if(m_smoothSize==0)
	{
		loadTexture(T_ORG,m_images[0]);
		update();
	}
	else
	{
		/// all regions, splines, flows have been recomputed after pre-smoothing the input image
		const int w = m_images[0].width();
		const int h = m_images[0].height();
		float *fdest = new float[w*h*4];
		memset(fdest,0,sizeof(float)*w*h*4);

		_pre_smooth(m_smoothMethod, fdest, m_smoothSize, 4, m_images[0].bits(), w, h, 4);

		_tex[T_ORG]->bind();
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0,	GL_BGRA, GL_FLOAT, fdest);
		delete []fdest;

		update();
	}
	std::cout << "pre-smoothing finished!" << std::endl;
}
void ImagePaint::initFBO() {
	if(_fbo[FBO1]==NULL)
	{
		for(int i=0; i<NB_FBO; i++)
			_fbo[i] = new FramebufferObject();

		_tex[T_ORG	] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(),m_imgSize.height(),
			GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT), TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_GRAD1] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_GRAD2] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_MLS_P1	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P2	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P3	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P4	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));

		_tex[T_MLS		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CURV		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_STROKE	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_S	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CURV_S	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_JOIN		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CANVAS	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_BRUSH	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_GEODESIC	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_SEGM		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_F_EDGE	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_F_USER	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_F_COMB	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_PAINT_C	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_PAINT_H	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_BLACK	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_EMBOSS1	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_EMBOSS2	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_FILL		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_FIN		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
	}

	/// load image to gpu texture	
	loadTexture(T_ORG,m_images[0]);
	setTextureDefault(T_CANVAS, 1.0);
	setTextureDefault(T_BRUSH, 0.0);
	setTextureDefault(T_GEODESIC, 1.0);
	setTextureDefault(T_SEGM, 0.0);
	setTextureDefault(T_F_EDGE, 0.0);
	setTextureDefault(T_F_USER, 0.0);
	setTextureDefault(T_BLACK, 0.0);
	setTextureDefault(T_FILL, 0.0);

	initNoiseTex(T_NOISE,m_imgSize);
	loadHeightOpacity(T_HEIGHT,T_COLOR,QString(".\\height.jpg"),QString(".\\opacity.jpg"));
	initSeedImage(m_pointQueue,0.975);

	/// bind to fbo attachment
	_fbo[FBO1]->bind();
	_fbo[FBO1]->unattachAll();
	{
		_tex[T_GRAD1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRAD1]->format().target(),_tex[T_GRAD1]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_GRAD2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRAD2]->format().target(),_tex[T_GRAD2]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_MLS_P1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P1]->format().target(),_tex[T_MLS_P1]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_MLS_P2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P2]->format().target(),_tex[T_MLS_P2]->id(),GL_COLOR_ATTACHMENT3_EXT);

		_tex[T_MLS_P3]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P3]->format().target(),_tex[T_MLS_P3]->id(),GL_COLOR_ATTACHMENT4_EXT);

		_tex[T_MLS_P4]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P4]->format().target(),_tex[T_MLS_P4]->id(),GL_COLOR_ATTACHMENT5_EXT);

		_tex[T_MLS]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS]->format().target(),_tex[T_MLS]->id(),GL_COLOR_ATTACHMENT6_EXT);

		_tex[T_CURV]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_CURV]->format().target(),_tex[T_CURV]->id(),GL_COLOR_ATTACHMENT7_EXT);
	}
	_fbo[FBO1]->isValid();

	_fbo[FBO2]->bind();
	_fbo[FBO2]->unattachAll();
	{
		_tex[T_MLS_S]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_MLS_S]->format().target(),_tex[T_MLS_S]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_CURV_S]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_CURV_S]->format().target(),_tex[T_CURV_S]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_F_COMB]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_F_COMB]->format().target(),_tex[T_F_COMB]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_PAINT_C]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_PAINT_C]->format().target(),_tex[T_PAINT_C]->id(),GL_COLOR_ATTACHMENT3_EXT);

		_tex[T_PAINT_H]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_PAINT_H]->format().target(),_tex[T_PAINT_H]->id(),GL_COLOR_ATTACHMENT4_EXT);

		_tex[T_EMBOSS1]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_EMBOSS1]->format().target(),_tex[T_EMBOSS1]->id(),GL_COLOR_ATTACHMENT5_EXT);

		_tex[T_EMBOSS2]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_EMBOSS2]->format().target(),_tex[T_EMBOSS2]->id(),GL_COLOR_ATTACHMENT6_EXT);

		_tex[T_FIN]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_FIN]->format().target(),_tex[T_FIN]->id(),GL_COLOR_ATTACHMENT7_EXT);

	}
	_fbo[FBO2]->isValid();

	FramebufferObject::unbind();
}

void ImagePaint::setShaderParameters() {
	_prog[P_GRAD]->enable();
	_prog[P_GRAD]->addUniform("wh");
	_prog[P_GRAD]->addUniform("txOrg");
	_prog[P_GRAD]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_GRAD]->disable();

	_prog[P_MLS_P]->enable();
	_prog[P_MLS_P]->addUniform("wh");
	_prog[P_MLS_P]->addUniform("bSketch");
	_prog[P_MLS_P]->addUniform("strokeSize");
	_prog[P_MLS_P]->addUniform("diffSize");
	_prog[P_MLS_P]->addUniform("zoomWnd");
	_prog[P_MLS_P]->addUniform("txOrg");
	_prog[P_MLS_P]->addUniform("txDert01");
	_prog[P_MLS_P]->addUniform("txDert02");
	_prog[P_MLS_P]->addUniform("txStroke");
	_prog[P_MLS_P]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_MLS_P]->setUniformTexture("txDert01",	1,GL_TEXTURE_2D,_tex[T_GRAD1]->id());
	_prog[P_MLS_P]->setUniformTexture("txDert02",	2,GL_TEXTURE_2D,_tex[T_GRAD2]->id());
	_prog[P_MLS_P]->setUniformTexture("txStroke",	3,GL_TEXTURE_2D,_tex[T_STROKE]->id());
	_prog[P_MLS_P]->disable();

	_prog[P_MLS]->enable();
	_prog[P_MLS]->addUniform("wh");
	_prog[P_MLS]->addUniform("bSketch");
	_prog[P_MLS]->addUniform("strokeSize");
	_prog[P_MLS]->addUniform("diffSize");
	_prog[P_MLS]->addUniform("zoomWnd");
	_prog[P_MLS]->addUniform("txOrg");
	_prog[P_MLS]->addUniform("txDert01");
	_prog[P_MLS]->addUniform("txDert02");
	_prog[P_MLS]->addUniform("txMLSP1");
	_prog[P_MLS]->addUniform("txMLSP2");
	_prog[P_MLS]->addUniform("txMLSP3");
	_prog[P_MLS]->addUniform("txMLSP4");
	_prog[P_MLS]->addUniform("txStroke");
	_prog[P_MLS]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_MLS]->setUniformTexture("txDert01",	1,GL_TEXTURE_2D,_tex[T_GRAD1]->id());
	_prog[P_MLS]->setUniformTexture("txDert02",	2,GL_TEXTURE_2D,_tex[T_GRAD2]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP1",	3,GL_TEXTURE_2D,_tex[T_MLS_P1]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP2",	4,GL_TEXTURE_2D,_tex[T_MLS_P2]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP3",	5,GL_TEXTURE_2D,_tex[T_MLS_P3]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP4",	6,GL_TEXTURE_2D,_tex[T_MLS_P4]->id());
	_prog[P_MLS]->setUniformTexture("txStroke",	7,GL_TEXTURE_2D,_tex[T_STROKE]->id());
	_prog[P_MLS]->disable();

	_prog[P_COMB]->enable();
	_prog[P_COMB]->addUniform("wh");
	_prog[P_COMB]->addUniform("txFlow");
	_prog[P_COMB]->addUniform("txFlowEdge");
	_prog[P_COMB]->addUniform("txFlowUser");
	_prog[P_COMB]->addUniform("txFill");
	_prog[P_COMB]->setUniformTexture("txFlow",		0,GL_TEXTURE_2D,_tex[T_MLS]->id());
	_prog[P_COMB]->setUniformTexture("txFlowEdge",	1,GL_TEXTURE_2D,_tex[T_F_EDGE]->id());
	_prog[P_COMB]->setUniformTexture("txFlowUser",	2,GL_TEXTURE_2D,_tex[T_F_USER]->id());
	_prog[P_COMB]->setUniformTexture("txFill",		3,GL_TEXTURE_2D,_tex[T_FILL]->id());
	_prog[P_COMB]->disable();

	_prog[P_TSMOOTH1]->enable();
	_prog[P_TSMOOTH1]->addUniform("wh");
	_prog[P_TSMOOTH1]->addUniform("txTensor");
	_prog[P_TSMOOTH1]->setUniformTexture("txTensor",	0,GL_TEXTURE_2D,_tex[T_F_COMB]->id());
	_prog[P_TSMOOTH1]->disable();

	_prog[P_TSMOOTH2]->enable();
	_prog[P_TSMOOTH2]->addUniform("wh");
	_prog[P_TSMOOTH2]->addUniform("txTensor");
	_prog[P_TSMOOTH2]->setUniformTexture("txTensor",	0,GL_TEXTURE_2D,_tex[T_CURV_S]->id());
	_prog[P_TSMOOTH2]->disable();

	_prog[P_EMBOSS1]->enable();
	_prog[P_EMBOSS1]->addUniform("wh");
	_prog[P_EMBOSS1]->addUniform("currRegion");
	_prog[P_EMBOSS1]->addUniform("txOrg");
	_prog[P_EMBOSS1]->addUniform("txFlow");
	_prog[P_EMBOSS1]->addUniform("txPaintC");
	_prog[P_EMBOSS1]->addUniform("txPaintH");
	_prog[P_EMBOSS1]->addUniform("txFill");
	_prog[P_EMBOSS1]->addUniform("txPrev");
	_prog[P_EMBOSS1]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_EMBOSS1]->setUniformTexture("txFlow",	1,GL_TEXTURE_2D,_tex[T_MLS]->id());
	_prog[P_EMBOSS1]->setUniformTexture("txPaintC",	2,GL_TEXTURE_2D,_tex[T_PAINT_C]->id());
	_prog[P_EMBOSS1]->setUniformTexture("txPaintH",	3,GL_TEXTURE_2D,_tex[T_PAINT_H]->id());
	_prog[P_EMBOSS1]->setUniformTexture("txFill",	4,GL_TEXTURE_2D,_tex[T_FILL]->id());
	_prog[P_EMBOSS1]->setUniformTexture("txPrev",	5,GL_TEXTURE_2D,_tex[T_EMBOSS2]->id());
	_prog[P_EMBOSS1]->disable();

	_prog[P_EMBOSS2]->enable();
	_prog[P_EMBOSS2]->addUniform("wh");
	_prog[P_EMBOSS2]->addUniform("currRegion");
	_prog[P_EMBOSS2]->addUniform("txOrg");
	_prog[P_EMBOSS2]->addUniform("txFlow");
	_prog[P_EMBOSS2]->addUniform("txPaintC");
	_prog[P_EMBOSS2]->addUniform("txPaintH");
	_prog[P_EMBOSS2]->addUniform("txFill");
	_prog[P_EMBOSS2]->addUniform("txPrev");
	_prog[P_EMBOSS2]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_EMBOSS2]->setUniformTexture("txFlow",	1,GL_TEXTURE_2D,_tex[T_MLS]->id());
	_prog[P_EMBOSS2]->setUniformTexture("txPaintC",	2,GL_TEXTURE_2D,_tex[T_PAINT_C]->id());
	_prog[P_EMBOSS2]->setUniformTexture("txPaintH",	3,GL_TEXTURE_2D,_tex[T_PAINT_H]->id());
	_prog[P_EMBOSS2]->setUniformTexture("txFill",	4,GL_TEXTURE_2D,_tex[T_FILL]->id());
	_prog[P_EMBOSS2]->setUniformTexture("txPrev",	5,GL_TEXTURE_2D,_tex[T_EMBOSS1]->id());
	_prog[P_EMBOSS2]->disable();

	_prog[P_GLASS1]->enable();
	_prog[P_GLASS1]->addUniform("wh");
	_prog[P_GLASS1]->addUniform("glassSize");
	_prog[P_GLASS1]->addUniform("isVert");
	_prog[P_GLASS1]->addUniform("txOrg");
	_prog[P_GLASS1]->addUniform("txNoise");
	_prog[P_GLASS1]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_GLASS1]->setUniformTexture("txNoise",	1,GL_TEXTURE_2D,_tex[T_NOISE]->id());
	_prog[P_GLASS1]->disable();

	_prog[P_GLASS2]->enable();
	_prog[P_GLASS2]->addUniform("wh");
	_prog[P_GLASS2]->addUniform("glassSize");
	_prog[P_GLASS2]->addUniform("isVert");
	_prog[P_GLASS2]->addUniform("txOrg");
	_prog[P_GLASS2]->addUniform("txNoise");
	_prog[P_GLASS2]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_GLASS2]->setUniformTexture("txNoise",	1,GL_TEXTURE_2D,_tex[T_PAINT_C]->id());
	_prog[P_GLASS2]->disable();

	_prog[P_FIN]->enable();
	_prog[P_FIN]->addUniform("wh");
	_prog[P_FIN]->addUniform("display");
	_prog[P_FIN]->addUniform("zoomWnd");
	_prog[P_FIN]->addUniform("brushSize");
	_prog[P_FIN]->addUniform("currRegion");
	_prog[P_FIN]->addUniform("emb1or2");
	_prog[P_FIN]->addUniform("geodesicThres");
	_prog[P_FIN]->addUniform("imgPos");

	_prog[P_FIN]->addUniform("txOrg");	
	_prog[P_FIN]->addUniform("txFlow");
	_prog[P_FIN]->addUniform("txCurv");
	_prog[P_FIN]->addUniform("txJoin");
	_prog[P_FIN]->addUniform("txNoise");
	_prog[P_FIN]->addUniform("txBrush");
	_prog[P_FIN]->addUniform("txGeodesic");
	_prog[P_FIN]->addUniform("txSegm");
	_prog[P_FIN]->addUniform("txFlowEdge");
	_prog[P_FIN]->addUniform("txFlowUser");
	_prog[P_FIN]->addUniform("txFlowComb");
	_prog[P_FIN]->addUniform("txPaintC");
	_prog[P_FIN]->addUniform("txPaintH");
	_prog[P_FIN]->addUniform("txEmboss1");
	_prog[P_FIN]->addUniform("txEmboss2");
	_prog[P_FIN]->addUniform("txFill");

	_prog[P_FIN]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_FIN]->setUniformTexture("txFlow",	1,GL_TEXTURE_2D,_tex[T_MLS]->id());
	_prog[P_FIN]->setUniformTexture("txCurv",	2,GL_TEXTURE_2D,_tex[T_CURV]->id());
	_prog[P_FIN]->setUniformTexture("txJoin",	3,GL_TEXTURE_2D,_tex[T_JOIN]->id());
	_prog[P_FIN]->setUniformTexture("txNoise",	4,GL_TEXTURE_2D,_tex[T_NOISE]->id());
	_prog[P_FIN]->setUniformTexture("txBrush",	5,GL_TEXTURE_2D,_tex[T_BRUSH]->id());
	_prog[P_FIN]->setUniformTexture("txGeodesic",6,GL_TEXTURE_2D,_tex[T_GEODESIC]->id());
	_prog[P_FIN]->setUniformTexture("txSegm",	7,GL_TEXTURE_2D,_tex[T_SEGM]->id());
	_prog[P_FIN]->setUniformTexture("txFlowEdge",8,GL_TEXTURE_2D,_tex[T_F_EDGE]->id());
	_prog[P_FIN]->setUniformTexture("txFlowUser",9,GL_TEXTURE_2D,_tex[T_F_USER]->id());
	_prog[P_FIN]->setUniformTexture("txFlowComb",10,GL_TEXTURE_2D,_tex[T_F_COMB]->id());
	_prog[P_FIN]->setUniformTexture("txPaintC",	11,GL_TEXTURE_2D,_tex[T_PAINT_C]->id());
	_prog[P_FIN]->setUniformTexture("txPaintH",	12,GL_TEXTURE_2D,_tex[T_PAINT_H]->id());
	_prog[P_FIN]->setUniformTexture("txEmboss1",13,GL_TEXTURE_2D,_tex[T_EMBOSS1]->id()); ///Ϊʲô���ܳ���15����
	_prog[P_FIN]->setUniformTexture("txEmboss2",14,GL_TEXTURE_2D,_tex[T_EMBOSS2]->id());
	_prog[P_FIN]->setUniformTexture("txFill",	15,GL_TEXTURE_2D,_tex[T_FILL]->id());
	_prog[P_FIN]->disable();	
}
void ImagePaint::initShaders() {
	static std::string SHADER_DIR = "../flowDesign/shaders/";
	_prog[P_GRAD	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"gradient.fs");
	_prog[P_MLS_P	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"mlsPre.fs");
	_prog[P_MLS		]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"mls.fs");
	_prog[P_COMB	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"combine.fs");
	_prog[P_EMBOSS1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"emboss.fs");
	_prog[P_EMBOSS2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"emboss.fs");
	_prog[P_GLASS1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"glass.fs");
	_prog[P_GLASS2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"glass.fs");
	_prog[P_TSMOOTH1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"tsmooth1.fs");
	_prog[P_TSMOOTH2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"tsmooth2.fs");
	_prog[P_FIN		]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"fin.fs");
	
	setShaderParameters();
}

void ImagePaint::resizeGL(int w, int h) {
	m_wndSize = QSize(w,h);
}

void ImagePaint::paintGL() {
	if(!m_imgLoaded)
		return;

	QRectF zoomWnd = QRectF(-m_zoomOrigin
		+QPointF(m_imgSize.width(),m_imgSize.height())*(0.5-0.5/float(m_resolution)),
		QSizeF(m_imgSize)/float(m_resolution));
	float ws = 1.0f/float(m_imgSize.width());
	float hs = 1.0f/float(m_imgSize.height());

	glDisable(GL_LIGHTING);
	glColor4f(1,1,1,0);
	glEnable(GL_TEXTURE_2D);

	swapToLocalMode(m_imgSize.width(), m_imgSize.height());
		
	if(m_repaintLevel<=0)
	{
		/////////////////////////////////////////////// render to texture: FBO1
		_fbo[FBO1]->bind();

		glColor3f(1,1,1);
		glDrawBuffers(2,FramebufferObject::buffers(0));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_GRAD]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_GRAD]->setUniform2f("wh",ws,hs);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_GRAD]->disable();

		glDrawBuffers(4,FramebufferObject::buffers(2));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_MLS_P]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_MLS_P]->setUniform2f("wh",ws,hs);
		_prog[P_MLS_P]->setUniform1i("bSketch",0);
		_prog[P_MLS_P]->setUniform1i("diffSize",m_diffSize);
		_prog[P_MLS_P]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_MLS_P]->disable();

		glDrawBuffers(2,FramebufferObject::buffers(6));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_MLS]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_MLS]->setUniform2f("wh",ws,hs);
		_prog[P_MLS]->setUniform1i("bSketch",0);
		_prog[P_MLS]->setUniform1i("diffSize",m_diffSize);
		_prog[P_MLS]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_MLS]->disable();

		glDrawBuffers(4,FramebufferObject::buffers(2));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_MLS_P]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_MLS_P]->setUniform2f("wh",ws,hs);
		_prog[P_MLS_P]->setUniform1i("bSketch",1);
		_prog[P_MLS_P]->setUniform1i("diffSize",m_diffSize);
		_prog[P_MLS_P]->setUniform1i("strokeSize",1);
		_prog[P_MLS_P]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_MLS_P]->disable();
	}

	_fbo[FBO2]->bind();			///  FBO2
	if(m_repaintLevel<=1)
	{
		glDrawBuffers(2,FramebufferObject::buffers(0));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_MLS]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_MLS]->setUniform2f("wh",ws,hs);
		_prog[P_MLS]->setUniform1i("bSketch",1);
		_prog[P_MLS]->setUniform1i("diffSize",m_diffSize);
		_prog[P_MLS]->setUniform1i("strokeSize",1);
		_prog[P_MLS]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_MLS]->disable();

		glDrawBuffer(*FramebufferObject::buffers(2));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_COMB]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_COMB]->setUniform2f("wh",ws,hs);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_COMB]->disable();

		glDrawBuffer(*FramebufferObject::buffers(1));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_TSMOOTH1]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_TSMOOTH1]->setUniform2f("wh",ws,hs);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_TSMOOTH1]->disable();

		glDrawBuffer(*FramebufferObject::buffers(2));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_TSMOOTH2]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_TSMOOTH2]->setUniform2f("wh",ws,hs);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_TSMOOTH2]->disable();
	}

	//////////////////////////////////// painterly rendering
	if(m_repaintLevel<2  && (displayList[m_index]==QString("Painter") || displayList[m_index]==QString("Final")) )	//
	{
		setTextureDefault(T_EMBOSS2, 0.0);	
		const int sz = m_regionSize + (m_bSettedBackground?1:0);
		for (int s=0; s<sz; s++)
		{
			int idx = (s==m_regionSize ? 0 : (s+1));
			glDrawBuffer(*FramebufferObject::buffers(3));
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		//	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , GL_MODULATE); 
			glEnable(GL_TEXTURE_2D);
			PainterRendering(idx,0.0f,0.0f);

			glDrawBuffer(*FramebufferObject::buffers(4));
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		//	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , GL_BLEND);
			glEnable(GL_TEXTURE_2D);
			HeightRendering(idx,0.0f,0.0f);
			glDisable(GL_BLEND);
			
			glDrawBuffer(*FramebufferObject::buffers(5+s%2));
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			int progID = P_EMBOSS1 + s%2;
			_prog[progID]->enable();
			glEnable(GL_TEXTURE_2D);
			_prog[progID]->setUniform2f("wh",ws,hs);
			_prog[progID]->setUniform1i("currRegion",idx);
			drawQuad(m_imgSize.width(), m_imgSize.height());
			_prog[progID]->disable();
		}
	}
	////////////////////////////////////// continuous glass pattern
	else if(m_repaintLevel<2  && displayList[m_index]==QString("CGP"))
	{
		glDrawBuffer(*FramebufferObject::buffers(3));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_GLASS1]->enable();
		_prog[P_GLASS1]->setUniform2f("wh",ws,hs);
		_prog[P_GLASS1]->setUniform1i("glassSize",m_brushSize);
		_prog[P_GLASS1]->setUniform1i("isVert",0);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_GLASS1]->disable();

		glDrawBuffer(*FramebufferObject::buffers(4));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_GLASS2]->enable();
		_prog[P_GLASS2]->setUniform2f("wh",ws,hs);
		_prog[P_GLASS2]->setUniform1i("glassSize",m_brushSize);
		_prog[P_GLASS2]->setUniform1i("isVert",1);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_GLASS2]->disable();
	}

	//////////////////////////////////// final combination
	glDrawBuffer(*FramebufferObject::buffers(7));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_FIN]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_FIN]->setUniform2f("wh",ws,hs);
	_prog[P_FIN]->setUniform1f("brushSize",float(m_brushSize));
	_prog[P_FIN]->setUniform1i("currRegion",m_regionIndex);
	_prog[P_FIN]->setUniform1i("emb1or2",(m_regionSize+(m_bSettedBackground?1:0))%2);
	_prog[P_FIN]->setUniform1f("geodesicThres",m_geodesicThres);
	_prog[P_FIN]->setUniform2f("imgPos",m_currPosImg.x(),m_currPosImg.y());
	_prog[P_FIN]->setUniform1i("display",m_index);
	_prog[P_FIN]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_FIN]->disable();

	/// draw edge/spline/stroke to buffer texture
	if(m_bDisplaySpline && displayList[m_index]==QString("Segmentation"))
		drawEdges(m_edgePos);		/// draw the geodesic edges
	else if( m_bDisplaySpline && (displayList[m_index]==QString("Boundary") || displayList[m_index]==QString("Final")
		|| displayList[m_index]==QString("FieldBoundary") ) )
		drawSpline(m_vSpline,true);		/// draw splines
	else if( m_bDisplaySpline && (displayList[m_index]==QString("Geodesic") ||displayList[m_index]==QString("FieldStroke") ))
		drawStrokeAll(m_vUserStroke);	/// draw user strokes
	else if( m_bDisplaySpline && displayList[m_index]==QString("Input"))
		drawSpline(m_vSpline,false);		/// draw splines
	
	if(m_bLeftButtonPainting || m_bSetBackground)
		drawStrokeOne(m_currUserStroke);

	swapToWorldMode();
	
	/////////////////////////////////// render to screen �� horizontal flip ��
	swapToLocalMode(m_wndSize.width(), m_wndSize.height());
	FramebufferObject::unbind();

	glEnable(GL_TEXTURE_2D);
	if(m_showOriginal)	_tex[T_ORG]->bind();
	else				_tex[T_FIN]->bind();
	QColor bc = palette().color(QPalette::Window);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	QSize isz = m_imgSize*m_zoom;
	drawQuadScreen(isz.width(), isz.height(), 
		float(m_wndSize.width()-isz.width())/2.0f + m_moveOrigin.x()*m_zoom, 
		float(m_wndSize.height()-isz.height())/2.0f - m_moveOrigin.y()*m_zoom);
	glClearColor(0,0,0,0);

	swapToWorldMode();
	m_repaintLevel = 0;
}
void ImagePaint::PainterRendering(int idx, float xoff, float yoff)
{
	glEnable(GL_TEXTURE_2D);
	_tex[T_ORG]->bind();
	drawQuad(m_imgSize.width(),m_imgSize.height(),xoff,yoff);

	const int sz = m_imgSize.width()*m_imgSize.height()*4;
	float *grad = new float[sz];
	_tex[T_F_COMB]->bind();
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,grad);

	_tex[T_MLS]->bind();
	float *pConf = new float[sz];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pConf);

	_tex[T_CURV]->bind();
	float *pCurv = new float[sz];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pCurv);

	const int brushsz = idx==0 ? m_brushSizeBackground : m_brushSize;
	const int wb = brushsz*6;
	const int hb = brushsz;
	const int slicesNum = 10;

	for (int s=0; s<2; s++)
	{
		/// drawing color filed at scale 's'
		for (int k=0; k<m_pointQueue[s].size(); k++)	//
		{
			int xa = m_pointQueue[s][k].second.first;
			int ya = m_pointQueue[s][k].second.second;
			if( m_fillRegionImg.pixelIndex(xa,ya)!=idx )
				continue;
			if(s==1)	/// do not put brushes when confidence is low at detail-level scale
			{
				float *pc = pConf + ya*m_imgSize.width()*4+xa*4+3;
				if(pc[0]<0.02)
					continue;
			}
			int randVal = m_pointQueue[s][k].first;
			float brushScale = (float(randVal)*0.6/1000.0+0.8)*pow(0.7f,float(s));
			const float wrand = float(wb)*brushScale;
			const float hrand = float(hb)*brushScale;

			/// get image color
			QRgb clr = m_images[0].pixel(xa,ya);
			int ccc[3] = {qRed(clr), qGreen(clr), qBlue(clr)};
			uchar *pOpacity = m_brushTex.bits();
			for (int yi=0; yi<m_brushTex.height(); yi++,pOpacity+=m_brushTex.bytesPerLine())
			{
				uchar *pO = pOpacity;
				for (int xi=0; xi<m_brushTex.width(); xi++,pO+=4)
					for(int c=0; c<3; c++)
						pO[c] = ccc[c];
			}
			_tex[T_COLOR]->bind();
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_brushTex.width(),m_brushTex.height(), 0, 
				GL_RGBA, GL_UNSIGNED_BYTE, m_brushTex.bits());

			/// use constructed flow
			float *pG = grad + ya*m_imgSize.width()*4 + xa*4;
			float tx = -pG[1];
			float ty = pG[0];

			////////////////////////////////////////////// draw color strokes
			//////////////////////////// draw rectangle
			//glTranslatef(xoff+xa,yoff+ya,0.00001);
			//glBegin(GL_TRIANGLE_STRIP);
			//for(int k=0; k<=slicesNum; k++)
			//{
			//	float v = float(k)/float(slicesNum)-0.5;
			//	glTexCoord2f(v+0.5,0.0);
			//	glVertex2f(tx*wrand*v - ty*hrand, (ty*wrand*v + tx*hrand));

			//	glTexCoord2f(v+0.5,1.0);
			//	glVertex2f(tx*wrand*v + ty*hrand, (ty*wrand*v - tx*hrand));
			//}
			//glEnd();
			//glTranslatef(-(xoff+xa),-(yoff+ya),-0.00001);

			//////////////////////////// draw thin spline based on the curvature
			float *pcur = pCurv + ya*m_imgSize.width()*4+xa*4;
			glTranslatef(xoff+xa,yoff+ya,0.00001);
			glBegin(GL_TRIANGLE_STRIP);
			for(int k=0; k<=slicesNum; k++)
			{
				float v = float(k)/float(slicesNum)-0.5;
				float offs = max(min(fabsf(pcur[1]),1.0),0.0)*(1.0-cos(v*2.0));
				glTexCoord2f(v+0.5,0.0);
				glVertex2f(tx*wrand*v - ty*hrand - offs*hrand*ty, ty*wrand*v + tx*hrand + offs*hrand*tx );

				glTexCoord2f(v+0.5,1.0);
				glVertex2f(tx*wrand*v + ty*hrand - offs*hrand*ty, ty*wrand*v - tx*hrand + offs*hrand*tx );
			}
			glEnd();
			glTranslatef(-(xoff+xa),-(yoff+ya),-0.00001);
#if 0
			/////////////////////////// draw thin spline tracing the stream curves : very slow
			float *pc = pConf + ya*m_imgSize.width()*4+xa*4+3;
			if(pc[0]<m_streamThre*0.3)
				continue;

			//int len2 = (xa-249)*(xa-249) + (ya-217)*(ya-217);
			//if(len2 > 49)
			//	continue;

			const int maxStep = 4;
			const float stepLen = float(m_brushSize);
			vector<Pot3f> pnt = streamline(xa, ya, m_imgSize.width(), m_imgSize.height(), 4, 
				grad, pConf, 3, float(m_streamThre), 0.0, stepLen, maxStep);

			if(!pnt.empty())
			{
				const int sz1 = int(pnt[pnt.size()-1].x);
				const int sz2 = int(pnt[pnt.size()-1].y);
				vector<QPoint> vCurve(sz1+sz2-1);
				for(int i=0; i<sz1; i++)
					vCurve[i] = QPoint(pnt[sz1-1-i].x, pnt[sz1-1-i].y);
				for(int i=sz1; i<sz1+sz2-1; i++)
					vCurve[i] = QPoint(pnt[i+1].x, pnt[i+1].y);

				std::cout << "stream painting @ [" << xa<< "," << ya<< "]" << std::endl;

				glTranslatef(xoff,yoff,0.00001);
				glBegin(GL_TRIANGLE_STRIP);
				if(vCurve.size()>=2)
				{
					for(int k=0; k<vCurve.size(); k++)
					{
						float v = float(k)/float(vCurve.size()-1);
						int kk = max(k,1);
						QPointF step = QPointF(vCurve[kk] - vCurve[kk-1]) * (stepLen/float(m_brushSize));
						glTexCoord2f(v,0.0);
						glVertex2f(vCurve[k].x()+step.y(),vCurve[k].y()-step.x());
						glTexCoord2f(v,1.0);
						glVertex2f(vCurve[k].x()-step.y(),vCurve[k].y()+step.x());
					}
					glEnd();
					glTranslatef(-(xoff),-(yoff),-0.00001);
				}	
			}
#endif
		}
	}
	delete []grad;
	delete []pConf;
	delete []pCurv;
}
void ImagePaint::HeightRendering(int idx, float xoff, float yoff)
{
	glEnable(GL_TEXTURE_2D);
	_tex[T_BLACK]->bind();
	drawQuad(m_imgSize.width(),m_imgSize.height(),xoff,yoff);

	const int sz = m_imgSize.width()*m_imgSize.height()*4;
	float *grad = new float[sz];
	_tex[T_F_COMB]->bind();
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,grad);

	_tex[T_MLS]->bind();
	float *pConf = new float[sz];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pConf);

	_tex[T_CURV]->bind();
	float *pCurv = new float[sz];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pCurv);

	const int brushsz = idx==0 ? m_brushSizeBackground : m_brushSize;
	const int wb = brushsz*6;
	const int hb = brushsz;
	const int slicesNum = 10;

	_tex[T_HEIGHT]->bind();	
	for (int s=0; s<2; s++)
	{
		/// drawing height filed at scale 's'
		for (int k=0; k<m_pointQueue[s].size(); k++)
		{
			int xa = m_pointQueue[s][k].second.first;
			int ya = m_pointQueue[s][k].second.second;
			if( m_fillRegionImg.pixelIndex(xa,ya)!=idx )
				continue;

			if(s==1)	/// do not put brushes when confidence is low at detail-level scale
			{
				float *pc = pConf + ya*m_imgSize.width()*4+xa*4+3;
				if(pc[0]<0.02)
					continue;
			}
			int randVal = m_pointQueue[s][k].first;
			float brushScale = (float(randVal)*0.6/1000.0+0.8)*pow(0.7f,float(s));
			const float wrand = float(wb)*brushScale;
			const float hrand = float(hb)*brushScale;


			/// use constructued flow
			float *pG = grad + ya*m_imgSize.width()*4 + xa*4;
			float tx = -pG[1];
			float ty = pG[0];

			////////////////////////////////////////////// draw height fields
			//////////////////////////////// draw rectangle
			//glTranslatef(xoff+xa,(yoff+ya),0.00001);
			//glBegin(GL_TRIANGLE_STRIP);
			//for(int k=0; k<=slicesNum; k++)
			//{
			//	float v = float(k)/float(slicesNum)-0.5;
			//	glTexCoord2f(v+0.5,1.0);
			//	glVertex2f(tx*wrand*v - ty*hrand, (ty*wrand*v + tx*hrand));

			//	glTexCoord2f(v+0.5,0.0);
			//	glVertex2f(tx*wrand*v + ty*hrand, (ty*wrand*v - tx*hrand));
			//}
			//glEnd();
			//glTranslatef(-(xoff+xa),-(yoff+ya),0.00001);

			////////////////////////////////// draw thin spline based on the curvature
			float *pcur = pCurv + ya*m_imgSize.width()*4+xa*4;
			glTranslatef(xoff+xa,yoff+ya,0.00001);
			glBegin(GL_TRIANGLE_STRIP);
			for(int k=0; k<=slicesNum; k++)
			{
				float v = float(k)/float(slicesNum)-0.5;
				float offs = max(min(fabsf(pcur[1]),1.0),0.0)*(1.0-cos(v*2.0));
				glTexCoord2f(v+0.5,0.0);
				glVertex2f(tx*wrand*v - ty*hrand - offs*hrand*ty, ty*wrand*v + tx*hrand + offs*hrand*tx );

				glTexCoord2f(v+0.5,1.0);
				glVertex2f(tx*wrand*v + ty*hrand - offs*hrand*ty, ty*wrand*v - tx*hrand + offs*hrand*tx );
			}
			glEnd();
			glTranslatef(-(xoff+xa),-(yoff+ya),-0.00001);
#if 0
			//////////////////////////////////// draw thin spline tracing the stream curves : very slow
			float *pc = pConf + ya*m_imgSize.width()*4+xa*4+3;
			if(pc[0]<m_streamThre*0.3)
				continue;

			//int len2 = (xa-249)*(xa-249) + (ya-217)*(ya-217);
			//if(len2 > 49)
			//	continue;

			const int maxStep = 4;
			const float stepLen = float(m_brushSize);
			vector<Pot3f> pnt = streamline(xa, ya, m_imgSize.width(), m_imgSize.height(), 4, 
				grad, pConf, 3, float(m_streamThre), 0.0, stepLen, maxStep);

			if(!pnt.empty())
			{
				const int sz1 = int(pnt[pnt.size()-1].x);
				const int sz2 = int(pnt[pnt.size()-1].y);
				vector<QPoint> vCurve(sz1+sz2-1);
				for(int i=0; i<sz1; i++)
					vCurve[i] = QPoint(pnt[sz1-1-i].x, pnt[sz1-1-i].y);
				for(int i=sz1; i<sz1+sz2-1; i++)
					vCurve[i] = QPoint(pnt[i+1].x, pnt[i+1].y);

				std::cout << "stream painting @ [" << xa<< "," << ya<< "]" << std::endl;

				glTranslatef(xoff,yoff,0.00001);
				glBegin(GL_TRIANGLE_STRIP);
				if(vCurve.size()>=2)
				{
					for(int k=0; k<vCurve.size(); k++)
					{
						float v = float(k)/float(vCurve.size()-1);
						int kk = max(k,1);
						QPointF step = QPointF(vCurve[kk] - vCurve[kk-1]) * (stepLen/float(m_brushSize));
						glTexCoord2f(v,0.0);
						glVertex2f(vCurve[k].x()+step.y(),vCurve[k].y()-step.x());
						glTexCoord2f(v,1.0);
						glVertex2f(vCurve[k].x()-step.y(),vCurve[k].y()+step.x());
					}
					glEnd();
					glTranslatef(-(xoff),-(yoff),-0.00001);
				}	
			}
#endif
		}
	}
	delete []grad;
	delete []pConf;
	delete []pCurv;
}
void ImagePaint::drawEdges(const spline::closeEdge &edgePos)
{
	glDisable(GL_TEXTURE_2D);
	glPointSize(2.0);
	glColor4f(1,0,0,1);		/// red for common points
	glBegin(GL_POINTS);
	for(int k=0; k<edgePos.vPoint.size(); k++)
		glVertex3f(edgePos.vPoint[k].i+1, (edgePos.vPoint[k].j+1),0.01);
	glEnd();

	glPointSize(4.0);
	glBegin(GL_POINTS);
	glColor4f(1,1,0,1);		/// yellow for potential keypoints
	for(int k=0; k<edgePos.vPoint.size(); k++)
		if(edgePos.vKeyPoint[k]>=1)
			glVertex3f(edgePos.vPoint[k].i+1,(edgePos.vPoint[k].j+1),0.01);

	glColor4f(0,1,0,1);		/// green for interval keypoints
	for(int k=0; k<edgePos.vPoint.size(); k++)
		if(edgePos.vKeyPoint[k]>=2)
			glVertex3f(edgePos.vPoint[k].i+1, (edgePos.vPoint[k].j+1),0.01);

	glColor4f(0,0,1,1); 	/// blue for ultimate keypoints
	for(int k=0; k<edgePos.vPoint.size(); k++)
		if(edgePos.vKeyPoint[k]>=3)
			glVertex3f(edgePos.vPoint[k].i+1, (edgePos.vPoint[k].j+1),0.01);

	glEnd();
	glColor4f(1,1,1,0);
	glEnable(GL_TEXTURE_2D);
}
void ImagePaint::drawSpline(const vector<spline::divideSpot> &sp, bool isDual)
{
	/// display splines
	const int internalN = m_keyInterval;
	glDisable(GL_TEXTURE_2D);
	for(int s=0; s<sp.size(); s++)
	{
		if(!sp[s].vSpot.empty())
		{
			if(!isDual)
			{
				/// draw internal samples : red
				glPointSize(3);
				if(s==m_regionIndex-1)	glColor4f(1,0,0,1);	/// for editing region
				else					glColor4f(0.75,0,1,1);
				glBegin(GL_POINTS);
				for(int k=0; k<sp[s].vSpot.size(); k++)
				{	
					if(m_bEditingSpline && s==m_pressedSpline.x() && k==m_pressedSpline.y())
						if(m_bInnerSpline)  glColor4f(0,1,0,1);	/// for editing inner spline
						else				glColor4f(1,1,0,1);	/// for editing outside spline
					for (int t=1; t<internalN; t++)
					{
						spline::posd samp = spline::samplingSpline(sp[s].vPara[k],double(t)/double(internalN));
						glVertex3f(1+int(samp.i+0.5), (int(samp.j+0.5)+1),0.0001);
					}
					if(m_bEditingSpline && s==m_pressedSpline.x() && k==m_pressedSpline.y())
						if(s==m_regionIndex-1)	glColor4f(1,0,0,1);
						else					glColor4f(0.75,0,1,1);
				}
				glEnd();
			}
			else
			{
				/// draw internal samples : red
				glPointSize(3);
				glEnable(GL_SMOOTH);
				glBegin(GL_POINTS);
				for(int k=0; k<sp[s].vSpot.size(); k++)
				{	
					//if(s==m_regionIndex-1)
					//	glPointSize(5);

					/// inside spline
					const double sc = 2;
					spline::posd offset = spline::posd(sp[s].vPara[k].a.i-sp[s].vPara[k].d.i, sp[s].vPara[k].a.j-sp[s].vPara[k].d.j);
					float leng = sqrt(offset.i*offset.i + offset.j*offset.j);
					if(leng!=0) offset = spline::posd(-offset.j*sc/leng,offset.i*sc/leng);

					if(sp[s].vType[k] & spline::INSIDE)		glColor4f(1,0,0,1);
					else									glColor4f(0,1,0,1);
					if(m_bEditingSpline && s==m_pressedSpline.x() && k==m_pressedSpline.y() && m_bInnerSpline)
						glColor4f(1,1,0,1);
					for (int t=1; t<internalN; t++)
					{
						spline::posd samp = spline::samplingSpline(sp[s].vPara[k],double(t)/double(internalN));
						glVertex3f(1+int(offset.i+samp.i+0.5), (int(offset.j+samp.j+0.5)+1),0.0001);
					}

					/// outside spline
					if(sp[s].vType[k] & spline::OUTSIDE)	glColor4f(1,0,0,1);
					else									glColor4f(0,1,0,1);
					if(m_bEditingSpline && s==m_pressedSpline.x() && k==m_pressedSpline.y() && !m_bInnerSpline)
						glColor4f(1,1,0,1);
					for (int t=1; t<internalN; t++)
					{
						spline::posd samp = spline::samplingSpline(sp[s].vPara[k],double(t)/double(internalN));
						glVertex3f(1+int(-offset.i+samp.i+0.5), (int(-offset.j+samp.j+0.5)+1),0.0001);
					}
				}
				glEnd();
			}

			/// draw key spot : blue
			glPointSize(5);
			glColor4f(0,0,1,1);
			glBegin(GL_POINTS);
			for(int k=0; k<sp[s].vSpot.size(); k++)
				glVertex3f(sp[s].vSpot[k].i+1, (sp[s].vSpot[k].j+1),0.0001);
			glEnd();
		}
	}

	///// display normal directons
	//if(m_regionSize>=1 && !m_bLeftButtonPainting)
	//{
	//	int idx = m_regionIndex-1;
	//	int tangsz = sp[idx].vSpot.size()*2;
	//	const float sc = 1.0;
	//	glLineWidth(0.5);
	//	glBegin(GL_LINES);	
	//	for(int k=0; k<sp[idx].vSpot.size(); k++)
	//	{
	//		float sx = sp[idx].vSpot[k].i+1;
	//		float sy = sp[idx].vSpot[k].j+1;
	//		glColor3f(0,1,0);
	//		glVertex3f(sx, sy,0.0001);
	//		glVertex3f(sx+sc*sp[idx].vTangent[(2*k-1+tangsz)%tangsz].j, sy-sc*sp[idx].vTangent[(2*k-1+tangsz)%tangsz].i,0.0001);
	//		glColor3f(0,1,1);
	//		glVertex3f(sx, sy,0.0001);
	//		glVertex3f(sx-sc*sp[idx].vTangent[2*k].j, sy+sc*sp[idx].vTangent[2*k].i,0.0001);  // opposite to outward
	//	}
	//	glEnd();
	//}

	glColor4f(1,1,1,1);


	/// display dragging keypoints in green
	if (m_bPressedKeypoint && !sp.empty() )
	{
		int i0=m_pressedPoint.x();
		int i1=m_pressedPoint.y();
		if(i1<sp[i0].vSpot.size())
		{
			glPointSize(5);//green
			glColor4f(0,1,0,1);
			glBegin(GL_POINTS);
			glVertex3f(sp[i0].vSpot[i1].i+1, (sp[i0].vSpot[i1].j+1),0.0001);
			glEnd();
		}
	}
	glColor4f(1,1,1,0);
	glEnable(GL_TEXTURE_2D);
}
void ImagePaint::drawStrokeAll(const vector<UserStroke> &vstr)
{
	glDisable(GL_TEXTURE_2D);
	glLineWidth(3);
	glColor4f(1,0,0,1);		/// red for common point
	for(int k=0; k<vstr.size(); k++)
	{
		glBegin(GL_LINE_STRIP);
		for (int j=0; j<vstr[k].m_vPos.size(); j++)
			glVertex3f(m_vUserStroke[k].m_vPos[j].x(), m_vUserStroke[k].m_vPos[j].y(), 0.0001);
		glEnd();
	}	
	glColor4f(1,1,1,0);
	glEnable(GL_TEXTURE_2D);
}
void ImagePaint::drawStrokeOne(const UserStroke &st)
{
	glDisable(GL_TEXTURE_2D);
	glLineWidth(3);
	glColor4f(1,0,0,1);		/// red for common point

	glBegin(GL_LINE_STRIP);
	for (int j=0; j<st.m_vPos.size(); j++)
		glVertex3f(st.m_vPos[j].x(), st.m_vPos[j].y(), 0.0001);
	glEnd();

	glColor4f(1,1,1,0);
	glEnable(GL_TEXTURE_2D);
}