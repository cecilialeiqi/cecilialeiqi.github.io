#ifndef STREAM_LINE_H
#define STREAM_LINE_H

#include <vector>
#include <iostream>
using namespace std;

struct Pot3
{
	int		x;
	int		y;
	float	ang;
	Pot3(int xx=0,int yy=0, float a=0.0):x(xx),y(yy),ang(a){};
};

struct Pot3f
{
	float		x;
	float		y;
	float		ang;
	Pot3f(float xx=0.0,float yy=0.0, float a=0.0):x(xx),y(yy),ang(a){};
};

struct Pot2
{
	int x;
	int y;
	Pot2(int xx=0,int yy=0):x(xx),y(yy){};
};

struct Pot2f
{
	float x;
	float y;
	Pot2f(float xx=0.0,float yy=0.0):x(xx),y(yy){};
};

#define MAX_STREAM_SIZE 3000

//
//vector<Point2> streamline(int px, int py, int w, int h, int cn, float *flow, 
//					   int len, int maxLen=MAX_STREAM_SIZE);
//vector<Point2> streamline(Point2 pos, Point2 wsz, int cn, float *flow, 
//						  int len, int maxLen=MAX_STREAM_SIZE);
//
//vector<Point2> streamline(int px, int py, int w, int h, int cn, float *flow, 
//					   float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);
//
//vector<Point2> streamline(Point2 pos, Point2 wsz, int cn, float *flow, 
//						  float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);

vector<Pot3f> streamline(int px, int py, int w, int h, int cn, float *flow, 
						  float *confidence, int th=0, float thre=0.05, float angle=0.0, float stepLen=1.0, int maxLen=MAX_STREAM_SIZE);

vector<Pot3f> streamline(Pot2 pos, Pot2 wsz, int cn, float *flow, 
						  float *confidence, int th=0, float thre=0.05, float angle=0.0, float stepLen=1.0, int maxLen=MAX_STREAM_SIZE);

//vector<Point2> streamlineHatching(vector<int> &hat, int hatStep, int hatLen, float hatAngle, int px, int py, int w, int h, int cn, float *flow, 
//						  float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);
//
//vector<Point2> streamlineHatching(vector<Point2> &hat, Point2 hatSize, float hatAngle, Point2 pos, Point2 wsz, int cn, float *flow, 
//						  float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);

vector<Pot3f> streamlineHatching(int hatStep, int hatLeftLen, int hatRightLen, float hatAngle, 
								  int px, int py, int w, int h, int cn, float *flow, 
								  float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);

vector<Pot3f> streamlineHatching(int hatStep, Pot2 hatLen, float hatAngle, 
								  Pot2 pos, Pot2 wsz, int cn, float *flow, 
								  float *confidence, int th=0, float thre=0.05, float angle=0.0, int maxLen=MAX_STREAM_SIZE);


#endif // STREAM_LINE_H
