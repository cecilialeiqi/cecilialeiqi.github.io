#ifndef ROLLOUTBOX_H
#define ROLLOUTBOX_H

#include "utilDLL.h"
#include <QtGui/QtGui>

//namespace util 
//{

class UTIL_API RolloutBox : public QFrame {
    Q_OBJECT
public:
    RolloutBox(QWidget *parent);

    void saveSettings(QSettings& settings);
    void restoreSettings(QSettings& settings);

    void setFrame(bool frame);
    QString title() const { return m_toolButton->text(); }
    void setTitle(const QString &title);
    bool isCheckable() const { return m_checkable; }
    void setCheckable(bool checkable);
    bool isChecked() const { return m_checked; }
    bool isExpanded() const { return m_expanded; }

    QWidgetList widgets() const;
    void addWidget(QWidget *w);
    void addWidget(QWidget *left, QWidget *right);

public slots:
    void setChecked(bool checked);
    void setExpanded(bool expanded);
    void toggle();

signals:
    void checkChanged(bool checked = false);
    void toggled(bool);

private:
    QGridLayout *m_layout;
    QToolButton *m_toolButton;
    QCheckBox *m_checkBox;
    bool m_checkable;
    bool m_checked;
    bool m_expanded;

public:
    static void restoreSettings(QSettings& settings, QObject *obj);
    static void saveSettings(QSettings& settings, QObject *obj);
};

//} // util namespace

#endif //ROLLOUTBOX_H
