#ifndef MATNM_H
#define MATNM_H

#include <assert.h>
#include <mat2.h>
#include <mat3.h>
#include <mat4.h>

namespace math {

  /*==============================================================================
    CLASS MatNM
    ==============================================================================*/

  //! N*M Matrix class.
  //! N = nbRows
  //! M = nbColumns
  
  template<class T>
    class MatNM {

  public:
    MatNM(unsigned int n,unsigned int m);
    MatNM(unsigned int n,unsigned int m,T *e);
    MatNM(const MatNM<T> &m);
    MatNM(const Mat2<T> &m);
    MatNM(const Mat3<T> &m);
    MatNM(const Mat4<T> &m);
    ~MatNM();

    unsigned int nbRows()    const;
    unsigned int nbColumns() const;

    T *ptr();


    Mat2<T> toMat2() const;
    Mat3<T> toMat3() const;
    Mat4<T> toMat4() const;
    MatNM transpose() const;

    MatNM operator+(const MatNM<T>& m) const;
    MatNM operator-(const MatNM<T>& m) const;
    MatNM operator*(const T& val)      const;
    MatNM operator*(const MatNM<T>& m) const;
    MatNM operator/(const T& val)      const;
    
    MatNM& operator+=(const MatNM<T>& m);
    MatNM& operator-=(const MatNM<T>& m);
    MatNM& operator*=(const T& val);
    MatNM& operator*=(const MatNM<T>& m);
    MatNM& operator/=(const T& val);
    MatNM& operator=(const MatNM<T>& m);
    
    T& operator()(int line, int col);
    const T& operator()(int line,int col) const;

  private:
    unsigned int  _n; // nb rows
    unsigned int  _m; // nb colums
    T            *_e; // data
  };

  template<class T>
    inline MatNM<T>::MatNM(unsigned int n,unsigned int m) 
    : _n(n),_m(m),_e(NULL) {

    assert(_n>0);
    assert(_m>0);

    _e = new T[n*m];
  }

  template<class T>
    inline MatNM<T>::MatNM(unsigned int n,unsigned int m,T *e)
    : _n(n),_m(m),_e(NULL) {

    assert(e!=NULL);
    assert(_n>0);
    assert(_m>0);

    _e = new T[n*m];
    
    for(unsigned int i=0;i<n*m;++i) {
      _e[i] = e[i];
    }
  }

  template<class T>
    inline MatNM<T>::MatNM(const MatNM<T> &m) {
    *this = m;
  }

  template<class T>
    inline MatNM<T>::MatNM(const Mat2<T> &m)
    : _n(2),_m(2),_e(NULL) {
    
    _e = new T[4];
    _e[0] = m(0,0);
    _e[1] = m(0,1);
    _e[2] = m(1,0);
    _e[3] = m(1,1);
  }
  
  template<class T>
    inline MatNM<T>::MatNM(const Mat3<T> &m)
    : _n(3),_m(3),_e(NULL) {
    
    _e = new T[9];
    _e[0] = m(0,0);
    _e[1] = m(0,1);
    _e[2] = m(0,2);
    _e[3] = m(1,0);
    _e[4] = m(1,1);
    _e[5] = m(1,2);
    _e[6] = m(2,0);
    _e[7] = m(2,1);
    _e[8] = m(2,2);
  }
  
  template<class T>
    inline MatNM<T>::MatNM(const Mat4<T> &m)
    : _n(4),_m(4),_e(NULL) {
    
    _e = new T[16];
    _e[0 ] = m(0,0);
    _e[1 ] = m(0,1);
    _e[2 ] = m(0,2);
    _e[3 ] = m(0,3);
    _e[4 ] = m(1,0);
    _e[5 ] = m(1,1);
    _e[6 ] = m(1,2);
    _e[7 ] = m(1,3);
    _e[8 ] = m(2,0);
    _e[9 ] = m(2,1);
    _e[10] = m(2,2);
    _e[11] = m(2,3);
    _e[12] = m(3,0);
    _e[13] = m(3,1);
    _e[14] = m(3,2);
    _e[15] = m(3,3);


  }

  template<class T> 
    inline MatNM<T>::~MatNM() {
    delete [] _e;
  }

  template<class T>
    inline unsigned int MatNM<T>::nbRows() const {
    return _n;
  }

  template<class T>
    inline unsigned int MatNM<T>::nbColumns() const {
    return _m;
  }

  template<class T>
    inline T *MatNM<T>::ptr() {
    return _e;
  }

  template<class T>
    inline Mat2<T> MatNM<T>::toMat2() const {
    assert(_n>1);
    assert(_m>1);

    return Mat2<T>((*this)(0,0),(*this)(0,1),
		   (*this)(1,0),(*this)(1,1));
  }

  template<class T>
    inline Mat3<T> MatNM<T>::toMat3() const {
    assert(_n>2);
    assert(_m>2);

    return Mat3<T>((*this)(0,0),(*this)(0,1),(*this)(0,2),
		   (*this)(1,0),(*this)(1,1),(*this)(1,2),
		   (*this)(2,0),(*this)(2,1),(*this)(2,2));
  }

  template<class T>
    inline Mat4<T> MatNM<T>::toMat4() const {
    assert(_n>3);
    assert(_m>3);

    return Mat4<T>((*this)(0,0),(*this)(0,1),(*this)(0,2),(*this)(0,3),
		   (*this)(1,0),(*this)(1,1),(*this)(1,2),(*this)(1,3),
		   (*this)(2,0),(*this)(2,1),(*this)(2,2),(*this)(2,3),
		   (*this)(3,0),(*this)(3,1),(*this)(3,2),(*this)(3,3));
  }

  template<class T>
    inline MatNM<T> MatNM<T>::transpose() const {
    MatNM<T> mat(_m,_n);
    
    for(unsigned int i=0;i<_n;++i) {
      for(unsigned int j=0;j<_m;++j) {
	mat(j,i) = (*this)(i,j);
      }
    }
    
    return mat;
  }

  template<class T>
    inline MatNM<T> MatNM<T>::operator+(const MatNM<T>& m) const {
    assert(_m==m._m);
    assert(_n==m._n);
    
    T e[_n*_m];
    for(unsigned int i=0;i<_n*_m;++i) {
      e[i] = _e[i]+m._e[i];
    }
    
    return MatNM<T>(_n,_m,e);
  }

  template<class T>
    inline MatNM<T> MatNM<T>::operator-(const MatNM<T>& m) const {
    assert(_m==m._m);
    assert(_n==m._n);
    
    T e[_n*_m];
    for(unsigned int i=0;i<_n*_m;++i) {
      e[i] = _e[i]-m._e[i];
    }
    
    return MatNM<T>(_n,_m,e); 
  }

  template<class T>
    inline MatNM<T> MatNM<T>::operator*(const T& val) const {

    T e[_n*_m];
    for(unsigned int i=0;i<_n*_m;++i) {
      e[i] = _e[i]*val;
    }
    
    return MatNM<T>(_n,_m,e); 
  }

  template<class T>
    inline MatNM<T> MatNM<T>::operator*(const MatNM<T>& m) const {
    assert(_m==m._n);
    
    MatNM<T> mat(_n,m._m);

    T val;
    for(unsigned int i=0;i<_n;++i) {
      for(unsigned int j=0;j<m._m;++j) {
	val = (T)0;
	for(unsigned int k=0;k<_m;++k) {
	    val += (*this)(i,k)*m(k,j);
	}
	mat(i,j) = val;
      }
    }

    return mat;
  }

  template<class T>
    inline MatNM<T> MatNM<T>::operator/(const T& val) const {
    
    T e[_n*_m];
    for(unsigned int i=0;i<_n*_m;++i) {
      e[i] = _e[i]/val;
    }
    
    return MatNM<T>(_n,_m,e); 
  }

  template<class T>
    inline MatNM<T>& MatNM<T>::operator+=(const MatNM<T>& m) {
    assert(_m==m._m);
    assert(_n==m._n);
    
    for(unsigned int i=0;i<_n*_m;++i) {
      _e[i] += m._e[i];
    }
    
    return *this;
  }

  template<class T>
    inline MatNM<T>& MatNM<T>::operator-=(const MatNM<T>& m) {
    assert(_m==m._m);
    assert(_n==m._n);
    
    for(unsigned int i=0;i<_n*_m;++i) {
      _e[i] -= m._e[i];
    }
    
    return *this;
  }

  template<class T>
    inline MatNM<T>& MatNM<T>::operator*=(const T& val) {
    for(unsigned int i=0;i<_n*_m;++i) {
      _e[i] *= val;
    }
    
    return *this;
  }

  template<class T>
    inline MatNM<T>& MatNM<T>::operator/=(const T& val) {
    for(unsigned int i=0;i<_n*_m;++i) {
      _e[i] /= val;
    }
    
    return *this;
  }

  template<class T>
    inline MatNM<T>& MatNM<T>::operator=(const MatNM<T>& m) {
    if(_e!=NULL) {
      delete [] _e;
    }

    _n = m._n;
    _m = m._m;
    _e = new T[_n*_m];
    
    for(unsigned int i=0;i<_n*_m;++i) {
      _e[i] = m._e[i];
    }

    return *this;
  }

  template<class T>
    inline T& MatNM<T>::operator()(int line, int col) {
    return _e[line*_m + col];
  }

  template<class T>
    inline const T& MatNM<T>::operator()(int line,int col) const {
    return _e[line*_m + col];
  }

  typedef MatNM< int >    MatNMi;
  typedef MatNM< float >  MatNMf;
  typedef MatNM< double > MatNMd;

} // namespace math

#endif // MATNM_H
