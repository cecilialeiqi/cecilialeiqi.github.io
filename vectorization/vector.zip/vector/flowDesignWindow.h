
#pragma once

#include "ui_mainwindow.h"
#include "flowDesignPaint.h"
#include "videoplayer.h"


//enum TOOL_MODE	{E_MOVE=0, E_ZOOM, E_ROTO, E_FREE, E_SEG };

const QStringList displayList = (QStringList()
								 << "Final"
								 << "Geodesic"
								 << "Segmentation"
								 << "Boundary"
								 << "FieldBoundary"
								 << "FieldStroke"
								 << "FieldImage"
								 << "LIC"
								 << "CGP"	
								 << "Painter"		
								 << "Input"		);

class MainWindow : public QMainWindow, protected Ui_MainWindow {
    Q_OBJECT
public:
    MainWindow();
    ~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

    void restoreSettings();
    void closeEvent(QCloseEvent *e);

	const QImage& image() const { return m_result; }
 
	void setCurrentTool(const QString &name);

	/// status bar
	void setStatusMessage(const QString &txt) {statusBar()->showMessage(txt);}
	void setStatusMouse(const QString& txt) {m_statusMouseLabel->setText(txt);}
	void setStatusZoom(const QString& txt) {m_statusZoomLabel->setText(txt);}
	void setStatusResolution(const QString& txt) {m_statusReslLabel->setText(txt);}
	void setStatusTool(const int idx);
	int  selectItemSize() { return m_selectitem->count(); }

	void addRegionIndex(int idx) {m_regionCom->addItem(QString("%1").arg(idx));
	m_regionCom->setCurrentIndex(idx-1);}
	void setRegionIndex(int idx) { if(idx>=1 && idx<=m_regionCom->count())
	m_regionCom->setCurrentIndex(idx-1);}
	void clearRegionIndex()	{m_regionCom->clear();}
	void setRegionIncreasing( bool isOk ){ m_regionChk->setChecked(isOk); }
	void setEditingSpline(bool isOK) { m_editingBtn->setChecked(isOK); }
	void setSetBackground(bool isOk) {m_backgroundBtn->setChecked(isOk); }
	
protected slots:
    void on_actionOpen_triggered();
    void on_actionAbout_triggered();
    //void on_actionSelectDevice_triggered();
    void on_actionRecord_triggered();
	void setFullScreen();

    void setDirty();
	void setDirty2();
    void process();
	void process2();
    
    void onVideoChanged(int nframes);

	void regionComboboxChanged(int);
	void regionCheckboxClicked(bool);
	void overlapCheckboxClicked(bool);

signals:
    void imageChanged(const QImage&);

protected:
    virtual void draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image);

    VideoPlayer *m_player;
    //cpu_image<float4> m_st;
    //cpu_image<float4> m_tfm;
    QImage m_result;
    bool m_dirty;

private:
	static MainWindow*	_mainWindow;

	QLabel		*m_statusMouseLabel;
	QLabel		*m_statusZoomLabel;
	QLabel		*m_statusReslLabel;

	QComboBox *m_regionCom;
	QCheckBox *m_regionChk;
	QCheckBox *m_overlapChk;

	QPushButton *m_editingBtn;
	QPushButton *m_backgroundBtn;

	QComboBox   *m_smoothMethodCombobox;
	QComboBox	*m_smoothSizeCombobox;
	QPushButton *m_smoothCompute;

};