#include "mls.h"
#include "mlsfieldPaint.h"
#include <mlsfieldWindow.h>
#include <vector>
#include <fstream>
#include <time.h>
#include <iostream>
#include <iomanip>
#include "vec2.h"

using namespace math;
using namespace std;

void ImagePaint::drawFittingCircle()
{
	int cn =4;
	const GLenum format1 = GL_RGBA;
	_tex[T_MLS]->bind();
	float *pMLS = new float[m_imgSize.width()*m_imgSize.height()*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,pMLS);

	int xi = max(min(int(m_currPosImg.x()+0.5),m_imgSize.width()-1),0);
	int yi = max(min(int(m_currPosImg.y()+0.5),m_imgSize.height()-1),0);
	float curv = pMLS[];
	float xf = m_currPosWnd.x();
	float yf = m_wndSize.height()-m_currPosWnd.y();
	float rad = 20.0;
	glDisable(GL_TEXTURE_2D);
	glLineWidth(1.0);
	glColor3f(1,0,0);
	glBegin(GL_LINES);
	float pi = 3.1415926;
	float theta = min(2*pi/(rad),2*pi/6.0);
	float ang = 0.0;
	while(ang<2*pi)
	{
		glVertex3f(rad*cos(ang)+xf,rad*sin(ang)+yf,0.0001);
		ang += theta;		
	}	
	glEnd();
	glColor3f(1,1,1);
	glEnable(GL_TEXTURE_2D);
}

void ImagePaint::computeFullLinear()
{
	/// collect data
	int cn =4;
	const int dsz = m_imgSize.width()*m_imgSize.height();
	const int _imageWidth = m_imgSize.width();
	const int _imageHeight = m_imgSize.height();
	Vec4f defaultZoomWnd = Vec4f(0.0, float(_imageHeight), float(_imageWidth), float(_imageHeight));
	Vec4f zoomWndSrc = defaultZoomWnd;
	const GLenum format1 = GL_RGBA;
	_tex[T_GRAD1]->bind();
	float *fdata = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata);

	_tex[T_GRAD2]->bind();
	float *fdata2 = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata2);

	float *rdata = new float[dsz*cn];
	memset(rdata,0,dsz*cn*sizeof(float));

	float *cdata = new float[dsz*cn];
	memset(cdata,0,dsz*cn*sizeof(float));

	clock_t ti = clock();
	/// mls recontruction

	int neigsize = 2*m_diffSize+1;

	Eigen::Vector2d src = Eigen::Vector2d(0.0,0.0);		/* point of evaluation */
	uint nofSamples = neigsize*neigsize*3;

	/* position of the neighbor point */
	std::vector<Eigen::Vector2d,Eigen::aligned_allocator<Eigen::Vector2d> > positions(nofSamples);

	/* associated weight */
	std::vector<double>          weights(nofSamples);
	if(zoomWndSrc==defaultZoomWnd)		/// pre-compute weights and position information
	{
		for(int yd=-m_diffSize; yd<=m_diffSize; yd++)
		{
			for(int xd=-m_diffSize; xd<=m_diffSize; xd++)
			{
				Eigen::Vector2d pos = Eigen::Vector2d(double(xd),double(yd));
				float dist2 = min(float(xd*xd+yd*yd)/float(m_diffSize*m_diffSize), 1.0);
				double wn = (1.0-dist2)*(1.0-dist2);
				int idx = (yd+m_diffSize)*neigsize+xd+m_diffSize;
				for(int i=0; i<3; i++)
				{				
					positions[idx*3+i] = pos;
					weights[idx*3+i] = wn;
				}
			}
		}
	}

	/* associated vector */
	std::vector<Eigen::Vector2d>	uvec(nofSamples);

	for(int yi=0; yi<_imageHeight; yi++)
	{
		float *pRD = rdata + _imageWidth*cn*(_imageHeight-1-yi);
		float *pCD = cdata + _imageWidth*cn*(_imageHeight-1-yi);
		for(int xi=0; xi<_imageWidth; xi++,pRD+=cn,pCD+=cn)
		{
			////////////////////////////////////////////////////////////////////////// for each pixel
			math::Vec4f zoomWnd(zoomWndSrc[0], float(_imageHeight)-zoomWndSrc[1], zoomWndSrc[2], zoomWndSrc[3]);
			//math::Vec4f zoomWnd(zoomWndSrc[0], zoomWndSrc[1], zoomWndSrc[2], zoomWndSrc[3]);
			Vec2f texShift = Vec2f(0.0,0.0);
			Vec2f zoomLoc = Vec2f(float(xi)*zoomWnd[2]/float(_imageWidth)+zoomWnd[0],
				float(yi)*zoomWnd[3]/float(_imageHeight)+zoomWnd[1]);
#if 1		/// using infinte resolution 
			Vec2f intLoc = Vec2f(float(int(zoomLoc.x())),float(int(zoomLoc.y())));
			Vec2f pixelShift = Vec2f(zoomLoc.x()-intLoc.x(), zoomLoc.y()-intLoc.y());
			int xiN = min(max(int(intLoc.x()),0),_imageWidth-1);
			int yiN = min(max(_imageHeight-1-int(intLoc.y()),0),_imageHeight-1);
			float zoomFact = zoomWndSrc[2]/float(_imageWidth);
#else
			xi = min(max(xi,0),_imageWidth-1);
			yi = min(max(_imageHeight-1-yi,0),_imageHeight-1);
			Vec2f intLoc = Vec2f(xi,yi);
			Vec2f pixelShift = Vec2f(0.0,0.0);
			float zoomFact = 1.0;
#endif

			bool allZero = true;
			for(int yn=-m_diffSize; yn<=m_diffSize; yn++)
			{
				int yimg = min(max(yiN+yn,0),_imageHeight-1);
				for(int xn=-m_diffSize; xn<=m_diffSize; xn++)
				{

					int ximg = min(max(xiN+xn,0),_imageWidth-1);
					float *pGx = fdata + ((/*_imageHeight-1-*/yimg)*_imageWidth+ximg)*cn;
					float *pGy = fdata2 + ((/*_imageHeight-1-*/yimg)*_imageWidth+ximg)*cn;

					//if(zoomWndSrc!=defaultZoomWnd)  /// compute weights and position on-line
					//{
					//	int xd = xn;
					//	int yd = yn;
					//	Eigen::Vector2d pos = Eigen::Vector2d(double(xd)-double(pixelShift.x()),double(yd)+double(pixelShift.y()));
					//	float dist2 = min(float(pos.x()*pos.x()+pos.y()*pos.y())/float(m_diffSize*m_diffSize), 1.0);
					//	double wn = (1.0-dist2)*(1.0-dist2);
					//	int idx = (yd+m_diffSize)*neigsize+xd+m_diffSize;
					//	for(int i=0; i<3; i++)
					//	{				
					//		positions[idx*3+i] = pos;
					//		weights[idx*3+i] = wn;
					//	}
					//}

					int idx = (m_diffSize+yn)*neigsize+xn+m_diffSize;
#if 0
					float gx = pGx[0]*pGx[3];
					float gy = pGx[1]*pGx[3];
					for(int i=0; i<3; i++)
						uvec[idx*3+i] = Eigen::Vector2d(double(gx),double(gy));
#else
					for(int i=0; i<3; i++)
					{
						uvec[idx*3+i] = Eigen::Vector2d(double(pGx[i]),double(pGy[i]));
						if(xn==0 && yn==0 && allZero==true && (pGx[i]!=0.0f || pGy[i]!=0.0f))
							allZero = false;
					//	if(allZero==true && (pGx[i]!=0.0f || pGy[i]!=0.0f))
					//		allZero = false;
					}
					//uvec[idx*3+i] = Eigen::Vector2d(-double(yimg-_imageHeight/2),double(ximg-_imageWidth/2));
					//uvec[idx*3+i] = Eigen::Vector2d(double(ximg-_imageWidth*2/3),double(yimg-_imageHeight/3));
					//uvec[idx*3+i] = Eigen::Vector2d(-double(yimg-_imageHeight/3),double(ximg-_imageWidth*2/3));
#endif
				}
			}

			Eigen::Vector3d mlsVec = Eigen::Vector3d(0.0, 0.0, 0.0);
			Eigen::Vector2d curva = Eigen::Vector2d(0.0, 0.0);
			if(!allZero)	/// at least one sample is non-zero
			{
				if(m_diffType==0)	/// isotropic linear
				{
					Eigen::VectorXd vecCD = mlsSpherical(src,nofSamples,weights,uvec,positions);
					mlsVec = Eigen::Vector3d(vecCD.x(),vecCD.y(),vecCD.z());
					curva = Eigen::Vector2d(vecCD(3),vecCD(4));
				}
				else if(m_diffType==1)		/// constant 
				{
					int polynomial_degree = 0;				/* 0, 1, 2, or 3*/
					mlsVec = mlsConstant(src,nofSamples,weights,uvec,positions,polynomial_degree);
				}
				else if(m_diffType==2)		/// full linear
				{
					mlsVec = mlsLinear(src,nofSamples,weights,uvec,positions);
				}
				else 
					std::cout << "the flow type is out of range!" << std::endl;
			}

			double len = sqrt(mlsVec.x()*mlsVec.x()+mlsVec.y()*mlsVec.y());
			pRD[0] = len==0.0?0.0:mlsVec.x()/len;
			pRD[1] = len==0.0?0.0:mlsVec.y()/len;
			pRD[2] = mlsVec.z();
			pRD[3] = mlsVec.z();

			pCD[0] = curva.x();
			pCD[1] = curva.y();
			pCD[2] = 0.0f;
			pCD[3] = 0.0f;	
		}
		if(yi%10==0)
			std::cout << "L" << yi << " ";
	}		

	_tex[T_MLS]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, _imageWidth, _imageHeight, 0, 
		GL_RGBA, GL_FLOAT, rdata);

	_tex[T_CURV]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, _imageWidth, _imageHeight, 0, 
		GL_RGBA, GL_FLOAT, cdata);

	std::cout << (clock()-ti)/CLOCKS_PER_SEC <<  " seconds" << std::endl;


	/// store data
	delete []fdata;
	delete []fdata2;
	delete []rdata;
	delete []cdata;
}
double ImagePaint::computePSNR()
{
	return 0.0;
}
double ImagePaint::computeFittingError(double *wetError)
{
	/// collect data
	int cn =4;
	const int dsz = m_imgSize.width()*m_imgSize.height();
	const int _imageWidth = m_imgSize.width();
	const int _imageHeight = m_imgSize.height();
	Vec4f defaultZoomWnd = Vec4f(0.0, float(_imageHeight), float(_imageWidth), float(_imageHeight));
	Vec4f zoomWndSrc = defaultZoomWnd;
	const GLenum format1 = GL_RGBA;
	_tex[T_CHAN]->bind();
	float *forg = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,forg);

	_tex[T_GRAD1]->bind();
	float *fdata = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata);

	_tex[T_GRAD2]->bind();
	float *fdata2 = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata2);

	_tex[T_MLS]->bind();
	float *fmls = new float[dsz*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fmls);

	//const int boundary = m_diffSize*2+1;
	const int boundary = m_imgSize.width()/4;
	const int cnt = (_imageHeight-2*boundary)*(_imageWidth-2*boundary);
	double err = 0.0;
	double wetSum = 0.0;
	double wsum = 0.0;
	const int stepcn = _imageWidth*cn;
	float *fo = forg + boundary*stepcn+boundary*cn;
	float *fd = fdata + boundary*stepcn+boundary*cn;
	float *fd2 = fdata2 + boundary*stepcn+boundary*cn;
	float *fm = fmls + boundary*stepcn+boundary*cn;
	for (int yi=boundary; yi<_imageHeight-boundary; yi++, fo+=stepcn,fd+=stepcn, fd2+=stepcn, fm+=stepcn)
	{
		for(int xi=boundary; xi<_imageWidth-boundary; xi++)
		{
			double wet = fo[xi*cn];
			double gx = fd[xi*cn+3];
			double gy = fd2[xi*cn+3];
		//	double mx = fm[xi*cn];
		//	double my = fm[xi*cn+1];
			double mx = fd[xi*cn];
			double my = fd2[xi*cn];
			double len = sqrt(gx*gx+gy*gy)==0.0 ? 0.0 : sqrt(gx*gx+gy*gy)*sqrt(mx*mx+my*my);
			bool equ = (gx==mx && gy==my);
			float val = (equ==true || len==0.0) ? 0.0 : abs(gx*my-gy*mx)/len;
			err += val;
			wsum += wet;
			wetSum += wet*val;
		}
	}
	err /= double(cnt);

	wetError[0] = double( wetSum / wsum);

	delete []fdata;
	delete []fdata2;
	delete []fmls;
	return err;
}
void	ImagePaint::saveBatchResults(const std::string &filename)
{
//#define BATCH_IMAGE
	const int m_heightTypeSaver = m_heightType;
	const int m_diffSizeSaver = m_diffSize;
	const double m_noiseAlpSaver = m_noiseAlp;
	const int m_diffTypeSaver = m_diffType;
	const int m_indexSaver = m_index;
	const bool m_isCPUSaver = m_isCPU;
#ifndef BATCH_IMAGE
	std::ofstream outf(filename.c_str());
	if(!outf){
		std::cout << "output file cannot be open!" << std::endl;
		return;
	}		
#endif
//	int cnt = 0;
//	int finCnt = 8;
	for(int heightType=m_heightType; heightType<=m_heightType; heightType++)
	{
		m_heightType = heightType;
		for(int diffsize=m_diffSize; diffsize<=m_diffSize; diffsize+=4)		/// inscreasing support size
		{
			m_diffSize = diffsize;
			int ni = int(m_noiseAlp*100.0);
			for(int noiseInt=ni; noiseInt<=ni; noiseInt+=5)	/// increasing noises
			{
				double noisef = double(noiseInt)/100.0;
				m_noiseAlp = noisef;
				for(int dt=m_diffType; dt<=m_diffType; dt++)					/// different diffuse types
				{
			//		if(cnt<finCnt)
			//		{
			//			cnt++;
			//			continue;
			//		}
					

					m_diffType = dt;
					if(m_diffType==0 || m_diffType==1)
						m_isCPU = false;
					else if(m_diffType==2)
					{
						m_isCPU = true;
						m_cpuRecompute = true;
					}

			//		QString saveName = ;
	#ifdef BATCH_IMAGE	/// save result images
					m_index = 0;
					paintGL();
					QString saveFlow = QString(filename.c_str()).append("_flow_noise%1_size%2_diff%3.png").arg(noiseInt).arg(diffsize).arg(dt);
					savePNG(saveFlow,true);

					// save the error image
					m_index = 2;
					paintGL();
					QString saveError =QString(filename.c_str()).append("_error_noise%1_size%2_diff%3.png").arg(noiseInt).arg(diffsize).arg(dt);
					savePNG(saveError,true);

					// save the hsv image
					m_index = 4;
					paintGL();
					QString saveHsv = QString(filename.c_str()).append("_hsv_noise%1_size%2_diff%3.png").arg(noiseInt).arg(diffsize).arg(dt);
					savePNG(saveHsv,true);
	#else	/// record fitting errors
					m_index = 3;
					paintGL();
					glFlush();
					savePNG(QString(filename.c_str()).append("_mls_height%1_size%2_noise%3_diff%4.png").arg(m_heightType).arg(m_diffSize).arg(noiseInt).arg(m_diffType),true);

					m_index = 2;
					paintGL();
					glFlush();
					savePNG(QString(filename.c_str()).append("_error_height%1_size%2_noise%3_diff%4.png").arg(m_heightType).arg(m_diffSize).arg(noiseInt).arg(m_diffType),true);
					double wetError = 0.0;
					double fittingError = computeFittingError(&wetError);
					std::cout << "height=" << m_heightType <<" size=" << setw(3) << m_diffSize << " noise=" << setw(4) << m_noiseAlp << 
						" diff=" << setw(2) << m_diffType << " fittingError=" << fittingError << " wetError="<< wetError << std::endl;
					outf << m_heightType << setw(3) << m_diffSize << " " << setw(4) << m_noiseAlp << " " 
						<< setw(2) << m_diffType << " " << fittingError << " " << wetError << std::endl;
	#endif
				}
			}
		}
	}

	outf.close();
	m_heightType = m_heightTypeSaver;
	m_diffSize = m_diffSizeSaver;
	m_noiseAlp = m_noiseAlpSaver;
	m_diffType = m_diffTypeSaver;
	m_index = m_indexSaver;
	m_isCPU = m_isCPUSaver;
}
static float clamp01(float v)
{
	return min(max(v,0.0),1.0);
}
static QColor jetMap( float val)
{
	float v = 4.0*clamp01(val);
	float red   = min(v - 1.5, -v + 4.5);
	float green = min(v - 0.5, -v + 3.5);
	float blue  = min(v + 0.5, -v + 2.5);
	return QColor(int(clamp01(red)*255.0),int(clamp01(green)*255.0),int(clamp01(blue)*255.0));
}
void	ImagePaint::saveErrorMap(const std::string &filename)
{
	const int eWidth = 13;	// noise
	const int eHeight = 9;	// size
	const int grid = 10;

	std::ifstream inf(filename.c_str());
	if(!inf){
		std::cout << "input file cannot be open!" << std::endl;
		return;
	}		

	//QImage img(eWidth*3+2, eHeight*3+2, QImage::Format_RGB888);
	//img.fill(Qt::white);
	for(int fi=0; fi<2; fi++)	// three methods
	{
		for(int hi=0; hi<3; hi++) // height maps
		{
			QImage img(eWidth, eHeight, QImage::Format_RGB888);
			for(int xe=0; xe<eWidth; xe++)
				for(int ye=0; ye<eHeight; ye++)
				{
					int hei, met, siz;
					float noi, err;
					inf >> hei >> siz >> noi >> met >> err;
					std::cout << hei << " " << siz << " " << noi << " " << met << " " << err << std::endl;
					//img.setPixel((eWidth+1)*met+xe, (eHeight+1)*hei+ye, jetMap(err*30.0).rgb());
					img.setPixel(xe, ye, jetMap(err*30.0).rgb());
				}
			QImage imgn = img.scaled(eWidth*grid, eHeight*grid, Qt::IgnoreAspectRatio, Qt::FastTransformation);
			QString qf(QString(filename.c_str()));
			imgn.save(qf.append("_%1_%2.png").arg(hi).arg(fi));
		}
	}	
	/*QImage imgn = img.scaled((eWidth*3+2)*grid, (eHeight*3+2)*grid, Qt::IgnoreAspectRatio, Qt::FastTransformation);
	QString qf(QString(filename.c_str()));
	imgn.save(qf.append(".png"));*/

	inf.close();
}