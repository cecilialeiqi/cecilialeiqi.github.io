
#pragma once

#include "ui_mainwindow.h"
#include "animationPaint.h"
#include "videoplayer.h"
#include "playWidget.h"

class ToolButton;

const QStringList toolList = (QStringList()
							  << "Move"	
							  << "Zoom"
							  << "Rotoscoping"								  
							  << "FreeHand"	
							  << "Erase"
							  << "Shift"
							  << "Rotate"
							  << "Scale");

enum TOOL_MODE	{E_MOVE=0, E_ZOOM, E_ROTO, E_FREE, E_ERASE, 
		E_SHIFT,	E_ROTATE, E_SCALE };

const int TOOL_NUM = 8;
const QStringList toolTipList = (QStringList()
								 << "Common zooming and panning"	
								 << "Especial zooming"
								 << "Rotoscoping ..."		
								 << "Free hand drawing..."	
								 << "Erase strokes"
								 << "Move strokes"	
								 << "Rotate strokes"	
								 << "Scale strokes");

const QStringList displayList = (QStringList()
								 << "Canvas"
								 << "Projection"
								 << "Sketching Flow"
								 << "Flow"	
								 << "Confidence"	
								 << "Curvature"	
								 << "Derivative"	
								 << "Input"		);

class MainWindow : public QMainWindow, protected Ui_MainWindow {
    Q_OBJECT
public:
    MainWindow();
    ~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

    void restoreSettings();
    void closeEvent(QCloseEvent *e);

	const QImage& image() const { return m_result; }
 
	void setCurrentTool(const QString &name);

	/// status bar
	void setStatusMessage(const QString &txt) {statusBar()->showMessage(txt);}
	void setStatusMouse(const QString& txt) {m_statusMouseLabel->setText(txt);}
	void setStatusZoom(const QString& txt) {m_statusZoomLabel->setText(txt);}
	void setStatusResolution(const QString& txt) {m_statusReslLabel->setText(txt);}
	void setStatusTool(const int idx);

	void setFrame(const int idx);
	void setCurrentKeyFrame(const int idx);
	void setAnimationStatus(bool val) {m_imagePaint->setAnimationSaving(val);}
	void saveAnimationName(const QString& file){m_imagePaint->setAnimationSavingName(file);}

protected slots:
    void on_actionOpen_triggered();
    void on_actionAbout_triggered();
    //void on_actionSelectDevice_triggered();
    void on_actionRecord_triggered();
	void setFullScreen();

    void setDirty();
	void setDirty2();
    void process();
	void process2();
    
    void onVideoChanged(int nframes);
//	void setContourTool(bool bv) ;
//	void setInteriorTool(bool bv) ;

signals:
    void imageChanged(const QImage&);

protected:
    virtual void draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image);

    VideoPlayer *m_player;
    //cpu_image<float4> m_st;
    //cpu_image<float4> m_tfm;
    QImage m_result;
    bool m_dirty;

	int m_tool;

private:
	static MainWindow*	_mainWindow;

	ToolButton*			m_toolButton[TOOL_NUM];

	QLabel		*m_statusMouseLabel;
	QLabel		*m_statusZoomLabel;
	QLabel		*m_statusReslLabel;
	QPushButton	*m_statusIconButton;
	QLabel		*m_statusToolLabel;
	PlayWidget  *m_playWidget;

//	QPushButton *toolTypePushButton[2];
};

class ToolButton : public QPushButton {
	Q_OBJECT
public:
	ToolButton(int w=0, int h=0, QString ico="") {
		setCheckable(true);
		setFlat(true);	
		connect(this, SIGNAL(clicked(bool)), this, SLOT(onChecked(bool)));

		if(w!=0 && h!=0)
			setFixedSize(w,h);
		if (ico!="")
		{
			setIcon(QIcon(QString("../icon/").append(ico).append(".png")));
			setIconSize(QSize(w,h));
		}
	}
protected slots:
	void onChecked(bool bch) {
		if(bch)
		{
			if(!isChecked())
				setChecked(true);
			MainWindow::getInstance()->setCurrentTool(objectName());
		}
	}
protected:
	virtual void enterEvent(QEvent *me) {
		if(!isChecked())
			setFlat(false);
	}
	virtual void leaveEvent(QEvent *me) {
		if(!isChecked())
			setFlat(true);
	}
	//virtual	void mouseReleaseEvent(QMouseEvent *me) {
	//	if(!isChecked())
	//	{
	//		MainWindow::getInstance()->setCurrentTool(objectName());
	//		QPushButton::mouseReleaseEvent(me);
	//	}
	//}
};
