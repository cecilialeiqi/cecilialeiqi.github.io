#ifndef RENDERBUFFER_OBJECT
#define RENDERBUFFER_OBJECT

#include "gpuDLL.h"
#include <glew.h>

namespace gpu {

  class GPU_API RenderbufferObject {
  public:
    RenderbufferObject();
    ~RenderbufferObject();
  
    inline void bind();
    inline static void unbind();

    void setValues(GLenum internal_format,int width,int height);

    inline GLuint getId();
    GLint  getMaxSize();
 
  private:
    GLuint rbo_id;
  };

  inline void RenderbufferObject::bind() {
    glBindRenderbufferEXT(GL_RENDERBUFFER_EXT,rbo_id);
  }

  inline void RenderbufferObject::unbind() {
    glBindRenderbufferEXT(GL_RENDERBUFFER_EXT,0);
  }

  inline GLuint RenderbufferObject::getId() {
    return rbo_id;
  }

} // gpu namespace

#endif // RENDERBUFFER_OBJECT
