/****************************************************************************
** Meta object code from reading C++ file 'videoplayer.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../util/videoplayer.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'videoplayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_VideoPlayer[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   13,   12,   12, 0x05,
      46,   38,   12,   12, 0x05,
      70,   64,   12,   12, 0x05,
     101,   95,   12,   12, 0x05,
     137,  129,   12,   12, 0x05,
     159,   12,   12,   12, 0x05,
     177,   12,   12,   12, 0x05,
     194,   95,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
     216,   12,   12,   12, 0x0a,
     223,   12,   12,   12, 0x0a,
     231,   12,   12,   12, 0x0a,
     240,   12,   12,   12, 0x0a,
     254,   12,   12,   12, 0x0a,
     265,   64,   12,   12, 0x0a,
     286,  129,   12,   12, 0x0a,
     304,   12,   12,   12, 0x0a,
     311,   12,   12,   12, 0x0a,
     319,   12,   12,   12, 0x0a,
     328,   95,   12,   12, 0x0a,
     346,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_VideoPlayer[] = {
    "VideoPlayer\0\0size\0videoChanged(QSize)\0"
    "nframes\0videoChanged(int)\0frame\0"
    "currentFrameChanged(int)\0image\0"
    "currentFrameChanged(QImage)\0playing\0"
    "playbackChanged(bool)\0playbackStarted()\0"
    "playbackPaused()\0outputChanged(QImage)\0"
    "open()\0close()\0rewind()\0stepForward()\0"
    "stepBack()\0setCurrentFrame(int)\0"
    "setPlayback(bool)\0play()\0pause()\0"
    "toggle()\0setOutput(QImage)\0record()\0"
};

void VideoPlayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        VideoPlayer *_t = static_cast<VideoPlayer *>(_o);
        switch (_id) {
        case 0: _t->videoChanged((*reinterpret_cast< const QSize(*)>(_a[1]))); break;
        case 1: _t->videoChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->currentFrameChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->currentFrameChanged((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 4: _t->playbackChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->playbackStarted(); break;
        case 6: _t->playbackPaused(); break;
        case 7: _t->outputChanged((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 8: _t->open(); break;
        case 9: _t->close(); break;
        case 10: _t->rewind(); break;
        case 11: _t->stepForward(); break;
        case 12: _t->stepBack(); break;
        case 13: _t->setCurrentFrame((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->setPlayback((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->play(); break;
        case 16: _t->pause(); break;
        case 17: _t->toggle(); break;
        case 18: _t->setOutput((*reinterpret_cast< const QImage(*)>(_a[1]))); break;
        case 19: _t->record(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData VideoPlayer::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject VideoPlayer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_VideoPlayer,
      qt_meta_data_VideoPlayer, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &VideoPlayer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *VideoPlayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *VideoPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_VideoPlayer))
        return static_cast<void*>(const_cast< VideoPlayer*>(this));
    return QObject::qt_metacast(_clname);
}

int VideoPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void VideoPlayer::videoChanged(const QSize & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void VideoPlayer::videoChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void VideoPlayer::currentFrameChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void VideoPlayer::currentFrameChanged(const QImage & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void VideoPlayer::playbackChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void VideoPlayer::playbackStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void VideoPlayer::playbackPaused()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void VideoPlayer::outputChanged(const QImage & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
