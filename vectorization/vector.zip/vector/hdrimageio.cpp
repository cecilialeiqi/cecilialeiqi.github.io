#include <hdrimageio.h>

using namespace std;

#ifdef USE_LAIR
#include <ImageIO.h>
#include <hdrcol.h>
#endif

namespace image {

  vector<string> HDRImageIO::getExtensions() {
    vector<string> ext;
  
#ifdef USE_LAIR
    ext.push_back("hdr");
    ext.push_back("HDR");
#endif
  
    return ext;
  }

  Image *HDRImageIO::createImage(const string &filename) {
#ifdef USE_LAIR
    ImageIO *img = new ImageIO();
    HDRColor *c;
    unsigned int w,h,dim;
    float r,g,b;

    img->Load(filename,c,w,h,dim);
    int width  = (int)w;
    int height = (int)h;
    
    Image *im = new Image(filename,width,height,Image::RGBA_IMAGE);

    float *ptr = im->ptr();
    
    for(unsigned int i=0; i<im->getHeight();++i)
      for(unsigned int j=0; j<im->getWidth();++j) {
        c->RGBColor(r,g,b);
        c++;
	
        *(ptr)   = (*c)[0];
        *(ptr+1) = (*c)[1];
        *(ptr+2) = (*c)[2];
	*(ptr+3) = 1.0;

	ptr += im->pixelSize();
      }
  delete img;
   
  return im;
#else     
  cerr << "Unable to create " << filename << ", LIB_HDR needed" << endl;
  return NULL;
#endif
  }

  bool HDRImageIO::saveImage(const Image &img,const string &filename) {
#ifdef USE_LAIR
  ImageIO *im  = new ImageIO();
  unsigned int w = img.getWidth();
  unsigned int h = img.getHeight();
  unsigned int d = img.pixelSize();
  float values[3];

  HDRColor *c = (HDRColor *)malloc(w*h*sizeof(HDRColor));

  float *ptr = img.ptr();

  for(unsigned int i=0; i<w*h;++i) {
    values[0] = *(ptr);
    values[1] = *(ptr+1);
    values[2] = *(ptr+2);
    
    ptr += img.pixelSize();
    
    c[i] = HDRColor(values);
  }

  if(!im->Save(filename,c,w,h,d)) {
    cerr << "Unable to save " << filename << endl;
    return false;
  }

  delete im;
  return true;
#else 
  cerr << "Unable to save " << img.getName() << "in " << filename << ", LIB_HDR needed" << endl;
  return false;
#endif
  }

} // image namespace 
