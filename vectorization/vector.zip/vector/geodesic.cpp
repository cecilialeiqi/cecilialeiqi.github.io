#include "geodesic.h"


GeoSegN24::GeoSegN24()
:m_wpx(NULL), m_dist(NULL)
{
}

GeoSegN24::~GeoSegN24()
{
	delete[]m_wpx;
	delete[]m_dist;
}

static float _px_diff_c3(const uchar *pix, const uchar *piy)
{
	return float((pix[0]-piy[0])*(pix[0]-piy[0])+(pix[1]-piy[1])*(pix[1]-piy[1])+(pix[2]-piy[2])*(pix[2]-piy[2]));
}
static void _calc_gs_dist_c24(const uchar *img, int width, int height, int istep, int icn, GeoSegN24::WorkPixel *wpx0, int stride, bool bGeodesic)
{
	float *diff=new float[width*height*12], *pdx=diff;
	int  dstride=12*width;
	double mean=0;

	const int dix[]={-2*istep-2*icn, -2*istep-icn, -2*istep, -2*istep+icn, -2*istep+2*icn, -istep-2*icn, -istep-icn, -istep, -istep+icn, -istep+2*icn, -2*icn, -icn};

	int dxy[15][2];
	int n=0;

	for(int i=-2; i<=0; ++i)
	{
		for(int j=-2; j<=2; ++j, ++n)
		{
			dxy[n][0]=j;
			dxy[n][1]=i;
		}
	}

	for(int yi=0; yi<height; ++yi, img+=istep, pdx+=dstride)
	{
		float *ppx=pdx;
		const uchar *pix=img;

		for(int xi=0; xi<width; ++xi, pix+=icn, ppx+=12)
		{
			for(int i=0; i<12; ++i)
			{
				int x=xi+dxy[i][0], y=yi+dxy[i][1];

				if(bGeodesic && uint(x)<(uint)width&&uint(y)<(uint)height)
				{
					const uchar *piy=pix+dix[i];

					mean+=ppx[i]=_px_diff_c3(pix, piy);
				}
				else
					ppx[i]=0;
			}
		}
	}

	mean/=width*height*12;
	float scale=float(_DIST_MEAN/mean);
	const int vmax=USHRT_MAX;
	GeoSegN24::WorkPixel *wpx=wpx0;

	pdx=diff;

	for(int yi=0; yi<height; ++yi, wpx+=stride, pdx+=dstride)
	{
		GeoSegN24::WorkPixel *ppx=wpx;
		float *pdxx=pdx;

		for(int xi=0; xi<width; ++xi, ++ppx, pdxx+=12)
		{
			for(int i=0; i<12; ++i)
			{
				int v=(int)(scale*pdxx[i]);
				if(!bGeodesic)
					v=0;

				if(v>vmax)
					ppx->nbrw[i]=vmax;
				else
					ppx->nbrw[i]=max(ushort(v),ushort(1)); //std::
			}
		}
	}

	const int dwx[]={-2*width-2, -2*width-1, -2*width, -2*width+1, -2*width+2, -width-2, -width-1, -width, -width+1, -width+2, -2, -1};

	wpx=wpx0;

	for(int yi=0; yi<height; ++yi, wpx+=stride)
	{
		GeoSegN24::WorkPixel *ppx=wpx;

		for(int xi=0; xi<width; ++xi, ++ppx)
		{
			for(int i=0; i<12; ++i)
			{
				int x=xi+dxy[i][0], y=yi+dxy[i][1];

				if(uint(x)<(uint)width&&uint(y)<(uint)height)
				{
					ppx[dwx[i]].nbrw[23-i]=ppx->nbrw[i];
				}
			}
		}
	}

	delete[]diff;
}


int GeoSegN24::SetImage(const uchar *img, int width, int height, int istep, int icn, bool bGeodesic)
{
	int ec=-1;

	if(img)
	{
		if(m_wpx)
		{
			delete[]m_wpx;
			m_wpx=NULL;
		}

		m_wpx=new WorkPixel[width*height];

		if(m_dist)
		{
			delete[]m_dist;
			m_dist=NULL;
		}

		m_dist=new uint[(width+4)*(height+4)];

		m_width=width;
		m_height=height;
		m_stride=width;

		_calc_gs_dist_c24(img,width,height,istep,icn,m_wpx,m_stride,bGeodesic);

		ec=0;
	}

	return ec;
}

#define _NBR(i) wpx[xi].nbrw[i]

const int _MAX_DIST=100000000;

static void _init_dist(uint *dist, int width, int height, int dstride)
{
	for(int yi=0; yi<height; ++yi, dist+=dstride)
	{
		for(int xi=0; xi<width; ++xi)
		{
			dist[xi]=_MAX_DIST;
		}
	}
}

static void _raster_LT_c24(const GeoSegN24::WorkPixel *wpx, int width, int height, int stride, uint *dist, int dstride, const uchar *mask,int mstep, uchar mv)
{
	const int dd[]={-dstride*2-2, -dstride*2-1, -dstride*2, -dstride*2+1, -dstride*2+2, -dstride-2, -dstride-1, -dstride, -dstride+1, -dstride+2, -2, -1};

	for(int yi=0; yi<height; ++yi, wpx+=stride, dist+=dstride, mask+=mstep)
	{
		for(int xi=0; xi<width; ++xi)
		{
			if(mask[xi]==mv)
				dist[xi]=0;
			else
				if(mask[xi]!=0)
					dist[xi]=_MAX_DIST;
				else
				{
					uint dmin=dist[xi];

					for(int i=0; i<12; ++i)
					{
						uint dx=_NBR(i)+dist[xi+dd[i]];

						if(dx<dmin)
							dmin=dx;
					}
					dist[xi]=dmin;
				}
		}
	}
}

static void _raster_RB_c24(const GeoSegN24::WorkPixel *wpx, int width, int height, int stride, uint *dist, int dstride, const uchar *mask,int mstep, uchar mv)
{
	const int dd[]={1,2, dstride-2, dstride-1, dstride, dstride+1, dstride+2, dstride*2-2, dstride*2-1,dstride*2, dstride*2+1, dstride*2+2};

	width=-width;

	for(int yi=0; yi<height; ++yi, wpx-=stride, dist-=dstride, mask-=mstep)
	{
		for(int xi=0; xi>width; --xi)
		{
			if(mask[xi]==mv)
				dist[xi]=0;
			else
				if(mask[xi]!=0)
					dist[xi]=_MAX_DIST;
				else
				{
					uint dmin=dist[xi];

					for(int i=0; i<12; ++i)
					{
						uint dx=_NBR(i+12)+dist[xi+dd[i]];

						if(dx<dmin)
							dmin=dx;
					}
					dist[xi]=dmin;
				}
		}
	}
}

static void _raster_RT_c24(const GeoSegN24::WorkPixel *wpx, int width, int height, int stride, uint *dist, int dstride, const uchar *mask,int mstep, uchar mv)
{
	const int dd[]={-dstride*2-2, -dstride*2-1, -dstride*2, -dstride*2+1, -dstride*2+2, -dstride-2, -dstride-1, -dstride, -dstride+1, -dstride+2, 1, 2};
	const int iw[]={0,1,2,3,4,5,6,7,8,9,12,13};

	width=-width;

	for(int yi=0; yi<height; ++yi, wpx+=stride, dist+=dstride, mask+=mstep)
	{
		for(int xi=0; xi>width; --xi)
		{
			if(mask[xi]==mv)
				dist[xi]=0;
			else
				if(mask[xi]!=0)
					dist[xi]=_MAX_DIST;
				else
				{
					uint dmin=dist[xi];

					for(int i=0; i<12; ++i)
					{
						uint dx=_NBR(iw[i])+dist[xi+dd[i]];

						if(dx<dmin)
							dmin=dx;
					}
					dist[xi]=dmin;
				}
		}
	}
}


static void _raster_LB_c24(const GeoSegN24::WorkPixel *wpx, int width, int height, int stride, uint *dist, int dstride, const uchar *mask,int mstep, uchar mv)
{
	const int dd[]={-2,-1, dstride-2, dstride-1, dstride, dstride+1, dstride+2, 2*dstride-2, 2*dstride-1, 2*dstride, 2*dstride+1, 2*dstride+2};
	const int iw[]={10,11, 14, 15, 16, 17, 18, 19, 20 ,21, 22, 23};

	for(int yi=0; yi<height; ++yi, wpx-=stride, dist-=dstride, mask-=mstep)
	{
		for(int xi=0; xi<width; ++xi)
		{
			if(mask[xi]==mv)
				dist[xi]=0;
			else
				if(mask[xi]!=0)
					dist[xi]=_MAX_DIST;
				else
				{
					uint dmin=dist[xi];

					for(int i=0; i<12; ++i)
					{
						uint dx=_NBR(iw[i])+dist[xi+dd[i]];

						if(dx<dmin)
							dmin=dx;
					}
					dist[xi]=dmin;
				}
		}
	}
}

#undef _NBR

static void _calc_geo_dist_c24(const GeoSegN24::WorkPixel *wpx, int width, int height, int stride, uint *dist, int dstride, const uchar *mask, int mstep, uchar mv)
{
#define _WPP(x,y) (wpx+(y)*stride+(x))
#define _WMP(x,y) (mask+(y)*mstep+(x))
#define _WDP(x,y) (dist+(y)*dstride+(x))

	for(int i=0; i<1; ++i) //��������
	{
		_raster_LT_c24(_WPP(2,2), width-2, height-2, stride, _WDP(2,2),dstride, _WMP(2,2), mstep,mv);

		_raster_RB_c24(_WPP(width-3,height-3), width-2, height-2, stride, _WDP(width-3,height-3), dstride,_WMP(width-3,height-3),mstep,mv);

		_raster_RT_c24(_WPP(width-3,2), width-2, height-2, stride, _WDP(width-3,2),dstride, _WMP(width-3,2),mstep,mv);

		_raster_LB_c24(_WPP(2,height-3), width-2, height-2, stride, _WDP(2,height-3), dstride,_WMP(2,height-3),mstep,mv);
	}
#undef _WPP
#undef _WMP
#undef _WDP
}


static void _get_dist(uint *dist, int width, int height, int dstride, double *prob, int pstride)
{
	for(int yi=0; yi<height; ++yi, dist+=dstride, prob+=pstride)
	{
		for(int xi=0; xi<width; ++xi)
		{
			prob[xi]=(double)dist[xi];
		}
	}
}

static void _get_dist(uint *dist, int width, int height, int dstride, float *prob, int pstride)
{
	for(int yi=0; yi<height; ++yi, dist+=dstride, prob+=pstride)
	{
		for(int xi=0; xi<width; ++xi)
		{
			prob[xi]=(float)dist[xi];
		}
	}
}

template<typename _DestT>
static void _get_prob_x(uint *dist, int width, int height, int dstride, _DestT *prob, int pstride, int method)
{
	if(method==GSM_ALL)
	{
		for(int yi=0; yi<height; ++yi, dist+=dstride, prob+=pstride)
		{
			for(int xi=0; xi<width; ++xi)
			{
				float db=(float)dist[xi];

				prob[xi]=db/(prob[xi]+db);
			}
		}
	}
	else
	{
		uint dmax=dist[0];

		uint *dx=dist;

		for(int yi=0; yi<height; ++yi, dx+=dstride)
		{
			for(int xi=0; xi<width; ++xi)
			{
				if(dx[xi]>dmax)
					dmax=dx[xi];
			}
		}

		uint nh=dmax/8+1;
		uint *hist=new uint[nh];

		memset(hist,0,sizeof(uint)*nh);

		dx=dist;

		for(int yi=0; yi<height; ++yi, dx+=dstride)
		{
			for(int xi=0; xi<width; ++xi)
			{
				++hist[dx[xi]>>3];
			}
		}

		int np=width*height/10;

		for(dmax=nh-1;np>0;--dmax)
		{
			np-=hist[dmax];
		}

		dmax*=8;//_SECF_VVP(8,hvd,50);

		delete[]hist;

		float scale=1.0f/(dmax+1);

		dx=dist;

		if(method==GSM_FORE)
		{
			for(int yi=0; yi<height; ++yi, dx+=dstride, prob+=pstride)
			{
				for(int xi=0; xi<width; ++xi)
				{
					uint d=dx[xi]>dmax? dmax:dx[xi];

					prob[xi]=1.0f-d*scale;
				}
			}
		}
		else
		{
			for(int yi=0; yi<height; ++yi, dx+=dstride, prob+=pstride)
			{
				for(int xi=0; xi<width; ++xi)
				{
					uint d=dx[xi]>dmax? dmax:dx[xi];

					prob[xi]=d*scale;
				}
			}
		}
	}
}

int GeoSegN24::GetProb(const uchar *mask, int mstep, float *prob, int stride, int method, uchar mv)
{
	int ec=-1;

	int dstride=m_width+4;
	uint *dist=m_dist+2*dstride+2;

#if 1
	if(method&GSM_FORE)
	{
		_init_dist(m_dist, m_width+4, m_height+4, dstride);
		_calc_geo_dist_c24(m_wpx,m_width,m_height,m_stride, dist,dstride, mask,mstep,mv);

		if(method&GSM_BACK)
			_get_dist(dist,m_width,m_height,dstride, prob, stride);
	}

	if(method&GSM_BACK)
	{
		_init_dist(m_dist, m_width+4, m_height+4, dstride);
		_calc_geo_dist_c24(m_wpx,m_width,m_height,m_stride,dist,dstride, mask,mstep,mv);
	}

	_get_prob_x(dist,m_width,m_height,dstride,prob,stride, method);
#else

	_init_dist(m_dist, m_width+4, m_height+4, dstride);
	_calc_geo_dist_c24(m_wpx,m_width,m_height,m_stride,dist,dstride, mask,mstep,mv);

	_get_dist(dist,m_width,m_height,dstride,prob,stride);

#endif

	return ec;
}