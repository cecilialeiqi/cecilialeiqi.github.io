#ifndef PIPELINE_H
#define PIPELINE_H

#include "gpuDLL.h"
#include <vertexbufferObject.h>
#include <framebufferObject.h>
#include <textureFormat.h>
#include <textureParams.h>
#include <texture2D.h>
#include <gpuProgram.h>
#include <gpuShader.h>
#include <pass.h>

#include <assert.h>
#include <vector>

namespace gpu {

  class GPU_API Pipeline {

  public:
    Pipeline(unsigned int nbPass=1,const TextureFormat &tf=TextureFormat(),const TextureParams &tp=TextureParams(),int depthMode=USE_ONE_DEPTH_BUFFER);
    ~Pipeline();

    static const int USE_ONE_DEPTH_BUFFER  = 0;
    static const int USE_NO_DEPTH_BUFFER   = 1;
    static const int USE_MULT_DEPTH_BUFFER = 2;

    // pass initialization
    bool setPass(unsigned int i,unsigned int nbTexOutput=0,GPUProgram *prog=NULL);

    // init must be called after the creation of each pass
    bool init();

    // texture settings
    void setTextureSize(unsigned int w,unsigned int h);
    void setTextureData(const TextureFormat &tf,const TextureParams &tp);

    // accessors 
    inline FloatTexture2D *outputTex(int tex,unsigned int pass) const;
    inline GPUProgram *prog(unsigned int pass) const;
    inline void setProg(GPUProgram *prog,unsigned int pass);
    inline void reloadShaders();
    inline FramebufferObject *getDataFromPass(unsigned int pass,unsigned int *nbTexOutput,int *attachment);

    // current functions 
    inline void swapToScreenMode();
    inline void swapToWorldMode();
    inline void drawQuad();
  
    inline void bindPassAndClearBuffers(unsigned int pass,GLbitfield mask);
    inline void bindPass(unsigned int pass);
    inline void unbindPass(unsigned int pass);

    inline void bindDrawQuadAndUnbind(unsigned int pass);
    inline void bindDrawVBOAndUnbind(unsigned int pass,VertexbufferObject *vbo);
    inline void bindCleanDrawQuadAndUnbind(unsigned int pass,GLbitfield mask);
    inline void bindCleanDrawVBOAndUnbind(unsigned int pass,VertexbufferObject *vbo,GLbitfield mask);

    inline void bindDrawQuadsAndUnbind(unsigned int from,unsigned int to);
    inline void bindDrawVBOsAndUnbind(unsigned int from,unsigned int to,VertexbufferObject *vbo);
    inline void bindCleanDrawQuadsAndUnbind(unsigned int from,unsigned int to,GLbitfield mask);
    inline void bindCleanDrawVBOsAndUnbind(unsigned int from,unsigned int to,VertexbufferObject *vbo,GLbitfield mask);

    inline void drawQuadAndUnbindPass(unsigned int pass);
    inline void drawVBOAndUnbindPass(unsigned int pass,VertexbufferObject *vbo);

    // test function 
    void printInfo();

  private:
    void createFBOs();
    void createTextures();

    bool attachTexturesToFBOs();

    unsigned int _nbPass;
    unsigned int _nbFBOs;
    unsigned int _nbTexs;

    std::vector<Pass              *> _pass;
    std::vector<FramebufferObject *> _fbos;
    std::vector<FloatTexture2D    *> _texs;

    TextureFormat _tf;
    TextureParams _tp;

    int _depthMode;
    int _currentFbo;
  };

  inline FloatTexture2D *Pipeline::outputTex(int tex,unsigned int pass) const {
    assert(pass<_nbPass);
    assert(_pass[pass]!=NULL);
    assert((unsigned int)tex<_pass[pass]->nbTexOutput());
 
    return _texs[_pass[pass]->texId(tex)];
  }

  inline GPUProgram *Pipeline::prog(unsigned int pass) const {
    assert(pass<_nbPass);

    return _pass[pass]->prog();
  }

  inline void Pipeline::setProg(GPUProgram *prog,unsigned int pass) {
    assert(pass<_nbPass);
    assert(_pass[pass]!=NULL);

    _pass[pass]->setProg(prog);
  }

  inline void Pipeline::swapToScreenMode() {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glDepthMask(GL_FALSE);
  }

  inline void Pipeline::swapToWorldMode() {
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glDepthMask(GL_TRUE);
  }

  inline void Pipeline::drawQuad() {
    glBegin(GL_QUADS);

    glTexCoord2f(0.0,0.0);  glVertex2f(-1.0,-1.0);
    glTexCoord2f(1.0,0.0);  glVertex2f( 1.0,-1.0);
    glTexCoord2f(1.0,1.0);  glVertex2f( 1.0, 1.0);
    glTexCoord2f(0.0,1.0);  glVertex2f(-1.0, 1.0);

    glEnd();
  }

  inline void Pipeline::bindPassAndClearBuffers(unsigned int pass,GLbitfield mask) {
    bindPass(pass);
    glClear(mask);
  }

  inline void Pipeline::bindPass(unsigned int pass) {
    Pass *p = _pass[pass];
  
    if(p->nbTexOutput()==0) {
      FramebufferObject::unbind();
      _currentFbo = -1;
    } else {
      int c = p->fboNum();
    
      if(c!=_currentFbo) {
        _currentFbo = c;
        _fbos[_currentFbo]->bind();
      }
    
      glDrawBuffers(p->nbTexOutput(),FramebufferObject::buffers(p->attachment(0)));
    }
  
    p->prog()->enable();
  }

  inline void Pipeline::unbindPass(unsigned int pass) {
    _pass[pass]->prog()->disable();
  }

  inline void Pipeline::bindDrawQuadAndUnbind(unsigned int pass) {
    bindPass(pass);
    drawQuad();
    unbindPass(pass);
  }

  inline void Pipeline::bindDrawVBOAndUnbind(unsigned int pass,VertexbufferObject *vbo) {
    bindPass(pass);
    vbo->enableDrawAndDisable();
    unbindPass(pass);
  }

  inline void Pipeline::bindCleanDrawQuadAndUnbind(unsigned int pass,GLbitfield mask) {
    bindPassAndClearBuffers(pass,mask);
    drawQuad();
    unbindPass(pass);
  }

  inline void Pipeline::bindCleanDrawVBOAndUnbind(unsigned int pass,VertexbufferObject *vbo,GLbitfield mask) {
    bindPassAndClearBuffers(pass,mask);
    vbo->enableDrawAndDisable();
    unbindPass(pass);
  }

  inline void Pipeline::bindDrawQuadsAndUnbind(unsigned int from,unsigned int to) {
    for(unsigned int i=from;i<=to;++i) {
      bindDrawQuadAndUnbind(i);
    }
  }

  inline void Pipeline::bindDrawVBOsAndUnbind(unsigned int from,unsigned int to,VertexbufferObject *vbo) {
    for(unsigned int i=from;i<=to;++i) {
      bindDrawVBOAndUnbind(i,vbo);
    }
  }

  inline void Pipeline::bindCleanDrawQuadsAndUnbind(unsigned int from,unsigned int to,GLbitfield mask) {
    for(unsigned int i=from;i<=to;++i) {
      bindCleanDrawQuadAndUnbind(i,mask);
    }
  }

  inline void Pipeline::bindCleanDrawVBOsAndUnbind(unsigned int from,unsigned int to,VertexbufferObject *vbo,GLbitfield mask) {
    for(unsigned int i=from;i<=to;++i) {
      bindCleanDrawVBOAndUnbind(i,vbo,mask);
    }
  }

  inline void Pipeline::drawQuadAndUnbindPass(unsigned int pass) {
    drawQuad();
    unbindPass(pass);
  }

  inline void Pipeline::drawVBOAndUnbindPass(unsigned int pass,VertexbufferObject *vbo) {
    vbo->enableDrawAndDisable();
    unbindPass(pass);
  }

  inline FramebufferObject *Pipeline::getDataFromPass(unsigned int pass,unsigned int *nbTexOutput,int *attachment) {
    *nbTexOutput = _pass[pass]->nbTexOutput();
    
    if(*nbTexOutput==0) {
      *attachment = -1;
      return NULL;
    }

    *attachment = _pass[pass]->attachment(0);
    return _fbos[_pass[pass]->fboNum()];
  }
  
  inline void Pipeline::reloadShaders() {
    for(unsigned int i=0;i<_nbPass;++i) {
      assert(_pass[i]->prog()!=NULL);
      _pass[i]->prog()->reload();
    }
  }

} // gpu namespace 

#endif // PIPELINE_H
