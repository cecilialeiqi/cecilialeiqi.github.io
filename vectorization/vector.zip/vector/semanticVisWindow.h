
#pragma once

#include "ui_mainwindow.h"
#include "semanticVisPaint.h"
#include "videoplayer.h"
#include "mlabel.h"

const QStringList displayList = (QStringList()
								 << "Result"	
								 << "Class"
								 << "Smoothing"	
								 << "Lines"	
								 << "Importance"
								 << "Segmentation"
								 << "Flow"		
								 << "Input"		);

class MainWindow : public QMainWindow, protected Ui_MainWindow {
    Q_OBJECT
public:
    MainWindow();
    ~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

    void restoreSettings();
    void closeEvent(QCloseEvent *e);

    const QImage& image() const { return m_result; }
	QString fileName() { return m_player->filename(); }
 
	/// status bar
	void setStatusMessage(const QString &txt) {statusBar()->showMessage(txt);}
	void setStatusMouse(const QString& txt) {m_statusMouseLabel->setText(txt);}
	void setStatusZoom(const QString& txt) {m_statusZoomLabel->setText(txt);}

	Mlabel *getGradientLabel() const {return gradientLabel;}

protected slots:
    void on_actionOpen_triggered();
    void on_actionAbout_triggered();
    void on_actionRecord_triggered();
	void setFullScreen();

    void setDirty();
    void process();
    
    void onVideoChanged(int nframes);

signals:
    void imageChanged(const QImage&);

protected:
    virtual void draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image);

    VideoPlayer *m_player;
    QImage m_result;
    bool m_dirty;

	Mlabel *gradientLabel;

private:
	static MainWindow*	_mainWindow;

	QLabel		*m_statusMouseLabel;
	QLabel		*m_statusZoomLabel;
};
