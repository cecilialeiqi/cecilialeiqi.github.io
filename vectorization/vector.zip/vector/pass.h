#ifndef PASS_H
#define PASS_H 

#include "gpuDLL.h"
#include <textureFormat.h>
#include <textureParams.h>
#include <gpuProgram.h>
#include <gpuShader.h>

namespace gpu {

  class GPU_API Pass {
    
  public:
  Pass(GPUProgram *prog,unsigned int nbTexOutput) : 
    _prog(prog),
    _nbTexOuput(nbTexOutput),
    _fboNum(-1) { }

    ~Pass() {}

    inline GPUProgram    *prog()            const { return _prog;           }
    inline unsigned int   nbTexOutput()     const { return _nbTexOuput;     }
    inline int            fboNum()          const { return _fboNum;         }
    inline int            attachment(int i) const { return _attachments[i]; }
    inline int            texId(int i)      const { return _texIds[i];      }

    inline void setProg(GPUProgram *prog) { _prog = prog;              }
    inline void clearAttachment()         { _attachments.clear();      }
    inline void addAttachment(int a)      { _attachments.push_back(a); }
    inline void setFboNum(int num)        { _fboNum = num;             }
    inline void clearTexIds()             { _texIds.clear();           }
    inline void addTexId(int id)          { _texIds.push_back(id);     }

  private:
    GPUProgram      *_prog;
    unsigned int     _nbTexOuput;
    int              _fboNum;
    std::vector<int> _attachments;
    std::vector<int> _texIds;
  };

} // gpu namespace 

#endif // PASS_H
