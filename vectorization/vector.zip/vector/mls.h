#pragma once

#define EIGEN_DONT_ALIGN_STATICALLY
#include <Eigen/Dense>
//#include "/home/gael/Coding/ImplicitSkin/ImplicitSkin/Rbf/RBF.h"
#include <vector>
#include <iostream>

template<int Dim>
int basisSize(int degree)
{
  int n = degree+1;
  int size = 1;
  if(Dim==1)
    size = n;
  else if(Dim==2)
    size = n*(n+1)/2;
  else if(Dim==3)
  {
    size = 0;
    for(int i=1;i<=n;++i)
      size += i*(i+1)/2;
  }
  return size;
}

template<typename Scalar, int Dim>
void fill_basis(Eigen::Matrix<Scalar,Eigen::Dynamic,1>& b, const Eigen::Matrix<Scalar,Dim,1>& v, int degree)
{
  b[0] = 1;
  if(degree >= 1)
      for(int k=0; k < Dim; k++)
          b[1 + k] = v[k];
  if(degree >= 2)
      for(int k=0; k < Dim; k++)
          for(int j=0; j <= k; j++)
              b[1 + Dim + k*(k+1)/2 + j] =  v[k]*v[j];		// ??
  if(degree >= 3)
      for(int k=0; k < Dim; k++)
          for(int j=0; j <= k; j++)
              for(int i=0; i <= j; i++)
                  b[1 + Dim + Dim*(Dim+1)/2 + k*(k+1)*(k+2)/6 + j*(j+1)/2 + i] = v[k]*v[j]*v[i];
}

/** Given a set of points \a positions with associated values \a values,
  * it performs a weighted least fit and returns the value of the local
  * approximation at position \a ref.
  *
  * \param weights the weights used for least square fit
  * \param Scalar the scalar type
  * \param Dim the dimension of the ambient space (max = 3)
  * \param Degree degree of the fitted polynomial (max = 3)
  */
template<
  typename Scalar, int Dim,
  typename EvalPosType,
  typename PositionContainer,
  typename ValueContainer,
  typename WeightContainer>
Scalar mls_reconstruction(const EvalPosType& ref, const PositionContainer& positions, const ValueContainer& values, const WeightContainer& weights, int degree, Eigen::Matrix<Scalar,Eigen::Dynamic,1>* pU = 0)
{
  using namespace Eigen;
  
  int size = basisSize<Dim>(degree);
  
  typedef Matrix<Scalar,Dim,1> VectorD;
  typedef Matrix<Scalar,Dynamic,1> VectorX;
  typedef Matrix<Scalar,Dynamic,Dynamic> MatrixX;
  

  // compute the covariance matrix
  int nbPoints = positions.size();
  MatrixX M(nbPoints,size);
  M.setZero();
  VectorX b(nbPoints);
  b.setZero();
  VectorX vec(size);
  int i=0;
  for(typename PositionContainer::const_iterator pos = positions.begin(); pos!=positions.end(); ++pos, ++i)
  {
    VectorD d = ((*pos)-ref);
    fill_basis(vec, d, degree);
                                      
    M.row(i) = sqrt(weights[i]) * vec.transpose();
    //a += weights[i] * vec * vec.transpose();
    b[i] = sqrt(weights[i]) * values[i];// += vec * (values[i] * weights[i]);
  }

  // solve Ax = b, and evaluate the polynomial at 0
  // since the we used the centered basis, => we simply have to return the coeff of the constant basis

  VectorX x = M.transpose() * b;
  
  //A.llt().solveInPlace(x);
  x = (M.transpose() * M).lu().solve(x);
  
  if(pU)
  {
    *pU = x;
  }
//   JacobiSVD<MatrixX> svd(M,ComputeThinU|ComputeThinV);
//   x = svd.solve(b);
  return x[0];
}

typedef unsigned int uint;

/**************************************/
/* MLS interpolation of symmetric 2x2 */
/* tensors representing a constant    */
/* vector field                       */
/**************************************/
Eigen::Vector3d mlsConstant(const Eigen::Vector2d &src, uint nofSamples,  
	const std::vector<double> &weights, 
	const std::vector<Eigen::Vector2d> &uvec,
	const std::vector<Eigen::Vector2d,Eigen::aligned_allocator<Eigen::Vector2d> > &positions,
	int polynomial_degree)
{
	Eigen::Matrix<double,3,Eigen::Dynamic> vectors(3,nofSamples);
	//std::vector<double>             values(nofSamples);

	double sumOfWeights = 0.0;
	for(uint i=0 ; i<nofSamples ; ++i)
	{
		//  positions[i]      = /* position of the neighbor point */;
		//  weights[i]        = /* associated weight */
		Eigen::Vector2d u = uvec[i];	/* associated vector */;

		// traceless tensor:
		//Eigen::Vector2d v = u.unitOrthogonal();
		//vectors.col(i) << u.x()*u.x() - v.x()*v.x(), u.y()*u.x() - v.y()*v.x(), u.y()*u.y() - v.y()*v.y();

		// rank-one tensor:
		vectors.col(i) << u.x()*u.x(), u.y()*u.x(), u.y()*u.y();
	}

	Eigen::Vector3d result;
	int bsize = basisSize<2>(polynomial_degree /* 0, 1, 2, or 3*/);
	//std::cout << "polynomial_degree = " << polynomial_degree << ";  bsize = " << bsize << std::endl;
	Eigen::MatrixXd U(3,bsize);
	Eigen::VectorXd val(nofSamples);

	for (int j=0; j<3; ++j)
	{
	//	values = vectors.row(j);
		val = vectors.row(j);
		//for(int k=0; k<nofSamples; k++)
		//	values[k] = val[k];

		Eigen::VectorXd poly(bsize);
		result[j] = mls_reconstruction<double,2>(src, positions, 
			val, weights, polynomial_degree, &poly);
		U.row(j) = poly;
	}
	//result = vectors.col(0);

	Eigen::Matrix2d C;
	C << result[0], result[1], result[1], result[2];

	Eigen::SelfAdjointEigenSolver<Eigen::Matrix2d> eig(C);
	int i = 0;
	eig.eigenvalues().maxCoeff(&i);
	return Eigen::Vector3d(eig.eigenvectors().col(i).x(), eig.eigenvectors().col(i).y(),
		//eig.eigenvalues()[i]*(eig.eigenvalues()(0)/eig.eigenvalues().sum()));
		//eig.eigenvalues()(i)*(1.0-eig.eigenvalues()(0)/eig.eigenvalues().sum()));
		eig.eigenvalues()(i) );
}

/**************************************************/
/* Spherical MLS interpolation of a vector field  */
/**************************************************/
template<typename Mat>
void chol(Mat& A)
{
	typedef typename Mat::Scalar Scalar;
	int n = A.cols();
	for(int i=0; i<n; ++i)
	{
		for(int j=i+1; j<n; ++j)
		{
			A(j,i) = A(i,j)/A(i,i);
			for(int k=j; k<n ; ++k)
				A(j,k) -= A(j,i) * A(i,k);
		}
	}
}
template<typename Mat>
void cholsolve(const Mat& A, typename Mat::Scalar* x)
{
	int n = A.cols();
	// forward substitution : x <- inv(U') * x
	for (int i=1; i<n; ++i)
		for (int k=0; k<i; ++k)
			x[i] -= A(i,k) * x[k];
	// x <- inv(D) * x
	for (int k=0 ; k<n ; ++k)
		x[k] /= A(k,k);
	// backsubstitution : x <- inv(U) * x
	for (int i=n-2; i>=0; --i)
		for (int k=i+1; k<n; ++k)
			x[i] -= x[k] * A(k,i);
}

// solve Ax = lx with l maximal and |x|=1
// you must provide an initial guess for y,
// e.g., x = [1 0 0 0 0 ... ]
template<typename Mat, typename Vec>
void power(const Mat& A, Vec& y)
{
	typedef typename Mat::Scalar Scalar;
	int iters = 0;
	Scalar theta;
	Vec v;
	do {
		v = y.normalized();
		y.noalias() = A * v; // matrix - vector product
		theta = v.dot(y);
		iters++;
	} while (iters<100 && (y-theta*v).squaredNorm() > 1e-10*Eigen::internal::abs2(theta));
	//std::cout << "::" << iters << "::" ;
	y.normalize();
}

// solve Ax = lBx with l maximal and x'Bx=1
// you must provide an initial guess for y,
// e.g., x = [1 0 0 0 0 ... ]
template<typename Mat, typename Vec>
void gen_power(const Mat& A, const Mat& B, Vec& x)
{
	Eigen::Matrix4d Q(A),C(B);

	chol(C);
	for(int i=0; i<4; ++i)
		cholsolve(C,Q.col(i).data());
	power(Q,x);
}

Eigen::VectorXd mlsSpherical(const Eigen::Vector2d &src, uint nofSamples,  
	const std::vector<double> &weights, 
	const std::vector<Eigen::Vector2d> &uvec,
	const std::vector<Eigen::Vector2d,Eigen::aligned_allocator<Eigen::Vector2d> > &positions)
{
	//Eigen::Vector2d src = /* point of evaluation */;

	typedef Eigen::Matrix<double,4,4> Matrix44;
	typedef Eigen::Matrix<double,4,1> Vector4;
	Matrix44 cov = Matrix44::Zero();
	double sumOfWeights = 0.;

	Matrix44 Q2 = Matrix44::Zero();
	float sumOfNorm = 0;

	for(uint i=0 ; i<nofSamples ; ++i)
	{
		Eigen::Vector2d p = positions[i];	/* position of the neighbor point */;
		Eigen::Vector2d u = uvec[i];		/* associated vector */;
		double w = weights[i];				/* associated weight */;

		// centered basis:
		//p -= src;
		sumOfWeights += w;
		double len = u.norm();
		w *= len;
		u = len==0.0 ? u:u/len;

		Vector4 basis;
		basis << u, u.dot(p), u.y()*p.x() - u.x()*p.y();
		cov += w * basis * basis.transpose();
		
		Matrix44 q = Matrix44::Zero();
		q <<   1,    0,      p.x(), -p.y(),
			   0,    1,      p.y(),  p.x(),
			   p.x(), p.y(), p.squaredNorm(), 0,
			  -p.y(), p.x(), 0, p.squaredNorm();

		Q2 += w * q;
		sumOfNorm += w;// * u.norm();
	}
	cov /= sumOfNorm;
	Q2  /= sumOfNorm;
	sumOfNorm /= sumOfWeights;
	//Q2 /= sumOfNorm;


	// TODO use a GeneralizedSelfAdjointEigenSolver:
	//Eigen::SelfAdjointEigenSolver<Matrix33> eig(cov);
	//Eigen::GeneralizedSelfAdjointEigenSolver<Matrix33> eig(cov,Q1,Eigen::Ax_lBx);

#if 1
	Matrix44 M = Q2.inverse() * cov;
	Eigen::EigenSolver<Matrix44> eig(M);
	int maxId = 0;
	eig.eigenvalues().real().maxCoeff(&maxId);

//	std::cout << "EigenValues = " << eig.eigenvalues().real() << " Max @ " << maxId <<std::endl;	
//	double c = eig.eigenvalues().real().maxCoeff()/eig.eigenvalues().real().sum();
//	c = (c-0.25)/0.75;

	Vector4 eivec = eig.eigenvectors().col(maxId).real();
#else
	Vector4 eivec;
	eivec << 1, 0, 0, 0;
	gen_power(cov, Q2, eivec);
#endif

	Eigen::Vector2d b = eivec.head<2>();
	double a0 = eivec(2);
	double a1 = eivec(3);
	//Matrix44 A;
	Eigen::Matrix2d A; 
	A << a0, -a1, a1, a0;

	// the flow is locally approximated by A * p + b;
	// with p a point in the basis centered at src.
	Eigen::Vector2d fl =   b;

	/**********************************************************************/
	/* analysis of a linear vector field of the form A * Pp + b at (0,0)  */
	/**********************************************************************/

	double norm = b.norm();

	// direct solution for the curl:
	double curl = A(0,1) - A(1,0);	
	
	// direct solution for the divergence:
	double div = A(0,0) + A(1,1);

	////// curl of the normalized linear vector field,
	////// if norm==1, then they are equivalent !!
	//curl = (A(0,1) - A(1,0))/norm 
	//	- (b(0)*b(0)*A(0,1) + b(0)*b(1)*A(1,1) 
	//	- b(1)*b(0)*A(0,0) - b(1)*b(1)*A(1,0))
	//	/(norm*norm*norm);

	////// divergence of the normalized linear vector field,
	////// if norm==1, then they are equivalent !!
	//div = (A(0,0) - A(1,1))/norm 
	//	- (b(0)*b(0)*A(0,0) + b(0)*b(1)*A(1,0) 
	//	+ b(1)*b(0)*A(0,1) + b(1)*b(1)*A(1,1))
	//	/(norm*norm*norm);

	//return Eigen::Vector4d(fl.x(), fl.y(), curl, div);
	Eigen::VectorXd res(5);
	res(0) = fl.x();
	res(1) = fl.y();
	res(2) = sumOfNorm*sumOfNorm;
	res(3) = curl;
	res(4) = div;
	return res;
}

/**************************************************/
/* Linear MLS interpolation of a vector field     */
/**************************************************/
Eigen::Vector3d mlsLinear(const Eigen::Vector2d &src, uint nofSamples,  
	const std::vector<double> &weights, 
	const std::vector<Eigen::Vector2d> &uvec,
	const std::vector<Eigen::Vector2d,Eigen::aligned_allocator<Eigen::Vector2d> > &positions)
{
	typedef Eigen::Matrix<double,5,5> Matrix55;
	typedef Eigen::Matrix<double,5,1> Vector5;

	Matrix55 cov = Matrix55::Zero();
	Eigen::Vector2d sumP = Eigen::Vector2d::Zero();
	double sumDotPP = 0.;
	Matrix55 Q = Matrix55::Zero();

	Eigen::Matrix<double,3,Eigen::Dynamic> vectors(3,nofSamples);
	//std::vector<double>             values(nofSamples);

	double sumOfWeights = 0.0;
	double sumOfNorm = 0.0;
	for(uint i=0 ; i<nofSamples ; ++i)
	{
		Eigen::Vector2d p = positions[i];
		Eigen::Vector2d u = uvec[i];
		double w = weights[i];

		double len = u.norm();
		sumOfWeights += w;
		w *= len;
		u = len==0.0 ? u:u/len;

		Vector5 basis;
		basis << u, u.cwiseProduct(p), u.x()*p.y()+u.y()*p.x();

		cov += w * basis * basis.transpose();

		sumOfNorm += w;

		Matrix55 q;
		q <<  1,     0,      p.x(),        0,            p.y(),
			0,     1,      0,            p.y(),        p.x(),
			p.x(), 0,      p.x()*p.x(),  0,            p.x()*p.y(),
			0,     p.y(),  0,            p.y()*p.y(),  p.x()*p.y(),
			p.y(), p.x(),  p.x()*p.y(),  p.x()*p.y(),  p.squaredNorm();

		Q += w * q;

		sumP += w * p;
		sumDotPP += w * p.squaredNorm();
	}
	cov /= sumOfNorm;
	Q   /= sumOfNorm;
	sumOfNorm /= sumOfWeights;

	Matrix55 M = Q.inverse() * cov;
	Eigen::EigenSolver<Matrix55> eig(M);
	Vector5 eivals = eig.eigenvalues().real();
	int maxId = 0;
	double l = eivals.maxCoeff(&maxId);
	Vector5 eivec5 = eig.eigenvectors().col(maxId).real();

	// The flow is of the form: b + A*x
	Eigen::Vector2d b = eivec5.head<2>();
	Eigen::Matrix2d A;
	A << eivec5(2), eivec5(4),
		eivec5(4), eivec5(3);

	// evaluate the flow at the current position:
	Eigen::Vector2d grad = (b + A * src).normalized();
	// store it:
	Eigen::Vector2d mFlowVec = Eigen::Vector2d(grad.x(), grad.y());
	return Eigen::Vector3d(mFlowVec(0),mFlowVec(1), sumOfNorm*sumOfNorm);

	// integrate
	// the potential is of the form 1 x y x^2 y^2 xy

	Eigen::VectorXd vecU(6);
	vecU[0] = 0;
	vecU[1] = eivec5(0);
	vecU[2] = eivec5(1);
	vecU[3] = 0.5*eivec5(2);
	vecU[4] = 0.5*eivec5(3);
	vecU[5] = eivec5(4);

	double sumPot = 0;
	Eigen::VectorXd basis(6);
	for(uint i=0 ; i<nofSamples ; ++i)
	{
		Eigen::Vector2d p = positions[i];
		double w = weights[i];

		basis << 1, p, p.array().abs2(), p.prod();

		sumPot += w * basis.dot(vecU);
	}

	vecU[0] = -sumPot/sumOfWeights;

	basis << 1, src, src.array().abs2(), src.prod();

	double pot = basis.dot(vecU);
	Eigen::Vector2d proj = src + grad*pot;
}