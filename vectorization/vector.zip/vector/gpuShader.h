#ifndef GPUSHADER_H
#define GPUSHADER_H

#include "gpuDLL.h"
#include <glew.h>
#include <string>

namespace gpu {

  enum SHADER_TYPE {VERT,FRAG,GEOM};

  class GPU_API GPUShader {

  public: 
    
	  // bFile==true:  @strFile means the string name of the file
	  // bfile==false: @strFile means the string content of the file
    GPUShader(SHADER_TYPE type,const std::string &strFile,bool printLog=true, bool bFile=true);
    ~GPUShader();
    
    bool load();         
    bool compile();
    bool loadAndCompile();
    
    inline GLuint id() const;
    inline SHADER_TYPE type() const;
    inline std::string filename() const;

  protected:
    std::string _filename;
   
  private:
    SHADER_TYPE _type; 
    
    GLuint      _shaderId;
    bool        _printLog;
    
    GLsizei     _vnStrings;
    GLcharARB** _vStrings;
    GLint*      _vLengths;
    bool        _created;

    void cleanStrings();  
    bool createShader();
    void printInfoLog();
  };
  
  inline GLuint GPUShader::id() const {
    return _shaderId;
  }
  
  inline SHADER_TYPE GPUShader::type() const {
    return _type;
  }

  inline std::string GPUShader::filename() const {
    return _filename;
  }

} // gpu namespace

#endif // GPUSHADER
