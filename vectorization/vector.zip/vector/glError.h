#ifndef GLERROR_H
#define GLERROR_H

#include "gpuDLL.h"
#include <glew.h>
#include <string>
#include <stdlib.h>
namespace gpu {

    class GPU_API GLUtils{
    public:
        static bool glCheckErrors(const char* location, int line, std::ostream& ostr)
            {
                bool ok = true;
                GLuint errnum;
                const char *errstr;
                while ((errnum = glGetError())) {
                    ok = false;
                    if(location) ostr << "[ " << location << " " << line <<" ]";		
                    errstr = reinterpret_cast<const char *>(gluErrorString(errnum));
                    ostr << errstr;
                    ostr << errnum;
                    ostr << std::endl;
                }
/*                if(!ok){
                    int * i = (int *)10;
                    *i = 10;
                    }*/
                return ok;
            }

        static bool glCheckFrameBufferStatus(const char* location, int line, std::ostream& ostr)
            {
                const GLenum s = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
                bool ok=true;

                if(s!=GL_FRAMEBUFFER_COMPLETE_EXT)
                {
                    if(location) ostr << "[ " << location << " " << line << " ]";
                    switch(s) {	    
                    case GL_FRAMEBUFFER_COMPLETE_EXT:
                        break;
                    case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT :
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT"<<std::endl;
                        break;
                    case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
                        // Missing attachment
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT"<<std::endl;
                        break;
/*	case GL_FRAMEBUFFER_INCOMPLETE_DUPLICATE_ATTACHMENT_EXT:
// Duplicate attachment
ostr<<"GL_FRAMEBUFFER_INCOMPLETE_DUPLICATE_ATTACHMENT_EXT"<<std::endl;
break;*/
                    case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
                        // Incomplete dimensions
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT"<<std::endl;
                        break;
                    case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
                        // Incomplete formats
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT"<<std::endl;
                        break;
                    case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
                        // Incomplete draw buffer
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT"<<std::endl;
                        break;
                    case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
                        // Incomplete read buffer
                        ostr<<"GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT"<<std::endl;
                        break;
                    case GL_FRAMEBUFFER_UNSUPPORTED_EXT:
                        // Framebuffer unsupported
                        ostr<<"GL_FRAMEBUFFER_UNSUPPORTED_EXT"<<std::endl;
                        ok=false;
                        break;
                    }
                }	
//                if(!ok) exit(-1);
                return ok;
            }
    };
}

#define PRINT_ERROR_GL  gpu::GLUtils::glCheckErrors(__FILE__, __LINE__, std::cout)
#define PRINT_ERROR_FBO	gpu::GLUtils::glCheckFrameBufferStatus(__FILE__, __LINE__, std::cout)


#endif
