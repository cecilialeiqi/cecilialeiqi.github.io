#pragma once
#include "skeleton.h"
#include "vectorizationPaint.h"
#include <vectorizationWindow.h>
#include <fstream>

namespace skeleton{

void SkeletonGraph::drawOpenGL(float height, float offx, float offy)
{
	/// draw the skeleton graph using OpenGL functions
	if (m_vEdge.empty())
		return;

	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0,0.0,0.0);
	glLineWidth(1.0f);
	int sz1=m_vEdge.size();

	for(int i=0; i<sz1; i++)
	{
		glBegin(GL_LINE_STRIP);
		int sz2=m_vEdge[i].m_vPoint.size();
		for (int j=0;j<sz2;j++)
		{
			QPointF m_pos=m_vEdge[i].m_vPoint[j];
		    glVertex3f(m_pos.x()+offx, height-(m_pos.y()+offy), 0.001);
		}
		glEnd();
	}
	sz1=m_vVertex.size();
	glColor3f(0.0,1.0,0.0);
	glPointSize(5.0f);
	glBegin(GL_POINTS);
	for (int i=0;i<sz1;i++)
	{
		glVertex3f(m_vVertex[i].m_pos.x()+offx, height-(m_vVertex[i].m_pos.y()+offy), 0.002);
	}
	glEnd();
}

void SkeletonGraph::clear()
{
	m_vVertex.clear();
	
	for(int k=0; k<m_vEdge.size(); k++)
		m_vEdge[k].m_vPoint.clear();
	m_vEdge.clear();
	
	for(int k=0; k<m_vvEdge42vertex.size(); k++)
		m_vvEdge42vertex[k].clear();
	m_vvEdge42vertex.clear();

	for(int k=0; k<m_vvEdgeContinuity.size(); k++)
		m_vvEdgeContinuity[k].clear();
	m_vvEdgeContinuity.clear();

	m_vVertex42edge.clear();
}

QPoint getStartingPoint(const QImage &img)
{
	const int imin = 20;
	int yi = 0;
	int xmax = 0;
	for(yi=0; yi<img.height(); yi++)
	{
		int imax = 0;
		xmax = 0;
		for(int xi=0; xi<img.width(); xi++)
		{
			int itensity = qRed(img.pixel(xi,yi));
			if(itensity>imax)
			{
				imax = itensity;
				xmax = xi;
			}
		}
		if(imax>imin)
			break;
	}
	return QPoint(xmax,yi);
}

//void computeSkeletonGraph(SkeletonGraph &sktGraph)
//{
//}

} // mamespace