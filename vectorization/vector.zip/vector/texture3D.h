#ifndef TEXTURE_3D_H
#define TEXTURE_3D_H

#include <glew.h>
#include <gl.h>
#include <glu.h>

#include <string>
#include <image.h>
#include <imageio.h>

using namespace image;

namespace gpu {
  
  template<typename T = float> 
    class Texture3D {
  public:

  Texture3D(const TextureFormat &tf=TextureFormat(),
            const TextureParams &tp=TextureParams(),
            T* map=NULL,
            int id=-1);

  ~Texture3D();

  inline GLuint        id    () const;
  inline TextureFormat format() const;
  inline TextureParams params() const;
  inline void          bind  () const;

  protected:
  GLuint        _id;
  TextureFormat _format;
  TextureParams _params;
  };

  template<typename T>
    inline GLuint Texture3D<T>::id() const {
    return _id;
  }

  template<typename T>
    inline TextureFormat Texture3D<T>::format() const {
    return _format;
  }

  template<typename T>
    inline TextureParams Texture3D<T>::params() const {
    return _params;
  }

  template<typename T>
    inline void Texture3D<T>::bind() const {

    glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,_params.mode());
    glBindTexture(format.target(),_id);

  }

  template<typename T>
    Texture3D<T>::Texture3D(const TextureFormat &tf,const TextureParams &tp,T* map,int id)
    : _id(0),
      _format(tf),
      _params(tp)
     {

    assert(_format.target()==GL_TEXTURE_3D);

    if(id<0)
      glGenTextures(1,&_id);
    else _id = id;

    glBindTexture(_format.target(),_id);
    

    glTexImage3D(_format.target(),
		 _format.level(),
		 _format.internalformat(),
		 _format.width(),
		 _format.height(),
		 _format.depth(),
		 _format.border(),
		 _format.format(),
		 _format.type(),
		 (const GLvoid *)map);
  
    glTexParameteri(_format.target(),GL_TEXTURE_MIN_FILTER,_params.minfilter());
    glTexParameteri(_format.target(),GL_TEXTURE_MAG_FILTER,_params.maxfilter()); 
    glTexParameteri(_format.target(),GL_TEXTURE_WRAP_S,_params.wraps());
    glTexParameteri(_format.target(),GL_TEXTURE_WRAP_R,_params.wrapr());
    glTexParameteri(_format.target(),GL_TEXTURE_WRAP_T,_params.wrapt());

  }
  
  template<typename T>
    Texture3D<T>::~Texture3D() {	
    glDeleteTextures(1,&_id);
  }

  typedef Texture3D<float>         FloatTexture3D;
  typedef Texture3D<unsigned char> UbyteTexture3D;
  typedef Texture3D<unsigned int>  UintTexture3D;

} // gpu namespace 

#endif // TEXTURE_3D_H
