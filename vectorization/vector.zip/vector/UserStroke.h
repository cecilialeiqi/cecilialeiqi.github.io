#ifndef USER_STROKE_H
#define USER_STROKE_H

#include <vec2.h>
#include <vector>
#include <iostream>
#include <QPoint>

using namespace  math;
using namespace std;

class UserStroke
{
public:
	vector<QPoint>	m_vPos;
	vector<QPointF>  m_vTangent;
	int				m_index;
	bool			m_closeness;

public:
	UserStroke(int i=0, bool c=false):m_index(i),m_closeness(c){}
	void computeTangent()
	{
		int sz = m_vPos.size();
		m_vTangent.resize(sz);
		const int gap = 5;
		for(int k=0; k<sz; k++)
		{
			int k0 = max(k-gap,0);
			int k1 = min(sz-1,k+gap);
			QPointF dif = m_vPos[k1] - m_vPos[k0];
			float len = sqrtf(dif.x()*dif.x()+dif.y()*dif.y());
			m_vTangent[k] = len==0.0 ? QPointF(0.0,0.0) : dif/len;
		}
	}
	void clear()
	{
		m_vPos.clear();
		m_vTangent.clear();
		m_closeness = false;
	}
	void combine(const UserStroke &ust)
	{
		if(m_index!=ust.m_index)
			return;

		m_closeness = ust.m_closeness;
		m_vTangent.insert(m_vTangent.end(), ust.m_vTangent.begin(), ust.m_vTangent.end());
		m_vPos.insert(m_vPos.end(), ust.m_vPos.begin(), ust.m_vPos.end());
	}
};

#endif