#ifndef KEYFRAME_H
#define KEYFRAME_H

#include <vec2.h>
#include <vector>
#include <iostream>

using namespace  math;
using namespace std;

class Keyframe
{
public:

};


#endif // KEYFRAME_H