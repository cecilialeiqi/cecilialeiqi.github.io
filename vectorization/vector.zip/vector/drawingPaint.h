#pragma once

#include <glew.h>
#include <QtGui/QtGui>
#include <QGLWidget>
#include <gl.h>
#include <glu.h>

#include <framebufferObject.h>
#include <texture2D.h>
#include <gpuProgram.h>
#include <gpuShader.h>
#include "stroke.h"

using namespace gpu;

class ImagePaint : public QGLWidget {
	Q_OBJECT
		Q_PROPERTY(QImage image READ image WRITE setImage NOTIFY imageChanged(const QImage&)) 
		Q_PROPERTY(double zoom READ zoom WRITE setZoom NOTIFY zoomChanged(double)) 
		Q_PROPERTY(double resolution READ resolution WRITE setResolution NOTIFY resolutionChanged)
		Q_PROPERTY(double originX READ originX WRITE setOriginX NOTIFY originXChanged)
		Q_PROPERTY(double originY READ originY WRITE setOriginY NOTIFY originYChanged)
public:
	ImagePaint(QWidget *parent);
	~ImagePaint();

	virtual void restoreSettings(QSettings& settings);
	virtual void saveSettings(QSettings& settings);

	QSize imageSize() const { return image().size(); }
	const QImage& image() const { return m_images[m_index]; }
	QPointF origin() const { return m_moveOrigin; }
	double originX() const { return m_moveOrigin.x(); }
	double originY() const { return m_moveOrigin.y(); }
	double zoom() const { return m_zoom; }
	double resolution() const { return m_resolution; }
	double scale() const { return m_zoom * m_resolution; }

	virtual QPointF view2image(const QPointF& p) const;
	virtual QPointF image2zoom(const QPointF& p) const;
	virtual QPointF image2view(const QPointF& p) const;
	virtual QTransform viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const;
	virtual float pt2px(float pt) const;

	void setOverlay(QWidget *overlay);
	void setCurrentTool(int idx);

	public slots:
		void setImage(const QImage& image);
		void setOriginX(double value);
		void setOriginY(double value);
		void setZoom(double value);
		void setResolution(double value);
		void zoomIn();
		void zoomOut();
		void reset();
		void hold();
		void toggle();
		void copy();
		void savePNG(const QString& text=QString());

		void reloadShaders();
		void onIndexChanged(int);

signals:
		void imageChanged(const QImage&);
		void originXChanged(double);
		void originYChanged(double);
		void zoomChanged(double);
		void resolutionChanged(double);

public:
	void draw(QPainter& p, const QRectF& R, const QImage& image);
	void refresh() { update(); }

protected:
	virtual bool eventFilter( QObject *watched, QEvent *e );
	virtual void leaveEvent( QEvent *e );
	virtual void keyPressEvent( QKeyEvent *e );
	virtual void keyReleaseEvent( QKeyEvent *e );
	virtual void mousePressEvent( QMouseEvent *e );
	virtual void mouseMoveEvent( QMouseEvent *e );
	virtual void mouseReleaseEvent( QMouseEvent *e );
	virtual void wheelEvent(QWheelEvent *e);

	virtual void initializeGL();
	virtual void resizeGL(int w, int h);
	virtual void paintGL();

	inline void drawQuad(int width, int height, int xoff=0, int yoff=0);
	inline void drawQuadScreen(int width, int height, int xoff=0, int yoff=0);
	inline void swapToLocalMode(int w, int h);
	inline void swapToWorldMode();

protected:
	/// move tool
	QPointF m_moveOrigin;
	QPointF m_moveStart;
	QPointF m_moveOriginKeep;
	double m_zoom;

	/// zoom tool
	QPointF m_zoomOrigin;
	QPointF m_zoomOriginKeep;
	double m_resolution;	

	enum Mode { MODE_MOVE=0, MODE_ROTO };
	Mode m_mode;

	bool m_spacePressed;
	/// interaction
	int	m_toolMode;	
	QCursor m_cursor;
	Qt::MouseButton m_dragButton;	
	QPoint	m_currPosWnd;
	QPointF  m_currPosImg;

	/// image buffer
	int m_index;
	QImage m_images[2];
	bool	m_imgLoaded;
	QWidget *m_overlay;

	/// for sketching
	bool				m_bSketch;
	bool				m_bSketchRestart;
	vector<Stroke>		m_vStroke;
	Stroke				m_currStroke;
	bool				m_bHiddenProjection;
	bool				m_bHiddenStroke;

	/// size
	QSize	m_wndSize;
	QSize	m_imgSize;

	enum    TOOLTYPE {TOOL_CONTOUR=0, TOOL_INTEROIR};
	int		m_toolType;

	int		m_diffSize;
	int		m_strokeSize;

	int		m_streamLen;
	double	m_streamThre;

public:
	void	setToolType(int val) { m_toolType=val;}
	int*	diffSizePtr() {return &m_diffSize; }
	int*	strokeSizePtr() {return &m_strokeSize; }

	int*	streamLenPtr() {return &m_streamLen; }
	double* streamThrePtr()  {return &m_streamThre; }
	

	////////////////////////////////////////// GPU
private:
	enum {FBO1=0, FBO2};

	enum {T_ORG=0,	T_GRAD1, T_GRAD2, T_NOISE, T_MLS_P1, 
		T_MLS_P2, T_MLS_P3, T_MLS_P4, T_MLS, T_CURV, 
		T_STROKE, T_MLS_S, T_CURV_S, T_PROJ, T_CANVAS, 
		T_FIN};
	
	enum {P_GRAD=0, P_MLS_P, P_MLS, P_PROJ, P_FIN};

	static const int NB_FBO = 2;
	static const int NB_TEX = 16;
	static const int NB_PROG = 5;

	FramebufferObject	  *_fbo[NB_FBO];
	GPUProgram            *_prog[NB_PROG];
	FloatTexture2D        *_tex[NB_TEX];

private:
	void initGPU();
	void finalizeGPU();
	
	void initFBO();
	void cleanFBO();

	void initShaders();
	void setShaderParameters();
	void cleanShaders();

	void loadTexture(int tex_id, const QImage &qimg);
	void setTextureDefault(int tex_id, float val);
	void initNoiseTex(int tex_id, const QSize &imgSize);

private:
//	void drawLocalGradient(const QPointF &curpos, bool bFlip = false);
//	void drawStreamLine(const QPointF &curpos, int len, bool bFilp = false);
	bool getStreamLine(const QPointF &curpos, Stroke &stok);

	void readSketch2Texture(const vector<Stroke> &vs, int tex_id);
	void readProjection(int tex_id, vector<Stroke> &vs);
};

inline void ImagePaint::drawQuad(int width, int height, int xoff/* =0 */, int yoff/* =0 */)
{
	glBegin(GL_QUADS);
	glTexCoord2i(0,0);  glVertex2i(xoff, yoff);
	glTexCoord2i(1,0);  glVertex2i(width+xoff, yoff);
	glTexCoord2i(1,1);  glVertex2i(width+xoff, height+yoff);
	glTexCoord2i(0,1);  glVertex2i(xoff, height+yoff);
	glEnd();
}

inline void ImagePaint::drawQuadScreen(int width, int height, int xoff/* =0 */, int yoff/* =0 */)
{
	glBegin(GL_QUADS);
	glTexCoord2i(0,1);  glVertex2i(xoff, yoff);
	glTexCoord2i(1,1);  glVertex2i(width+xoff, yoff);
	glTexCoord2i(1,0);  glVertex2i(width+xoff, height+yoff);
	glTexCoord2i(0,0);  glVertex2i(xoff, height+yoff);
	glEnd();
}

inline void ImagePaint::swapToLocalMode(int w, int h)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0,w,0,h,-1,1);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glViewport(0,0,w,h);
	glLoadIdentity();
}

inline void ImagePaint::swapToWorldMode()
{
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}
