#pragma once
#include <vector>
using namespace std;

enum
{
	GSM_BACK=0x01,
	GSM_FORE=0x02,
	GSM_ALL =GSM_BACK|GSM_FORE
};

const int _DIST_MEAN=128;

typedef  unsigned int uint;
typedef  unsigned char uchar;
typedef  unsigned short ushort;

class GeoSegN24
{
public:
	class  WorkPixel;

private:
	WorkPixel  *m_wpx;
	uint       *m_dist;
	int         m_width, m_height, m_stride;
public:
	GeoSegN24();

	~GeoSegN24();

	int SetImage(const uchar *img, int width, int height, int istep, int icn, bool bGeodesic=true);

	int GetProb(const uchar *mask, int mstep, float *prob, int stride, int method, uchar mv);

};


class GeoSegN24::WorkPixel
{
public:
	ushort nbrw[24];
};
