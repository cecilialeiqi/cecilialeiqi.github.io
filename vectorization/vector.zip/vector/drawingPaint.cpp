#include "drawingPaint.h"
#include <drawingWindow.h>
#include "streamline.h"

ImagePaint::ImagePaint(QWidget *parent) : QGLWidget(parent) {
	m_spacePressed = false;
	m_mode = MODE_MOVE;
	m_toolMode = E_MOVE;
	m_index = 0;
	m_toolMode = 0;
	m_overlay = 0;
	m_zoom = m_resolution = 1;
	m_wndSize = QSize(0,0);
	m_imgLoaded = false;
	m_moveOriginKeep = QPointF(0.0,0.0);
	m_zoomOriginKeep = QPointF(0.0,0.0);

	m_toolType = TOOL_CONTOUR;

	m_bSketch = false;
	m_bSketchRestart = false;
	m_bHiddenProjection = true;
	m_bHiddenStroke = true;

	setAutoFillBackground(true);
	QPalette p = palette();
	p.setBrush(QPalette::Base, p.mid());
	setPalette(p);
	setCursor(Qt::OpenHandCursor);

	qApp->installEventFilter(this);
}


ImagePaint::~ImagePaint() {
}


void ImagePaint::restoreSettings(QSettings& settings) {
	setZoom(settings.value("zoom", 1.0).toDouble());
	setResolution(settings.value("resolution", 1.0).toDouble());
	setOriginX(settings.value("originX", 0).toDouble());
	setOriginY(settings.value("originY", 0).toDouble());
}


void ImagePaint::saveSettings(QSettings& settings) {
	settings.setValue("zoom", m_zoom);
	settings.setValue("resolution", m_resolution);
	settings.setValue("originX", m_moveOrigin.x());
	settings.setValue("originY", m_moveOrigin.y());
}


QPointF ImagePaint::view2image(const QPointF& p) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	QPointF res = QPointF(
		(p.x() - m_moveOrigin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
		(p.y() - m_moveOrigin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	return res;
}

QPointF ImagePaint::image2zoom(const QPointF& p) const {
	return p;
	//QSize sz = size();
	//float z = m_zoom /** m_resolution*/;
	//QPointF res = QPointF(
	//	(p.x() - m_origin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
	//	(p.y() - m_origin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	//return res;
}

QPointF ImagePaint::image2view(const QPointF& q) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	return QPointF(
		(q.x() - m_imgSize.width() / 2) * z + m_moveOrigin.x() * z + sz.width() / 2,
		(q.y() - m_imgSize.height() / 2) * z + m_moveOrigin.y() * z + sz.height() / 2 );
}

QTransform ImagePaint::viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const {
	QTransform tr;
	tr.translate(sz.width()/2.0f, sz.height()/2.0f);
	tr.translate(origin.x() * zoom, origin.y() * zoom);
	tr.scale(zoom, zoom);
	tr.translate(-imageSize().width()/2.0f, -imageSize().height()/2.0f);
	return tr;
}

float ImagePaint::pt2px(float pt) const {
	return pt / (m_zoom /** m_resolution*/);
}

void ImagePaint::setOverlay(QWidget *overlay) {
	if (overlay) {
		setMouseTracking(true);
		m_overlay = overlay;
		m_overlay->setVisible(false);
	} else {
		setMouseTracking(false);
		if (m_overlay) m_overlay->setVisible(false);
		m_overlay = 0;
	}
}

void ImagePaint::onIndexChanged(int idx)
{
	m_index = idx;
	update();
}

void ImagePaint::setImage(const QImage& image) {
	m_images[0] = image;
	imageChanged(m_images[0]);
	m_imgSize = image.size();
	if(!m_imgLoaded)
		initGPU();
	m_imgLoaded = true;
	cleanFBO();
	initFBO();
	update();
}

void ImagePaint::setOriginX(double value) {
	double x = value;
	if (m_moveOrigin.x() != x) {
		m_moveOrigin.setX(x);
		originXChanged(x);
		update();
	}
}

void ImagePaint::setOriginY(double value) {
	double y = value;
	if (m_moveOrigin.y() != y) {
		m_moveOrigin.setY(y);
		originYChanged(y);
		update();
	}
}

void ImagePaint::setZoom(double value) {
	if (value != m_zoom) {
		m_zoom = value;
		zoomChanged(m_zoom);
		update();
	}
}

void ImagePaint::setResolution(double value) {
	if (value != m_resolution) {
		m_resolution = value;
		resolutionChanged(m_resolution);
		update();
	}
}

void ImagePaint::zoomIn() {
	setZoom(m_zoom * 2);
}

void ImagePaint::zoomOut() {
	setZoom(m_zoom / 2);
}

void ImagePaint::reset() {
	m_zoom = 1.0;
	m_resolution = 1.0;
	m_moveOrigin = QPoint(0, 0);
	m_zoomOrigin = QPoint(0, 0);
	m_moveOriginKeep = QPoint(0, 0);
	m_zoomOriginKeep = QPoint(0, 0);
	zoomChanged(1);
	resolutionChanged(1);
	originXChanged(0);
	originYChanged(0);
	update();
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
	MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
	MainWindow::getInstance()->setStatusResolution(QString("| Resl: %1%").arg(m_resolution*100.0));
}

void ImagePaint::hold() {
	m_images[1] = m_images[0];
	update();
}

void ImagePaint::toggle() {
	m_index = 1 - m_index;
	QString title = window()->windowTitle().replace(" -- hold", "");
	if (m_index)
		title += " -- hold";
	window()->setWindowTitle(title);
	update();
} 

void ImagePaint::copy() {
	QClipboard *clipboard = QApplication::clipboard();
	clipboard->setImage(image());
}

void ImagePaint::savePNG(const QString& text) {
	QSettings settings;
	QString inputPath = window()->windowFilePath();
	QString outputPath = settings.value("savename", inputPath).toString();

	QString filename;
	QFileInfo fi(inputPath);
	QFileInfo fo(outputPath);
	if (!fi.baseName().isEmpty()) {
		QFileInfo fn(fo.dir(), fi.baseName() + "-out.png");
		filename  = fn.absoluteFilePath();
	} else {
		filename  = fo.absolutePath();
	}

	filename = QFileDialog::getSaveFileName(this, "Save PNG", filename, 
		"PNG Format (*.png);;All files (*.*)");
	if (!filename.isEmpty()) {
		//QImage tmp(image());
		_tex[T_FIN]->bind();
		unsigned char *pData = new unsigned char[m_imgSize.width()*m_imgSize.height()*3];
		glGetTexImage(GL_TEXTURE_2D,0,GL_RGB,GL_UNSIGNED_BYTE,pData);
		QImage tmp = QImage(pData, m_imgSize.width(), m_imgSize.height(), QImage::Format_RGB888);

		if (!text.isEmpty()) tmp.setText("Description", text);
		if (!tmp.save(filename)) {
			QMessageBox::critical(this, "Error", QString("Saving PNG '%1' failed!").arg(filename));
			return;
		}
		settings.setValue("savename", filename);
	}
}

bool ImagePaint::eventFilter( QObject *watched, QEvent *e ) {
	if (!hasFocus() && (m_mode == MODE_MOVE) && (e->type() == QEvent::KeyPress)) {
		QKeyEvent *k = (QKeyEvent*)e;
		if (k->key() == Qt::Key_Space) {
			QPoint gp = mapFromGlobal(QCursor::pos());
			if (rect().contains(gp)) {
				setFocus(Qt::OtherFocusReason);
				keyPressEvent(k);
				return true;
			}
		}
	}
	return QWidget::eventFilter(watched, e);
}


void ImagePaint::leaveEvent( QEvent *e ) {
	//if (m_spacePressed) {
	//	setCursor(m_cursor);
	//	m_cursor = QCursor();
	//	m_spacePressed = false;
	//}
	//if (m_overlay) {
	//	m_overlay->setVisible(false);
	//}
	QWidget::leaveEvent(e);
}

void ImagePaint::setCurrentTool(int idx) {
	m_toolMode = idx;
	switch (idx)
	{
	case E_MOVE:
		setCursor(Qt::OpenHandCursor);
		break;
	case E_ROTO:
		setCursor(Qt::ArrowCursor);
		break;
	default:
		setCursor(Qt::ArrowCursor);
	}
}

void ImagePaint::keyPressEvent( QKeyEvent *e ) {
	//if ((m_mode == MODE_MOVE) && (e->key() == Qt::Key_Space)) {
	//	if (!m_spacePressed) {
	//		if (m_overlay && m_overlay->isVisible()) m_overlay->setVisible(false);
	//		m_cursor = cursor();
	//		setCursor(Qt::OpenHandCursor);
	//		m_spacePressed = true;
	//	}
	//} else 
	{
		if(e->key()==Qt::Key_D)
		{
			if(!m_vStroke.empty())
				m_vStroke.pop_back();
		}
		else if(e->key()==Qt::Key_H )
		{
			m_bHiddenProjection = !m_bHiddenProjection;
		}
		else if(e->key()==Qt::Key_J )
		{
			m_bHiddenStroke = !m_bHiddenStroke;
		}
		else if(e->key()==Qt::Key_A )
		{
			/// erase the canvas
			setTextureDefault(T_CANVAS,1.0);
			/// remove all strokes
			for(unsigned int i=0; i<m_vStroke.size(); i++)
				m_vStroke[i]._vBrush.clear();
			m_vStroke.clear();
		}
		else if(e->key()==Qt::Key_Space)
		{
			for(unsigned int i=0; i<m_vStroke.size(); i++)
				m_vStroke[i].setValid(false);
			/// reapint to remove the gray lines from canvas
			update();

			/// copy canvas
			int cn =4;
			const GLenum format1 = GL_RGBA;
			float *fdata = new float[m_imgSize.width()*m_imgSize.height()*cn];
			////////////////////////////////// preserve the previous result
			/// copy from texture buffer	
			_tex[T_PROJ]->bind();	
			glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata);
			/// set to texture buffer
			_tex[T_CANVAS]->bind();
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
				GL_RGBA, GL_FLOAT, fdata);
			/// delete memory
			delete []fdata;

			/// remove all strokes
			for(unsigned int i=0; i<m_vStroke.size(); i++)
				//_vStroke[i].setValid(false);
				m_vStroke[i]._vBrush.clear();
			m_vStroke.clear();
		}
		update();
		QWidget::keyPressEvent(e);
	}
}


void ImagePaint::keyReleaseEvent( QKeyEvent *e ) {
	if (e->key() == Qt::Key_Space) {
		if (!e->isAutoRepeat()) {
			if (m_mode == MODE_MOVE) {
				setCursor(m_cursor);
				m_cursor = QCursor();
			}
			m_spacePressed = false;
		}
	} else {
		QWidget::keyReleaseEvent(e);
	}
}

bool ImagePaint::getStreamLine(const QPointF &curpos, Stroke &stok)
{
	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return false;

	/// get texture data
	int cn =4;
	_tex[T_MLS]->bind();
	float *pFlow = new float[m_imgSize.width()*m_imgSize.height()*cn];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pFlow);

	_tex[T_CURV]->bind();
	float *pCurv = new float[m_imgSize.width()*m_imgSize.height()*cn];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pCurv);

	/// get stream line
	vector<Pot3f> pnt = streamline(int(m_currPosImg.x()), int(m_currPosImg.y()), 
		m_imgSize.width(), m_imgSize.height(), 4, 
		pFlow, pCurv, 1, float(m_streamThre), 0.0, m_streamLen);
	delete [] pFlow;
	delete [] pCurv;

	if(pnt.empty())
		return false;

	stok._vBrush.clear();
	const int sz1 = int(pnt[pnt.size()-1].x);
	const int sz2 = int(pnt[pnt.size()-1].y);

	for(int i=0; i<sz1; i++)
		stok._vBrush.push_back(Brush(pnt[sz1-1-i].x, pnt[sz1-1-i].y));

	for(int i=sz1; i<sz1+sz2; i++)
		stok._vBrush.push_back(Brush(pnt[i].x, pnt[i].y));

	return true;
}

void ImagePaint::mousePressEvent( QMouseEvent *e ) {
	m_dragButton = e->button();
	if(m_toolMode == E_MOVE )
	{
		if(m_dragButton == Qt::LeftButton || m_dragButton == Qt::RightButton)
		{
			setCursor(Qt::ClosedHandCursor);
			m_moveStart =  e->pos();
			update();
		}
	}
	else if(m_toolMode == E_ZOOM )
	{
		if(m_dragButton == Qt::LeftButton || m_dragButton == Qt::RightButton)
		{
			setCursor(Qt::ClosedHandCursor);
			m_moveStart = e->pos();
			update();
		}
	}
	else if(m_toolMode == E_ROTO && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		getStreamLine(m_currPosImg,m_currStroke);
		update();
	}
	else if(m_toolMode == E_FREE && m_dragButton == Qt::LeftButton)
	{
		if(m_toolType==TOOL_CONTOUR)
		{
			m_currPosWnd = e->pos();
			m_currPosImg = view2image(m_currPosWnd);
			m_currStroke._vBrush.clear();
		}
		else if(m_toolType==TOOL_INTEROIR)
		{
		}
	}
}


void ImagePaint::mouseMoveEvent( QMouseEvent *e ) {
	if(m_toolMode == E_MOVE )
	{
		if(m_dragButton == Qt::LeftButton)
		{
			m_moveOrigin = m_moveOriginKeep + QPointF(e->pos() - m_moveStart) / m_zoom;
			originXChanged(m_moveOrigin.x());
			originYChanged(m_moveOrigin.y());
			update();
		}
		else if(m_dragButton == Qt::RightButton)
		{
			double u = double(e->pos().y()-m_moveStart.y())/double(m_wndSize.height());
			setZoom(m_zoom * (1 + u));
			m_moveStart = e->pos();
		}
	}
	else if(m_toolMode == E_ZOOM )
	{
		if(m_dragButton==Qt::LeftButton)
		{
			m_zoomOrigin = m_zoomOriginKeep + QPointF(e->pos() - m_moveStart) / (m_resolution*m_zoom);
			update();
		}
		else if(e->pos().y()!=m_moveStart.y() && m_dragButton == Qt::RightButton)
		{
			double u = double(e->pos().y()-m_moveStart.y())/double(m_imgSize.height());
			setResolution(m_resolution * (1 + u));
			m_moveStart = e->pos();
		}
	}
	else if(m_toolMode == E_ROTO && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		getStreamLine(m_currPosImg,m_currStroke);
		update();
	}
	else if(m_toolMode == E_FREE && m_dragButton == Qt::LeftButton)
	{
		if(m_toolType==TOOL_CONTOUR)
		{
			m_currPosWnd = e->pos();
			m_currPosImg = view2image(m_currPosWnd);
			if( QRectF(0.0,0.0,double(m_imgSize.width()),double(m_imgSize.height())).contains(m_currPosImg) )
			{
				Vec2f curPos = Vec2f(m_currPosImg.x(), m_currPosImg.y());
				if(m_currStroke._vBrush.empty())
					m_currStroke._vBrush.push_back(Brush(float(curPos.x()),float(curPos.y())));
				else
				{
					Vec2f prevPos = Vec2f(m_currStroke._vBrush[m_currStroke._vBrush.size()-1]._x, 
						m_currStroke._vBrush[m_currStroke._vBrush.size()-1]._y);
					float diffx = (prevPos.x()-curPos.x());
					float diffy = (prevPos.y()-curPos.y());
					if( abs(diffx) < abs(diffy) )
					{
						float pro = diffx/diffy;
						float walky = prevPos.y();
						while (true)
						{
							if(curPos.y()>prevPos.y()) 
							{
								if(walky>=curPos.y())
									break;
								walky += 1.0 ;
							}
							else
							{
								if(walky<=curPos.y())
									break;
								walky -= 1.0;
							}
							m_currStroke._vBrush.push_back(Brush(pro*(walky-prevPos.y())+prevPos.x(),walky));
						}
					}
					else
					{
						float pro = diffy/diffx;
						float walkx = prevPos.x();
						while (true)
						{
							if(curPos.x()>prevPos.x()) 
							{
								if(walkx>=curPos.x())
									break;
								walkx += 1.0 ;
							}
							else
							{
								if(walkx<=curPos.x())
									break;
								walkx -= 1.0;
							}
							m_currStroke._vBrush.push_back(Brush(walkx,pro*(walkx-prevPos.x())+prevPos.y()));
						}
					}
				}
			}
		}
		else if(m_toolType==TOOL_INTEROIR)
		{
		}
		update();
	}
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
}


void ImagePaint::mouseReleaseEvent( QMouseEvent *e ) {
	if(m_toolMode == E_MOVE)
	{
		setCursor(Qt::OpenHandCursor);
		m_moveOriginKeep = m_moveOrigin;
	}
	else if(m_toolMode == E_ZOOM)
	{
		setCursor(Qt::OpenHandCursor);
		m_zoomOriginKeep = m_zoomOrigin;
	}
	else if((m_toolMode == E_ROTO || m_toolMode == E_FREE) && m_dragButton == Qt::LeftButton)
	{
		if(m_toolType==TOOL_CONTOUR)
		{
			Stroke tmp;  /// remove the first and last point
			int bsz = m_currStroke._vBrush.size()-2;
			if(bsz>0)
			{
				tmp._vBrush.resize(bsz);
				for(int i=0; i<bsz; i++)
					tmp._vBrush[i] = m_currStroke._vBrush[i+1];

				tmp.computeNormal();
				m_vStroke.push_back(tmp);
				m_currStroke._vBrush.clear();
			}
		}
		else if(m_toolType==TOOL_INTEROIR)
		{
		}
		update();
	}
	/// reset mouse button
	m_dragButton = Qt::NoButton; 
}

void ImagePaint::wheelEvent(QWheelEvent *e) {
	QSize sz = size();
	double u = e->delta() / 120.0 / 4.0;
	if (u < -0.5) u = -0.5;
	if (u > 0.5) u = 0.5;

	if(m_toolMode == E_MOVE)
	{
		setZoom(m_zoom * (1 + u));
		MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
	}
	else if(m_toolMode == E_ZOOM)
	{
		setResolution(m_resolution * (1 + u));
		MainWindow::getInstance()->setStatusResolution(QString("| Resl: %1%").arg(m_resolution*100.0));
	}
}

void ImagePaint::draw(QPainter& p, const QRectF& R, const QImage& image) {
	QRect aR = R.toAlignedRect();
	p.drawImage(aR.x(), aR.y(), image.copy(aR));
}
//////////////////////////////////////////////////////////////////////////// opengl
void ImagePaint::initGPU() {
	finalizeGPU();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_LIGHTING);

	initFBO();
	initShaders();
}
void ImagePaint::finalizeGPU() {
	cleanFBO();
	cleanShaders();
	//glPopAttrib();
}

void ImagePaint::cleanFBO() {
	for(int i=0; i<NB_FBO; i++)
	{
		delete _fbo[i];
		_fbo[i] = NULL;
	}
	for(int i=0;i<NB_TEX;++i) 
	{
		delete _tex[i];
		_tex[i] = NULL;
	}
}

void ImagePaint::cleanShaders() {
	for(int i=0;i<NB_PROG;++i) 
	{
		if(_prog[i]!=NULL) 
		{
			delete _prog[i];
			_prog[i] = NULL;
		}
	}
}
void ImagePaint::reloadShaders() {
	if(_prog[0]!=NULL)
	{
		for(int i=0; i<NB_PROG; i++)
			_prog[i]->reload();
		setShaderParameters();
		update();
		std::cout<< "Shaders have been successfully reloaded!" << std::endl;
	}
}

void ImagePaint::initializeGL() {
	/// glew initialization
	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
		fprintf(stderr, "Error: %s\n",glewGetErrorString(err));

	/// GPU initialization
	for(int i=0; i<NB_FBO; i++)
		_fbo[i] = NULL;
	for(int i=0; i<NB_TEX; i++)
		_tex[i] = NULL;
	for(int i=0; i<NB_PROG; i++)
		_prog[i] = NULL;

	if(m_imgLoaded)
		initGPU();

	/// opengl initialization
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);

	QColor bc = palette().color(QPalette::Base);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void ImagePaint::loadTexture(int tex_id, const QImage &qimg)
{
	_tex[tex_id]->bind();
	if(qimg.format()!=QImage::Format_RGB32)
		qimg.convertToFormat(QImage::Format_RGB32);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, qimg.width(), qimg.height(), 0,
		GL_BGRA, GL_UNSIGNED_BYTE, qimg.bits());
}
void ImagePaint::initNoiseTex(int tex_id, const QSize &imgSize)
{
	int num = imgSize.width()*imgSize.height()*4;
	float *pNoise = new float[num];
	int maxsc = 3000;
	for (int i=0; i<num; i++)
	{		
		pNoise[i] = float((rand()%maxsc))/float(maxsc-1);
	}
	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,imgSize.width(),imgSize.height(),
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_LINEAR,GL_LINEAR),pNoise);
	delete []pNoise;
}
void ImagePaint::setTextureDefault(int tex_id, float val)
{
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*4];
	for(int i=0; i<m_imgSize.width()*m_imgSize.height()*4; i++)
		pData[i] = val;
	_tex[tex_id]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
		GL_BGRA, GL_FLOAT, pData);
	delete []pData;
}
void ImagePaint::initFBO() {
	if(_fbo[FBO1]==NULL)
	{
		for(int i=0; i<NB_FBO; i++)
			_fbo[i] = new FramebufferObject();

		_tex[T_ORG	] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(),m_imgSize.height(),
			GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT), TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_GRAD1] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_GRAD2] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_MLS_P1	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P2	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P3	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_P4	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));

		_tex[T_MLS		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CURV		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_STROKE	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_MLS_S	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CURV_S	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_PROJ		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_CANVAS	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_NEAREST));
		_tex[T_FIN		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
	}

	/// load image to gpu texture	
	loadTexture(T_ORG,m_images[0]);

	setTextureDefault(T_CANVAS, 1.0);

	initNoiseTex(T_NOISE,m_imgSize);

	/// bind to fbo attachment
	_fbo[FBO1]->bind();
	_fbo[FBO1]->unattachAll();
	{
		_tex[T_GRAD1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRAD1]->format().target(),_tex[T_GRAD1]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_GRAD2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRAD2]->format().target(),_tex[T_GRAD2]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_MLS_P1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P1]->format().target(),_tex[T_MLS_P1]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_MLS_P2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P2]->format().target(),_tex[T_MLS_P2]->id(),GL_COLOR_ATTACHMENT3_EXT);

		_tex[T_MLS_P3]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P3]->format().target(),_tex[T_MLS_P3]->id(),GL_COLOR_ATTACHMENT4_EXT);

		_tex[T_MLS_P4]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS_P4]->format().target(),_tex[T_MLS_P4]->id(),GL_COLOR_ATTACHMENT5_EXT);

		_tex[T_MLS]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_MLS]->format().target(),_tex[T_MLS]->id(),GL_COLOR_ATTACHMENT6_EXT);

		_tex[T_CURV]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_CURV]->format().target(),_tex[T_CURV]->id(),GL_COLOR_ATTACHMENT7_EXT);
	}
	_fbo[FBO1]->isValid();

	_fbo[FBO2]->bind();
	_fbo[FBO2]->unattachAll();
	{
		_tex[T_MLS_S]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_MLS_S]->format().target(),_tex[T_MLS_S]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_CURV_S]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_CURV_S]->format().target(),_tex[T_CURV_S]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_PROJ]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_PROJ]->format().target(),_tex[T_PROJ]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_FIN]->bind();
		_fbo[FBO2]->attachTexture(_tex[T_FIN]->format().target(),_tex[T_FIN]->id(),GL_COLOR_ATTACHMENT3_EXT);
	}
	_fbo[FBO2]->isValid();

	FramebufferObject::unbind();
}
void ImagePaint::readSketch2Texture(const vector<Stroke> &vs, int tex_id)
{
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*4];
	memset(pData,0,m_imgSize.width()*m_imgSize.height()*4*sizeof(float));

	/// read sketch data
	for(unsigned int k=0; k<vs.size(); k++)
	{
		float age = float(k+1)/float(vs.size());
		if(vs[k]._valid)
		{
			for(unsigned int i=0; i<vs[k]._vBrush.size(); i++)
			{
				Brush br = vs[k]._vBrush[i];
				Vec2f ximg = Vec2f( br._x, br._y );
				if(ximg[0]>=0.0 && ximg[0]<float(m_imgSize.width()) 
					&& ximg[1]>=0.0 && ximg[1]<float(m_imgSize.height()) )
				{
					float * pD = pData + (int(ximg[1])*m_imgSize.width() + int(ximg[0]))*4;
					pD[0] = br._gx;
					pD[1] = br._gy;
					pD[2] = age;
					pD[3] = age;
				}
			}
		}
	}

	_tex[tex_id]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
		GL_RGBA, GL_FLOAT, pData);
	delete []pData;
}
void ImagePaint::readProjection(int tex_id, vector<Stroke> &vs)
{
	int cn =4;
	const GLenum format1 = GL_RGBA;
	_tex[tex_id]->bind();
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*cn];
	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,pData);

	/// read sketch data
	for(unsigned int k=0; k<vs.size(); k++)
	{
		//		float age = float(k+1)/float(vs.size());
		if(vs[k]._valid)
		{
			for(unsigned int i=0; i<vs[k]._vBrush.size(); i++)
			{
				Brush *br = &(vs[k]._vBrush[i]);
				Vec2f ximg = Vec2f( br->_x, br->_y );
				//if(ximg[0]>=0.0 && ximg[0]<float(_imageWidth) 
				//	&& ximg[1]>=0.0 && ximg[1]<float(_imageHeight) )
				{
					float * pD = pData + (int(ximg[1])*m_imgSize.width() + int(ximg[0]))*4;
					br->_rad = pD[1];
					br->_px = pD[2];
					br->_py = pD[3];
				}
			}
		}
	}

	_tex[tex_id]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
		GL_RGBA, GL_FLOAT, pData);
	delete []pData;
}
//void ImagePaint::drawStreamLine(const QPointF &curpos, int len, bool bFlip)
//{
//	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
//		return;
//
//	/// get texture data
//	int cn =4;
//	_tex[T_MLS]->bind();
//	float *pFlow = new float[m_imgSize.width()*m_imgSize.height()*cn];
//	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pFlow);
//
//	_tex[T_CURV]->bind();
//	float *pCurv = new float[m_imgSize.width()*m_imgSize.height()*cn];
//	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pCurv);
//
//	/// get stream line
//	vector<Pot3f> pnt = streamline(int(m_currPosImg.x()), int(m_currPosImg.y()), 
//		m_imgSize.width(), m_imgSize.height(), 4, 
//		pFlow, pCurv, 1, float(m_streamThre), 0.0, m_streamLen);
//	delete [] pFlow;
//	delete [] pCurv;
//
//	float fp = bFlip ? -1.0f : 1.0f;
//
//	if(!pnt.empty())
//	{
//		const int sz1 = int(pnt[pnt.size()-1].x);
//		const int sz2 = int(pnt[pnt.size()-1].y);
//
//		/// draw stream line
//		glDisable(GL_TEXTURE_2D);
//		glColor3f(1,0,0);
//		glBegin(GL_LINE_STRIP);
//		for(int i=0; i<sz1; i++)
//			glVertex3f(pnt[sz1-1-i].x-m_currPosImg.x()+curpos.x(), (pnt[sz1-1-i].y-m_currPosImg.y())*fp+curpos.y(), 0.001);
//		glEnd();
//
//		glBegin(GL_LINE_STRIP);
//		for(int i=sz1; i<sz1+sz2; i++)
//			glVertex3f(pnt[i].x-m_currPosImg.x()+curpos.x(), (pnt[i].y-m_currPosImg.y())*fp+curpos.y(), 0.001);
//		glEnd();
//		glColor3f(1,1,1);
//	}
//}

void ImagePaint::setShaderParameters() {
	_prog[P_GRAD]->enable();
	_prog[P_GRAD]->addUniform("wh");
	_prog[P_GRAD]->addUniform("txOrg");
	_prog[P_GRAD]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_GRAD]->disable();

	_prog[P_MLS_P]->enable();
	_prog[P_MLS_P]->addUniform("wh");
	_prog[P_MLS_P]->addUniform("bSketch");
	_prog[P_MLS_P]->addUniform("strokeSize");
	_prog[P_MLS_P]->addUniform("diffSize");
	_prog[P_MLS_P]->addUniform("zoomWnd");
	_prog[P_MLS_P]->addUniform("txOrg");
	_prog[P_MLS_P]->addUniform("txDert01");
	_prog[P_MLS_P]->addUniform("txDert02");
	_prog[P_MLS_P]->addUniform("txStroke");
	_prog[P_MLS_P]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_MLS_P]->setUniformTexture("txDert01",	1,GL_TEXTURE_2D,_tex[T_GRAD1]->id());
	_prog[P_MLS_P]->setUniformTexture("txDert02",	2,GL_TEXTURE_2D,_tex[T_GRAD2]->id());
	_prog[P_MLS_P]->setUniformTexture("txStroke",	3,GL_TEXTURE_2D,_tex[T_STROKE]->id());
	_prog[P_MLS_P]->disable();

	_prog[P_MLS]->enable();
	_prog[P_MLS]->addUniform("wh");
	_prog[P_MLS]->addUniform("bSketch");
	_prog[P_MLS]->addUniform("strokeSize");
	_prog[P_MLS]->addUniform("diffSize");
	_prog[P_MLS]->addUniform("zoomWnd");
	_prog[P_MLS]->addUniform("txOrg");
	_prog[P_MLS]->addUniform("txDert01");
	_prog[P_MLS]->addUniform("txDert02");
	_prog[P_MLS]->addUniform("txMLSP1");
	_prog[P_MLS]->addUniform("txMLSP2");
	_prog[P_MLS]->addUniform("txMLSP3");
	_prog[P_MLS]->addUniform("txMLSP4");
	_prog[P_MLS]->addUniform("txStroke");
	_prog[P_MLS]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_MLS]->setUniformTexture("txDert01",	1,GL_TEXTURE_2D,_tex[T_GRAD1]->id());
	_prog[P_MLS]->setUniformTexture("txDert02",	2,GL_TEXTURE_2D,_tex[T_GRAD2]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP1",	3,GL_TEXTURE_2D,_tex[T_MLS_P1]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP2",	4,GL_TEXTURE_2D,_tex[T_MLS_P2]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP3",	5,GL_TEXTURE_2D,_tex[T_MLS_P3]->id());
	_prog[P_MLS]->setUniformTexture("txMLSP4",	6,GL_TEXTURE_2D,_tex[T_MLS_P4]->id());
	_prog[P_MLS]->setUniformTexture("txStroke",	7,GL_TEXTURE_2D,_tex[T_STROKE]->id());
	_prog[P_MLS]->disable();

	_prog[P_PROJ]->enable();
	_prog[P_PROJ]->addUniform("txCanvas");
	_prog[P_PROJ]->setUniformTexture("txCanvas",	0,GL_TEXTURE_2D,_tex[T_CANVAS]->id()	);
	_prog[P_PROJ]->disable();

	_prog[P_FIN]->enable();
	_prog[P_FIN]->addUniform("wh");
	_prog[P_FIN]->addUniform("display");
	_prog[P_FIN]->addUniform("zoomWnd");
	_prog[P_FIN]->addUniform("txOrg");
	_prog[P_FIN]->addUniform("txDert01");
	_prog[P_FIN]->addUniform("txDert02");
	_prog[P_FIN]->addUniform("txFlow");
	_prog[P_FIN]->addUniform("txCurv");
	_prog[P_FIN]->addUniform("txStroke");
	_prog[P_FIN]->addUniform("txFlowS");
	_prog[P_FIN]->addUniform("txCurvS");
	_prog[P_FIN]->addUniform("txProj");
	_prog[P_FIN]->addUniform("txCanvas");
	_prog[P_FIN]->addUniform("txNoise");
	_prog[P_FIN]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_FIN]->setUniformTexture("txDert01",	1,GL_TEXTURE_2D,_tex[T_GRAD1]->id());
	_prog[P_FIN]->setUniformTexture("txDert02",	2,GL_TEXTURE_2D,_tex[T_GRAD2]->id());
	_prog[P_FIN]->setUniformTexture("txFlow",	3,GL_TEXTURE_2D,_tex[T_MLS]->id());
	_prog[P_FIN]->setUniformTexture("txCurv",	4,GL_TEXTURE_2D,_tex[T_CURV]->id());
	_prog[P_FIN]->setUniformTexture("txStroke",	5,GL_TEXTURE_2D,_tex[T_STROKE]->id());
	_prog[P_FIN]->setUniformTexture("txFlowS",	6,GL_TEXTURE_2D,_tex[T_MLS_S]->id());
	_prog[P_FIN]->setUniformTexture("txCurvS",	7,GL_TEXTURE_2D,_tex[T_CURV_S]->id());
	_prog[P_FIN]->setUniformTexture("txProj",	8,GL_TEXTURE_2D,_tex[T_PROJ]->id());
	_prog[P_FIN]->setUniformTexture("txCanvas",	9,GL_TEXTURE_2D,_tex[T_CANVAS]->id());
	_prog[P_FIN]->setUniformTexture("txNoise",	10,GL_TEXTURE_2D,_tex[T_NOISE]->id());
	_prog[P_FIN]->disable();
}
void ImagePaint::initShaders() {
	static std::string SHADER_DIR = "../drawing/shaders/";
	_prog[P_GRAD	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"gradient.fs");
	_prog[P_MLS_P	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"mlsPre.fs");
	_prog[P_MLS		]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"mls.fs");
	_prog[P_PROJ	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"project.fs");
	_prog[P_FIN		]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"fin.fs");

	setShaderParameters();
}

void ImagePaint::resizeGL(int w, int h) {
	m_wndSize = QSize(w,h);
}

void ImagePaint::paintGL() {
	if(!m_imgLoaded)
		return;

	QRectF zoomWnd = QRectF(-m_zoomOrigin
		+QPointF(m_imgSize.width(),m_imgSize.height())*(0.5-0.5/float(m_resolution)),
		QSizeF(m_imgSize)/float(m_resolution));
	float ws = 1.0f/float(m_imgSize.width());
	float hs = 1.0f/float(m_imgSize.height());

	glDisable(GL_LIGHTING);
	glColor4f(1,1,1,1);
	glEnable(GL_TEXTURE_2D);

	/////////////////////////////////////////////// render to texture: FBO1
	_fbo[FBO1]->bind();
	swapToLocalMode(m_imgSize.width(), m_imgSize.height());

	glDrawBuffers(2,FramebufferObject::buffers(0));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_GRAD]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_GRAD]->setUniform2f("wh",ws,hs);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_GRAD]->disable();

	glDrawBuffers(4,FramebufferObject::buffers(2));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_MLS_P]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_MLS_P]->setUniform2f("wh",ws,hs);
	_prog[P_MLS_P]->setUniform1i("bSketch",0);
	_prog[P_MLS_P]->setUniform1i("diffSize",m_diffSize);
	_prog[P_MLS_P]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_MLS_P]->disable();

	glDrawBuffers(2,FramebufferObject::buffers(6));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_MLS]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_MLS]->setUniform2f("wh",ws,hs);
	_prog[P_MLS]->setUniform1i("bSketch",0);
	_prog[P_MLS]->setUniform1i("diffSize",m_diffSize);
	_prog[P_MLS]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_MLS]->disable();

	/// generate sketching texture
	readSketch2Texture(m_vStroke,T_STROKE);

	glDrawBuffers(4,FramebufferObject::buffers(2));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_MLS_P]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_MLS_P]->setUniform2f("wh",ws,hs);
	_prog[P_MLS_P]->setUniform1i("bSketch",1);
	_prog[P_MLS_P]->setUniform1i("diffSize",m_diffSize);
	_prog[P_MLS_P]->setUniform1i("strokeSize",m_strokeSize);
	_prog[P_MLS_P]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_MLS_P]->disable();

	_fbo[FBO2]->bind();			///  FBO2
	glDrawBuffers(2,FramebufferObject::buffers(0));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_MLS]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_MLS]->setUniform2f("wh",ws,hs);
	_prog[P_MLS]->setUniform1i("bSketch",1);
	_prog[P_MLS]->setUniform1i("diffSize",m_diffSize);
	_prog[P_MLS]->setUniform1i("strokeSize",m_strokeSize);
	_prog[P_MLS]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_MLS]->disable();

	glDrawBuffer(*FramebufferObject::buffers(2));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_PROJ]->enable();
	glEnable(GL_TEXTURE_2D);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_PROJ]->disable();

	if(m_bHiddenStroke)		
		for (unsigned int k=0; k<m_vStroke.size(); k++)
			if(m_vStroke[k]._valid)
				m_vStroke[k].drawPoint();

	for (unsigned int k=0; k<m_vStroke.size(); k++)
	{
		//_vStroke[k].drawNormal();
		if(m_bHiddenProjection)
		{
			readProjection(T_CURV_S,m_vStroke);
			m_vStroke[k].drawProjection();
		}
	}		

	if(m_bHiddenStroke)		
		m_currStroke.drawPoint();

	glDrawBuffer(*FramebufferObject::buffers(3));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_FIN]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_FIN]->setUniform2f("wh",ws,hs);
	_prog[P_FIN]->setUniform1i("display",m_index);
	_prog[P_FIN]->setUniform4f("zoomWnd",zoomWnd.x(),zoomWnd.y(),zoomWnd.width(),zoomWnd.height());
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_FIN]->disable();

	swapToWorldMode();

	/////////////////////////////////// render to screen �� horizontal flip ��
	swapToLocalMode(m_wndSize.width(), m_wndSize.height());
	FramebufferObject::unbind();

	glEnable(GL_TEXTURE_2D);
	_tex[T_FIN]->bind();
	QColor bc = palette().color(QPalette::Window);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	QSize isz = m_imgSize*m_zoom;
	drawQuadScreen(isz.width(), isz.height(), 
		float(m_wndSize.width()-isz.width())/2.0f + m_moveOrigin.x()*m_zoom, 
		float(m_wndSize.height()-isz.height())/2.0f - m_moveOrigin.y()*m_zoom);
	glClearColor(1,1,1,0);

	swapToWorldMode();
}