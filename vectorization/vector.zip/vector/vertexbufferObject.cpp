#include <vertexbufferObject.h>

namespace gpu {

  VertexbufferObject::VertexbufferObject(GLenum usage) 
    : _target(GL_ARRAY_BUFFER),
      _type(GL_FLOAT),
      _usage(usage),
      _indexTarget(GL_ELEMENT_ARRAY_BUFFER),
      _indexType(GL_UNSIGNED_INT),
      _positions(NULL),
      _normals(NULL),
      _colors(NULL),
      _texcoords(NULL),
      _indices(NULL)  {
  
  }

  VertexbufferObject::~VertexbufferObject() {
    clear();
  }

} // gpu namespace 
