#include <tgaimageio.h>

using namespace std;

#ifdef USE_TGA

#endif

namespace image {

  vector<string> TGAImageIO::getExtensions() {
    vector<string> ext;
  
#ifdef USE_TGA
    ext.push_back("tga");
    ext.push_back("TGA");
#endif
  
    return ext;
  }

  Image *TGAImageIO::createImage(const string &filename) {
#ifdef USE_TGA
    cout << "TODO createImage " << filename << ", LIB_TGA needed" << endl;
    return NULL;
#else 
    cerr << "Unable to create " << filename << ", LIB_TGA needed" << endl;
    return NULL;
#endif
  }

  bool TGAImageIO::saveImage(const Image &img,const string &filename) {
#ifdef USE_TGA
    cout << "TODO : saveImage " << img.getName() << "in " << filename << ", LIB_TGA needed" << endl;
 
    return false;
#else 
    cerr << "Unable to save " << img.getName() << "in " << filename << ", LIB_TGA needed" << endl;
    return false;
#endif
  }

} // image namespace 
