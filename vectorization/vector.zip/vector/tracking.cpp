#include "tracking.h"
#include <math.h>

namespace tracking{

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}
const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}
void rotateDirection(float &dx, float &dy, float angle)
{
	float px = dx, py=dy;
	dx = cos(angle)*px - sin(angle)*py;
	dy = sin(angle)*px + cos(angle)*py;
}
////////////////////////////////////////////////////////////////////////// streamline stopping at low confidence (high curvature)
vector<Pot3f> streamline(float px, float py, int w, int h, int cn, float *flow, 
						 float angle, int maxLen)
{
	vector<Pot3f> pos1, pos2;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float prevTangx = fcenter[1];
	float prevTangy = -fcenter[0];
	rotateDirection(prevTangx, prevTangy, angle);

	pos1.push_back(Pot3f(float(px),float(/*h-1-*/py),atan2(-prevTangy,prevTangx)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		const float *fseed = getDirection(w,h,cn,flow,int(seedx+0.5),int(seedy+0.5));
		float tangx = fseed[1];
		float tangy = -fseed[0];
		rotateDirection(tangx, tangy, angle);
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

		pos1.push_back(Pot3f(seedx,/*float(h-1)-*/seedy,atan2(-tangy,tangx)));

		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	cnt = 0;
	seedx = float(px);
	seedy = float(py);
	prevTangx = -fcenter[1];
	prevTangy = fcenter[0];
	rotateDirection(prevTangx, prevTangy, angle);

	pos2.push_back(Pot3f(float(px),float(/*h-1-*/py),atan2(prevTangy,-prevTangx)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		const float *fseed = getDirection(w,h,cn,flow,int(seedx+0.5),int(seedy+0.5));
		float tangx = fseed[1];
		float tangy = -fseed[0];
		rotateDirection(tangx, tangy, angle);
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

		pos2.push_back(Pot3f(seedx,/*float(h-1)-*/seedy,atan2(tangy,-tangx)));

		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

	pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));

	//	cout << "left::" << pos1.size()-pos2.size()-1 << " right::" << pos2.size() << endl;
	return pos1;
}
//vector<Pot3f> streamline(Pot2 pos, Pot2 wsz, int cn, float *flow, 
//						 float angle, int maxLen)
//{
//	return streamline(float(pos.x), float(pos.y), wsz.x, wsz.y, cn, flow, angle, maxLen);
//}

vector<Pot3f> trackingProj(float px, float py, int w, int h, int cn, float *flow, float *proj,
						   float angle, int maxLen)
{
	vector<Pot3f> pos1;
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos1;
	}

	const float *pProj = getDirection(w,h,cn,proj,px,py);
	float pxNew = pProj[0]*pProj[2]+px;
	float pyNew = pProj[1]*pProj[2]+py;

	return streamline(pxNew, pyNew, w, h, cn, flow, angle, maxLen);
	///////////////////////////////////////////////////////////////
	/// codes above have to be rewritten, using pull-back mechanism
	///////////////////////////////////////////////////////////////
	//vector<Pot3f> pos1, pos2;
	//if(px<0 || py<0 || px>=w || py>=h)
	//{
	//	cout << "seed should not out of the image." << endl;
	//	return pos1;
	//}

	//int cnt = 0;
	//float seedx = float(px);
	//float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	//float prevTangx = fcenter[1];
	//float prevTangy = -fcenter[0];
	//rotateDirection(prevTangx, prevTangy, angle);

	//pos1.push_back(Pot3f(float(px),float(/*h-1-*/py),atan2(-prevTangy,prevTangx)));
	//while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	//{
	//	const float *fseed = getDirection(w,h,cn,flow,int(seedx+0.5),int(seedy+0.5));
	//	float tangx = fseed[1];
	//	float tangy = -fseed[0];
	//	rotateDirection(tangx, tangy, angle);
	//	float tangsign = tangx*prevTangx + tangy*prevTangy;
	//	if(tangsign<0.0)
	//	{
	//		tangx = -tangx;
	//		tangy= -tangy;
	//	}		
	//	seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
	//	seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

	//	pos1.push_back(Pot3f(seedx,/*float(h-1)-*/seedy,atan2(-tangy,tangx)));

	//	prevTangx = tangx;
	//	prevTangy = tangy;
	//	cnt ++;
	//}

	//cnt = 0;
	//seedx = float(px);
	//seedy = float(py);
	//prevTangx = -fcenter[1];
	//prevTangy = fcenter[0];
	//rotateDirection(prevTangx, prevTangy, angle);

	//pos2.push_back(Pot3f(float(px),float(/*h-1-*/py),atan2(prevTangy,-prevTangx)));
	//while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	//{
	//	const float *fseed = getDirection(w,h,cn,flow,int(seedx+0.5),int(seedy+0.5));
	//	float tangx = fseed[1];
	//	float tangy = -fseed[0];
	//	rotateDirection(tangx, tangy, angle);
	//	float tangsign = tangx*prevTangx + tangy*prevTangy;
	//	if(tangsign<0.0)
	//	{
	//		tangx = -tangx;
	//		tangy= -tangy;
	//	}		
	//	seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
	//	seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

	//	pos2.push_back(Pot3f(seedx,/*float(h-1)-*/seedy,atan2(tangy,-tangx)));

	//	prevTangx = tangx;
	//	prevTangy = tangy;
	//	cnt ++;
	//}

	//pos1.insert(pos1.end(),pos2.begin(),pos2.end());
	//pos1.push_back(Pot3f(float(pos1.size()-pos2.size()),float(pos2.size()),0.0));

	////	cout << "left::" << pos1.size()-pos2.size()-1 << " right::" << pos2.size() << endl;
	//return pos1;
}

//vector<Pot3f> trackingProj(Pot2 pos, Pot2 wsz, int cn, float *flow, float *proj,
//						   float angle, int maxLen)
//{
//	return trackingProj(pos.x, pos.y, wsz.x, wsz.y, cn, flow, proj, angle, maxLen);
//}

void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGrad, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = k;
			magMax = mag;
		}
	}

	stepPos[0] = float(distMax)*pGS[0]+float(pxi);
	stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	stepPos[2] = float(distMax);
	stepPos[3] = magMax;
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = -k;
			magMax = mag;
		}
	}
	stepPos[4] = float(distMax)*pGS[0]+float(pxi);
	stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	stepPos[6] = float(distMax);
	stepPos[7] = magMax;
}

} // namespace