#pragma once

#include <glew.h>
#include <QtGui/QtGui>
#include <QGLWidget>
#include <gl.h>
#include <glu.h>
#include <QGLFramebufferObject>
#include <framebufferObject.h>
#include <texture2D.h> 
#include <gpuProgram.h>
#include <gpuShader.h>
#include "geodesic.h"
#include "spline.h" 
#include "UserStroke.h"

using namespace gpu; 

using spline::divideSpot;
using spline::posd;
using spline::posi;
using spline::Spline;

#define _HACK

class ImagePaint : public QGLWidget {
	Q_OBJECT
		Q_PROPERTY(QImage image READ image WRITE setImage NOTIFY imageChanged(const QImage&)) 
		Q_PROPERTY(double zoom READ zoom WRITE setZoom NOTIFY zoomChanged(double)) 
		Q_PROPERTY(double resolution READ resolution WRITE setResolution NOTIFY resolutionChanged)
		Q_PROPERTY(double originX READ originX WRITE setOriginX NOTIFY originXChanged)
		Q_PROPERTY(double originY READ originY WRITE setOriginY NOTIFY originYChanged)

	//////////////////////////////////// system //////////////////////////////////////
public:
	ImagePaint(QWidget *parent);
	~ImagePaint();

	virtual void restoreSettings(QSettings& settings);
	virtual void saveSettings(QSettings& settings);

	QSize imageSize() const { return image().size(); }
	const QImage& image() const { return m_images[m_index]; }
	QPointF origin() const { return m_moveOrigin; }
	double originX() const { return m_moveOrigin.x(); }
	double originY() const { return m_moveOrigin.y(); }
	double zoom() const { return m_zoom; }
	double resolution() const { return m_resolution; }
	double scale() const { return m_zoom * m_resolution; }

	virtual QPointF view2image(const QPointF& p) const;
	virtual QPointF image2zoom(const QPointF& p) const;
	virtual QPointF image2view(const QPointF& p) const;
	virtual QTransform viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const;
	virtual float pt2px(float pt) const;

	void setOverlay(QWidget *overlay);
	void draw(QPainter& p, const QRectF& R, const QImage& image);
	void refresh() { update(); }

signals:
	void imageChanged(const QImage&);
	void originXChanged(double);
	void originYChanged(double);
	void zoomChanged(double);
	void resolutionChanged(double);

public slots:
	void setImage(const QImage& image);
	void setOriginX(double value);
	void setOriginY(double value);
	void setZoom(double value);
	void setResolution(double value);
	void zoomIn();
	void zoomOut();
	void reset();
	void hold();
	void toggle();
	void copy();
	void reloadShaders();

protected:
	/// move tool
	QPointF m_moveOrigin;
	QPointF m_moveStart;
	QPointF m_moveOriginKeep;
	double m_zoom;

	/// zoom tool
	QPointF m_zoomOrigin;
	QPointF m_zoomOriginKeep;
	double m_resolution;	

	/// image buffer
	int m_index;
	QImage m_images[2];
	bool	m_imgLoaded;
	QWidget *m_overlay;

	///////////////////////////////////////// GPU /////////////////////////////////
private:
	enum {FBO1=0, FBO2};

	enum {T_ORG=0,	T_GRAD1, T_GRAD2, T_NOISE, T_MLS_P1, 
		T_MLS_P2, T_MLS_P3, T_MLS_P4, T_MLS, T_CURV, 
		T_STROKE, T_MLS_S, T_CURV_S, T_JOIN, T_CANVAS, 
		T_BRUSH, T_GEODESIC, T_SEGM, T_F_EDGE, T_F_USER,
		T_F_COMB, T_HEIGHT, T_COLOR, T_PAINT_C, T_PAINT_H,
		T_BLACK, T_EMBOSS1, T_EMBOSS2, T_FILL, T_FIN};

	enum {P_GRAD=0, P_MLS_P, P_MLS, P_COMB, P_EMBOSS1, 
		P_EMBOSS2, P_GLASS1, P_GLASS2, P_TSMOOTH1, P_TSMOOTH2, 
		P_FIN};

	static const int NB_FBO = 2;
	static const int NB_TEX = 30;
	static const int NB_PROG = 11;

	FramebufferObject	  *_fbo[NB_FBO];
	GPUProgram            *_prog[NB_PROG];
	FloatTexture2D        *_tex[NB_TEX];

protected:
	virtual void initializeGL();
	virtual void resizeGL(int w, int h);
	virtual void paintGL();

	void initGPU();
	void finalizeGPU();

	void initShaders();
	void setShaderParameters();
	void cleanShaders();

	void initFBO();
	void cleanFBO();
	void loadTexture(int tex_id, const QImage &qimg);
	void setTextureDefault(int tex_id, float val);
	void initNoiseTex(int tex_id, const QSize &imgSize);
	void loadHeightOpacity(int tex_id1, int tex_id2, const QString &file1, const QString &file2);

	///////////////////////////////////// interface & interaction /////////////////////////////////////

public slots:
	/// interface
	void onIndexChanged(int);
	void savePNG(const QString& text=QString());
	void saveAllPNG(const QString& text=QString());
	void clearAllDrawn();
	void loadSplineFile();
	void saveSplineFile();
	void displaySpline(bool ck){m_bDisplaySpline=ck; update();}
	void editingSpline(bool ck){m_bMovingKeypoint=ck; 
			if(ck) setCursor(Qt::ArrowCursor);		
			else setCursor(Qt::OpenHandCursor); }
	void setBackground() { m_bSetBackground=true; }
	void smoothMethodCombocChanged(int sm) {m_smoothMethod=sm;}
	void smoothSizeCombocChanged(int smoothSize) {m_smoothSize=smoothSize;}
	void smoothComputeClicked();

protected:
	/// interaction event
//	virtual bool	eventFilter( QObject *watched, QEvent *e );
//	virtual void	leaveEvent( QEvent *e );
	virtual void	keyPressEvent( QKeyEvent *e );
	virtual void	keyReleaseEvent( QKeyEvent *e );
	virtual void	mousePressEvent( QMouseEvent *e );
	virtual void	mouseMoveEvent( QMouseEvent *e );
	virtual void	mouseReleaseEvent( QMouseEvent *e );
	virtual void	wheelEvent(QWheelEvent *e);
//	virtual void	paintEvent(QPaintEvent *event);

	/// paintGL funtion
	inline void		drawQuad(int width, int height, int xoff=0, int yoff=0);
	inline void		drawQuadScreen(int width, int height, int xoff=0, int yoff=0);
	inline void		swapToLocalMode(int w, int h);
	inline void		swapToWorldMode();

	/// stylization function
	//void			ContinuousGlassPattern();
	//void			CoherenceEnhancingFiltering();
	void			PainterRendering(int idx, float xoff=0.0f, float yoff=0.0f);
	void			HeightRendering(int idx, float xoff=0.0f, float yoff=0.0f);

protected:
	/// interaction
	Qt::MouseButton m_dragButton;
	QPoint			m_currPosWnd;
	QPointF			m_currPosImg;
	QPoint			m_pressedSpline;

	int				m_repaintLevel;
	bool			m_bPressedKeypoint;
	QPoint			m_pressedPoint;
	bool			m_showOriginal;
	bool			m_bSetBackground;
	bool			m_bSettedBackground;

	///////////////////////////////////////// algorithm /////////////////////////////////
public:
	void	updateStrokeImage(int idx);
	void	updateRegionImage();
	void	regionSegmentation(QImage &segImg, float *fdest, int m_currRegion, float thres);
	void	updateEdgeAndSpline();
	void    edgeFromRegion(const QImage &regImg,  int idx, QImage &edgeImg);
	spline::posd splineSampling(const spline::Spline &sp, double t);
	void	updateJoinImage(const spline::divideSpot &sp, int index, int joinSize, QImage &img);
	void	initSeedImage(QVector<pair<int,pair<int,int> > >	*m_pointQueue, float thres);

	QImage	edgeFromSpline(const spline::divideSpot &sp);
	QImage	edgeFromSplineForFlow(const spline::divideSpot &sp);
	void	updateRegionFilling(const QImage &edge, QImage &region, QPoint seed);	

	void	drawEdges(const spline::closeEdge &m_edgePos);
	void	drawSpline(const vector<spline::divideSpot> &sp, bool isDual);
	void	drawStrokeAll(const vector<UserStroke> &str);
	void	drawStrokeOne(const UserStroke &st);

	void	PedroDistanceTransform(const QImage &edgeImg, const QImage &regionImg, float *dest, int idx);
	void	computeFlowFromEdge(const QImage &edgeImg, const QImage &regionImg, int idx);
	void	computeFlowFromUserStroke(const vector<UserStroke> &vstroke, const QImage &regionImg, int idx);
	/// get stream curve for stroke-based paiterly rendering
	//	void	getSteamCurve(const float *grad, vector<QPoint> &curve, const QPoint &pos,
	//			QPoint imgSize, float stepLen, int maxStep, float confThre=0.1);
	bool	keypointSearch(const QPointF &imgPos, QPoint &idxVal, QPointF &currPos);
	bool	splineSearch(const spline::divideSpot sp, const QPointF &imgPos, int &splineIdx);

	/// parameters transfer with MianWindow
	//int*	smoothSizePtr (return &m_smoothSize;)
	int*	diffSizePtr() {return &m_diffSize; }
	int*	strokeSizePtr() {return &m_strokeSize; }
	int*	brushSizePtr() {return &m_brushSize; }
	int*	brushSizeBackgroundPtr() {return &m_brushSizeBackground; }
	int*	keyIntervalPtr() {return &m_keyInterval; }
	int*	joinSizePtr() {return &m_joinSize; }

	int*	streamLenPtr() {return &m_streamLen; }
	double* streamThrePtr()  {return &m_streamThre; }
	double* geodesicThresPtr() {return &m_geodesicThres;}

	void	setCurrRegion(int idx);
	void	setRegionIncreasing(bool isT)	{m_regionIncreasing=isT;}
	void	setOverlap(bool isO)	{m_regionOverlap = isO;}

protected:
	/// size
	QSize		m_wndSize;
	QSize		m_imgSize;

	/// algorithm parameters
	int			m_smoothMethod;
	int			m_smoothSize;
	int			m_diffSize;
	int			m_strokeSize;

	int			m_streamLen;	// to be deleted
	double		m_streamThre;	// to be deleted

	int			m_brushSize;
	int			m_brushSizeBackground;
	double		m_geodesicThres;
	int			m_keyInterval;
	int			m_joinSize;
	
	/// status parameters
	bool		m_bDisplaySpline;
	bool		m_bMovingKeypoint;
	bool		m_regionIncreasing;
	bool		m_regionOverlap;
	bool		m_bLeftButtonPainting;
	bool		m_bEditingSpline;
	bool		m_bInnerSpline;

	/// geodesic-based segmentation
	GeoSegN24	m_geos;
	GeoSegN24	m_dist;

	/// user-drawn strokes
	UserStroke			m_currUserStroke;
	vector<UserStroke>	m_vUserStroke;

	/// splines of the boundaries
	spline::closeEdge	m_edgePos;
	vector<spline::divideSpot>	m_vSpline;

	QImage		m_strokeImg;
	QImage		m_regionImg;
	QImage		m_joinImg;
	QImage		m_brushTex;
	QImage		m_fillRegionImg;

	int			m_regionIndex;
	int			m_regionSize;
	vector<int>	m_regionOrder;	// to be deleted
	static const int m_backgroudnIndex = 255;

	/// for painterly rendering
	QVector<pair<int,pair<int,int> > >	m_pointQueue[2];
};

inline void ImagePaint::drawQuad(int width, int height, int xoff/* =0 */, int yoff/* =0 */)
{
	glBegin(GL_QUADS);
	glTexCoord2i(0,0);  glVertex2i(xoff, yoff);
	glTexCoord2i(1,0);  glVertex2i(width+xoff, yoff);
	glTexCoord2i(1,1);  glVertex2i(width+xoff, height+yoff);
	glTexCoord2i(0,1);  glVertex2i(xoff, height+yoff);
	glEnd();
}

inline void ImagePaint::drawQuadScreen(int width, int height, int xoff/* =0 */, int yoff/* =0 */)
{
	glBegin(GL_QUADS);
	glTexCoord2i(0,1);  glVertex2i(xoff, yoff);
	glTexCoord2i(1,1);  glVertex2i(width+xoff, yoff);
	glTexCoord2i(1,0);  glVertex2i(width+xoff, height+yoff);
	glTexCoord2i(0,0);  glVertex2i(xoff, height+yoff);
	glEnd();
}

inline void ImagePaint::swapToLocalMode(int w, int h)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0,w,0,h,-1,1);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glViewport(0,0,w,h);
	glLoadIdentity();
}

inline void ImagePaint::swapToWorldMode()
{
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}
