#include "flowDesignPaint.h"
#include <flowDesignWindow.h>
#include "streamline.h"
#include <fstream>
#include "dt.h"
#include "timage.h"

////////////////////////////////////////////////////////////////////////// interface and interaction
//bool ImagePaint::eventFilter( QObject *watched, QEvent *e ) {
//	if (!hasFocus() /*&& (m_mode == MODE_MOVE)*/ && (e->type() == QEvent::KeyPress)) {
//		QKeyEvent *k = (QKeyEvent*)e;
//		if (k->key() == Qt::Key_Space) {
//			QPoint gp = mapFromGlobal(QCursor::pos());
//			if (rect().contains(gp)) {
//				setFocus(Qt::OtherFocusReason);
//				keyPressEvent(k);
//				return true;
//			}
//		}
//	}
//	return QWidget::eventFilter(watched, e);
//}
//
//
//void ImagePaint::leaveEvent( QEvent *e ) {
//	//if (m_spacePressed) {
//	//	setCursor(m_cursor);
//	//	m_cursor = QCursor();
//	//	m_spacePressed = false;
//	//}
//	//if (m_overlay) {
//	//	m_overlay->setVisible(false);
//	//}
//	QWidget::leaveEvent(e);
//}

void ImagePaint::keyPressEvent( QKeyEvent *e ) 
{
	if (e->key()==Qt::Key_I)
	{
		m_showOriginal = true;
		update();
	}
	else if(e->key()==Qt::Key_S)
	{
		if(m_bEditingSpline)
		{
			spline::SplineType st = m_vSpline[m_pressedSpline.x()].vType[m_pressedSpline.y()];
			if(m_bInnerSpline)
				m_vSpline[m_pressedSpline.x()].vType[m_pressedSpline.y()] = spline::SplineType(st^spline::INSIDE);
			else 
				m_vSpline[m_pressedSpline.x()].vType[m_pressedSpline.y()] = spline::SplineType(st^spline::OUTSIDE);
			m_bEditingSpline = false;
			const int iii = m_regionIndex;
			QImage edgeSplineImgTest = edgeFromSplineForFlow(m_vSpline[m_pressedSpline.x()]);
			computeFlowFromEdge(edgeSplineImgTest,m_fillRegionImg,m_pressedSpline.x()+1);
			update();
		}
	}
	//else if(e->key()==Qt::Key_Space)
	//{
	//	for(unsigned int i=0; i<m_vStroke.size(); i++)
	//		m_vStroke[i].setValid(false);
	//	/// reapint to remove the gray lines from canvas
	//	update();

	//	/// copy canvas
	//	int cn =4;
	//	const GLenum format1 = GL_RGBA;
	//	float *fdata = new float[m_imgSize.width()*m_imgSize.height()*cn];
	//	////////////////////////////////// preserve the previous result
	//	/// copy from texture buffer	
	//	_tex[T_JOIN]->bind();	
	//	glGetTexImage(GL_TEXTURE_2D,0,format1,GL_FLOAT,fdata);
	//	/// set to texture buffer
	//	_tex[T_CANVAS]->bind();
	//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
	//		GL_RGBA, GL_FLOAT, fdata);
	//	/// delete memory
	//	delete []fdata;

	//	/// remove all strokes
	//	for(unsigned int i=0; i<m_vStroke.size(); i++)
	//		//_vStroke[i].setValid(false);
	//		m_vStroke[i]._vBrush.clear();
	//	m_vStroke.clear();
	//}
	update();
	QWidget::keyPressEvent(e);
}


void ImagePaint::keyReleaseEvent( QKeyEvent *e ) {
	if (e->key()==Qt::Key_I)
	{
		m_showOriginal = false;
		update();
	}
	//else if (e->key() == Qt::Key_Space) 
	//{
	//	if (!e->isAutoRepeat()) 
	//		m_spacePressed = false;
	//} 
	else 
		QWidget::keyReleaseEvent(e);
}

//bool ImagePaint::getStreamLine(const QPointF &curpos, Stroke &stok)
//{
//	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
//		return false;
//
//	/// get texture data
//	int cn =4;
//	_tex[T_MLS]->bind();
//	float *pFlow = new float[m_imgSize.width()*m_imgSize.height()*cn];
//	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pFlow);
//
//	_tex[T_CURV]->bind();
//	float *pCurv = new float[m_imgSize.width()*m_imgSize.height()*cn];
//	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pCurv);
//
//	/// get stream line
//	vector<Pot3f> pnt = streamline(int(m_currPosImg.x()), int(m_currPosImg.y()), 
//		m_imgSize.width(), m_imgSize.height(), 4, 
//		pFlow, pCurv, 1, float(m_streamThre), 0.0, 1.0, m_streamLen);
//	delete [] pFlow;
//	delete [] pCurv;
//
//	if(pnt.empty())
//		return false;
//
//	stok._vBrush.clear();
//	const int sz1 = int(pnt[pnt.size()-1].x);
//	const int sz2 = int(pnt[pnt.size()-1].y);
//
//	for(int i=0; i<sz1; i++)
//		stok._vBrush.push_back(Brush(pnt[sz1-1-i].x, pnt[sz1-1-i].y));
//
//	for(int i=sz1; i<sz1+sz2; i++)
//		stok._vBrush.push_back(Brush(pnt[i].x, pnt[i].y));
//
//	return true;
//}

bool ImagePaint::keypointSearch(const QPointF &imgPos, QPoint &idxVal, 
								QPointF &currPos)
{
	//const uchar *pI = m_joinImg.bits();
	//int idx2 = pI[(int)m_currPosImg.y() * m_joinImg.width() + (int)m_currPosImg.x()];
	int idx2 = m_joinImg.pixelIndex((int)m_currPosImg.x(), (int)m_currPosImg.y());
	int idx = (idx2-1)/2;
	if(idx2>m_vSpline.size()*2)
	{
		cerr << "keypoint index " << idx <<" in joinImg is out of range!" << std::endl;
	}
	spline::posd head((int)imgPos.x(),(int)imgPos.y());
	if(idx2!=0 && idx2%2==0)			/// meet a keypoint
	{
		int minDist=100000;
		int minIdx;
		for (int s=0; s<m_vSpline[idx].vSpot.size(); s++)
		{
			int dist = (head.i-m_vSpline[idx].vSpot[s].i)*(head.i-m_vSpline[idx].vSpot[s].i);
			dist += (head.j-m_vSpline[idx].vSpot[s].j)*(head.j-m_vSpline[idx].vSpot[s].j);
			if (dist<minDist)
			{
				minIdx=s;
				minDist=dist;
			}
		}
		if(minDist<m_joinSize*m_joinSize)
		{
			idxVal = QPoint(idx,minIdx);
			currPos = QPointF(float(m_vSpline[idx].vSpot[minIdx].i),float(m_vSpline[idx].vSpot[minIdx].j));
			return true;
		}
	}
	return false;
}
bool ImagePaint::splineSearch(const spline::divideSpot sp, const QPointF &imgPos, int &splineIdx)
{	
	const int internal = 10;
	int minIdx;
	float minDist = 100000;
	for (int k=0; k<sp.vSpot.size(); k++)
	{
		for (int t=1; t<internal; t++)
		{
			spline::posd samp = spline::samplingSpline(sp.vPara[k],double(t)/double(internal));
			float dist = (imgPos.x()-samp.i)*(imgPos.x()-samp.i) + (imgPos.y()-samp.j)*(imgPos.y()-samp.j);
			if(dist<minDist)
			{
				minIdx = k;
				minDist = dist;
			}
		}
	}
	if(minDist<float(m_joinSize*m_joinSize))
	{
		splineIdx = minIdx;
		return true;
	}
	else return false;
}
void ImagePaint::mousePressEvent( QMouseEvent *e ) {
	m_dragButton = e->button();
	if(m_bMovingKeypoint && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		if( m_bPressedKeypoint = keypointSearch(m_currPosImg,m_pressedPoint,m_moveStart) )
			update();
	}
	else if(m_bSetBackground && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		updateStrokeImage(m_backgroudnIndex);

		m_repaintLevel = 2;
		m_currUserStroke.m_vPos.clear();
		m_currUserStroke.m_index = m_backgroudnIndex;
		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		update();
	}
	else if(m_dragButton == Qt::LeftButton)
	{
		if(m_regionIncreasing)
		{
			m_regionSize++;
			m_regionIndex = m_regionSize;			
			MainWindow::getInstance()->addRegionIndex(m_regionIndex);
		}

		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		updateStrokeImage(m_regionIndex);
		//updateRegionImage();
		//updateEdgeAndSpline();
		m_bLeftButtonPainting = true;
		m_repaintLevel = 2;
		m_currUserStroke.m_vPos.clear();
		m_currUserStroke.m_index = m_regionIndex;
		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		update();
	}
	else if(m_dragButton==Qt::RightButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		int joinIdx = m_joinImg.pixelIndex(m_currPosImg.x(),m_currPosImg.y());
		int fillIdx = m_fillRegionImg.pixelIndex(m_currPosImg.x(),m_currPosImg.y());
		if(joinIdx!=0 && joinIdx%2==1)		/// editing spline
		{
			int splineIdx = 0;
			if(m_bEditingSpline = splineSearch(m_vSpline[(joinIdx-1)/2],m_currPosImg,splineIdx) )
			{
				m_pressedSpline = QPoint((joinIdx-1)/2,splineIdx);
				m_bInnerSpline = (fillIdx-1==(joinIdx-1)/2);
			}
		}
		else		/// editing keypoint
		{
			//m_regionIndex = (idx>=0 && idx<=m_regionSize) ? idx : m_regionIndex;
			MainWindow::getInstance()->setRegionIndex(fillIdx);
		}		
		update();
	}
}

//void ImagePaint::paintEvent(QPaintEvent *event)
//{
//	paintGL();
//	//QPointF offset= QPointF(m_wndSize.width()-m_imgSize.width(),m_wndSize.height()-m_imgSize.height())/2.0;
//
//	QPainter painter(this);
//	painter.setRenderHint(QPainter::Antialiasing);
//	//QPainterPath path;
//	//path.moveTo(20, 80);
//	//path.lineTo(20, 30);
//	//path.cubicTo(80, 0, 50, 50, 80, 80);
//	//painter.drawPath(path);
//	//painter.end();
//}
void ImagePaint::mouseMoveEvent( QMouseEvent *e ) {
	if(m_bMovingKeypoint && m_bPressedKeypoint && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		spline::posi tail= spline::posi((int)m_currPosImg.x(),(int)m_currPosImg.y());
		m_vSpline[m_pressedPoint.x()].vSpot[m_pressedPoint.y()]=tail;
		update();
	}
	else if(m_bSetBackground && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		updateStrokeImage(m_backgroudnIndex);
		m_repaintLevel = 2;
		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		update();
	}
	else if(m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		updateStrokeImage(m_regionIndex);
		//updateRegionImage();
		//updateEdgeAndSpline();
		//m_bLeftButtonPainting = true;
		m_repaintLevel = 2;
		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		update();		
	}
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
}

void ImagePaint::mouseReleaseEvent( QMouseEvent *e ) {
	if(m_bMovingKeypoint && m_dragButton == Qt::LeftButton && m_bPressedKeypoint)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		spline::posi tail= spline::posi((int)m_currPosImg.x(),(int)m_currPosImg.y());
		spline::posi oldPos = spline::posi(int(m_moveStart.x()),int(m_moveStart.y()) );
		m_vSpline[m_pressedPoint.x()].vSpot[m_pressedPoint.y()]=tail;
		MainWindow::getInstance()->setRegionIndex(m_pressedPoint.x()+1);

		spline::recomputeSpline(m_vSpline[m_pressedPoint.x()],m_pressedPoint.y());

		int sz = m_vUserStroke[m_pressedPoint.x()].m_vPos.size();
		QImage edgeSplineImg = edgeFromSpline(m_vSpline[m_pressedPoint.x()]);
		updateRegionFilling(edgeSplineImg,m_fillRegionImg,m_vUserStroke[m_pressedPoint.x()].m_vPos[sz-1]);
		_tex[T_FILL]->bind();
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
			0, GL_ALPHA, GL_UNSIGNED_BYTE, m_fillRegionImg.bits());

		updateJoinImage(m_vSpline[m_regionIndex-1],m_regionIndex, m_joinSize, m_joinImg);
		_tex[T_JOIN]->bind();
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
			0, GL_ALPHA, GL_UNSIGNED_BYTE, m_joinImg.bits());

		QImage edgeSplineImgTest = edgeFromSplineForFlow(m_vSpline[m_pressedPoint.x()]);
		computeFlowFromEdge(edgeSplineImgTest,m_fillRegionImg,m_regionIndex);
		computeFlowFromUserStroke(m_vUserStroke,m_fillRegionImg,m_regionIndex);

		update();
	}
	else if(m_bSetBackground && m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		updateStrokeImage(m_backgroudnIndex);

		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		m_currUserStroke.computeTangent();
		m_vUserStroke.push_back(m_currUserStroke);
		computeFlowFromUserStroke(m_vUserStroke,m_fillRegionImg,m_backgroudnIndex);
		m_bSettedBackground = true;
		update();

		MainWindow::getInstance()->setSetBackground(false);
		m_bSetBackground = false;
	}
	else if(m_dragButton == Qt::LeftButton)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);

		updateStrokeImage(m_regionIndex);
		updateRegionImage();
		updateEdgeAndSpline();
		QImage edgeSplineImg = edgeFromSpline(m_vSpline[m_regionIndex-1]);
		//if (m_currUserStroke.m_vPos.size()>=1 && m_vSpline.size()>=1)
		updateRegionFilling(edgeSplineImg,m_fillRegionImg,m_currUserStroke.m_vPos[0]);
		
		QImage edgeSplineImgTest = edgeFromSplineForFlow(m_vSpline[m_regionIndex-1]);
		computeFlowFromEdge(edgeSplineImgTest,m_fillRegionImg,m_regionIndex);
		m_currUserStroke.m_vPos.push_back(QPoint(int(m_currPosImg.x()),int(m_currPosImg.y())));
		m_currUserStroke.computeTangent();
		m_vUserStroke.push_back(m_currUserStroke);
		computeFlowFromUserStroke(m_vUserStroke,m_fillRegionImg,m_regionIndex);

		update();
		m_bLeftButtonPainting = false;
	}

	/// reset mouse button
	m_dragButton = Qt::NoButton; 
}

void ImagePaint::wheelEvent(QWheelEvent *e) {
	QSize sz = size();
	double u = e->delta() / 120.0 / 4.0;
	if (u < -0.5) u = -0.5;
	if (u > 0.5) u = 0.5;
}

void ImagePaint::savePNG(const QString& text) {
	QSettings settings;
	QString inputPath = window()->windowFilePath();
	QString outputPath = settings.value("savename", inputPath).toString();

	QString filename;
	QFileInfo fi(inputPath);
	QFileInfo fo(outputPath);
	if (!fi.baseName().isEmpty()) {
		QFileInfo fn(fo.dir(), fi.baseName() + "-out.png");
		filename  = fn.absoluteFilePath();
	} else {
		filename  = fo.absolutePath();
	}

	filename = QFileDialog::getSaveFileName(this, "Save PNG", filename, 
		"PNG Format (*.png);;All files (*.*)");
	if (!filename.isEmpty()) {
		_tex[T_FIN]->bind();
		unsigned char *pData = new unsigned char[m_imgSize.width()*m_imgSize.height()*3];
		glGetTexImage(GL_TEXTURE_2D,0,GL_RGB,GL_UNSIGNED_BYTE,pData);
		QImage tmp = QImage(pData, m_imgSize.width(), m_imgSize.height(), QImage::Format_RGB888);

		if (!text.isEmpty()) tmp.setText("Description", text);
		if (!tmp.save(filename)) {
			QMessageBox::critical(this, "Error", QString("Saving PNG '%1' failed!").arg(filename));
			return;
		//delete  []pData;
		}
		settings.setValue("savename", filename);
	}
}
void ImagePaint::saveAllPNG(const QString& text) {
	QSettings settings;
	QString inputPath = window()->windowFilePath();
	QString outputPath = settings.value("savename", inputPath).toString();

	QString filename;
	QFileInfo fi(inputPath);
	QFileInfo fo(outputPath);
	if (!fi.baseName().isEmpty()) {
		QFileInfo fn(fo.dir(), fi.baseName());
		filename  = fn.absoluteFilePath();
	} else {
		filename  = fo.absolutePath();
	}

	filename = QFileDialog::getSaveFileName(this, "Save PNG", filename);

	if (filename.isEmpty()) return;

	const int sz = MainWindow::getInstance()->selectItemSize();
	const int idxKept = m_index;
	unsigned char *pData = new unsigned char[m_imgSize.width()*m_imgSize.height()*3];
	for(int k=0; k<sz; k++)
	{
		m_index = (idxKept+k+1)%sz;
		paintGL();		
		//glFlush();
		_tex[T_FIN]->bind();	
		glGetTexImage(GL_TEXTURE_2D,0,GL_RGB,GL_UNSIGNED_BYTE,pData);
		QImage tmp = QImage(pData, m_imgSize.width(), m_imgSize.height(), QImage::Format_RGB888);
		tmp.save(QString("-%1-%2.png").arg(m_index,2,10,QChar('0')).arg(displayList[m_index]).prepend(filename));
	}	
	//delete []pData;
}
void ImagePaint::clearAllDrawn()
{
	m_strokeImg.fill(0);
	setTextureDefault(T_BRUSH, 0.0);
	m_regionImg.fill(0);
	setTextureDefault(T_SEGM, 0.0);
	m_fillRegionImg.fill(0);
	setTextureDefault(T_FILL, 0.0);
	setTextureDefault(T_GEODESIC, 1.0);
	m_joinImg.fill(0);
	setTextureDefault(T_JOIN,0.0);
	m_regionIndex = 0;
	m_regionSize = 0;	
	m_regionOrder.clear();
	m_edgePos.clear();
	m_bPressedKeypoint= false;
	m_bSetBackground = false;
	m_bSettedBackground = false;
	MainWindow::getInstance()->setEditingSpline(false);

	m_currUserStroke.clear();
	for(int k=0; k<m_vUserStroke.size(); k++)
		m_vUserStroke[k].clear();
	m_vUserStroke.clear();
	setTextureDefault(T_F_EDGE, 0.0);
	setTextureDefault(T_F_USER, 0.0);
	for(int k=0; k<m_vSpline.size(); k++)
		m_vSpline[k].clear();
	m_vSpline.clear();
	MainWindow::getInstance()->clearRegionIndex();
	update();
}
////////////////////////////////////////////////////////////////////////// region and splines
static int _clamp(float pos, int vmin, int vmax) {
	return max(min(int(pos+0.5),vmax),vmin);
}
static float _clamp(float val, float vmin, float vmax) {
	return max(min(val,vmax),vmin);
}
void ImagePaint::updateStrokeImage(int idx)
{
	/// update mask from brushes
	const int dsz = m_imgSize.width()*m_imgSize.height();
	int lx = _clamp(m_currPosImg.x()-m_strokeSize, 0, m_imgSize.width()-1);
	int ly = _clamp(m_currPosImg.y()-m_strokeSize, 0, m_imgSize.height()-1);
	int rx = _clamp(m_currPosImg.x()+m_strokeSize, 0, m_imgSize.width()-1);
	int ry = _clamp(m_currPosImg.y()+m_strokeSize, 0, m_imgSize.height()-1);

	if(lx==rx || ly==ry)
		return;

	uchar *pmask = m_strokeImg.bits() + ly*m_strokeImg.bytesPerLine()+lx;
	for(int yi=ly; yi<=ry; yi++,pmask+=m_strokeImg.bytesPerLine())
	{
		uchar *pm = pmask;
		for(int xi=lx; xi<=rx; xi++,pm+=1)
		{
			if(pm[0]==idx)	/// painted before by this index
				continue;
			if(m_regionOverlap==false && pm[0]!=0)	/// painted before by other indices 
				continue;
			float dv[] = {m_currPosImg.x()-float(xi), m_currPosImg.y()-float(yi)};
			float dist = dv[0]*dv[0]+dv[1]*dv[1];
			if(dist<=float(m_strokeSize*m_strokeSize))
				pm[0] = idx;
		}
	}

	/// save mask to texture
	_tex[T_BRUSH]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
		0, GL_ALPHA, GL_UNSIGNED_BYTE, m_strokeImg.bits());
}
/////////////////////////////////////////// region texture update
void ImagePaint::regionSegmentation(QImage &segImg, float *fdest, int m_currRegion, float thres)
{
	int w = segImg.width();
	int h = segImg.height();
	int cn = segImg.bytesPerLine()/segImg.width();
	segImg.setColor(m_currRegion,qRgb(m_currRegion,m_currRegion,m_currRegion));
	float *ffd = fdest;
	uchar *ffs = segImg.bits();
	for(int yi=0; yi<h; yi++,ffd+=w,ffs+=segImg.bytesPerLine())
	{
		float *fd = ffd;
		uchar *fs = ffs;
		for(int xi=0; xi<w; xi++,fd++,fs+=cn)
		{
			if(_clamp(float(1.0-fd[0]),0.0f,1.0f) < thres)
			{
				if(fs[0]==m_currRegion)
					continue;
				if(m_regionOverlap==false && fs[0]!=0)
					continue;
				for(int i=0; i<cn; i++)
					fs[i] = m_currRegion;
			}
		}
	}
}
void ImagePaint::updateRegionImage()
{	
	/// compute geodesic distance map
	float *fdest = new float[m_images[0].width()*m_images[0].height()];
	m_geos.GetProb(m_strokeImg.bits(), m_strokeImg.bytesPerLine(), fdest,m_images[0].width(),GSM_FORE,m_regionIndex);

	/// save geodesic distance map to texture
	_tex[T_GEODESIC]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 0, 
		GL_ALPHA, GL_FLOAT, fdest);

	/// compute region segmentation
	regionSegmentation(m_regionImg,fdest,m_regionIndex,float(m_geodesicThres));
	delete []fdest;

	/// save region to texture
	_tex[T_SEGM]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
		0, GL_ALPHA, GL_UNSIGNED_BYTE, m_regionImg.bits());
}
///////////////////////////////////////////////// edge and spline data update
void ImagePaint::edgeFromRegion(const QImage &regImg, int idx, QImage &edgeImg)
{
	int w=regImg.width();
	int h=regImg.height();
	edgeImg = QImage(w,h,QImage::Format_Indexed8);
	edgeImg.fill(0);
	edgeImg.setColor(255,qRgb(255,0,255));

	uchar *ffs = edgeImg.bits();
	for (int yi=0; yi<h; yi++,ffs+=edgeImg.bytesPerLine())
	{
		uchar *fs = ffs;
		for (int xi=0; xi<w; xi++,fs++)
		{
			uchar pc = regImg.pixelIndex(xi,yi);
			if(pc==idx)
			{
				if(regImg.pixelIndex(max(xi-1,0),yi)!=idx || regImg.pixelIndex(min(xi+1,w-1),yi)!=idx ||
					regImg.pixelIndex(xi,min(yi+1,h-1))!=idx || regImg.pixelIndex(xi,max(0,yi-1))!=idx )
					fs[0] = 255;
			}
		}
	}
	/// save region to texture
	_tex[T_JOIN]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
		0, GL_ALPHA, GL_UNSIGNED_BYTE, edgeImg.bits());
}
QImage ImagePaint::edgeFromSpline(const spline::divideSpot &sp)
{
	const int w = m_imgSize.width();
	const int h = m_imgSize.height();
	const int interval=30;

	/// generate edge image
	QImage edge(w,h,QImage::Format_Indexed8);
	edge.fill(0);
	const int curcnt = m_regionIndex;
	edge.setColor(curcnt,qRgb(curcnt, curcnt, curcnt));
	for (int i=0;i<sp.vSpot.size();i++)
	{
		double t=0;
		double dt=1/double(interval);
		spline::posd prevSamp=spline::samplingSpline(sp.vPara[i],t);
		spline::posi prevTemp(int(prevSamp.i+0.5), int(prevSamp.j+0.5));
		while (t<=1)
		{
			//spline::samplingSpline(const spline::Spline &sp, double t)
			spline::posd samp = spline::samplingSpline(sp.vPara[i],t+dt);
			spline::posi temp(int(samp.i+0.5), int(samp.j+0.5));
			int dist=(temp.i-prevTemp.i)*(temp.i-prevTemp.i)+(temp.j-prevTemp.j)*(temp.j-prevTemp.j);
			if (dist<=2)
			{
				edge.setPixel(temp.i,temp.j,curcnt);
				t=t+dt;
				prevTemp=temp;
				dt=1/double(interval);
			}
			else 
				dt=dt/2;
		}
	}
	return edge;
}
QImage ImagePaint::edgeFromSplineForFlow(const spline::divideSpot &sp)
{
	const int w = m_imgSize.width();
	const int h = m_imgSize.height();
	const int interval=30;

	/// generate edge image
	QImage edge(w,h,QImage::Format_Indexed8);
	edge.fill(0);
	const int curcnt = m_regionIndex;
	edge.setColor(curcnt,qRgb(curcnt, curcnt, curcnt));
	for (int i=0;i<sp.vSpot.size();i++)
	{
		if(sp.vType[i] & spline::INSIDE)	/// places for flow
		{
			double t=0;
			double dt=1/double(interval);
			spline::posd prevSamp=spline::samplingSpline(sp.vPara[i],t);
			spline::posi prevTemp(int(prevSamp.i+0.5), int(prevSamp.j+0.5));
			while (t<=1)
			{
				//spline::samplingSpline(const spline::Spline &sp, double t)
				spline::posd samp = spline::samplingSpline(sp.vPara[i],t+dt);
				spline::posi temp(int(samp.i+0.5), int(samp.j+0.5));
				int dist=(temp.i-prevTemp.i)*(temp.i-prevTemp.i)+(temp.j-prevTemp.j)*(temp.j-prevTemp.j);
				if (dist<=2)
				{
					edge.setPixel(temp.i,temp.j,curcnt);
					t=t+dt;
					prevTemp=temp;
					dt=1/double(interval);
				}
				else 
					dt=dt/2;
			}
		}
	}
	return edge;
}
void ImagePaint::updateRegionFilling(const QImage &edgeImg, QImage &region, QPoint seed)
{
	/// edge -> region, using seed
	//edge.setColor(curcnt,qRgb(curcnt, curcnt, curcnt));
	const int w = m_imgSize.width();
	const int h = m_imgSize.height();
	bool spanNeedFill;
	int xl,xr,x,y;
	//�����ɫ

	QImage edge = edgeImg;
	const int curcnt = m_regionIndex;
	typedef vector<QPoint> Stack;
	Stack myStack;
	myStack.clear();
	myStack.push_back(seed);
	while(!myStack.empty())
	{
		seed=myStack.back();
		myStack.pop_back();
		y=seed.y();
		x=seed.x();
		while(edge.pixelIndex(x,y)==0)
		{
			edge.setPixel(x,y,curcnt);
			x++;
		}
		xr=x-1;
		x=seed.x()-1;
		while(edge.pixelIndex(x,y)==0)
		{
			edge.setPixel(x,y,curcnt);
			x--;
		}
		xl=x+1;
		//��������һ��ɨ����
		x=xl;
		y=y+1;
		while(x<xr)
		{
			spanNeedFill=FALSE;
			while(edge.pixelIndex(x,y)==0)
			{
				spanNeedFill=TRUE;
				x++;
			}
			if (spanNeedFill)
			{
				seed.setX(x-1);
				seed.setY(y);
				myStack.push_back(seed);
				spanNeedFill=FALSE;

			}
			while(edge.pixelIndex(x,y)!=0 && x<xr) x++;
		}
		x=xl;
		y=y-2;
		while(x<xr)
		{
			spanNeedFill=FALSE;
			while (edge.pixelIndex(x,y)==0)
			{
				spanNeedFill=TRUE;
				x++;
			}
			if (spanNeedFill)
			{
				seed.setX(x-1);
				seed.setY(y);
				myStack.push_back(seed);
				spanNeedFill=FALSE;

			}
			while(edge.pixelIndex(x,y)!=0 && x<xr) x++;
		}
	}

	//edge.save("edge.PNG");

	uchar *pFill = region.bits();
	const uchar *pEdge = edge.bits();
	for(int yi=0; yi<h; yi++,pFill+=region.bytesPerLine(),pEdge+=edge.bytesPerLine())
	{
		uchar *pF = pFill;
		const uchar *pE = pEdge;
		for (int xi=0; xi<w; xi++,pF++,pE++)	
		{
			if(pE[0]==0 && pF[0]==curcnt) pF[0] = 0;
			else if(pE[0]!=0) pF[0] = pE[0];
		}
	}

	/// save region to texture
	_tex[T_FILL]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
		0, GL_ALPHA, GL_UNSIGNED_BYTE, region.bits());
}
void ImagePaint::updateEdgeAndSpline()
{
	/// get the edge texture from region texture
	QImage edgeImg;
	edgeFromRegion(m_regionImg,m_regionIndex,edgeImg);

	/// get the edge position from edge texture
	m_edgePos.clear();
	spline::findEdge(edgeImg,m_edgePos);

	/// compute the spline from the edge position (based on key points)
	spline::divideSpot sp;
	spline::splineFitting(m_edgePos,sp);
	sp.index = m_regionIndex;
	if(m_regionIncreasing)	/// spline for new region or not
		spline::addSpline(m_vSpline,sp,m_joinImg,m_joinSize);
	else	/// if not, change existed splines instead of adding
	{
		m_joinImg.fill(0);
		setTextureDefault(T_JOIN,0.0);

		for (int k=0; k<m_vSpline.size(); k++)
			if((k+1)!=m_regionIndex)
				updateJoinImage(m_vSpline[k],k+1,m_joinSize,m_joinImg);

		/// save region to texture
		_tex[T_JOIN]->bind();
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
			0, GL_ALPHA, GL_UNSIGNED_BYTE, m_joinImg.bits());
		spline::changeSpline(m_vSpline,sp,m_regionIndex,m_joinImg,m_joinSize);
	}

	if(!m_vSpline.empty())
		updateJoinImage(m_vSpline[m_vSpline.size()-1],m_regionIndex, m_joinSize, m_joinImg);
	/// save region to texture
	_tex[T_JOIN]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, m_imgSize.width(), m_imgSize.height(), 
		0, GL_ALPHA, GL_UNSIGNED_BYTE, m_joinImg.bits());
}
static void _draw_join_circle(QImage &img, const spline::posd &pos, int joinSize, int idx)
{
	int cx = int(pos.i+0.5);
	int cy = int(pos.j+0.5);
	uchar *pI = img.bits();

	int top = max(cy-joinSize,0);
	int bottom = min(cy+joinSize,img.height()-1);
	for (int yi=top; yi<=bottom; yi++)
	{
		int left = max(cx-joinSize,0);
		int right = min(cx+joinSize,img.width()-1);
		int disty = (yi-cy)*(yi-cy);
		for (int xi=left; xi<=right; xi++)
		{
			int dist = disty + (xi-cx)*(xi-cx);
			if(dist > joinSize*joinSize)
				continue;
			if(img.pixelIndex(xi,yi)!=idx)
			{
				//pI[yi*img.width()+xi] = idx;
				img.setPixel(xi,yi,idx);
			}
		}
	}
}

void ImagePaint::updateJoinImage(const spline::divideSpot &sp, int index, int joinSize, QImage &img)
{
	int w=img.width();
	int h=img.height();
	img.setColor(index*2,qRgb(index*2,index*2,index*2));
	img.setColor(index*2+1,qRgb(index*2+1,index*2+1,index*2+1));

	uchar *pI = img.bits();
	for (int yi=0; yi<h; yi++)
		for(int xi=0; xi<w; xi++)
		{
			uchar *pv = pI + yi*w+xi;
			if(pv[0]==(index*2-1) || pv[0]==(index*2))
				pv[0] = 0;
		}

	if(!sp.vSpot.empty())
	{
		int internalN = m_keyInterval/2;
		/// mark internal keypoints : index*2
		for(int k=0; k<sp.vSpot.size(); k++)
		{				
			for (int t=1; t<=internalN; t++)
			{
				spline::posd samp = spline::samplingSpline(sp.vPara[k],double(t)/double(internalN));
				_draw_join_circle(img,samp,joinSize,index*2-1);
			}
		}

		/// mark ultimate keypoints : index*2 + 1
		for(int k=0; k<sp.vSpot.size(); k++)
			_draw_join_circle(img,spline::posd(double(sp.vSpot[k].i),double(sp.vSpot[k].j)),joinSize,index*2);
	}
}
void ImagePaint::setCurrRegion(int idx)
{ 
	m_regionIndex = idx;
	update();
}

void ImagePaint::loadSplineFile(){
	QString filename = QFileDialog::getOpenFileName(0,"Open spline file",
		QString("F:/data/snapshot/flowDesign"), "TXT(*.txt)");
	if(filename.isNull())
		return;

	std::ifstream inf(std::string(filename.toAscii()).c_str());
	if(!inf){
		std::cout << "input file cannot be created!" << std::endl;
		return;
	}

	/// clear all splines
	for(int k=0; k<m_vSpline.size(); k++)
		m_vSpline.clear();
	m_vSpline.clear();

	/// read in data
	std::string str;
	int sz = 0;
	inf >> str >> sz;
	m_vSpline.resize(sz);
	for(int k=0; k<sz; k++)
		inf >> m_vSpline[k];

	inf.close();
}
void ImagePaint::saveSplineFile(){
	QString filename = QFileDialog::getSaveFileName(0,"Save spline file",
		QString("F:/data/snapshot/flowDesign"), "TXT(*.txt)");
	if(filename.isNull())
		return;

	std::ofstream outf(std::string(filename.toAscii()).c_str());
	if(!outf){
		std::cout << "output file cannot be open!" << std::endl;
		return;
	}

	/// write out data
	outf << "spline= " << m_vSpline.size() << endl;
	for(int k=0; k<m_vSpline.size(); k++)
		outf << m_vSpline[k];

	outf.close();
}

////////////////////////////////////////////////////////// vector field computation
static void _gradient_from_distance(const float *dist, const QImage &regionImg, int idx, float *grad)
{
	int w = regionImg.width();
	int h = regionImg.height();

#define _DTP(x,y)  ( dist+(y)*(w)+(x) )

	float ww[5] = {-1.0f/12.0f, -8.0f/12.0f, 0, 8.0f/12.0f, 1.0f/12.0f};
	float *fGrad = grad;
	for(int yi=0; yi<h; yi++,fGrad+=4*w)
	{
		float *fG = fGrad;
		int yw[5] = {max(yi-2,0), max(yi-1,0), 0, min(yi+1,h-1), min(yi+2,h-1)};
		for (int xi=0; xi<w; xi++,fG+=4)
		{
			if(regionImg.pixelIndex(xi,yi)==idx)
			{
				/// compute gradient
				int xw[5] = { max(xi-2,0), max(xi-1,0), 0, min(xi+1,w-1), min(xi+2,w-1)};

				fG[0] = fG[1] = 0;
				for(int k=0; k<5; k++)
				{
					fG[0] +=  (*_DTP(xw[k],yi))*ww[k];
					fG[1] +=  (*_DTP(xi,yw[k]))*ww[k];
				}				
				fG[2] = *_DTP(xi,yi);	/// distance
				fG[3] = idx;	/// store the region index
			}			
		}
	}
#undef _DTP
}
static void _gauss_smooth(const float *src, int fsize, const QImage &regionImg, int idx, float *dest,bool hFilter)
{
	int w=regionImg.width();
	int h=regionImg.height();

#define _SRCP(x,y)  ( src+(y)*(w)+(x) )
	/// compute the weights
	float sigma2 = float(fsize*fsize)*2.0/9.0;
	float *wet = new float[fsize*2+1];
	float wetSum = 0.0;
	for(int k=-fsize; k<=fsize; k++)
	{
		float val = exp(-float(k*k)/sigma2);
		wetSum += val;
		wet[k+fsize] = val;
	}
	/// normalize the weights
	for(int k=-fsize; k<=fsize; k++)
		wet[k+fsize] = wet[k+fsize]/wetSum;

	/// apply the 1D Gauss filter
	float *fDest = dest;
	for (int yi=0; yi<h; yi++,fDest+=w)
	{
		float *fD = fDest;
		for (int xi=0; xi<w; xi++,fD++)
		{
			/// for pixels in the current region only
			if(regionImg.pixelIndex(xi,yi)==idx)	
			{
				fD[0] = 0;
				for(int k=-fsize; k<=fsize; k++)
				{
					if(hFilter)		/// horizontal filter 
					{
						int xx = min(max(xi+k,0),w-1);
						xx = regionImg.pixelIndex(xx,yi)==idx ? xx : xi;	/// not use pixel out of the region
						fD[0] += (*_SRCP(xx,yi)) * wet[k+fsize];
					}
					else			/// vertical filter
					{
						int yy = min(max(yi+k,0),h-1);
						yy = regionImg.pixelIndex(xi,yy)==idx ? yy : yi;	/// not use pixel out of the region
						fD[0] += (*_SRCP(xi,yy)) *wet[k+fsize];
					}
				}
			}
		}
	}
#undef _SRCP
}
void ImagePaint::PedroDistanceTransform(const QImage &edgeImg, const QImage &regionImg, float *dest, int idx)
{
	int w = edgeImg.width();
	int h = edgeImg.height();

	TImage<uchar> *boundary = new TImage<uchar>(w,h);
	for(int yi=0; yi<h; yi++)
		for(int xi=0; xi<w; xi++)
			boundary->access[yi][xi] = edgeImg.pixelIndex(xi,yi);

	TImage<float> *distance = dt(boundary, uchar(idx) );
#if 0
	memcpy(dest,distance->data,sizeof(float)*w*h);	// square distance
#else
	float maxDist = 0.0;
	for(int yi=0; yi<h; yi++)
		for(int xi=0; xi<w; xi++)
		{
			const int k = yi*w+xi;
			dest[k] = sqrt(distance->data[k]);			// distance
			if(regionImg.pixelIndex(xi,yi)==idx)
				maxDist = dest[k]>maxDist ? dest[k]:maxDist;
		}
	if(maxDist!=0.0)	
		for(int yi=0; yi<h; yi++)
			for(int xi=0; xi<w; xi++)		// normalization
				if(regionImg.pixelIndex(xi,yi)==idx)
					dest[yi*w+xi] /= maxDist;
#endif
}
void ImagePaint::computeFlowFromEdge(const QImage &edgeImg, const QImage &regionImg, int idx)
{
	int w = m_images[0].width();
	int h = m_images[0].height();
	float *fdist = new float[w*h];

#if 0	/// geodesic distance transform
	//m_dist.GetProb(m_strokeImg.bits(), m_strokeImg.bytesPerLine(), fdest,w,GSM_FORE,m_regionIndex);
	m_dist.GetProb(edgeImg.bits(), edgeImg.bytesPerLine(), fdist,w,GSM_FORE,255);
#else	/// Pedro Felzenszwalb's method (distance transform)
	PedroDistanceTransform(edgeImg,regionImg,fdist,idx);
#endif

	
#if 1	/// to  smooth the distance map
	float *fTemp = new float[w*h];
	memset(fTemp,0,sizeof(float)*w*h);
	_gauss_smooth(fdist,6,regionImg,idx,fTemp,true);
	_gauss_smooth(fTemp,6,regionImg,idx,fdist,false);
	delete []fTemp;
#endif

	/// compute gradient from distance map, update the T_F_EDGE texture
	float *grad = new float[w*h*4];
	_tex[T_F_EDGE]->bind();
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,grad);	
	_gradient_from_distance(fdist,regionImg,idx,grad);
	_tex[T_F_EDGE]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, w, h, 0, GL_RGBA, GL_FLOAT, grad);

	delete []grad;
	delete []fdist;	
}
static float _RBF_FLOW(const UserStroke &stroke, int maxCnt, const QPoint &pos, QPointF &fgrad)
{
	vector<float>	vDist(maxCnt);
	vector<int>		vIdx(maxCnt);

#define _DIST(x0,x1)  ((x0.x()-x1.x())*(x0.x()-x1.x()) + (x0.y()-x1.y())*(x0.y()-x1.y()))
	/// adding the first maxCnt distance
	for (int k=0; k<maxCnt; k++)
	{
		vDist[k] = _DIST(stroke.m_vPos[k],pos);
		vIdx[k] = k;
	}

	/// sorting
	for (int k=1; k<maxCnt; k++)
	{
		float dis = vDist[k];
		for(int i=k-1; i>=0; i--)
		{
			if(dis<vDist[i])
			{
				swap(vDist[i+1],vDist[i]);
				swap(vIdx[i+1],vIdx[i]);
			}
			else
				break;
		}
	}

	/// adding other distance
	for(int k=maxCnt; k<stroke.m_vPos.size(); k++)
	{
		float dis = _DIST(stroke.m_vPos[k],pos);
		if(dis<vDist[maxCnt-1])
		{
			vDist[maxCnt-1] = dis;
			vIdx[maxCnt-1] = k;
		}
		for(int i=1; i<maxCnt; i++)
		{
			if(dis<vDist[maxCnt-1-i])
			{
				swap(vDist[maxCnt-i],vDist[maxCnt-1-i]);
				swap(vIdx[maxCnt-i],vIdx[maxCnt-1-i]);
			}
			else
				break;
		}
	}

	/// compute gradient 
	float wetSum = 0.0;
	fgrad = QPointF(0,0);
	for(int k=0; k<maxCnt; k++)
	{
		float wet = exp(-sqrtf(float(vDist[k]))/50.0f)*10000.0;
		fgrad += stroke.m_vTangent[vIdx[k]]*wet;
		wetSum += wet;
	}
	fgrad /= wetSum;

#undef _DIST
	return sqrtf(vDist[0]);	/// return mininal distance
}
void ImagePaint::computeFlowFromUserStroke(const vector<UserStroke> &vstroke, const QImage &regionImg, int idx)
{
	int w = regionImg.width();
	int h = regionImg.height();
	
	/// get strokse with current index
	UserStroke tmpStroke(idx);
	for (int k=0; k<vstroke.size(); k++)
		if(vstroke[k].m_index==idx)
			tmpStroke.combine(vstroke[k]);

	/// compute the flow using #nearCnt tangents
	const int nearCnt = 5;
	int ssz = tmpStroke.m_vPos.size();
	const int maxCnt = min(nearCnt,ssz);
	const uchar *pReg = regionImg.bits();

	float *grad = new float[w*h*4];
	_tex[T_F_USER]->bind();
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,grad);	
	float *pGrad = grad;
	float maxDist = 0.0;
	for (int yi=0; yi<h; yi++,pReg+=regionImg.bytesPerLine(),pGrad+=w*4)
	{
		const uchar *pR = pReg;
		float *pG = pGrad;
		for (int xi=0; xi<w; xi++,pR++,pG+=4)
		{
			if(pR[0]==idx || (pR[0]==0 && idx==m_backgroudnIndex))
			{
				QPointF fgrad;
				float dist = _RBF_FLOW(tmpStroke,maxCnt,QPoint(xi,yi),fgrad);
				maxDist = dist>maxDist ? dist:maxDist;
				pG[0] = float(-fgrad.y());
				pG[1] = float(fgrad.x());
				pG[2] = dist;//20.0*exp(-dist/10.0) + 0.5;		/// magnitude
				pG[3] = pR[0];
			}
		}
	}

	if(maxDist!=0.0)
	{
		pGrad = grad;
		for(int yi=0; yi<h; yi++)		// normalization
			for(int xi=0; xi<w; xi++)
				if(regionImg.pixelIndex(xi,yi)==idx)
					pGrad[(yi*w+xi)*4+2] /= maxDist;
	}
	
	_tex[T_F_USER]->bind();
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, w, h, 0, GL_RGBA, GL_FLOAT, grad);
	delete []grad;		
}

