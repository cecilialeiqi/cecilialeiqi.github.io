#ifndef TEXTURE_PARAMS_H
#define TEXTURE_PARAMS_H

#include "gpuDLL.h"
#include <glew.h>
#include <gl.h>

namespace gpu {

  class GPU_API TextureParams {
  public:
    TextureParams(const TextureParams &tp);
    TextureParams(GLint minfilter = GL_LINEAR,
		  GLint maxfilter = GL_LINEAR,
		  GLint wrapr     = GL_CLAMP_TO_EDGE,
		  GLint wraps     = GL_CLAMP_TO_EDGE,
		  GLint wrapt     = GL_CLAMP_TO_EDGE,
		  GLint mode      = GL_REPLACE);
    
    ~TextureParams() {}
    
    inline void setMinfilter(GLint minfilter) {_minfilter = minfilter;}
    inline void setMaxfilter(GLint maxfilter) {_maxfilter = maxfilter;}
    inline void setWrapr    (GLint wrapr    ) {_wrapr     = wrapr;    }
    inline void setWraps    (GLint wraps    ) {_wraps     = wraps;    }
    inline void setWrapt    (GLint wrapt    ) {_wrapt     = wrapt;    }
    inline void setMode     (GLint mode     ) {_mode      = mode;     }

    inline GLint minfilter() const {return _minfilter;}
    inline GLint maxfilter() const {return _maxfilter;}
    inline GLint wrapr    () const {return _wrapr;    }
    inline GLint wraps    () const {return _wraps;    }
    inline GLint wrapt    () const {return _wrapt;    }
    inline GLint mode     () const {return _mode;     }

  protected:
    GLint _minfilter;
    GLint _maxfilter;
    GLint _wrapr;
    GLint _wraps;
    GLint _wrapt;
    GLint _mode;
  };

} // gpu namespace 

#endif // TEXTURE_PARAMS_H
