#ifndef TIFF_IMAGEIO_H
#define TIFF_IMAGEIO_H

#include <image.h>

#include <vector>
#include <string>

namespace image {

  class IMAGE_API TIFFImageIO {
  public:
    static std::vector<std::string> getExtensions();
    static Image *createImage(const std::string &filename);
    static bool   saveImage(const Image &img,const std::string &filename);
  };

} // image namespace 

#endif // TIFF_IMAGEIO_H
