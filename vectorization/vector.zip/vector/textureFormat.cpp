#include <textureFormat.h>
#include <assert.h>

namespace gpu {

  TextureFormat::TextureFormat(GLenum  target,
                               GLsizei width,
                               GLsizei height,
                               GLenum  internalformat,
                               GLenum  format,
                               GLenum  type,
                               GLsizei depth,
                               int     mipmapmode,
                               GLint   level,
                               GLint   border)
    : _target(target),
      _width(width),
      _height(height),
      _internalformat(internalformat),
      _format(format),
      _type(type),
      _depth(depth),
      _mipmapmode(mipmapmode),
      _level(level),
      _border(border) {

    //assert(_level!=0 && _mipmapmode!=MIPMAP_MANUAL);

  }

  TextureFormat::TextureFormat(const TextureFormat &tf)
    : _target(tf.target()),
      _width(tf.width()),
      _height(tf.height()),
      _internalformat(tf.internalformat()),
      _format(tf.format()),
      _type(tf.type()),
      _depth(tf.depth()),
      _mipmapmode(tf.mipmapmode()),
      _level(tf.level()),
      _border(tf.border()) {

  }

} // gpu namespace 
