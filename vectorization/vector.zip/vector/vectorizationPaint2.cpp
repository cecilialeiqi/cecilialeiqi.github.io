#include "vectorizationPaint.h"
#include <math.h>

void ImagePaint::computeSkeletonGraph(skeleton::SkeletonGraph &sktGraph)
{
	//start point has been pushed back into sktGraph

	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;
	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);

	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	/////////////////////////////////////////////// tracing along the vector field
	
	///a stack to record the junction points with edges haven't been searched
	vector<skeleton::Vertex> vertexRecord;//second one means angle
    vector<QPointF> angleRecord;

	/// get the original direction
	QPointF startPos=QPointF(sktGraph.m_vVertex[0].m_pos.x(), sktGraph.m_vVertex[0].m_pos.y());
	const float * tang=centerDirection(m_imgSize.width(),m_imgSize.height(),4,startPos.x(),startPos.y(),pGrad,pGradS);
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(-tang[0],-tang[1]));//make sure it goes both ways
	vertexRecord.push_back(sktGraph.m_vVertex[0]);
	angleRecord.push_back(QPointF(tang[0],tang[1]));

	while(!vertexRecord.empty())
	{
		QPointF pos=vertexRecord[vertexRecord.size()-1].m_pos;
		vertexRecord.pop_back();
		QPointF angle=angleRecord[angleRecord.size()-1];
		angleRecord.pop_back();
		
		skeleton::Edge m_edge=tracking(pos.x(),pos.y(),angle.x(),angle.y(), m_imgSize.width(), m_imgSize.height(), 4, pGrad, pGradS,vertexRecord,angleRecord);
		if (m_edge.m_vPoint.size()>1)
		{
			sktGraph.m_vEdge.push_back(m_edge);
			int edgeSz=sktGraph.m_vEdge.size();
			int pointSz=sktGraph.m_vEdge[edgeSz-1].m_vPoint.size();
			QPointF m_jPoint=sktGraph.m_vEdge[edgeSz-1].m_vPoint[pointSz-1];
			sktGraph.m_vVertex.push_back(skeleton::Vertex::Vertex(m_jPoint,true));

		}

	}

	
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;
}

int _clamp(int vmin, int vmax, int v)
{
	return min(max(v,vmin), vmax);
}
float module(float x,float y)
{
	return sqrt(double(x*x+y*y));
}
bool judgeJunctionArea(float *leftPos,float *rightPos,int cnt)
{
	int i;
	for (i=0;i<=8;i+=2)
	{
		if (leftPos[i]!=0) break;
	}
	float leftx=leftPos[8]-leftPos[i];
	float lefty=leftPos[9]-leftPos[i+1];
	for (i=0;i<=8;i+=2)
	{
		if (rightPos[i]!=0) break;
	}
	float rightx=rightPos[8]-rightPos[i];
	float righty=rightPos[9]-rightPos[i+1];
	float cosine = (leftx*rightx + lefty*righty)/module(leftx,lefty)/module(rightx,righty);
	if (abs(cosine)<sqrt(double(3))/2)//cos30
		return true;//directions we got from left and right boundaries are too different ==> junction area
	return false;
}

const float* getDirection(int w, int h, int cn, const float*flow,  int px, int py)
{
	const float *f = flow + _clamp(0,h-1,/*h-1-*/py)*w*cn + _clamp(0,w-1,px)*cn;
	return f;
}

bool isInImage(float px, float py, int w, int h)
{
	return (px>=0.0) && (px<=float(w-1)) && (py>=0.0) && (py<=float(h-1));
}

const float* ImagePaint::centerDirection(int w, int h, int cn, float px, float py, float* grad, float *flow)
{
	float stepPos[8];
	const int proWidth = 12;
	tracking::findStepPosition(stepPos,px,py,w,h,proWidth, grad ,flow);
	const float *fleft = getDirection(w, h, 4,flow,stepPos[0],stepPos[1]);
	const float *fright = getDirection(w,h, 4,flow,stepPos[4],stepPos[5]);
	float fleftx=fleft[1];
	float flefty=-fleft[0];
	if (!isInImage(px+fleftx,py+flefty,w,h))
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	float frightx=fright[1];
	float frighty=-fright[0];
	if (!isInImage(px+frightx,py+frighty,w,h))
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (fleftx*frightx+flefty*frighty<0)
	{
		frightx=-frightx;
		frighty=-frighty;
	}
	float tang[2];
	tang[0]=(fleftx+frightx)/2.0;
	tang[1]=(flefty+frighty)/2.0;
	return tang;
}
void findBoundary(float *stepPos, float px, float py, int w, int h,float tangx,float tangy,
	int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);

	int distMax = 0;
	float magMax = 0.0;
	bool flag=false;
	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*tangy);
		int yy = int(float(pyi)+float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{//if out of the image, we try to keep the streamline still
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = k;
			magMax = mag;
		}
	}
	if (flag)
	{
		stepPos[0]=float(pxi);
		stepPos[1]=float(pyi);
		stepPos[4]=float(pxi);
		stepPos[5]=float(pyi);
		return;
	}
	stepPos[0] = -float(distMax)*tangy+float(pxi);
	stepPos[1] = float(distMax)*tangx+float(pyi);
	stepPos[2] = float(distMax);
	stepPos[3] = magMax;
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*tangy);
		int yy = int(float(pyi)-float(k)*tangx);
		if (!isInImage(xx,yy,w,h))
		{
			flag=true;
			break;
		}
		float mag = pGradS[4*(yy*w+xx)+3];
		if(mag>magMax)
		{
			distMax = -k;
			magMax = mag;
		}
	}
	if (flag)
	{
		stepPos[0]=float(pxi);
		stepPos[1]=float(pyi);
		stepPos[4]=float(pxi);
		stepPos[5]=float(pyi);
		return;
	}
	stepPos[4] = -float(distMax)*tangy+float(pxi);
	stepPos[5] = float(distMax)*tangx+float(pyi);
	stepPos[6] = float(distMax);
	stepPos[7] = magMax;
}

bool judgeEdgeEnd(float px,float py,int w,int h, int radius,QImage m_image)
{
	///
	int totalPixel=0;
	int darkPixel=0;
	for (float angle=0;angle<2*3.14159;angle+=0.05)
	{
		int x=int(px+radius*sin(angle)+0.5);
		int y=int(py+radius*cos(angle)+0.5);
		//cout<<grad[]
		if (isInImage(x,y,w,h))
		{
			totalPixel++;
			if (qRed(m_image.pixel(x,y))<50) darkPixel++;
		    
		}
		//cout<<qRed(m_image.pixel(x,y))<<' ';
	}
	cout<<float(darkPixel)/float(totalPixel)<<endl;
	if (float(darkPixel)/float(totalPixel)>0.7) return true;
	return false;
}

void findStepPosition(float *stepPos, float px, float py, int w, int h,
					  int proWidth, const float *pGradS)
{
	const int pxi = int(px+0.5);
	const int pyi = int(py+0.5);
	const float *pGS = pGradS + 4*(pyi*w+pxi);
	
	int distMax = 0;
	float magMax = 0.0;

	/// maximal magnitude on the positive side
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)+float(k)*pGS[0]);
		int yy = int(float(pyi)+float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(mag>magMax)
			{
				distMax = k;
				magMax = mag;
			}
		}
	}
	if (distMax==0) 
	{
		stepPos[0]=-1;
		stepPos[1]=-1;
	}else
	{
		stepPos[0] = float(distMax)*pGS[0]+float(pxi);
		stepPos[1] = float(distMax)*pGS[1]+float(pyi);
	}
	distMax = 0;
	magMax = 0.0;
	/// maximal magnitude on the negative side	
	for(int k=0; k<=proWidth; k++)
	{
		int xx = int(float(pxi)-float(k)*pGS[0]);
		int yy = int(float(pyi)-float(k)*pGS[1]);
		if (isInImage(xx,yy,w,h))
		{
			float mag = pGradS[4*(yy*w+xx)+3];
			if(mag>magMax)
			{
				distMax = -k;
				magMax = mag;
			}
		}
	}
	if (distMax==0)
	{
		stepPos[4]=-1;
		stepPos[5]=-1;
	}else
	{
		stepPos[4] = float(distMax)*pGS[0]+float(pxi);
		stepPos[5] = float(distMax)*pGS[1]+float(pyi);
	}
}

skeleton::Edge ImagePaint::tracking(float px, float py,float tangx, float tangy, int w, int h, int cn, float *grad, float *flow, vector<skeleton::Vertex> &vertexRecord,vector<QPointF> &angleRecord)
{
	bool stop=false;
	skeleton::Edge pos;//(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		return pos;
	}

	int cnt = 0;
	float seedx = px;
	float seedy = py;
	float prevTangx = tangx;
	float prevTangy = tangy;
	float stepPos[8];
	//pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	const int proWidth = 8;
	float leftPos[10]={0};
	float rightPos[10]={0};
	
	//first step: get out of the junction area, Ӧ���ȸ�������ĳһ������һ���ٽ���tracking...
	findStepPosition(stepPos,px,py,w,h,proWidth,flow);
	const float *fleft = getDirection(w, h, 4,flow,stepPos[0],stepPos[1]);
	const float *fright = getDirection(w,h, 4,flow,stepPos[4],stepPos[5]);
	float fleftx=fleft[1];
	float flefty=-fleft[0];
	float lcos=(fleftx*tangx+flefty*tangy)/module(fleftx,flefty)/module(tangx,tangy);
	if (lcos<0)
	{
		fleftx= -fleftx;
		flefty= -flefty;
	}
	float frightx=fright[1];
	float frighty=-fright[0];
	float rcos=(frightx*tangx+frighty*tangy)/module(frightx,frighty)/module(tangx,tangy);
	if (rcos<0)
	{
		frightx= -frightx;
		frighty= -frighty;
	}
	if (lcos<rcos||!isInImage(stepPos[0],stepPos[1],w,h))//right way is better
	{
		/// trace starting from right step
		ImagePaint::trackingEdge(pos,stepPos[4],stepPos[5],frightx,frighty,w,h,cn,flow,10);
	    pos=pos+QPointF(px-stepPos[4],py-stepPos[5]);

		seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
		seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
		prevTangx=frightx;
		prevTangy=frighty;
	}else
	{
		/// trace starting from left step
		ImagePaint::trackingEdge(pos,stepPos[0],stepPos[1],fleftx,flefty,w,h,cn,flow,10);
		pos=pos+QPointF(px-stepPos[0],py-stepPos[1]);
		seedx=pos.m_vPoint[pos.m_vPoint.size()-1].x();
		seedy=pos.m_vPoint[pos.m_vPoint.size()-1].y();
		prevTangx=fleftx;
		prevTangy=flefty;
	}
	///new startPos and new angle

	while(!judgeJunctionArea(leftPos,rightPos,cnt) && isInImage(seedx,seedy,w,h))
	{	
		const float *fseed = centerDirection(w,h,cn,seedx,seedy,grad,flow);
		tangx = fseed[0];
		tangy = fseed[1];
		//rotateDirection(tangx, tangy, angle);
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += 2*tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += 2*tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

		///use left and right boundary to retract the streamline
		findBoundary(stepPos,seedx,seedy,m_imgSize.width(),
			m_imgSize.height(),tangx,tangy,proWidth, flow);
        if (isInImage(stepPos[0],stepPos[1],w,h)&&isInImage(stepPos[4],stepPos[5],w,h))
		{
			seedx=(stepPos[0]+stepPos[4])/2.0;
			seedy=(stepPos[1]+stepPos[5])/2.0;
		}
		pos.m_vPoint.push_back(QPointF(seedx,seedy));

		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;

		/// record the position of left and right boundary
		for (int i=1;i<=4;i++)
		{
			leftPos[2*i-2]=leftPos[2*i];
			leftPos[2*i-1]=leftPos[2*i+1];
			rightPos[2*i-2]=rightPos[2*i];
			rightPos[2*i-1]=rightPos[2*i+1];
		}
		if (stepPos[0]!=stepPos[4] || stepPos[1]!=stepPos[5]) //real boundaries
		{
			leftPos[8]=stepPos[0];
			leftPos[9]=stepPos[1];			
			rightPos[8]=stepPos[4];
			rightPos[9]=stepPos[5];

		}
//		cout<<stepPos[0]<<' '<<stepPos[1]<<endl;
//		cout<<stepPos[4]<<' '<<stepPos[5]<<endl;
//		cout<<endl;
		if  (judgeEdgeEnd(seedx,seedy,w,h,12,this->m_image))
		{
			stop=true;
			break;
		}
	}
	junctionCenter(seedx,seedy,stepPos[0],stepPos[1],stepPos[4],stepPos[5],tangx,tangy);

	//vertexRecord.push_back()
	if (!stop)//junction point
	{
		vertexRecord.push_back(skeleton::Vertex::Vertex(QPointF(seedx,seedy),true));
		const float *fleft=getDirection(w,h,cn,flow,stepPos[0],stepPos[1]);
		angleRecord.push_back(QPointF(fleft[1],-fleft[0]));
		const float *rleft=getDirection(w,h,cn,flow,stepPos[4],stepPos[5]);
		vertexRecord.push_back(skeleton::Vertex::Vertex(QPointF(seedx,seedy),true));
		angleRecord.push_back(QPointF(fright[1],-fright[0]));
	}

	return pos;
}

void junctionCenter(float px,float py,float leftx,float lefty,float rightx,float righty,float tx,float ty,int w,int h,float * flow)
{
	//���Ҹ���ǰ10
	int cnt=0;
	float seedx=leftx;
	float seedy=lefty;
	float prevTangx=tx;
	float prevTangy=ty;
	float leftx[11];
	float lefty[11];
	while( cnt < 10 && isInImage(seedx,seedy,w,h))
	{
		const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		float tangx = fseed[1];
		float tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

		leftx[cnt]=seedx;
		lefty[cnt]=seedy;
		
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}
	//����10����
	
	seedx=rightx;
	seedy=righty;
	float rightx[11];
	float righty[11];
	while( cnt < 10 && isInImage(seedx,seedy,w,h))
	{
		const float *fseed = getDirection(w,h,4,flow,int(seedx+0.5),int(seedy+0.5));
		float tangx = fseed[1];
		float tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);

		rightx[cnt]=seedx;
		righty[cnt]=seedy;
		
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}

}

void ImagePaint::trackingEdge(skeleton::Edge &pos, float px, float py,float &tangx, float &tangy, int w, int h, int cn, float *flow,int maxLen)
{
	//skeleton::Edge pos(QPointF(px,py));
	if(px<0 || py<0 || px>=w || py>=h)
	{
		cout << "seed should not out of the image." << endl;
		//return pos;
	}

	int cnt = 0;
	float seedx = float(px);
	float seedy = float(py);
	//const float *fcenter = getDirection(w,h,cn,flow,px,py);
	float prevTangx = tangx;
	float prevTangy = tangy;
	
	//pos.m_vPoint.push_back(QPointF(float(px),float(py)));
	while( cnt <maxLen && isInImage(seedx,seedy,w,h))
	{
		const float *fseed = getDirection(w,h,cn,flow,int(seedx+0.5),int(seedy+0.5));
		tangx = fseed[1];
		tangy = -fseed[0];
		float tangsign = tangx*prevTangx + tangy*prevTangy;
		if(tangsign<0.0)
		{
			tangx = -tangx;
			tangy= -tangy;
		}		
		seedx += tangx; //tangx>0.5?1: (tangx<-0.5?-1:0);
		seedy += tangy; //tangy>0.5?1: (tangy<-0.5?-1:0);
		
		float magMax=0;
		int distMax=0;
		for(int k=-3; k<=3; k++)
     	{
			int xx = int(float(seedx)+float(k)*fseed[0]);
			int yy = int(float(seedy)+float(k)*fseed[1]);
			if (isInImage(xx,yy,w,h))
			{
				float mag = flow[4*(yy*w+xx)+3];
				if(mag>magMax)
				{
					distMax = k;
					magMax = mag;
				}
			}
	    }
		seedx = float(distMax)*fseed[0]+float(seedx);
		seedy = float(distMax)*fseed[1]+float(seedy);
		pos.m_vPoint.push_back(QPointF(float(seedx),float(seedy)));
		prevTangx = tangx;
		prevTangy = tangy;
		cnt ++;
	}
	//return pos;
}