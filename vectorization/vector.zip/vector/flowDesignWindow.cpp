
#include "flowDesignWindow.h"
#include "param.h"
#include "paramui.h"

MainWindow *MainWindow::_mainWindow = NULL;

MainWindow::MainWindow() {
    setupUi(this);
    m_dirty = false;
	addAction(actionQuit);
	addAction(actionToolBox);
	addAction(actionFullScreen);
	addAction(actionReloadShader);

	//m_dockWidget->move(0,0);

    m_imagePaint->setFocus();

	m_selectitem->addItems(displayList);
	m_selectitem->setCurrentIndex(0);
	m_vboxTool->addWidget(m_selectitem);

	//////////////////////// set up the parameter part of the toolbox 
	/// add all the parameter units
//	new ParamEnum(this, "Interactive", 0, QString("Move|Zoom|Rotoscoping|Freehand|Segmentation"), m_imagePaint->toolModePtr());

	//new ParamInt(this, "smoothSize", 0, 1, 40, 1, m_imagePaint->smoothSizePtr());
	new ParamInt(this, "DiffSize", 5, 1, 40, 1, m_imagePaint->diffSizePtr());
	new ParamInt	(this, "streamLen", 150, 5, 500, 5, m_imagePaint->streamLenPtr());
	new ParamDouble	(this, "streamThre", 0.1, 0.0, 1.0, 0.01, m_imagePaint->streamThrePtr());
	new ParamInt(this, "strokeSize", 15, 1, 80, 1, m_imagePaint->strokeSizePtr());
	new ParamInt(this, "brushSize", 5, 1, 80, 1, m_imagePaint->brushSizePtr());
	new ParamInt(this, "brushSizeBack", 5, 1, 80, 1, m_imagePaint->brushSizeBackgroundPtr());
	new ParamInt(this, "keyInterval", 30, 5, 80, 1, m_imagePaint->keyIntervalPtr());
	new ParamInt(this, "joinSize", 4, 1, 25, 1, m_imagePaint->joinSizePtr());
	new ParamDouble	(this, "geodesicThres", 0.2, 0.0, 1.0, 0.01, m_imagePaint->geodesicThresPtr());
	

	QStringList paramList;
	paramList /*<< QString("smoothSize") */ <<QString("DiffSize") << QString("streamLen") 
		<< QString("streamThre")<< QString("strokeSize") << QString("brushSize") << QString("brushSizeBack") 
		<< QString("keyInterval") << QString("joinSize") << QString("geodesicThres");

	ParamUI *pui = new ParamUI(this, this, paramList);
	pui->setMinimumWidth(100);
	pui->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
	m_vboxTool->addWidget(pui);

	///////////////// add pushbutton
	QLabel *btnLabel = new QLabel(QString("Spline:"));
	m_editingBtn = new QPushButton(QString("Editing"));
	m_editingBtn->setCheckable(true);
	m_editingBtn->setChecked(false);
	connect(m_editingBtn,SIGNAL(toggled(bool)),m_imagePaint,SLOT(editingSpline(bool)));
	QPushButton *displayBtn = new QPushButton(QString("Display"));
	displayBtn->setCheckable(true);
	displayBtn->setChecked(true);
	connect(displayBtn,SIGNAL(clicked(bool)),m_imagePaint,SLOT(displaySpline(bool)));
	QHBoxLayout *hbLay = new QHBoxLayout();
	hbLay->addWidget(btnLabel);
	hbLay->addWidget(m_editingBtn);
	hbLay->addWidget(displayBtn);
	QWidget *splineWidget = new QWidget();
	splineWidget->setLayout(hbLay);
	m_vboxTool->addWidget(splineWidget);

	QPushButton *clearBtn = new QPushButton(QString("Clear"));
	connect(clearBtn,SIGNAL(clicked()),m_imagePaint,SLOT(clearAllDrawn()));
	QPushButton *loadBtn = new QPushButton(QString("Load"));
	connect(loadBtn,SIGNAL(clicked()),m_imagePaint,SLOT(loadSplineFile()));
	QPushButton *saveBtn = new QPushButton(QString("Save"));
	connect(saveBtn,SIGNAL(clicked()),m_imagePaint,SLOT(saveSplineFile()));
	QHBoxLayout *hbLay2 = new QHBoxLayout();
	hbLay2->addWidget(clearBtn);
	hbLay2->addWidget(loadBtn);
	hbLay2->addWidget(saveBtn);
	QWidget *splineWidget2 = new QWidget();
	splineWidget2->setLayout(hbLay2);
	m_vboxTool->addWidget(splineWidget2);

	QWidget *regionWgt = new QWidget;
	QHBoxLayout *regionLyt = new QHBoxLayout;
	QLabel *regionLbl = new QLabel("Region:");
	regionLyt->addWidget(regionLbl,2);
	m_regionCom = new QComboBox;
	regionLyt->addWidget(m_regionCom,4);
	connect(m_regionCom,SIGNAL(currentIndexChanged(int)),this,SLOT(regionComboboxChanged(int)));
	m_regionChk = new QCheckBox("++");
	m_regionChk->setCheckable(true);
	m_regionChk->setChecked(true);
	connect(m_regionChk,SIGNAL(clicked(bool)),this,SLOT(regionCheckboxClicked(bool)));
	regionLyt->addWidget(m_regionChk,1);
	m_overlapChk = new QCheckBox("Overlap?");
	m_overlapChk->setCheckable(true);
	m_overlapChk->setChecked(true);
	connect(m_overlapChk,SIGNAL(clicked(bool)),this,SLOT(overlapCheckboxClicked(bool)));
	regionLyt->addWidget(m_overlapChk,2);
	regionWgt->setLayout(regionLyt);
	m_vboxTool->addWidget(regionWgt);

	m_smoothMethodCombobox = new QComboBox();
	m_smoothMethodCombobox->addItem("Gaussian");
	m_smoothMethodCombobox->addItem("Bilateral");
	connect(m_smoothMethodCombobox,SIGNAL(currentIndexChanged(int)),m_imagePaint,SLOT(smoothMethodCombocChanged(int)));
	m_smoothSizeCombobox  = new QComboBox();
	for(int i=0; i<30; i++)
		m_smoothSizeCombobox->insertItem(i,QString("%1").arg(i));
	connect(m_smoothSizeCombobox,SIGNAL(currentIndexChanged(int)),m_imagePaint,SLOT(smoothSizeCombocChanged(int)));
	m_smoothCompute = new QPushButton("Compute");
	//m_smoothCompute->setCheckable(true);
	//m_smoothCompute->setChecked(false);
	connect(m_smoothCompute,SIGNAL(clicked()),m_imagePaint,SLOT(smoothComputeClicked()));
	QWidget *smoothWgt = new QWidget;
	QHBoxLayout *smoothLyt = new QHBoxLayout;
	smoothLyt->addWidget(m_smoothMethodCombobox);
	smoothLyt->addWidget(m_smoothSizeCombobox);
	smoothLyt->addWidget(m_smoothCompute);
	smoothWgt->setLayout(smoothLyt);
	m_vboxTool->addWidget(smoothWgt);

	m_backgroundBtn = new QPushButton("Set Background");
	m_backgroundBtn->setCheckable(true);
	m_backgroundBtn->setChecked(false);
	connect(m_backgroundBtn,SIGNAL(clicked()),m_imagePaint,SLOT(setBackground()));
	m_vboxTool->addWidget(m_backgroundBtn);

	QWidget *regionWgt2 = new QWidget;
	QHBoxLayout *regionLyt2 = new QHBoxLayout;

	regionWgt2->setLayout(regionLyt2);
	m_vboxTool->addWidget(regionWgt2);

	m_vboxTool->addStretch(100);
	/////////////////////////////// connection building
    connect(m_selectitem, SIGNAL(currentIndexChanged(int)), m_imagePaint, SLOT(onIndexChanged(int)));

    m_player = new VideoPlayer(this, ":/test.png");
    connect(m_player, SIGNAL(videoChanged(int)), this, SLOT(onVideoChanged(int)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), this, SLOT(setDirty2()));
    connect(m_player, SIGNAL(outputChanged(const QImage&)), m_imagePaint, SLOT(setImage(const QImage&)));
    connect(this, SIGNAL(imageChanged(const QImage&)), m_player, SLOT(setOutput(const QImage&)));

    m_videoControls->setFrameStyle(QFrame::NoFrame);
    m_videoControls->setAutoHide(true);
    connect(m_videoControls, SIGNAL(stepForward()), m_player, SLOT(stepForward()));
    connect(m_videoControls, SIGNAL(stepBack()), m_player, SLOT(stepBack()));
    connect(m_videoControls, SIGNAL(currentFrameTracked(int)), m_player, SLOT(setCurrentFrame(int)));
    connect(m_videoControls, SIGNAL(playbackChanged(bool)), m_player, SLOT(setPlayback(bool)));
    connect(m_videoControls, SIGNAL(trackingChanged(bool)), this, SLOT(setDirty()));

    connect(m_player, SIGNAL(videoChanged(int)), m_videoControls, SLOT(setFrameCount(int)));
    connect(m_player, SIGNAL(playbackChanged(bool)), m_videoControls, SLOT(setPlayback(bool)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), m_videoControls, SLOT(setCurrentFrame(int)));

	QObject::connect(actionAllSave, SIGNAL(triggered()), m_imagePaint, SLOT(saveAllPNG()));

	/// status bar
	statusBar()->showMessage(tr("WElCOME!"));

	m_statusMouseLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusMouseLabel);
	m_statusMouseLabel->setText("| Pos: (0,0)");

	m_statusZoomLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusZoomLabel);
	m_statusZoomLabel->setText("| Zoom: 100%");

	m_statusReslLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusReslLabel);
	m_statusReslLabel->setText("| Resl: 100%");
}
   

MainWindow::~MainWindow() {
}

void MainWindow::restoreSettings() {
    QSettings settings;
    restoreGeometry(settings.value("mainWindow/geometry").toByteArray());
    restoreState(settings.value("mainWindow/windowState").toByteArray());

    settings.beginGroup("imagePaint");
    m_imagePaint->restoreSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::restoreSettings(settings, this);
    settings.endGroup();

    m_player->restoreSettings(settings);
}

void MainWindow::closeEvent(QCloseEvent *e) {
    QSettings settings;
    settings.setValue("mainWindow/geometry", saveGeometry());
    settings.setValue("mainWindow/windowState", saveState());

    settings.beginGroup("imageView");
    m_imagePaint->saveSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::saveSettings(settings, this);
    settings.endGroup();

    m_player->saveSettings(settings);

    QMainWindow::closeEvent(e);
} 

void MainWindow::on_actionOpen_triggered() {
	m_player->open();
}

void MainWindow::on_actionAbout_triggered() {
    QMessageBox msgBox;
    msgBox.setWindowTitle("About");
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText(
        "<html><body>" \
        "<p><b>Sketch-based Drawing Tool</b><br/><br/>" \
        "Author: Jiazhou CHEN <br/>" \
        "Date: " __DATE__ "</p>" \
        "<p>This program is free software: you can redistribute it and/or modify " \
        "it under the terms of the GNU General Public License as published by " \
        "the Free Software Foundation, either version 3 of the License, or " \
        "(at your option) any later version.</p>" \
        "<p>This program is distributed in the hope that it will be useful, " \
        "but WITHOUT ANY WARRANTY; without even the implied warranty of " \
        "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the " \
        "GNU General Public License for more details.</p>" \

		"Parts of the framework of this software are copied and modified " \
		"from the source code of the softwares developed by: <br/>" \
		" Jan Eric Kyprianidis &lt;" \
		"<a href='http://www.kyprianidis.com'>www.kyprianidis.com</a> &gt; & <br/>" \
		" Romain Vergn &lt;" \
		"<a href='http://romain.vergne.free.fr'>http://romain.vergne.free.fr</a>&gt;<br/>" \
        /*"Related Publications:" \
        "<ul>" \
        "<li>" \
        "Kyprianidis, J. E., &amp; Kang, H. (2011). " \
        "Image and Video Abstraction by Coherence-Enhancing Filtering. " \
        "<em>Computer Graphics Forum</em>, 30(2), 593-602. " \
        "(Proceedings Eurographics 2011)" \
        "</li>" \
        "</ul>" \
        "<p>Test image courtesy of Ivan Mlinar @ flickr.com.</p>" \*/
        "</body></html>"
    );
    msgBox.setStandardButtons(QMessageBox::Ok);
    msgBox.exec();
}

//void MainWindow::on_actionSelectDevice_triggered() {
//    int current = 0;
//    cudaGetDevice(&current);
//    int N = CudaDeviceDialog::select(true);
//    if ((N >= 0) && (current != N)) {
//        QMessageBox::information(this, "Information", "Application must be restarted!");
//        qApp->quit();
//    }
//}

void MainWindow::on_actionRecord_triggered() {
    m_player->record();
}

void MainWindow::setFullScreen() {
	if(isFullScreen())
	{
		showNormal();
		m_menuBar->setVisible(true);
	}
	else
	{
		showFullScreen();
		m_menuBar->setVisible(false);
	}
}

void MainWindow::setDirty() {
    if (m_videoControls->isTracking()) {
        imageChanged(m_player->image());
    }
    else if (!m_dirty) {
        m_dirty = true;
        QMetaObject::invokeMethod(this, "process", Qt::QueuedConnection);
    }
}

void MainWindow::setDirty2() {
	if (m_videoControls->isTracking()) {
		imageChanged(m_player->image());
	}
	else /*if (!m_dirty)*/ {
		m_dirty = true;
		QMetaObject::invokeMethod(this, "process2", Qt::QueuedConnection);
	}
}

void MainWindow::process() {
    m_dirty = false;
    QImage src = m_player->image();
    if (src.isNull()) {
        m_result = src;
        imageChanged(image());
        return;
    }
    m_result = src;
//	m_imagePaint->setCurrentTool(*(m_imagePaint->toolModePtr()));
	m_imagePaint->refresh();
}

void MainWindow::process2() {
	m_dirty = false;
	QImage src = m_player->image();
	if (src.isNull()) {
		m_result = src;
		imageChanged(image());
		return;
	}
	m_result = src;
	imageChanged(image());
}

void MainWindow::onVideoChanged(int nframes) {
//    gpu_cache_clear();
    window()->setWindowFilePath(m_player->filename());
    window()->setWindowTitle(m_player->filename() + "[*]"); 
    actionRecord->setEnabled(nframes > 1);
}

void MainWindow::draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image) {
	view->draw(p,R,image);
}

void MainWindow::regionComboboxChanged(int regionInt)
{
	m_imagePaint->setCurrRegion(regionInt+1);
	if(m_regionCom->count()==0)
	{
		m_regionChk->setChecked(true);
		m_imagePaint->setRegionIncreasing(true);
	}
	m_imagePaint->refresh();
}
void MainWindow::regionCheckboxClicked(bool isRegion)
{
	m_imagePaint->setRegionIncreasing(isRegion);
	m_imagePaint->refresh();
}
void MainWindow::overlapCheckboxClicked(bool isRegion)
{
	m_imagePaint->setOverlap(isRegion);
	m_imagePaint->refresh();
}