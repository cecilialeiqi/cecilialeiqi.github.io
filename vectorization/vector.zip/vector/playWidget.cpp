#include "playWidget.h"
#include "animationWindow.h"


AnimationSettingDialog::AnimationSettingDialog(QWidget *parent)
:QDialog(parent)
{
	label = new QLabel(tr("Play &Time:"));
	lineEdit = new QLineEdit;
	label->setBuddy(lineEdit);

	repeatCheckBox = new QCheckBox(tr("&Repeat"));
	okButton = new QPushButton(tr("&OK"));
	closeButton = new QPushButton(tr("&Close"));

	connect(okButton, SIGNAL(clicked()),this, SLOT(accept()));
	connect(closeButton, SIGNAL(clicked()),this, SLOT(reject()));

	QHBoxLayout *timeLayout = new QHBoxLayout;
	timeLayout->addWidget(label);
	timeLayout->addWidget(lineEdit);

	QHBoxLayout *lastLayout = new QHBoxLayout;
	lastLayout->addWidget(okButton);
	lastLayout->addWidget(closeButton);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(timeLayout);
	//mainLayout->addLayout(repeatLayout);
	mainLayout->addWidget(repeatCheckBox);
	mainLayout->addLayout(lastLayout);
	setLayout(mainLayout);

	setWindowTitle(tr("Setting"));
	setFixedSize(sizeHint());
}

void AnimationSettingDialog::setDefaultSetting(const AnimationSetting& setting)
{
	lineEdit->setText(QString::number(setting._millisec));
	repeatCheckBox->setChecked(setting._isRepeat);
}

AnimationSetting AnimationSettingDialog::getSetting()
{
	AnimationSetting setting;
	setting._isRepeat = repeatCheckBox->isChecked();
	QString text = lineEdit->text();
	if(!text.isEmpty())
	{
		bool ok;
		setting._millisec = text.toInt(&ok, 10);
	}
	return setting;
}

//////////////////////////////////////////////////////////////////////////
PlayWidget::PlayWidget(QWidget *parent)
	:QWidget(parent)
{

	stopIcon	= new QIcon(QString("icon/stop.PNG"));
	playIcon	= new QIcon(QString("icon/play.PNG"));
	nonrIcon	= new QIcon(QString("icon/nonr.PNG"));
	saveIcon	= new QIcon(QString("icon/save.PNG"));
	optionIcon	= new QIcon(QString("icon/option.PNG"));

	_isPlaying = false;

	_timer = new QTimer(this);
	connect(_timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
	_timer->stop();

	QHBoxLayout *playLayer = new QHBoxLayout();

	frmLabel = new QLabel();
	frmLabel->setFixedWidth(40);
	frmLabel->setText("  0/  0");
	
	playBtn = new QPushButton();
	playBtn->setCheckable(true);
	playBtn->setFixedWidth(23);
	playBtn->setIcon(*playIcon);
	playBtn->setStatusTip(tr("Play Button"));

	playSld = new QScrollBar(Qt::Horizontal);
	

	keyframeBox = new QComboBox();
	keyframeBox->setFixedWidth(75);
	setMaxKeyframeBox(2);

	optionBtn = new QPushButton();
	optionBtn->setCheckable(true);
	optionBtn->setFixedWidth(23);
	optionBtn->setIcon(*optionIcon);
	optionBtn->setStatusTip(tr("Option Button"));

	saveBtn = new QPushButton();
	saveBtn->setCheckable(true);
	saveBtn->setFixedWidth(23);
	saveBtn->setIcon(*saveIcon);
	saveBtn->setStatusTip(tr("Save Button"));

	playLayer->addWidget(frmLabel);
	playLayer->addWidget(playBtn);
	playLayer->addWidget(playSld);
	playLayer->addWidget(optionBtn);
	playLayer->addWidget(keyframeBox);
	playLayer->addWidget(saveBtn);


	connect(playSld,SIGNAL(valueChanged(int)),this,SLOT(sliderValueChanged(int)));
	connect(playBtn,SIGNAL(clicked()),this,SLOT(playButtonClicked()));
	connect(saveBtn,SIGNAL(clicked()),this,SLOT(saveButtonClicked()));
	connect(keyframeBox,SIGNAL(currentIndexChanged(int)),this,SLOT(KeyframeBoxChanged(int)));
	connect(optionBtn,SIGNAL(clicked()),this,SLOT(optionButtonClicked()));

	this->setLayout(playLayer);
}

PlayWidget::~PlayWidget()
{
}

void PlayWidget::updateLabel(int currFrm, int nFrm)
{
	QString ls = QString("%1/%2").arg(currFrm,3,10,QChar(' ')).arg(nFrm,3,10,QChar(' '));
	frmLabel->setText(ls);
}
void PlayWidget::updateSilder(int currFrm)
{
	int nFrm = playSld->maximum();
	int c = currFrm>nFrm ? nFrm:currFrm;
	playSld->setValue(c);
	updateLabel(c,nFrm);
}
void PlayWidget::updateSilder(int currFrm, int nFrm)
{
	playSld->setMaximum(nFrm-1);
	playSld->setValue(currFrm);
	updateLabel(currFrm,nFrm);
}

////////////////////////////////////////////////////////////////////////// SLOT
void PlayWidget::sliderValueChanged(int val)
{
	updateSilder(val);
	MainWindow::getInstance()->setFrame(val);
}
void PlayWidget::nextFrame()
{
	int frmIdx = playSld->value();
	int frmMax = playSld->maximum();
	frmIdx++;
	if(frmIdx>frmMax)
	{
		if(_aniSetting._isRepeat)	frmIdx = 0;
		else			frmIdx--;
	}
	playSld->setValue(frmIdx);
}
void PlayWidget::playButtonClicked()
{
	_isPlaying = playBtn->isChecked();
	if(_isPlaying==true)
	{
		playBtn->setIcon(*stopIcon);
		_timer->start(_aniSetting._millisec);
	}
	else
	{
		playBtn->setIcon(*playIcon);
		_timer->stop();
	}
}
void PlayWidget::saveButtonClicked()
{
	if(!saveBtn->isChecked())
	{
		MainWindow::getInstance()->setAnimationStatus(false);
		return;
	}

	string DIRECTORY = "F:/data/video";

	QMessageBox msgBox;
	msgBox.setWindowTitle(QString("Output Type Choosing"));
	msgBox.setText(QString("What type your outputing video is?"));
	QPushButton *inputVideoButton = msgBox.addButton(tr("Video Type"),QMessageBox::YesRole);
	QPushButton *inputImageSetButton = msgBox.addButton(tr("Image Set Type"),QMessageBox::NoRole);
	QPushButton *abortButton = msgBox.addButton(QMessageBox::Abort);
	msgBox.exec();

	QString filename;
	if(msgBox.clickedButton() == inputVideoButton)
		filename = QFileDialog::getSaveFileName(0,"Save Video",QString(DIRECTORY.c_str()));
	else if(msgBox.clickedButton() == inputImageSetButton)
		filename = QFileDialog::getExistingDirectory(0,"Save Image Set",QString(DIRECTORY.c_str()));
	else
		return;

	/// todo: save the animation
	/// save the image sequence
	MainWindow::getInstance()->setAnimationStatus(true);
	MainWindow::getInstance()->saveAnimationName(filename);
}

void PlayWidget::optionButtonClicked()
{
	AnimationSettingDialog settingDlg;
	settingDlg.setDefaultSetting(_aniSetting);
	if( settingDlg.exec() )
	{
		_aniSetting = settingDlg.getSetting();
	}
}
void PlayWidget::setCurrentKeyframeBox(int idx)
{
	keyframeBox->setCurrentIndex(idx);
}

void PlayWidget::setMaxKeyframeBox(int idx)
{
	keyframeBox->setMaxCount(idx);
	keyframeBox->clear();
	QStringList lt;
	for(int i=0; i<idx; i++)
	{
		lt << QString("Key: %1").arg(i+1);
	}
	keyframeBox->addItems(lt);
}

void PlayWidget::KeyframeBoxChanged(int idx)
{
	MainWindow::getInstance()->setCurrentKeyFrame(idx);
}