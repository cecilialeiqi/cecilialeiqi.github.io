
#include "drawingWindow.h"
#include "param.h"
#include "paramui.h"

MainWindow *MainWindow::_mainWindow = NULL;

MainWindow::MainWindow() {
    setupUi(this);
    m_dirty = false;
	addAction(actionQuit);
	addAction(actionToolBox);
	addAction(actionFullScreen);
	addAction(actionReloadShader);

	m_dockWidget->move(0,0);

    m_imagePaint->setFocus();

	m_selectitem->addItems(displayList);
	m_selectitem->setCurrentIndex(0);

	//////////////////////// set up the button part of the toolbox 
	QGridLayout *toolLayout = new QGridLayout;
	int iconSize = 40;
	for(int k=0; k<toolList.size(); k++)
	{
		/// add tool buttons in toolbox
		m_toolButton[k] = new ToolButton(iconSize,iconSize,toolList[k]);
		m_toolButton[k]->setObjectName(toolList[k]);
		m_toolButton[k]->setToolTip(QString(toolList[k]).append(" Tool: ").append(toolTipList[k]));
		toolLayout->addWidget(m_toolButton[k],k/4,k%4);
		/// add tool munu in menubar
		QAction *toolAct = menuTool->addAction(toolList[k]);
		toolAct->setCheckable(true);
		/// intialize the first tool
		if(k==0)
		{
			m_toolButton[0]->setChecked(true);
			toolAct->setChecked(true);
			m_toolLabel->setText(toolList[k]);
		}
		connect(toolAct, SIGNAL(toggled(bool)), m_toolButton[k], SLOT(onChecked(bool)));
	}
	m_toolWidget->setLayout(toolLayout);
	m_vboxTool->addWidget(m_toolWidget);

	/////////////////////// set up  the parameter part of the gradient field smoothing
	toolTypePushButton[0] = new QPushButton();
	toolTypePushButton[0]->setIcon(QIcon(QString("../icon/contour.png")));
	toolTypePushButton[0]->setIconSize(QSize(50,50/2));
	toolTypePushButton[0]->setCheckable(true);
	toolTypePushButton[0]->setChecked(true);
	connect(toolTypePushButton[0], SIGNAL(clicked(bool)), this, SLOT(setContourTool(bool)));

	toolTypePushButton[1] = new QPushButton();
	toolTypePushButton[1]->setIcon(QIcon(QString("../icon/interior.png")));
	toolTypePushButton[1]->setIconSize(QSize(50,50/2));
	toolTypePushButton[1]->setCheckable(true);
	connect(toolTypePushButton[1], SIGNAL(clicked(bool)), this, SLOT(setInteriorTool(bool)));

	QHBoxLayout *buttonLayout = new QHBoxLayout();
	buttonLayout->addWidget(toolTypePushButton[0]);
	buttonLayout->addWidget(toolTypePushButton[1]);
	QWidget *buttonWidget = new QWidget();
	buttonWidget->setLayout(buttonLayout);
	m_vboxTool->addWidget(buttonWidget);
	
	//new ParamInt(this, "DiffSize", 5, 1, 40, 1, m_imagePaint->diffSizePtr());
	//ParamUI *pui = new ParamUI( this, this, QStringList()<<QString("DiffSize") );
	//m_vboxTool->addWidget(pui);
	
	//////////////////////// set up the parameter part of the toolbox 
	/// add all the parameter units
	new ParamInt(this, "DiffSize", 5, 1, 40, 1, m_imagePaint->diffSizePtr());
	new ParamInt	(this, "streamLen", 150, 5, 500, 5, m_imagePaint->streamLenPtr());
	new ParamDouble	(this, "streamThre", 0.1, 0.0, 1.0, 0.01, m_imagePaint->streamThrePtr());
	new ParamInt(this, "strokeSize", 15, 1, 80, 1, m_imagePaint->strokeSizePtr());

	QStringList *paramList = new QStringList[TOOL_NUM];
	paramList[E_ROTO] << QString("DiffSize") << QString("streamLen") << QString("streamThre");
	paramList[E_FREE] << QString("strokeSize");
	for(int k=0; k<toolList.size(); k++)
	{
		QVBoxLayout *lay = new QVBoxLayout();
		QWidget *wgt = new QWidget();
		ParamUI *pui = new ParamUI(this, this, paramList[k]);
		lay->addWidget(pui);
		lay->addStretch(100);
		wgt->setLayout(lay);
		m_toolStackedWidget->insertWidget(k,wgt);
	}
	delete []paramList;
	m_toolStackedWidget->setCurrentIndex(0);
	//new ParamGroup(this, "T1", true);
	//new ParamBool(this, "T2", true);
	//new ParamString(this, "T3", QString("whT3"), true);
	//new ParamChoice(this, "T4", QString("wsT4"), QString("ws2T4|ws2T41|ws2T42|ws2T43"));
	//new ParamEnum(this, "T5", 3, QString("wssT5|wssT51|wssT52"));
	//new ParamImage(this, "T6", QString("test.png"));
    //new ParamInt   (this, "N", 5, 1, 100, 1, &m_N);
    //new ParamDouble(this, "sigma_d", 1.0, 0.0, 10.0, 0.05, &m_sigma_d);

//    ParamUI *pui = new ParamUI(this, this);
//    pui->setMinimumWidth(100);
//    pui->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
//    m_vboxPara->addWidget(pui);
//    m_vboxPara->addStretch(100);

	/////////////////////////////// connection building
    connect(m_selectitem, SIGNAL(currentIndexChanged(int)), m_imagePaint, SLOT(onIndexChanged(int)));

    m_player = new VideoPlayer(this, ":/test.png");
    connect(m_player, SIGNAL(videoChanged(int)), this, SLOT(onVideoChanged(int)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), this, SLOT(setDirty2()));
    connect(m_player, SIGNAL(outputChanged(const QImage&)), m_imagePaint, SLOT(setImage(const QImage&)));
    connect(this, SIGNAL(imageChanged(const QImage&)), m_player, SLOT(setOutput(const QImage&)));

    m_videoControls->setFrameStyle(QFrame::NoFrame);
    m_videoControls->setAutoHide(true);
    connect(m_videoControls, SIGNAL(stepForward()), m_player, SLOT(stepForward()));
    connect(m_videoControls, SIGNAL(stepBack()), m_player, SLOT(stepBack()));
    connect(m_videoControls, SIGNAL(currentFrameTracked(int)), m_player, SLOT(setCurrentFrame(int)));
    connect(m_videoControls, SIGNAL(playbackChanged(bool)), m_player, SLOT(setPlayback(bool)));
    connect(m_videoControls, SIGNAL(trackingChanged(bool)), this, SLOT(setDirty()));

    connect(m_player, SIGNAL(videoChanged(int)), m_videoControls, SLOT(setFrameCount(int)));
    connect(m_player, SIGNAL(playbackChanged(bool)), m_videoControls, SLOT(setPlayback(bool)));
    connect(m_player, SIGNAL(currentFrameChanged(int)), m_videoControls, SLOT(setCurrentFrame(int)));

	/// status bar
	statusBar()->showMessage(tr("WElCOME!"));

	m_statusIconButton = new QPushButton(this);
	statusBar()->addPermanentWidget(m_statusIconButton);
	m_statusIconButton->setIcon(m_toolButton[0]->icon());
	m_statusIconButton->setFlat(true);
	m_statusIconButton->setCheckable(false);

	m_statusToolLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusToolLabel);
	m_statusToolLabel->setText(toolList[0]);

	m_statusMouseLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusMouseLabel);
	m_statusMouseLabel->setText("| Pos: (0,0)");

	m_statusZoomLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusZoomLabel);
	m_statusZoomLabel->setText("| Zoom: 100%");

	m_statusReslLabel = new QLabel(this);
	statusBar()->addPermanentWidget(m_statusReslLabel);
	m_statusReslLabel->setText("| Resl: 100%");
}
   

MainWindow::~MainWindow() {
}

void MainWindow::restoreSettings() {
    QSettings settings;
    restoreGeometry(settings.value("mainWindow/geometry").toByteArray());
    restoreState(settings.value("mainWindow/windowState").toByteArray());

    settings.beginGroup("imagePaint");
    m_imagePaint->restoreSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::restoreSettings(settings, this);
    settings.endGroup();

    m_player->restoreSettings(settings);
}

void MainWindow::closeEvent(QCloseEvent *e) {
    QSettings settings;
    settings.setValue("mainWindow/geometry", saveGeometry());
    settings.setValue("mainWindow/windowState", saveState());

    settings.beginGroup("imageView");
    m_imagePaint->saveSettings(settings);
    settings.endGroup();

    settings.beginGroup("parameters");
    AbstractParam::saveSettings(settings, this);
    settings.endGroup();

    m_player->saveSettings(settings);

    QMainWindow::closeEvent(e);
} 

void MainWindow::setContourTool(bool bv) 
{
	if(bv)
	{
		m_imagePaint->setToolType(0); 
		toolTypePushButton[1]->setChecked(false);
	}
}
void MainWindow::setInteriorTool(bool bv) 
{
	if(bv)
	{
		m_imagePaint->setToolType(1); 
		toolTypePushButton[0]->setChecked(false);
	}
}
void MainWindow::on_actionOpen_triggered() {
	m_player->open();
}

void MainWindow::on_actionAbout_triggered() {
    QMessageBox msgBox;
    msgBox.setWindowTitle("About");
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText(
        "<html><body>" \
        "<p><b>Sketch-based Drawing Tool</b><br/><br/>" \
        "Author: Jiazhou CHEN <br/>" \
        "Date: " __DATE__ "</p>" \
        "<p>This program is free software: you can redistribute it and/or modify " \
        "it under the terms of the GNU General Public License as published by " \
        "the Free Software Foundation, either version 3 of the License, or " \
        "(at your option) any later version.</p>" \
        "<p>This program is distributed in the hope that it will be useful, " \
        "but WITHOUT ANY WARRANTY; without even the implied warranty of " \
        "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the " \
        "GNU General Public License for more details.</p>" \

		"Parts of the framework of this software are copied and modified " \
		"from the source code of the softwares developed by: <br/>" \
		" Jan Eric Kyprianidis &lt;" \
		"<a href='http://www.kyprianidis.com'>www.kyprianidis.com</a> &gt; & <br/>" \
		" Romain Vergn &lt;" \
		"<a href='http://romain.vergne.free.fr'>http://romain.vergne.free.fr</a>&gt;<br/>" \
        /*"Related Publications:" \
        "<ul>" \
        "<li>" \
        "Kyprianidis, J. E., &amp; Kang, H. (2011). " \
        "Image and Video Abstraction by Coherence-Enhancing Filtering. " \
        "<em>Computer Graphics Forum</em>, 30(2), 593-602. " \
        "(Proceedings Eurographics 2011)" \
        "</li>" \
        "</ul>" \
        "<p>Test image courtesy of Ivan Mlinar @ flickr.com.</p>" \*/
        "</body></html>"
    );
    msgBox.setStandardButtons(QMessageBox::Ok);
    msgBox.exec();
}

//void MainWindow::on_actionSelectDevice_triggered() {
//    int current = 0;
//    cudaGetDevice(&current);
//    int N = CudaDeviceDialog::select(true);
//    if ((N >= 0) && (current != N)) {
//        QMessageBox::information(this, "Information", "Application must be restarted!");
//        qApp->quit();
//    }
//}

void MainWindow::on_actionRecord_triggered() {
    m_player->record();
}

void MainWindow::setFullScreen() {
	if(isFullScreen())
	{
		showNormal();
		m_menuBar->setVisible(true);
	}
	else
	{
		showFullScreen();
		m_menuBar->setVisible(false);
	}
}

void MainWindow::setDirty() {
    if (m_videoControls->isTracking()) {
        imageChanged(m_player->image());
    }
    else if (!m_dirty) {
        m_dirty = true;
        QMetaObject::invokeMethod(this, "process", Qt::QueuedConnection);
    }
}

void MainWindow::setDirty2() {
	if (m_videoControls->isTracking()) {
		imageChanged(m_player->image());
	}
	else /*if (!m_dirty)*/ {
		m_dirty = true;
		QMetaObject::invokeMethod(this, "process2", Qt::QueuedConnection);
	}
}

void MainWindow::process() {
    m_dirty = false;
    QImage src = m_player->image();
    if (src.isNull()) {
        m_result = src;
        imageChanged(image());
        return;
    }
    m_result = src;
	m_imagePaint->refresh();
}

void MainWindow::process2() {
	m_dirty = false;
	QImage src = m_player->image();
	if (src.isNull()) {
		m_result = src;
		imageChanged(image());
		return;
	}
	m_result = src;
	imageChanged(image());
}

void MainWindow::onVideoChanged(int nframes) {
//    gpu_cache_clear();
    window()->setWindowFilePath(m_player->filename());
    window()->setWindowTitle(m_player->filename() + "[*]"); 
    actionRecord->setEnabled(nframes > 1);
}

void MainWindow::draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image) {
    //Handler::draw(view, p, R, image);
	view->draw(p,R,image);
	//int t1= m_t1;
	//bool t2 = m_t2;
    //if (m_imagePaint->scale() > 6) {
    //    QRect aR = R.toAlignedRect();

    //    p.setPen(QPen(Qt::blue, 1 / m_imagePaint->scale()));
    //    for (int j = aR.top(); j <= aR.bottom(); ++j) {
    //        for (int i = aR.left(); i <= aR.right(); ++i) {
    //            float4 t = m_tfm(i, j);
    //                        
    //            QPointF q(i+0.5, j+0.5);
    //            QPointF v(0.9 * t.x-0.5f, 0.9 * t.y-0.5f);
    //                        
    //            p.drawLine(q-v, q+v);
    //        }
    //    }
    //}

    //if (m_st.is_valid() && (m_imagePaint->scale() > 6)) {
    //    QPointF c = R.center();
    //    std::vector<float3> path = gpu_stgauss2_path( c.x(), c.y(), m_st, m_sigma_t, m_max_angle, true, true, 2, 0.25f);

    //    QPolygonF P;
    //    for (int i = 0; i < (int)path.size(); ++i) {
    //        P.append(QPointF(path[i].x, path[i].y));
    //    }

    //    p.setPen(QPen(Qt::black, view->pt2px(2), Qt::SolidLine, Qt::RoundCap));
    //    p.drawPolyline(P);
    //    if (m_imagePaint->scale() > 30) {
    //        p.setPen(QPen(Qt::black, view->pt2px(5.0), Qt::SolidLine, Qt::RoundCap));
    //        p.drawPoints(P);
    //    }
    //}
}

void MainWindow::setStatusTool(const int idx) { 
	if(idx<TOOL_NUM)
	{
		m_statusIconButton->setIcon(m_toolButton[idx]->icon());
		m_statusToolLabel->setText(toolList[idx]);
	}
}

////////////////////////////////////// tool box interface
void MainWindow::setCurrentTool(const QString &name)
{
	for(int k=0; k<toolList.size(); k++)
	{
		if(name==toolList[k])
		{
			menuTool->actions()[k]->setChecked(true);
			/// TODO: change the tool parameter box
			m_toolLabel->setText(toolList[k]);
			m_toolStackedWidget->setCurrentIndex(k);
			m_imagePaint->setCurrentTool(k);
			setStatusTool(k);
		}
		else
		{
			m_toolButton[k]->setChecked(false);
			m_toolButton[k]->setFlat(true);
			menuTool->actions()[k]->setChecked(false);
		}
	}
}