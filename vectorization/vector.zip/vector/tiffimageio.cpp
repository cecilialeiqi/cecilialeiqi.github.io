#include <tiffimageio.h>
#include <stdio.h>
#include <stdlib.h>

#include <Qt/qimage.h>
#include <QtCore/QString>

using namespace std;

#ifdef USE_TIFF
#include <tiffio.h>
#endif

namespace image {

  vector<string> TIFFImageIO::getExtensions() {
    vector<string> ext;
  
#ifdef USE_TIFF
    ext.push_back("tif");
    ext.push_back("TIF");
    ext.push_back("tiff");
    ext.push_back("TIFF");
#endif
  
    return ext;
  }

  Image *TIFFImageIO::createImage(const string &filename) {
#ifdef USE_TIFF
	  {
		  QImage qimg;
		  if( !qimg.load(QString(filename.c_str()), "TIFF") )
		  {
			  cout << "Cannot load image: " << filename << endl;
			  return NULL;
		  }
		  else
		  {
			  Image *img;
			  int w=qimg.width(), h=qimg.height();

			  // if(!qimg.hasAlphaChannel())
			  {
				  float color[3];
				  QRgb rgb;
				  img = new Image(filename, w, h, Image::RGB_IMAGE);
				  for(unsigned int yi=0; yi<h; yi++)
					  for(unsigned int xi=0; xi<w; xi++)
					  {
						  rgb = qimg.pixel(xi,yi);
						  color[0] = float(qRed(rgb))/255.f;
						  color[1] = float(qGreen(rgb))/255.f;
						  color[2] = float(qBlue(rgb))/255.f;
						  img->setPix(xi, yi, 3, color);
					  }
			  }
			  return img;
		  }
	  }
	  return NULL;

 //   TIFF* tif = TIFFOpen(filename.c_str(), "r");

 //   if(!tif) {
 //     fprintf(stderr,"Error : unable to open file %s\n", filename.c_str());
 //     return NULL;
 //   }

 //   uint32 w, h;
 //   size_t npixels;
 //   uint32* raster;

 //   TIFFGetField(tif,TIFFTAG_IMAGEWIDTH,&w);
 //   TIFFGetField(tif,TIFFTAG_IMAGELENGTH,&h);
 //       
 //   npixels = w * h;
 //   
 //   raster = (uint32*) _TIFFmalloc(npixels*sizeof(uint32));
 // 
 //   if(raster==NULL) {
 //     fprintf(stderr,"Error : out of memory\n");
 //     TIFFClose(tif);
 //     return NULL;
 //   }

 //   if(!TIFFReadRGBAImageOriented(tif,w,h,raster,ORIENTATION_TOPLEFT,0)) {
 //     fprintf(stderr,"Error : scanning error\n");
 //     _TIFFfree(raster);
 //     TIFFClose(tif);
 //     return NULL;
 //   }

 //   int width  = (int)w;
 //   int height = (int)h;

 //   Image *img = new Image(filename,width,height,Image::RGBA_IMAGE);

 //   uint32 ptr_tiff = 0;

 //   float color[4];
 //   for(uint32 ih=0; ih<h;++ih) {
 //     for(uint32 jw=0; jw<w;++jw) {
	//
	//color[0] = ((unsigned int)TIFFGetR(raster[ptr_tiff]))   / 255.f;
	//color[1] = ((unsigned int)TIFFGetG(raster[ptr_tiff]))   / 255.f;
	//color[2] = ((unsigned int)TIFFGetB(raster[ptr_tiff]))   / 255.f;
	//color[3] = ((unsigned int)TIFFGetA(raster[ptr_tiff++])) / 255.f;
	//
	//img->setPix(jw,ih,4,color);
 //     }
 //   }
 // 
 //   _TIFFfree(raster);
 //   TIFFClose(tif);

 //   return img;
#else 
    cerr << "Unable to create " << filename << ", LIB_TIFF needed" << endl;
    return NULL;
#endif
  }

  bool TIFFImageIO::saveImage(const Image &img,const string &filename) {
#ifdef USE_TIFF
	  if(img.isLoaded())
	  {
		  int w=img.getWidth(), h=img.getHeight();
		  QImage qimg;
		  if(img.pixelSize()==4)
			  qimg = QImage(w,h,QImage::Format_ARGB32);
		  else 
			  qimg = QImage(w,h,QImage::Format_RGB32);

		  QRgb rgb;
		  for(unsigned int yi=0; yi<h; yi++)
		  {
			  for (unsigned int xi=0; xi<w; xi++)
			  {
				  rgb = qRgb(int( (img.getPix(xi,yi,0)*255.f) +0.5), int( (img.getPix(xi,yi,1)*255.f) +0.5), int( (img.getPix(xi,yi,2)*255.f) +0.5));
				  qimg.setPixel(xi,yi,rgb);
			  }
		  }
		  qimg.save(QString(filename.c_str()),"JPG");
	  }

	  return false;

    //uint32 w = (uint32)img.getWidth();
    //uint32 h = (uint32)img.getHeight();

    //unsigned char *buffer = (unsigned char *)malloc(w*h*img.pixelSize()*sizeof(unsigned char));

    //float *data = img.ptr();
    //for(unsigned int i=0;i<w*h*img.pixelSize();++i) {
    //  buffer[i] = (data[i]>1.0) ? (unsigned char)255 : (unsigned char)(data[i]*255.0);
    //  buffer[i] = (data[i]<0.0) ? (unsigned char)0   : buffer[i];
    //}

    //TIFF *image;

    //// Open the TIFF file
    //if((image = TIFFOpen(filename.c_str(), "w")) == NULL){
    //  printf("Could not open %s for writing\n",filename.c_str());
    //  return false;
    //}

    //TIFFSetField(image,TIFFTAG_IMAGEWIDTH     ,w);
    //TIFFSetField(image,TIFFTAG_IMAGELENGTH    ,h);
    //TIFFSetField(image,TIFFTAG_COMPRESSION    ,COMPRESSION_DEFLATE);
    //TIFFSetField(image,TIFFTAG_PLANARCONFIG   ,PLANARCONFIG_CONTIG);
    //TIFFSetField(image,TIFFTAG_PHOTOMETRIC    ,PHOTOMETRIC_RGB);
    //TIFFSetField(image,TIFFTAG_BITSPERSAMPLE  ,8);
    //TIFFSetField(image,TIFFTAG_SAMPLESPERPIXEL,img.pixelSize());

    //// Write the information to the file
    //if(TIFFWriteEncodedStrip(image, 0, buffer, w*h*img.pixelSize())==0){
    //  fprintf(stderr,"Could not write image\n");
    //  return false;
    //}

    //// Close the file
    //TIFFClose(image);
  
    //return true;
#else 
    cerr << "Unable to save " << img.getName() << "in " << filename << ", LIB_TIFF needed" << endl;
    return false;
#endif
  }

} // image namespace 
