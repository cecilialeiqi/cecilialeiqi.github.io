#include <renderbufferObject.h>
#include <iostream>

using namespace std;

namespace gpu {

  RenderbufferObject::RenderbufferObject() {
    glGenRenderbuffersEXT(1,&rbo_id);  
  }

  RenderbufferObject::~RenderbufferObject() {
    glDeleteRenderbuffersEXT(1,&rbo_id);
  }

  void RenderbufferObject::setValues(GLenum internal_format,int width,int height) {
    int max = getMaxSize();
    if(width>max || height>max)
      cerr << "Renderbuffer size too big" << endl;
    else {
    
      GLint current_id = 0;
      glGetIntegerv(GL_RENDERBUFFER_BINDING_EXT,&current_id);
    
      if(current_id!=(GLint)rbo_id)
        bind();
    
      glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT,internal_format,width,height);
    
      if (current_id!=(GLint)rbo_id)
        glBindRenderbufferEXT(GL_RENDERBUFFER_EXT,current_id);
    }
  }

  GLint RenderbufferObject::getMaxSize() {
    GLint max_size = 0;
    glGetIntegerv(GL_MAX_RENDERBUFFER_SIZE_EXT,&max_size);
    return max_size;
  }

} // gpu namespace
