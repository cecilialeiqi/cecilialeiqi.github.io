#ifndef PLAY_WINDOW_H
#define PLAY_WINDOW_H

#include <QList>
#include <QMainWindow>
#include <QScrollBar>
#include <QLabel>
#include <QCheckBox>
#include <QDialog>
#include <QPushButton>
#include <QComboBox>
#include <QBoxLayout>


QT_BEGIN_NAMESPACE
class QAction;
class QMenu;
class QTextEdit;
class MLabel;
class QPushButton;
class QComboBox;
QT_END_NAMESPACE

class AnimationSetting
{
public:
	int		_millisec;
	bool    _isRepeat;
	AnimationSetting():_millisec(50),_isRepeat(false){};
};

class AnimationSettingDialog : public QDialog
{
	Q_OBJECT
public:
	AnimationSettingDialog(QWidget *parent = 0);
	void setDefaultSetting(const AnimationSetting&);
	AnimationSetting getSetting();

private:
	QLabel *label;
	QLineEdit *lineEdit;
	QCheckBox *repeatCheckBox;
	QPushButton *okButton;
	QPushButton *closeButton;
};

class PlayWidget : public QWidget
{
	Q_OBJECT

private slots:
	void nextFrame();
	void sliderValueChanged(int);
	void playButtonClicked();
	void saveButtonClicked();
	void optionButtonClicked();
	void KeyframeBoxChanged(int);

public:
	PlayWidget(QWidget *parent=NULL);
	~PlayWidget();

private:

	QIcon		*stopIcon	;
	QIcon		*playIcon	;
	QIcon		*nonrIcon	;
	QIcon		*saveIcon	;
	QIcon		*optionIcon;
	
	QPushButton	*playBtn;
	QScrollBar	*playSld;
	QLabel		*frmLabel;
	QPushButton	*saveBtn;
	QPushButton *optionBtn;
	QComboBox	*keyframeBox;
	QWidget		*playWidget;

	bool		_isPlaying;
	QTimer		*_timer;
	AnimationSetting _aniSetting;

public:
	void updateLabel(int currFrm, int nFrm);
	void updateSilder(int currFrm);
	void updateSilder(int currFrm, int nFrm);
	void setCurrentKeyframeBox(int idx);
	void setMaxKeyframeBox(int idx);
};


#endif //PLAY_WINDOW_H