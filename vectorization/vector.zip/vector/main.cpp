#include "prototypeWindow.h"

int main(int argc, char **argv) 
{
	QApplication::setStyle("plastique");

	QApplication::setOrganizationDomain("Jiazhou");
	QApplication::setOrganizationName("Jiazhou");
	QApplication::setApplicationName("prototype");
	QApplication app(argc, argv);
	app.setWindowIcon(QIcon("../prototype/app.ico"));  
	
	MainWindow *mw = MainWindow::getInstance();
	mw->restoreSettings();
	mw->showNormal();
	app.setStyleSheet("QStatusBar::item { border: none;} ");
	app.connect(&app, SIGNAL(lastWindowClosed()), &app, SLOT(quit()));
	return app.exec();
}
