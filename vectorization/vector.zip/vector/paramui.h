#ifndef PARAMUI_H
#define PARAMUI_H

#include "utilDLL.h"
#include "rolloutbox.h"
#include <QtGui/QtGui>


//namespace util 
//{

class UTIL_API AbstractParam;


class UTIL_API ParamUI : public RolloutBox {
    Q_OBJECT
public:
    ParamUI(QWidget *parent, QObject *object, const QStringList &namelist=QStringList());
    virtual bool event(QEvent *event);

protected:
    void addObjectParameters(QObject *obj);
    QPointer<QObject> m_object;
	QStringList		  m_namelist;
};


class UTIL_API ParamLabel : public QLabel {
    Q_OBJECT
public:            
    ParamLabel(QWidget *parent, AbstractParam *param);

protected:
    void mouseDoubleClickEvent(QMouseEvent * e);
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamCheckBox : public QCheckBox {
    Q_OBJECT
public:            
    ParamCheckBox(QWidget *parent, AbstractParam *param);
    virtual bool event(QEvent *e);

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamSpinBox : public QSpinBox {
    Q_OBJECT
public:            
    ParamSpinBox(QWidget *parent, AbstractParam *param);

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamDoubleSpinBox : public QDoubleSpinBox {
    Q_OBJECT
public:            
    ParamDoubleSpinBox(QWidget *parent, AbstractParam *param);

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamComboBox : public QComboBox {
    Q_OBJECT
public:            
    ParamComboBox(QWidget *parent, AbstractParam *param);

protected slots:
    void setValue(const QVariant& value);
    void updateParam(int index);

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamLineEdit : public QLineEdit {
    Q_OBJECT
public:            
    ParamLineEdit(QWidget *parent, AbstractParam *param);

protected slots:
    void updateParam();

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamTextEdit : public QToolButton {
    Q_OBJECT
public:            
    ParamTextEdit(QWidget *parent, AbstractParam *param);

protected slots:
    void edit();

protected:
    QPointer<AbstractParam> m_param;
};


class UTIL_API ParamImageSelect : public QWidget {
    Q_OBJECT
public:            
    ParamImageSelect(QWidget *parent, AbstractParam *param);

protected slots:
    void setImage(const QImage& image);
    void clear();
    void edit();

protected:
    QPointer<AbstractParam> m_param;
    QImage m_image;
    QLabel *m_label;
    QToolButton *m_edit;
    QToolButton *m_clear;
};


//} // util namespace

#endif //PARAMUI_H