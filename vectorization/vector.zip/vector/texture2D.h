#ifndef TEXTURE_2D_H
#define TEXTURE_2D_H

#include <glew.h>
#include <gl.h>
#include <glu.h>

#include <string>
#include <image.h>
#include <imageio.h>
#include <textureFormat.h>
#include <textureParams.h>

using namespace image;

namespace gpu {
  
  template<typename T = float> 
  class Texture2D 
  {
  public:

	  Texture2D(const TextureFormat &tf=TextureFormat(),
				const TextureParams &tp=TextureParams(),
				T* map=NULL,
				int id=-1);

	  Texture2D(const Texture2D &tex);

	  ~Texture2D();

	  inline GLuint        id    () const;
	  inline TextureFormat format() const;
	  inline TextureParams params() const;
	  inline void          bind  () const;

	  inline static Texture2D<float> *fromImage(const Image &img           );
	  inline static Texture2D<float> *fromImage(const std::string &filename);

  protected:
	  GLuint        _id;
	  TextureFormat _format;
	  TextureParams _params;
  };

  template<typename T>
    inline GLuint Texture2D<T>::id() const {
    return _id;
  }

  template<typename T>
    inline TextureFormat Texture2D<T>::format() const {
    return _format;
  }

  template<typename T>
    inline TextureParams Texture2D<T>::params() const {
    return _params;
  }

  template<typename T>
    inline void Texture2D<T>::bind() const {

    glBindTexture(_format.target(),_id);
  }

  template<typename T>
    inline Texture2D<T>::Texture2D(const Texture2D<T> &tex)
    : _id(tex.id()),
    _format(tex.format()),
    _params(tex.params()) {

  }

  template<typename T>
    inline Texture2D<T>::Texture2D(const TextureFormat &tf,const TextureParams &tp,T* map,int id)
    : _id(id),
    _format(tf),
    _params(tp) 
	{

		assert(_format.target()==GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_2D);

		if(id<0 || glIsTexture(id)==GL_FALSE) 
		{
		  glGenTextures(1,&_id);
		} 
		else 
		{
		  _id = id;
		}

		glBindTexture(_format.target(),_id);
	    
		if(_format.mipmapmode()==TextureFormat::MIPMAP_GLU_AUTOM)
		{
	      
		  gluBuild2DMipmaps(_format.target(),
							_format.internalformat(),
							_format.width(),
							_format.height(),
							_format.format(),
							_format.type(),
							(const GLvoid *)map);
		} 
		else 
		{
	    
		  glTexImage2D(_format.target(),
					   _format.level(),
					   _format.internalformat(),
					   _format.width(),
					   _format.height(),
					   _format.border(),
					   _format.format(),
					   _format.type(),
					   (const GLvoid *)map);
	   
		  if(_format.mipmapmode()==TextureFormat::MIPMAP_FBO_AUTOM) 
		  {
			assert(map!=NULL);
			assert(map!=0);
			glGenerateMipmapEXT(_format.target());
		  }
	    
		}

		glTexParameteri(_format.target(),GL_TEXTURE_MIN_FILTER,_params.minfilter());
		glTexParameteri(_format.target(),GL_TEXTURE_MAG_FILTER,_params.maxfilter()); 
		glTexParameteri(_format.target(),GL_TEXTURE_WRAP_S,_params.wraps());
		glTexParameteri(_format.target(),GL_TEXTURE_WRAP_T,_params.wrapt());

		//glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,_params.mode());
  }
  
  template<typename T>
   inline Texture2D<T>::~Texture2D() {	
    glDeleteTextures(1,&_id);
  }

  template<typename T>
    inline Texture2D<float> *Texture2D<T>::fromImage(const Image &img) {
    
    GLenum format = img.glFormat();
    
    return new Texture2D<float>(TextureFormat(GL_TEXTURE_2D,img.getWidth(),img.getHeight(),format,format,GL_FLOAT),TextureParams(),img.ptr());
  }

  template<typename T>
    inline Texture2D<float> *Texture2D<T>::fromImage(const std::string &filename) {
    
    Image *img = ImageIO::createImage(filename);
    
    assert(!ImageIO::error());
    
    Texture2D<float> *tex = fromImage(*img);
    delete img;
    
    return tex;
  }

  typedef Texture2D<float>         FloatTexture2D;
  typedef Texture2D<unsigned char> UbyteTexture2D;
  typedef Texture2D<unsigned int>  UintTexture2D;

} // gpu namespace 

#endif // TEXTURE_2D_H
