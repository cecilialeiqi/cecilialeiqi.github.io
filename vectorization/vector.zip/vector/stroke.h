#ifndef STROKE_H
#define STROKE_H

#include <vec2.h>
#include <vector>
#include <iostream>

using namespace  math;
using namespace std;

//////////////////////////////////////////////// brush
class Brush
{
public:
	float		_x;
	float		_y;
	float		_gx;
	float		_gy;
	float		_px;
	float		_py;
	float		_rad;
public:
	Brush(float x=-100000, float y=-100000, float gx=0.0, float gy=0.0, float px=0.0, float py=0.0,
		float rad=0.0):
	  _x(x),_y(y),_gx(gx),_gy(gy),_px(px),_py(py),_rad(rad){};

	  Brush& operator = (const Brush& br)
	  {
		  _x = br._x;
		  _y = br._y;
		  _gx = br._gx;
		  _gy = br._gy;
		  _px = br._px;
		  _py = br._py;
		  _rad = br._rad;
		  return *this;
	  };

	  void setDirection(float dx, float dy) {
		  _gx = dx;
		  _gy = dy;
	  };

	  void setPosition(float dx, float dy) {
		  _x = dx;
		  _y = dy;
	  };

	  void setProjection(float px, float py) {
		  _px = px;
		  _py = py;
	  }
};

//////////////////////////////////////////////// stroke
class Stroke
{
private:
	float	_dep;
public:
	vector<Brush>	_vBrush;
	bool			_valid;
public:
	Stroke(bool va=true):_valid(va){
		_dep = 0.001f;
	};

	Stroke& operator = (const Stroke & sk)
	{
		_vBrush.clear();
		for(unsigned int i=0; i<sk._vBrush.size(); i++)
			_vBrush.push_back(sk._vBrush[i]);
		_valid = sk._valid;
		return *this;
	};

	void setValid(bool v) {
		_valid = v;
	};

	/// mush be called before draw normals
	void computeNormal();

	void drawPoint();
	void drawPath();
	void drawNormal();
	void drawProjection();
};

#endif // STROKE_H