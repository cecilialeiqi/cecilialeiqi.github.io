#include <image.h>
#include <iostream>
#include <math.h>
#include <stdlib.h>

using namespace std;

namespace image {

  float Image::LD_MAX = 100.0;

  double Image::RGB_TO_XYZ[3][3] = 
    {{0.412453, 0.357580, 0.180423},
     {0.212671, 0.715160, 0.072169},
     {0.019334, 0.119193, 0.950227}};

  double Image::XYZ_TO_RGB[3][3] = 
    {{3.240479 , -1.537150, -0.498535},
     {-0.969256, 1.875992 , 0.041556 },
     {0.055648 , -0.204043, 1.057311 }};

  double Image::RGB_WHITE[3] = {1.0,1.0,1.0};

  double Image::XYZ_WHITE[3] = {
    RGB_WHITE[0]*RGB_TO_XYZ[0][0] + RGB_WHITE[1]*RGB_TO_XYZ[0][1] + RGB_WHITE[2]*RGB_TO_XYZ[0][2],
    RGB_WHITE[0]*RGB_TO_XYZ[1][0] + RGB_WHITE[1]*RGB_TO_XYZ[1][1] + RGB_WHITE[2]*RGB_TO_XYZ[1][2],
    RGB_WHITE[0]*RGB_TO_XYZ[2][0] + RGB_WHITE[1]*RGB_TO_XYZ[2][1] + RGB_WHITE[2]*RGB_TO_XYZ[2][2]
  };

  bool Image::knownFormat() {
    return _pixelSize==Image::RGBA_IMAGE || _pixelSize==Image::RGB_IMAGE;
  }

  void Image::allocMemory() {
    assert(knownFormat());
    
    _data = (float *)malloc(_width*_height*_pixelSize*sizeof(float));
  }

  void Image::desallocMemory() {
    assert(_data!=NULL);

   free(_data);

  }


  Image::Image(const string &name,unsigned int w,unsigned int h,int pixSize)
    : _pixelSize(pixSize),
      _width(w),
      _height(h),
      _name(name),            
      _data(NULL),
      _colorFormat(RGB_FORMAT) {
  
    allocMemory();
  }

  Image::Image(const string &name,unsigned int w,unsigned int h,const Vec3f &color) 
    : _pixelSize(Image::RGB_IMAGE),
      _width(w),
      _height(h),
      _name(name),
      _data(NULL),
      _colorFormat(RGB_FORMAT)  {
  
    allocMemory();

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        setPix(i,j,color);
      }
    }
  }

  Image::Image(const string &name,unsigned int w,unsigned int h,const Vec4f &color) 
    : _pixelSize(Image::RGBA_IMAGE),
      _width(w),
      _height(h),
      _name(name),
      _data(NULL),
      _colorFormat(RGB_FORMAT)  {
  
    allocMemory();

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        setPix(i,j,color);
      }
    }
  }

  Image::Image(const Image &img,unsigned int ptw,unsigned int pth,unsigned int w,unsigned int h) 
    : _pixelSize(img.pixelSize()),
      _width(w),
      _height(h),
      _name(img.getName()),
      _data(NULL),
      _colorFormat(img.colorFormat())  {

    allocMemory();

    for(unsigned int i=ptw;i<ptw+_width;++i) {
      for(unsigned int j=pth;j<pth+_height;++j) {
	
        for(unsigned int k=0;k<_pixelSize;++k) {
          setPix(i-ptw,j-pth,k,img.getPix(i,j,k));
        }
      }
    }
  }

  Image::Image(const Image &img) 
    : _pixelSize(img.pixelSize()),
      _width(img._width),
      _height(img._height),
      _name(img.getName()),
      _data(NULL),
      _colorFormat(img.colorFormat())  {
  
    allocMemory();
  
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        for(unsigned int k=0;k<_pixelSize;++k) {
          setPix(i,j,k,img.getPix(i,j,k));
        }
      }
    }
  }

  Image::~Image() {
    desallocMemory();
  }

  void Image::RGBToXYZ() {

    float r,g,b;
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        r = getPix(i,j,0);
        g = getPix(i,j,1);
        b = getPix(i,j,2);
      
        setPix(i,j,0,RGB_TO_XYZ[0][0]*r + RGB_TO_XYZ[0][1]*g + RGB_TO_XYZ[0][2]*b);
        setPix(i,j,1,RGB_TO_XYZ[1][0]*r + RGB_TO_XYZ[1][1]*g + RGB_TO_XYZ[1][2]*b);
        setPix(i,j,2,RGB_TO_XYZ[2][0]*r + RGB_TO_XYZ[2][1]*g + RGB_TO_XYZ[2][2]*b);
      }
    }
    
    _colorFormat = XYZ_FORMAT;
  }

  void Image::XYZToRGB() {
    float x,y,z;
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        x = getPix(i,j,0);
        y = getPix(i,j,1);
        z = getPix(i,j,2);

        setPix(i,j,0,XYZ_TO_RGB[0][0]*x + XYZ_TO_RGB[0][1]*y + XYZ_TO_RGB[0][2]*z);
        setPix(i,j,1,XYZ_TO_RGB[1][0]*x + XYZ_TO_RGB[1][1]*y + XYZ_TO_RGB[1][2]*z);
        setPix(i,j,2,XYZ_TO_RGB[2][0]*x + XYZ_TO_RGB[2][1]*y + XYZ_TO_RGB[2][2]*z);
      }
    }

    _colorFormat = RGB_FORMAT;
  }
 
  void Image::YxyToRGB() {
    float tmpx,tmpy;
    float x,y,z;
  
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        y    = getPix(i,j,0);
        tmpx = getPix(i,j,1);
        tmpy = getPix(i,j,2);

        if(y>0.0 && tmpx>0.0 && tmpy>0.0) {
          x = (tmpx*y) / tmpy;
          z = (x/tmpx) - x - y;
        } else
          x = z = 0.0;
    
        setPix(i,j,0,XYZ_TO_RGB[0][0]*x + XYZ_TO_RGB[0][1]*y + XYZ_TO_RGB[0][2]*z);
        setPix(i,j,1,XYZ_TO_RGB[1][0]*x + XYZ_TO_RGB[1][1]*y + XYZ_TO_RGB[1][2]*z);
        setPix(i,j,2,XYZ_TO_RGB[2][0]*x + XYZ_TO_RGB[2][1]*y + XYZ_TO_RGB[2][2]*z);      
      }
    }

    _colorFormat = RGB_FORMAT;
  }

  void Image::RGBToYxy() {
    float x,y,z;
    float r,g,b;
    float w;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        r = getPix(i,j,0);
        g = getPix(i,j,1);
        b = getPix(i,j,2);

        x = RGB_TO_XYZ[0][0]*r + RGB_TO_XYZ[0][1]*g + RGB_TO_XYZ[0][2]*b;
        y = RGB_TO_XYZ[1][0]*r + RGB_TO_XYZ[1][1]*g + RGB_TO_XYZ[1][2]*b;
        z = RGB_TO_XYZ[2][0]*r + RGB_TO_XYZ[2][1]*g + RGB_TO_XYZ[2][2]*b;

        if((w = x+y+z)>0.0) {
          setPix(i,j,0,y);
          setPix(i,j,1,x/w);
          setPix(i,j,2,y/w);
        } else {
          setPix(i,j,0,0.0);
          setPix(i,j,1,0.0);
          setPix(i,j,2,0.0);
        }
      }
    }

    _colorFormat = Yxy_FORMAT;
  }


  void Image::RGBToLab() {
    const float factor1 = 1.0/3.0;
    const float factor2 = 16.0/116.0;

    float r,g,b;
    float x,y,z;
    float ratio_x,ratio_y,ratio_z;
  
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        r = getPix(i,j,0);
        g = getPix(i,j,1);
        b = getPix(i,j,2);
      
        // rgb -> xyz
        x = RGB_TO_XYZ[0][0]*r + RGB_TO_XYZ[0][1]*g + RGB_TO_XYZ[0][2]*b;
        y = RGB_TO_XYZ[1][0]*r + RGB_TO_XYZ[1][1]*g + RGB_TO_XYZ[1][2]*b;
        z = RGB_TO_XYZ[2][0]*r + RGB_TO_XYZ[2][1]*g + RGB_TO_XYZ[2][2]*b;
      
        ratio_x = x / XYZ_WHITE[0];
        ratio_y = y / XYZ_WHITE[1];
        ratio_z = z / XYZ_WHITE[2];
      
        // compute L
        if(ratio_y>0.008856)
          setPix(i,j,0,116.0*pow(ratio_y,factor1) - 16.0);
        else setPix(i,j,0,903.3*ratio_y);
      
        // compute a and b
        ratio_x = ratio_x>0.008856 ? pow(ratio_x,factor1) : ratio_x*7.787+factor2;
        ratio_y = ratio_y>0.008856 ? pow(ratio_y,factor1) : ratio_y*7.787+factor2;
        ratio_z = ratio_z>0.008856 ? pow(ratio_z,factor1) : ratio_z*7.787+factor2;
      
        setPix(i,j,1,500.0*(ratio_x - ratio_y)); // a
        setPix(i,j,2,200.0*(ratio_y - ratio_z)); // b
      }
    }

    _colorFormat = Lab_FORMAT;
  }

  void Image::LabToRGB() {
    const float factor1 = 1.0/3.0;
    const float factor2 = 16.0/116.0;
    const float factor3 = 1.0/787.0;

    float l,a,b;
    float fx,fy,fz;
    float x,y,z;
    float ratio_x,ratio_y,ratio_z;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        l = getPix(i,j,0);
        a = getPix(i,j,1);
        b = getPix(i,j,2);

        // compute y
        y = l>7.99968 ? pow((l+16.0)/116.0,3.0)*XYZ_WHITE[1] : (l*XYZ_WHITE[1])/903.3;
      
        // compute x and z
        ratio_y = y / XYZ_WHITE[1];
      
        fy = ratio_y>0.00856 ? pow(ratio_y,factor1) : 7.787*ratio_y+factor2;
        fx = fy + a/500.0;
        fz = fy - b/200.0;
      
        ratio_x = pow(float(fx),float(3.0));
        ratio_z = pow(float(fz),float(3.0));
      
        x = ratio_x>0.008856 ? XYZ_WHITE[0]*ratio_x : factor3*XYZ_WHITE[0]*(fx-factor2);
        z = ratio_z>0.008856 ? XYZ_WHITE[2]*ratio_z : factor3*XYZ_WHITE[2]*(fz-factor2);
      
        // xyz -> rgb
        setPix(i,j,0,XYZ_TO_RGB[0][0]*x + XYZ_TO_RGB[0][1]*y + XYZ_TO_RGB[0][2]*z);
        setPix(i,j,1,XYZ_TO_RGB[1][0]*x + XYZ_TO_RGB[1][1]*y + XYZ_TO_RGB[1][2]*z);
        setPix(i,j,2,XYZ_TO_RGB[2][0]*x + XYZ_TO_RGB[2][1]*y + XYZ_TO_RGB[2][2]*z);
      }
    }

    _colorFormat = RGB_FORMAT;
  }

  void Image::RGBToHSV() {
    float r,g,b;
    float h,s,v;
    float delta;
    float eps = 0.0000000001;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        r = getPix(i,j,0);
        g = getPix(i,j,1);
        b = getPix(i,j,2);
      
        v     = max(max(r,g),b);
        delta = v-min(min(r,g),b);
      
        if(delta<eps) {
          s = 0.0;
          h = 0.0;
        } else {
          s = delta/v;
	
          if(r==v)      h = (g-b)/delta;
          else if(g==v) h = 2.0 + (b-r)/delta;
          else          h = 4.0 + (r-g)/delta;
	
          h *= 60.0;
          if(h<0.0)
            h += 360;
        }
      
        setPix(i,j,0,h);
        setPix(i,j,1,s);
        setPix(i,j,2,v);
      }
    }

    _colorFormat = HSV_FORMAT;
  }

  void Image::HSVToRGB() {
    float r,g,b;
    float h,s,v;
    float k,f,m,n,p;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        h = getPix(i,j,0);
        s = getPix(i,j,1);
        v = getPix(i,j,2);
      
        h = h/60.0;
        k = floor(h);
        f = h-k;
        m = v*(1.0-s);
        n = v*(1.0-f*s);
        p = v*(1.0-s*(1.0-f));
      
        if(k==0.0) {r = v;g = p;b = m;} 
        else if(k==1.0) {r = n;g = v;b = m;} 
        else if(k==2.0) {r = m;g = v;b = p;} 
        else if(k==3.0) {r = m;g = n;b = v;} 
        else if(k==4.0) {r = p;g = n;b = v;} 
        else {r = v;g = m;b = n;}
      
        setPix(i,j,0,r);
        setPix(i,j,1,g);
        setPix(i,j,2,b);   
      
      }
    }

    _colorFormat = RGB_FORMAT;
  }

  void Image::toRGB() {
    switch(_colorFormat) {
    case XYZ_FORMAT:
      XYZToRGB();
      break;
    case Yxy_FORMAT:
      YxyToRGB();
      break;
    case Lab_FORMAT:
      LabToRGB();
      break;
    case HSV_FORMAT:
      HSVToRGB();
      break;
    default:
      break;
    }
  }

  void Image::toColorFormat(int colorFormat) {
    if(colorFormat==_colorFormat)
      return;
    
    if(colorFormat==RGB_FORMAT) {
      toRGB();
      return;
    }
    
    if(_colorFormat!=RGB_FORMAT) 
      toRGB();
    
    switch(colorFormat) {
    case XYZ_FORMAT:
      RGBToXYZ();
      break;
    case Yxy_FORMAT:
      RGBToYxy();
      break;
    case Lab_FORMAT:
      RGBToLab();
      break;
    case HSV_FORMAT:
      RGBToHSV();
      break;
    default:
      break;
    }
  }

  void Image::calibrate() {
    RGBToYxy();
    double lmin,lmax,lav;
    computeLminLmaxLav(&lmin,&lmax,&lav,true);
    calibrate(lmin,lmax,lav);
    YxyToRGB();
  }

  void Image::calibrate(double Lmin, double Lmax, double Lav) {
    // image must be in Yxy color space
    double f;
    double alpha;
    double factor;

    f      = (2.0*log(Lav) - log(Lmin) - log(Lmax)) / (log(Lmax) - log(Lmin));
    alpha  = 0.18*pow(4.0,f);
    factor = alpha / Lav;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
      
        setPix(i,j,0,getPix(i,j,0)*factor);
        if(getPix(i,j,0)>LD_MAX)
          setPix(i,j,0,LD_MAX);
      }
    }
  }

  void Image::computeLminLmaxLav(double *Lmin,double *Lmax,double *Lav,bool finalize_Lav) {
    // image must be in Yxy color space
    *Lmin = LD_MAX;
    *Lmax = 0.0;
    *Lav = 0.0;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        if(getPix(i,j,0)!=0.0 && getPix(i,j,1)!=0.0 && getPix(i,j,2)!=0.0) {
          *Lmin = getPix(i,j,0) < *Lmin ? getPix(i,j,0) : *Lmin;
          *Lmax = getPix(i,j,0) > *Lmax ? getPix(i,j,0) : *Lmax;
          *Lav += log(getPix(i,j,0));	
        }
      }
    }
  
    if(finalize_Lav)
      *Lav = exp(*Lav/(double)(_width*_height));
  }

  void Image::clamp(float min,float max) {
  
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        for(unsigned int k=0;k<_pixelSize;++k) {
	
          if(getPix(i,j,k)<min)
            setPix(i,j,k,min);
          else if(getPix(i,j,k)>max)
            setPix(i,j,k,max);
        }
      }
    }
  }

  void Image::normalize(double outputRange) {
    double minval  =  1e20;
    double maxval  = -1e20;
    double average = 0.0;
    double range;
    double value;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {      
        value = LUM(getPix(i,j,0),getPix(i,j,1),getPix(i,j,2));
      
        if(value<minval) minval = value;
        if(value>maxval) maxval = value;
      
        average += value;      
      }
    }

    range    = maxval - minval;
    average /= _width * _height;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        for(unsigned int k=0;k<_pixelSize;++k) {
          setPix(i,j,k,outputRange*((getPix(i,j,k)-minval)/range));
	
          if(getPix(i,j,k)<0.0)         setPix(i,j,k,0.0);
          if(getPix(i,j,k)>outputRange) setPix(i,j,k,outputRange);
        }
      }
    }
  }

  void Image::gammaCorrection(double gamma) {
    double gamma_inv = 1.0/gamma;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        for(unsigned int k=0;k<_pixelSize;++k) {
          setPix(i,j,k,pow(float(getPix(i,j,k)),float(gamma_inv)));
        }
      }
    }
  }

  void Image::mirror(int mirrorType) {
    float c1,c2;

    switch(mirrorType) {
    case HORIZONTAL:
      for(unsigned int i=0;i<_height/2;++i) {
        for(unsigned int j=0;j<_width;++j) {
          for(unsigned int k=0;k<_pixelSize;++k) {
	  
            c1 = getPix(j,i,k);
            c2 = getPix(j,_height-i-1,k);
	  
            setPix(j,i,k,c2);
            setPix(j,_height-i-1,k,c1);
          }
        }
      }
      break;
    case VERTICAL:
      for(unsigned int i=0;i<_height;++i) {
        for(unsigned int j=0;j<_width/2;++j) {
          for(unsigned int k=0;k<_pixelSize;++k) {
	  
            c1 = getPix(j,i,k);
            c2 = getPix(_width-j-1,i,k);
	  
            setPix(j,i,k,c2);
            setPix(_width-j-1,i,k,c1);
          }
        }
      }
      break;
    default:
      break;
    }
  }

  void Image::printMinMax() {
    float min_r,min_g,min_b;
    float max_r,max_g,max_b;

    min_r = min_g = min_b = 1000000000;
    max_r = max_g = max_b = 0.0;

    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        min_r = getPix(i,j,0)<min_r ? getPix(i,j,0) : min_r;
        max_r = getPix(i,j,0)>max_r ? getPix(i,j,0) : max_r;
        min_g = getPix(i,j,1)<min_g ? getPix(i,j,1) : min_g;
        max_g = getPix(i,j,1)>max_g ? getPix(i,j,1) : max_g;
        min_b = getPix(i,j,2)<min_b ? getPix(i,j,2) : min_b;
        max_b = getPix(i,j,2)>max_b ? getPix(i,j,2) : max_b;      
      }
    }

    cout << "r : [" << min_r << "," << max_r << "]" << endl;
    cout << "g : [" << min_g << "," << max_g << "]" << endl;
    cout << "b : [" << min_b << "," << max_b << "]" << endl;
  }

  void Image::resize(unsigned int w,unsigned int h,int mode) {
    assert(mode==NEAREST_INTERPOLATION);

    Image img(_name,w,h,_pixelSize);
  
    double ratiow = (double)_width/(double)w;
    double ratioh = (double)_height/(double)h;
    double currentw,currenth;
  
    for(unsigned int i=0;i<img.getWidth();++i) {
      for(unsigned int j=0;j<img.getHeight();++j) {

        currentw = (double)i*ratiow;
        currenth = (double)j*ratioh;
    
        if(mode==Image::NEAREST_INTERPOLATION) {
          for(unsigned int k=0;k<_pixelSize;++k) {
            img.setPix(i,j,k,getPix((unsigned int)currentw,(unsigned int)currenth,k));
          }
        } 
      }
    }

    desallocMemory();
  
    _width  = w;
    _height = h;
  
    allocMemory();
  
    for(unsigned int i=0;i<_width;++i) {
      for(unsigned int j=0;j<_height;++j) {
        for(unsigned int k=0;k<_pixelSize;++k) {
          setPix(i,j,k,img.getPix(i,j,k));
        }
      }
    }
  }

  bool Image::isLoaded() const
  {
	  return (_data!=NULL);
  }

  void Image::copy(Image *src,Image *dst) {
    assert(src!=NULL);
    assert(dst!=NULL);
    assert(src->getWidth()==dst->getWidth());
    assert(src->getHeight()==dst->getHeight());
    
    float *ptrSrc = src->ptr();
    float *ptrDst = dst->ptr();

    for(unsigned int i=0;i<src->getWidth()*src->getHeight()*src->pixelSize();++i) {
      *ptrDst = *ptrSrc;
      ptrSrc++;
      ptrDst++;
    }
  }

  ostream &operator<<(ostream &stream,const Image &img) {

    stream << img._pixelSize << " ";
    stream << img._width << " ";
    stream << img._height << " ";
    stream << img._name << " ";
    stream << img._colorFormat << endl;

    for(unsigned int i=0;i<img._width*img._height*img._pixelSize;++i) {
      stream << img._data[i] << " ";
    }
    
    stream << endl;
      
    return stream;

  }
  
  istream &operator>>(istream &stream,Image &img) {
 

    //stream >> num >> active >> a >> b >> c >> d >> e >> f >> g >> h >> i >> j >> k;
    stream >> img._pixelSize;
    stream >> img._width;
    stream >> img._height;
    stream >> img._name;
    stream >> img._colorFormat;

    if(img._data!=NULL)
      img.desallocMemory();
    
    img.allocMemory();
    
    for(unsigned int i=0;i<img._width*img._height*img._pixelSize;++i) {
      stream >> img._data[i];
    }

    return stream;
  }

} // image namespace 
