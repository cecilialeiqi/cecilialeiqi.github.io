#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <gpuShader.h>
#include <glError.h>

namespace gpu
{
  using namespace std;
      
  GPUShader::GPUShader(SHADER_TYPE type,const string &strFile,bool printLog,bool bFile)
    : _type(type),
      _shaderId(0),
      _printLog(printLog),
      _vnStrings(0),
      _vStrings(NULL),
      _vLengths(NULL)
  {
	  _created = createShader();
	  if(bFile)
	  {
		  _filename = strFile;
		  loadAndCompile();
	  }
	  else
	  {
		  /// comment in 2012/03/01
		  //ifstream inFile(strFile.c_str());
		  //stringstream sfile;
		  //string line, tmpFile;
		  //// convert file into string object
		  //while(std::getline(inFile,line))
			 // sfile << line << endl;
		  //tmpFile = sfile.str();
		  //
		  //int count = strlen(strFile.c_str())+1;

		  //_vnStrings=1;
		  //_vStrings = (GLcharARB**)malloc(sizeof(GLcharARB*)*_vnStrings);
		  //*_vStrings = (GLcharARB*)malloc(sizeof(GLcharARB)*(count+1));
		  //for(int i=0; i<count; i++)
			 // (*_vStrings)[i] = strFile[i];
		  //(*_vStrings)[count-1] = '\0';

		  //_vLengths  = (GLint*)malloc(sizeof(GLint)*_vnStrings);
		  //*_vLengths = count;

		  //glShaderSource(_shaderId,_vnStrings,
			 // const_cast<const GLcharARB **>(_vStrings),
			 // _vLengths);
		  //PRINT_ERROR_GL;

		  // _filename = "";
		  //compile();
	  }
  }

  GPUShader::~GPUShader() {
      if(_created){
      glDeleteShader(_shaderId);
      PRINT_ERROR_GL;
      }
    
  }
  
//   bool GPUShader::load() {
//     std::ifstream file(_filename.c_str());

//     if(!file.is_open()) {
//       std::ostringstream error;
//       error << "Can't access shader source " << _filename;
//       return false;
//     }
 
//     std::ostringstream stream;
//     std::string line, source;
//     while(std::getline(file, line)) {
//       stream << line << std::endl;
//     }
//     file.close();
 
//     const char *src = stream.str().c_str();
//     glShaderSource(_shaderId,1,(const GLchar**)&src,NULL); 

//     return true;
//   }

  bool GPUShader::load() {

    cleanStrings();
    
    FILE* fp = fopen(_filename.c_str(),"r");
    
    if(fp==NULL)		
	{
		std::cout << "Cannot open shader file " << _filename << std::endl;
		return false;
	}

    int count=0;
    char c;
    
    do {
      count++;
      c = fgetc(fp);
    } while(c!= EOF);
    
    if(count==0) {
      fclose(fp);
      return false;
    }
    
    fp = freopen(_filename.c_str(),"r",fp);
    
    if(fp==NULL)
	{
		return false;
	}
    
    _vnStrings = 1;
    _vStrings  = (GLcharARB**)malloc(sizeof(GLcharARB*)*_vnStrings);
    *_vStrings = (GLcharARB*)malloc(sizeof(GLcharARB)*(count+1));
    
    for(int i=0;i<count;(*_vStrings)[i++]=fgetc(fp))
      ;
    
    (*_vStrings)[count-1] = '\0';
    _vLengths  = (GLint*)malloc(sizeof(GLint)*_vnStrings);
    *_vLengths = count;
    fclose(fp);
    
    glShaderSource(_shaderId,_vnStrings,
                   const_cast<const GLcharARB **>(_vStrings),
                   _vLengths);
      PRINT_ERROR_GL;

    return true;
  }
  
  void GPUShader::cleanStrings() {
    if(_vnStrings>0) 
	{
      free(_vLengths);
		for(GLsizei i=0;i<_vnStrings;i++)
			if(_vStrings[i])
				free(_vStrings[i]);      
      free(_vStrings);
    }
    _vnStrings = 0;
  }
   
  bool GPUShader::compile() { 
    glCompileShader(_shaderId);

    if(_printLog)
      printInfoLog();
  
    return true;
  }

  void GPUShader::printInfoLog() {
    int   infologLength = 0;
    int   charsWritten  = 0;
    char* infolog;
    
    glGetObjectParameterivARB(_shaderId,GL_OBJECT_INFO_LOG_LENGTH_ARB,&infologLength);
    PRINT_ERROR_GL;
    if(infologLength>0) {
      infolog = (char*)malloc(infologLength);
      glGetInfoLogARB(_shaderId,infologLength,&charsWritten,infolog);
      if(infolog[0]!='\0') {
	printf("InfoLog ---> %s\n",_filename.c_str());
	printf("%s",infolog);
      }
      free(infolog);
    }
  }

  bool GPUShader::loadAndCompile() {
    return _created && load() && compile();
  }

  bool GPUShader::createShader() {
    switch(_type) {

    case VERT:
      if(GLEW_ARB_vertex_shader)
        _shaderId = glCreateShader(GL_VERTEX_SHADER);
      else { 
        cout << "Warning : vertex shader not supported !" << endl; 
	return false;
      }
      break;
      
    case FRAG:
        if(GLEW_ARB_fragment_shader){
        _shaderId = glCreateShader(GL_FRAGMENT_SHADER);
      PRINT_ERROR_GL;
        }
      else { 
        cout << "Warning : fragment shader not supported !" << endl; 
 	return false;
      }
      break;
      
    case GEOM:
#ifdef GL_EXT_geometry_shader4
        if(GL_EXT_geometry_shader4){
        _shaderId = glCreateShader(GL_GEOMETRY_SHADER_EXT);
      PRINT_ERROR_GL;
        }
      else { 
        cout << "Warning : geometry shader not supported !" << endl;  
  	return false;
      }
#else 
      cout << "Warning : geometry shader not supported !" << endl;  
      return false;
#endif
      break;
      
    default:
      cout << "Warning : unknown shader type !" << endl;
      return false;
      break;
    }
    
    if(_shaderId==0) {
      cout << "Warning : shader "  << "is not created !" << endl;
      return false;
    }
      
    return true;
  } 
} // gpu namespace
