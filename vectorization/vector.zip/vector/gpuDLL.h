#ifndef __GPUDLL_H_
#define __GPUDLL_H_


#if defined _WIN32
	#ifdef GPU_EXPORTS
		#define GPU_API __declspec(dllexport)
	#else
		#define GPU_API __declspec(dllimport)
	#endif
#else
	#define GPU_API
#endif

#endif  // __GPUDLL_H_
