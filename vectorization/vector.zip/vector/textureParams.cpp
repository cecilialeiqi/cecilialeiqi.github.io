#include <textureParams.h>

namespace gpu {

  TextureParams::TextureParams(GLint minfilter,
                               GLint maxfilter,
                               GLint wrapr,
                               GLint wraps,
                               GLint wrapt,
                               GLint mode) 
    : _minfilter(minfilter),
      _maxfilter(maxfilter),
      _wrapr(wrapr),
      _wraps(wraps),
      _wrapt(wrapt),
      _mode(mode) {

  }

  TextureParams::TextureParams(const TextureParams &tp) 
    : _minfilter(tp.minfilter()),
      _maxfilter(tp.maxfilter()),
      _wrapr(tp.wrapr()),
      _wraps(tp.wraps()),
      _wrapt(tp.wrapt()),
      _mode(tp.mode()) {
  
  }

} // gpu namespace 
