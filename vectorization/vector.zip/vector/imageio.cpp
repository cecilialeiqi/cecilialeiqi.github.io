#include <stdlib.h>
#include <imageio.h>
#include <exrimageio.h>
#include <hdrimageio.h>
#include <jpegimageio.h>
#include <bmpimageio.h>
#include <pngimageio.h>
#include <tgaimageio.h>
#include <tiffimageio.h>
#include <QtCore/QString>
#include <QtCore/QStringList>

using namespace std;

namespace image {


  string ImageIO::_extensions = "";
  string ImageIO::_lastDir    = ".";
  bool   ImageIO::_noError    = false;

  Image *ImageIO::createImage(const string &filename) 
  {
    Image *img = NULL;
    _noError   = false;
    vector<string> ext;
  
    // tiff images 
    ext = TIFFImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      img = TIFFImageIO::createImage(filename);
      _noError = img==NULL ? false : true;
      computeLastDir(filename);
      return img;
    }
  
    // hdr images
    ext = HDRImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      img = HDRImageIO::createImage(filename);
      _noError = img==NULL ? false : true;
      computeLastDir(filename);
      return img;
    }

    // png images
    ext = PNGImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      img = PNGImageIO::createImage(filename);
      _noError = img==NULL ? false : true;
      computeLastDir(filename);
      return img;
    }

    // tga images
    ext = TGAImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      img = TGAImageIO::createImage(filename);
      _noError = img==NULL ? false : true;
      computeLastDir(filename);
      return img;    
    }

    // exr images
    ext = EXRImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      img = EXRImageIO::createImage(filename);
      _noError = img==NULL ? false : true;
      computeLastDir(filename);
      return img;    
    }

    // jpeg images
	ext = JPEGImageIO::getExtensions();
	if(extensionInside(filename,ext)) {
		img = JPEGImageIO::createImage(filename);
		_noError = img==NULL ? false : true;
		computeLastDir(filename);
		return img;    
	}

	// bmp images
	ext = BMPImageIO::getExtensions();
	if(extensionInside(filename,ext)) {
		img = BMPImageIO::createImage(filename);
		_noError = img==NULL ? false : true;
		computeLastDir(filename);
		return img;    
	}

    return img;
  
  }

  bool ImageIO::saveImage(const Image &img,const string &filename) {
    vector<string> ext;
  
    // tiff images 
    ext = TIFFImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return TIFFImageIO::saveImage(img,filename);
    }
  
    // hdr images
    ext = HDRImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return HDRImageIO::saveImage(img,filename);
    }

    // png images
    ext = PNGImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return PNGImageIO::saveImage(img,filename);
    }

    // tga images
    ext = TGAImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return TGAImageIO::saveImage(img,filename);
    }

    // exr images
    ext = EXRImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return EXRImageIO::saveImage(img,filename);
    }

    // jpeg images
    ext = JPEGImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return JPEGImageIO::saveImage(img,filename);
    }

   // bmp images
    ext = BMPImageIO::getExtensions();
    if(extensionInside(filename,ext)) {
      return BMPImageIO::saveImage(img,filename);
    }

    return true;
  }

  bool ImageIO::extensionInside(const string &filename,vector<string> ext) {
    
    unsigned int size = filename.size();

    for(unsigned int i=0;i<ext.size();++i) {
      if(filename.find(ext[i],size-ext[i].size())!=string::npos)
	return true;
    }
    
    return false;
  }

  bool ImageIO::error() {
    return !_noError;
  }

  string ImageIO::extensionAvailable() {
    if(_extensions!="")
      return _extensions;
    
    _extensions = "Image (";

    vector<string> ext;
    ext = TIFFImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

    ext = HDRImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

    ext = PNGImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

    ext = TGAImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

    ext = EXRImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

    ext = JPEGImageIO::getExtensions();
    for(unsigned int i=0;i<ext.size();++i) {
      _extensions.append("*.");
      _extensions.append(ext[i]);
      _extensions.append(" ");
    }

	ext = BMPImageIO::getExtensions();
	for(unsigned int i=0;i<ext.size();++i) {
		_extensions.append("*.");
		_extensions.append(ext[i]);
		_extensions.append(" ");
	}

	_extensions.append(")");

    return _extensions;
  }

  void ImageIO::computeLastDir(const std::string &filename) {
    if(_noError) 
	{
      _lastDir.clear();

      QString name = QString(filename.c_str());
      QStringList splitName = name.split("/",QString::SkipEmptyParts);

	  if(_lastDir=="")
	  {
		  _lastDir = filename;
		  return ;
	  }
      
      for(int i=0;i<splitName.size()-1;++i) {
		  _lastDir.append(std::string(splitName[i].toAscii()));
	_lastDir.append("/");
      }
    }
  }

  string ImageIO::lastDir() {
    return _lastDir;
  }

} // image namespace
