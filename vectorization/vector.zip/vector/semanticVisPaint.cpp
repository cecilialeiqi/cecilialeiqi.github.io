#include "semanticVisPaint.h"
#include <semanticVisWindow.h>
#include <fstream>
#include "mlabel.h"

ImagePaint::ImagePaint(QWidget *parent) : QGLWidget(parent) {
	m_spacePressed = false;
	m_mode = MODE_MOVE;
//	m_toolMode = E_MOVE;
	m_index = 0;
//	m_toolMode = 0;
	m_numSpot = 0;
	m_overlay = 0;
	m_zoom = m_resolution = 1;
	m_wndSize = QSize(0,0);
	m_imgLoaded = false;
	m_moveOriginKeep = QPointF(0.0,0.0);
	m_zoomOriginKeep = QPointF(0.0,0.0);

	m_keyCtrl = false;
	_millisec = 50;
	m_frameCurr = 0;
	m_frameCount = 20;
	m_bZoomInOut = true;

	setAutoFillBackground(true);
	QPalette p = palette();
	p.setBrush(QPalette::Base, p.mid());
	setPalette(p);
	setCursor(Qt::OpenHandCursor);

	qApp->installEventFilter(this);

	_timer = new QTimer(this);
	connect(_timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
	_timer->stop();
}


ImagePaint::~ImagePaint() {
}


void ImagePaint::restoreSettings(QSettings& settings) {
	setZoom(settings.value("zoom", 1.0).toDouble());
	setResolution(settings.value("resolution", 1.0).toDouble());
	setOriginX(settings.value("originX", 0).toDouble());
	setOriginY(settings.value("originY", 0).toDouble());
}


void ImagePaint::saveSettings(QSettings& settings) {
	settings.setValue("zoom", m_zoom);
	settings.setValue("resolution", m_resolution);
	settings.setValue("originX", m_moveOrigin.x());
	settings.setValue("originY", m_moveOrigin.y());
}


QPointF ImagePaint::view2image(const QPointF& p) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	QPointF res = QPointF(
		(p.x() - m_moveOrigin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
		(p.y() - m_moveOrigin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	return res;
}

QPointF ImagePaint::image2zoom(const QPointF& p) const {
	return p;
	//QSize sz = size();
	//float z = m_zoom /** m_resolution*/;
	//QPointF res = QPointF(
	//	(p.x() - m_origin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
	//	(p.y() - m_origin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	//return res;
}

QPointF ImagePaint::image2view(const QPointF& q) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	return QPointF(
		(q.x() - m_imgSize.width() / 2) * z + m_moveOrigin.x() * z + sz.width() / 2,
		(q.y() - m_imgSize.height() / 2) * z + m_moveOrigin.y() * z + sz.height() / 2 );
}

QTransform ImagePaint::viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const {
	QTransform tr;
	tr.translate(sz.width()/2.0f, sz.height()/2.0f);
	tr.translate(origin.x() * zoom, origin.y() * zoom);
	tr.scale(zoom, zoom);
	tr.translate(-imageSize().width()/2.0f, -imageSize().height()/2.0f);
	return tr;
}

float ImagePaint::pt2px(float pt) const {
	return pt / (m_zoom /** m_resolution*/);
}

void ImagePaint::setOverlay(QWidget *overlay) {
	if (overlay) {
		setMouseTracking(true);
		m_overlay = overlay;
		m_overlay->setVisible(false);
	} else {
		setMouseTracking(false);
		if (m_overlay) m_overlay->setVisible(false);
		m_overlay = 0;
	}
}

void ImagePaint::onIndexChanged(int idx)
{
	m_index = idx;
	update();
}

void ImagePaint::setImage(const QImage& image) {
	m_image = image;
	imageChanged(m_image);
	m_imgSize = image.size();
	if(!m_imgLoaded)
		initGPU();
	m_imgLoaded = true;
	cleanFBO();
	initFBO();
	update();
}

void ImagePaint::setOriginX(double value) {
	double x = value;
	if (m_moveOrigin.x() != x) {
		m_moveOrigin.setX(x);
		originXChanged(x);
		update();
	}
}

void ImagePaint::setOriginY(double value) {
	double y = value;
	if (m_moveOrigin.y() != y) {
		m_moveOrigin.setY(y);
		originYChanged(y);
		update();
	}
}

void ImagePaint::setZoom(double value) {
	if (value != m_zoom) {
		m_zoom = value;
		zoomChanged(m_zoom);
		update();
	}
}

void ImagePaint::setResolution(double value) {
	if (value != m_resolution) {
		m_resolution = value;
		resolutionChanged(m_resolution);
		update();
	}
}

void ImagePaint::zoomIn() {
	setZoom(m_zoom * 2);
}

void ImagePaint::zoomOut() {
	setZoom(m_zoom / 2);
}

void ImagePaint::reset() {
	m_zoom = 1.0;
	m_resolution = 1.0;
	m_moveOrigin = QPoint(0, 0);
	m_zoomOrigin = QPoint(0, 0);
	m_moveOriginKeep = QPoint(0, 0);
	m_zoomOriginKeep = QPoint(0, 0);
	zoomChanged(1);
	resolutionChanged(1);
	originXChanged(0);
	originYChanged(0);
	update();
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
	MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
}

void ImagePaint::hold() {
	//m_images[1] = m_images[0];
	update();
}

void ImagePaint::toggle() {
	m_index = 1 - m_index;
	QString title = window()->windowTitle().replace(" -- hold", "");
	if (m_index)
		title += " -- hold";
	window()->setWindowTitle(title);
	update();
} 

void ImagePaint::copy() {
	QClipboard *clipboard = QApplication::clipboard();
	clipboard->setImage(image());
}

void ImagePaint::savePNG(const QString& text) {
	QSettings settings;
	QString inputPath = window()->windowFilePath();
	QString outputPath = settings.value("savename", inputPath).toString();

	QString filename;
	QFileInfo fi(inputPath);
	QFileInfo fo(outputPath);
	if (!fi.baseName().isEmpty()) {
		QFileInfo fn(fo.dir(), fi.baseName() + "-out.png");
		filename  = fn.absoluteFilePath();
	} else {
		filename  = fo.absolutePath();
	}

	filename = QFileDialog::getSaveFileName(this, "Save PNG", filename, 
		"PNG Format (*.png);;All files (*.*)");
	if (!filename.isEmpty()) {
		//QImage tmp(image());
		_tex[T_FIN]->bind();
		unsigned char *pData = new unsigned char[m_imgSize.width()*m_imgSize.height()*3];
		glGetTexImage(GL_TEXTURE_2D,0,GL_RGB,GL_UNSIGNED_BYTE,pData);
		QImage tmp = QImage(pData, m_imgSize.width(), m_imgSize.height(), QImage::Format_RGB888);
		
		if (!text.isEmpty()) tmp.setText("Description", text);
		if (!tmp.save(filename)) 
		{
			QMessageBox::critical(this, "Error", QString("Saving PNG '%1' failed!").arg(filename));
			return;
		}
		delete []pData;
		settings.setValue("savename", filename);
	}
}

bool ImagePaint::eventFilter( QObject *watched, QEvent *e ) {
	if (!hasFocus() && (m_mode == MODE_MOVE) && (e->type() == QEvent::KeyPress)) {
		QKeyEvent *k = (QKeyEvent*)e;
		if (k->key() == Qt::Key_Space) {
			QPoint gp = mapFromGlobal(QCursor::pos());
			if (rect().contains(gp)) {
				setFocus(Qt::OtherFocusReason);
				keyPressEvent(k);
				return true;
			}
		}
	}
	return QWidget::eventFilter(watched, e);
}


void ImagePaint::leaveEvent( QEvent *e ) {
	QWidget::leaveEvent(e);
}

void ImagePaint::keyPressEvent( QKeyEvent *e ) {
	if ((m_mode == MODE_MOVE) && (e->key() == Qt::Key_Space)) {
		if (!m_spacePressed) {
			if (m_overlay && m_overlay->isVisible()) m_overlay->setVisible(false);
			m_cursor = cursor();
			setCursor(Qt::OpenHandCursor);
			m_spacePressed = true;
		}
	} 
	else if(e->key() == Qt::Key_Control){
		m_keyCtrl = true;
	}
	else {
		QWidget::keyPressEvent(e);
	}
}


void ImagePaint::keyReleaseEvent( QKeyEvent *e ) {
	if (e->key() == Qt::Key_Space) {
		if (!e->isAutoRepeat()) {
			if (m_mode == MODE_MOVE) {
				setCursor(m_cursor);
				m_cursor = QCursor();
			}
			m_spacePressed = false;
		}
	}
	else if(e->key() == Qt::Key_Control){
		m_keyCtrl = false;
	}
	else {
		QWidget::keyReleaseEvent(e);
	}
}


void ImagePaint::mousePressEvent( QMouseEvent *e ) {
	m_dragButton = e->button();
	//if(m_toolMode == E_MOVE )
	if(m_keyCtrl == true && m_dragButton==Qt::LeftButton)
	{
		m_bZoomInOut = true;
		_timer->start(_millisec);
	}
	else if(m_keyCtrl == true && m_dragButton==Qt::RightButton)
	{
		m_bZoomInOut = false;
		_timer->start(_millisec);
	}
	else
	{
		if(m_dragButton == Qt::LeftButton || m_dragButton == Qt::RightButton)
		{
			setCursor(Qt::ClosedHandCursor);
			m_moveStart =  e->pos();
			update();
		}
	}
}


void ImagePaint::mouseMoveEvent( QMouseEvent *e ) {
	//if(m_toolMode == E_MOVE )
	{
		if(m_dragButton == Qt::LeftButton)
		{
			m_moveOrigin = m_moveOriginKeep + QPointF(e->pos() - m_moveStart) / m_zoom;
			originXChanged(m_moveOrigin.x());
			originYChanged(m_moveOrigin.y());
			update();
		}
		else if(m_dragButton == Qt::RightButton)
		{
			double u = double(e->pos().y()-m_moveStart.y())/double(m_wndSize.height());
			setZoom(m_zoom * (1 + u));
			m_moveStart = e->pos();
		}
	}
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
}


void ImagePaint::mouseReleaseEvent( QMouseEvent *e ) {
	m_dragButton = Qt::NoButton; 
	//if(m_toolMode == E_MOVE)
	{
		setCursor(Qt::OpenHandCursor);
		m_moveOriginKeep = m_moveOrigin;
	}
	/*else if(m_toolMode == E_ZOOM)
	{
		setCursor(Qt::OpenHandCursor);
		m_zoomOriginKeep = m_zoomOrigin;
	}*/
}

void ImagePaint::wheelEvent(QWheelEvent *e) {
	QSize sz = size();
	double u = e->delta() / 120.0 / 4.0;
	if (u < -0.5) u = -0.5;
	if (u > 0.5) u = 0.5;

	//if(m_toolMode == E_MOVE)
	{
		setZoom(m_zoom * (1 + u));
		MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
	}
}

void ImagePaint::draw(QPainter& p, const QRectF& R, const QImage& image) {
	QRect aR = R.toAlignedRect();
	p.drawImage(aR.x(), aR.y(), image.copy(aR));
}
//////////////////////////////////////////////////////////////////////////// opengl
void ImagePaint::initGPU() {
	finalizeGPU();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_LIGHTING);

	initFBO();
	initShaders();
}
void ImagePaint::finalizeGPU() {
	cleanFBO();
	cleanShaders();
	//glPopAttrib();
}

void ImagePaint::cleanFBO() {
	for(int i=0; i<NB_FBO; i++)
	{
		delete _fbo[i];
		_fbo[i] = NULL;
	}
	for(int i=0;i<NB_TEX;++i) 
	{
		delete _tex[i];
		_tex[i] = NULL;
	}
}

void ImagePaint::cleanShaders() {
	for(int i=0;i<NB_PROG;++i) 
	{
		if(_prog[i]!=NULL) 
		{
			delete _prog[i];
			_prog[i] = NULL;
		}
	}
}
void ImagePaint::reloadShaders() {
	if(_prog[0]!=NULL)
	{
		for(int i=0; i<NB_PROG; i++)
			_prog[i]->reload();
		setShaderParameters();
		update();
		std::cout<< "Shaders have been successfully reloaded!" << std::endl;
	}
}

void ImagePaint::initializeGL() {
	/// glew initialization
	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
		fprintf(stderr, "Error: %s\n",glewGetErrorString(err));

	/// GPU initialization
	for(int i=0; i<NB_FBO; i++)
		_fbo[i] = NULL;
	for(int i=0; i<NB_TEX; i++)
		_tex[i] = NULL;
	for(int i=0; i<NB_PROG; i++)
		_prog[i] = NULL;

	if(m_imgLoaded)
		initGPU();

	/// opengl initialization
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);

	QColor bc = palette().color(QPalette::Base);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void ImagePaint::loadTexture(int tex_id, const QImage &qimg)
{
	_tex[tex_id]->bind();
	if(qimg.format()!=QImage::Format_RGB32)
		qimg.convertToFormat(QImage::Format_RGB32);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, qimg.width(), qimg.height(), 0,
		GL_BGRA, GL_UNSIGNED_BYTE, qimg.bits());
}
static float hermite(float x, int order){
	switch(order){
	case 0 : return 1; break;
	case 1 : return 2*x; break;
	case 2 : return -2+4*x*x; break;
	case 3 : return -12*x+8*x*x*x; break;
	case 4 : return 12-48*x*x+16*x*x*x*x; break;
	case 5 : return 120*x+160*x*x*x+32*x*x*x*x*x; break;
	default: std::cerr << "Order not supported"<< endl; return 1; break;
	}
}
static std::vector<float> precomputeGaussianDerivatives(int upToOrder, float scale, float supportFactor)
{
	const float SQRT2 =  1.414213562373095049;
	const float SQRT2PI = 2.506628274631000502;

	int siz = (int)(supportFactor*scale+0.0001);
	siz = siz<1 ? 1 : siz;
	int m_precomputedScale = scale;
	std::vector<float> pgd = std::vector<float> ((upToOrder+1)*(2*siz+1));

	for (int k=-siz ; k<=siz ; k++)
	{
		float base =  (1.0f/(scale*SQRT2PI)) * exp(-(k*k)/(2.0f*scale*scale));
		float herm = 1.0f;
		float normFact = 1.0f;
		float naturalFact = 1.0f;
		pgd[k+siz] = (base * herm * normFact * naturalFact);
		for (int o=1 ; o<=upToOrder ; o++)
		{
			herm = hermite(k/(scale*SQRT2), o);
			normFact *= -1.0/(scale*SQRT2);
			naturalFact *= sqrt(scale);
			pgd[o*(2*siz+1)+k+siz] = (base * herm * normFact * naturalFact);
		}
	}
	return pgd;
}
void ImagePaint::initGaussWeightsTex(int tex_id, int smsz, float supportFactor)
{
	if(_tex[tex_id]!=NULL)
	{
		delete _tex[tex_id];
		_tex[tex_id] = NULL;
	}
	std::vector<float> GD = precomputeGaussianDerivatives(2,float(smsz)/supportFactor,supportFactor);
	int neighborhood = smsz*2+1;

	const int cn = 4;
	float *pGauss = new float[neighborhood*cn*3];
	for(int i=0; i<neighborhood; i++)
		for(int j=0; j<cn; j++)
			pGauss[cn*i+j] = GD[neighborhood-1-i];
	for(int i=0; i<neighborhood; i++)
		for(int j=0; j<cn; j++)
			pGauss[neighborhood*cn+cn*i+j] = GD[neighborhood-1-i+neighborhood];
	for(int i=0; i<neighborhood; i++)
		for(int j=0; j<cn; j++)
			pGauss[2*neighborhood*cn+cn*i+j] = GD[neighborhood-1-i+neighborhood*2];

	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,neighborhood,3,
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT), TextureParams(GL_NEAREST,GL_NEAREST),pGauss);
	delete []pGauss;
}
void ImagePaint::initNoiseTex(int tex_id, const QSize &imgSize)
{
	int num = imgSize.width()*imgSize.height()*4;
	float *pNoise = new float[num];
	int maxsc = 3000;
	for (int i=0; i<num; i++)
	{		
		pNoise[i] = float((rand()%maxsc))/float(maxsc-1);
	}
	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,imgSize.width(),imgSize.height(),
		GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_LINEAR,GL_LINEAR),pNoise);
	delete []pNoise;
}
void ImagePaint::setTextureDefault(int tex_id, float val)
{
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*4];
	for(int i=0; i<m_imgSize.width()*m_imgSize.height()*4; i++)
		pData[i] = val;
	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(), m_imgSize.height(),
		GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_NEAREST,GL_NEAREST),pData);
	delete []pData;
}
bool ImagePaint::loadSegmentation(int tex_id, const char*filename)
{
	QImage qimg(filename);
	if(qimg.isNull())
	{
		setTextureDefault(tex_id,0.0);
		return false;
	}
	int w = qimg.width();
	if(qimg.width()!=m_imgSize.width() || qimg.height()!=m_imgSize.height())
		return false;

	_tex[tex_id] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
	_tex[tex_id]->bind();
	if(qimg.format()!=QImage::Format_RGB32)
		qimg.convertToFormat(QImage::Format_RGB32);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, qimg.width(), qimg.height(), 0,
		GL_BGRA, GL_UNSIGNED_BYTE, qimg.bits());

	return true;
}
void ImagePaint::loadImportanceMap(int tex_id, const char*filename)
{
	std::ifstream infile(filename);
	if(infile.good())
	{
		std::vector<float> vv;
		int maxsc = 3000;

		/// random color for background
		vv.push_back(0.0); 
		vv.push_back(0.0);		
		vv.push_back(0.0);
		/// importance for background
		vv.push_back(0.0);

		std::string segname;
		std::string tmp1, tmp2;
		float importVal;
		int idx;
		int numspot;
		infile >> numspot >> tmp1 >> tmp2;
		vv.resize((numspot+1)*4);
		while (!infile.eof())
		{
			infile >> segname >> importVal >> idx;
			/// random color
			vv[idx*4+0] = (float((rand()%maxsc))/float(maxsc-1)); 
			vv[idx*4+1] = (float((rand()%maxsc))/float(maxsc-1));		
			vv[idx*4+2] = (float((rand()%maxsc))/float(maxsc-1));
			/// importance
			vv[idx*4+3] = (importVal);
		}
		
		m_numSpot = numspot+1;
		_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,numspot+1,1,
			GL_RGBA16F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_NEAREST,GL_NEAREST),&vv[0]);
	}
	else
	{
		setTextureDefault(tex_id,0.0);
		std::cerr << "Importance file doesn't exist!!!" << std::endl;
	}
}
void ImagePaint::initFBO() {
	if(_fbo[FBO1]==NULL)
	{
		for(int i=0; i<NB_FBO; i++)
			_fbo[i] = new FramebufferObject();

		_tex[T_ORG	] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(),m_imgSize.height(),
			GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT), TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_FLOW1] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_FLOW2] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_SMOOTH1] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_SMOOTH2] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_LINE1] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_LINE2] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_FIN	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
	}

	/// load image to gpu texture	
	loadTexture(T_ORG,m_image);
	QFileInfo fi(MainWindow::getInstance()->fileName());
	if (!fi.baseName().isEmpty()) 
	{
		QFileInfo fn(fi.dir(), "mask.png");
		QString sgname = fn.absoluteFilePath();
		if( !loadSegmentation(T_SEG, sgname.toAscii()) )
		{
			std::cerr << "Image sizes are not coincident!" << std::endl;
			m_imgLoaded = false;
		}
	}
	else 
	{		
		std::cerr << "Mask image doesn't exist!" << std::endl;
		m_imgLoaded = false;
	}
	if (!fi.baseName().isEmpty()) 
	{
		QFileInfo fn(fi.dir(), "output.txt");
		QString impname = fn.absoluteFilePath();
		loadImportanceMap(T_IMPORT, impname.toAscii());
	}
	else 
	{
		std::cerr << "Importance file doesn't exist!" << std::endl;
		m_imgLoaded = false;
	}

	initGaussWeightsTex(T_FLOW_G,m_flowSize,3.0);
	initGaussWeightsTex(T_SMOOTH_G,m_smoothSize,3.0);
	initGaussWeightsTex(T_LINE_G,m_lineSize,3.0);

	initNoiseTex(T_NOISE,m_imgSize);

	/// bind to fbo attachment
	_fbo[FBO1]->bind();
	_fbo[FBO1]->unattachAll();
	{
		_tex[T_FLOW1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_FLOW1]->format().target(),_tex[T_FLOW1]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_FLOW2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_FLOW2]->format().target(),_tex[T_FLOW2]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_SMOOTH1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_SMOOTH1]->format().target(),_tex[T_SMOOTH1]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_SMOOTH2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_SMOOTH2]->format().target(),_tex[T_SMOOTH2]->id(),GL_COLOR_ATTACHMENT3_EXT);

		_tex[T_LINE1]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_LINE1]->format().target(),_tex[T_LINE1]->id(),GL_COLOR_ATTACHMENT4_EXT);

		_tex[T_LINE2]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_LINE2]->format().target(),_tex[T_LINE2]->id(),GL_COLOR_ATTACHMENT5_EXT);

		_tex[T_FIN]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_FIN]->format().target(),_tex[T_FIN]->id(),GL_COLOR_ATTACHMENT6_EXT);
	}
	_fbo[FBO1]->isValid();
	FramebufferObject::unbind();
}

void ImagePaint::setShaderParameters() {
	for(int i=0; i<2; i++)		/// flow shaders
	{
		int pid = P_FLOW1 + i;
		_prog[pid]->enable();
		_prog[pid]->addUniform("wh");
		_prog[pid]->addUniform("flowSize");
		_prog[pid]->addUniform("isVertical");
		_prog[pid]->addUniform("txOrg");
		_prog[pid]->addUniform("txSeg");
		_prog[pid]->addUniform("txGauss");
		_prog[pid]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[(i==0?T_ORG:T_FLOW1)]->id());
		_prog[pid]->setUniformTexture("txSeg",		1,GL_TEXTURE_2D,_tex[T_SEG]->id());
		_prog[pid]->setUniformTexture("txGauss",	2,GL_TEXTURE_2D,_tex[T_LINE_G]->id());
		_prog[pid]->disable();
	}

	for(int i=0; i<2; i++)		/// smoothing shaders
	{
		int pid = P_SMOOTH1 + i;
		_prog[pid]->enable();
		_prog[pid]->addUniform("wh");
		_prog[pid]->addUniform("smoothSize");
		_prog[pid]->addUniform("isVertical");
		_prog[pid]->addUniform("txOrg");
		_prog[pid]->addUniform("txFlow");
		_prog[pid]->addUniform("txSeg");
		_prog[pid]->addUniform("txImport");
		_prog[pid]->addUniform("txGauss");
		_prog[pid]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[(i==0?T_ORG:T_SMOOTH1)]->id());
		_prog[pid]->setUniformTexture("txFlow",		1,GL_TEXTURE_2D,_tex[T_FLOW2]->id());
		_prog[pid]->setUniformTexture("txSeg",		2,GL_TEXTURE_2D,_tex[T_SEG]->id());
		_prog[pid]->setUniformTexture("txImport",	3,GL_TEXTURE_2D,_tex[T_IMPORT]->id());
		_prog[pid]->setUniformTexture("txGauss",	4,GL_TEXTURE_2D,_tex[T_SMOOTH_G]->id());
		_prog[pid]->disable();
	}

	for(int i=0; i<2; i++)		/// line extraction shaders
	{
		int pid = P_LINE1 + i;
		_prog[pid]->enable();
		_prog[pid]->addUniform("wh");
		_prog[pid]->addUniform("lineSize");
		_prog[pid]->addUniform("lineHard");
		_prog[pid]->addUniform("isVertical");
		_prog[pid]->addUniform("txOrg");
		_prog[pid]->addUniform("txFlow");
		_prog[pid]->addUniform("txSeg");
		_prog[pid]->addUniform("txImport");
		_prog[pid]->addUniform("txGauss");
		_prog[pid]->setUniformTexture("txOrg",		0,GL_TEXTURE_2D,_tex[(i==0?T_ORG:T_LINE1)]->id());
		_prog[pid]->setUniformTexture("txFlow",		1,GL_TEXTURE_2D,_tex[T_FLOW2]->id());
		_prog[pid]->setUniformTexture("txSeg",		2,GL_TEXTURE_2D,_tex[T_SEG]->id());
		_prog[pid]->setUniformTexture("txImport",	3,GL_TEXTURE_2D,_tex[T_IMPORT]->id());
		_prog[pid]->setUniformTexture("txGauss",	4,GL_TEXTURE_2D,_tex[T_LINE_G]->id());
		_prog[pid]->disable();
	}

	_prog[P_FIN]->enable();
	_prog[P_FIN]->addUniform("wh");
	_prog[P_FIN]->addUniform("display");
	_prog[P_FIN]->addUniform("numSpot");
	_prog[P_FIN]->addUniform("zoomType");
	_prog[P_FIN]->addUniform("frameCurr");
	_prog[P_FIN]->addUniform("frameCount");
	_prog[P_FIN]->addUniform("nClass");
	_prog[P_FIN]->addUniform("class1");
	_prog[P_FIN]->addUniform("class2");
	_prog[P_FIN]->addUniform("class3");
	_prog[P_FIN]->addUniform("class4");
	_prog[P_FIN]->addUniform("class5");
	_prog[P_FIN]->addUniform("class6");
	_prog[P_FIN]->addUniform("txOrg");
	_prog[P_FIN]->addUniform("txNoise");
	_prog[P_FIN]->addUniform("txSeg");
	_prog[P_FIN]->addUniform("txImport");
	_prog[P_FIN]->addUniform("txFlow");
	_prog[P_FIN]->addUniform("txSmooth");
	_prog[P_FIN]->addUniform("txLine");
	_prog[P_FIN]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_FIN]->setUniformTexture("txNoise",	1,GL_TEXTURE_2D,_tex[T_NOISE]->id());
	_prog[P_FIN]->setUniformTexture("txSeg",	2,GL_TEXTURE_2D,_tex[T_SEG]->id());
	_prog[P_FIN]->setUniformTexture("txImport",	3,GL_TEXTURE_2D,_tex[T_IMPORT]->id());
	_prog[P_FIN]->setUniformTexture("txFlow",	4,GL_TEXTURE_2D,_tex[T_FLOW2]->id());
	_prog[P_FIN]->setUniformTexture("txSmooth",	5,GL_TEXTURE_2D,_tex[T_SMOOTH2]->id());
	_prog[P_FIN]->setUniformTexture("txLine",	6,GL_TEXTURE_2D,_tex[T_LINE2]->id());
	_prog[P_FIN]->disable();
}
void ImagePaint::initShaders() {
	static std::string SHADER_DIR = "../semanticVis/shaders/";
	_prog[P_FLOW1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"flow.fs");
	_prog[P_FLOW2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"flow.fs");
	_prog[P_SMOOTH1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"smooth.fs");
	_prog[P_SMOOTH2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"smooth.fs");
	_prog[P_LINE1	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"line.fs");
	_prog[P_LINE2	]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"line.fs");
	_prog[P_FIN		]= new GPUProgram(SHADER_DIR+"default.vs",		SHADER_DIR+"fin.fs");

	setShaderParameters();
}

void ImagePaint::resizeGL(int w, int h) {
	m_wndSize = QSize(w,h);
}

void ImagePaint::paintGL() {
	if(!m_imgLoaded)
		return;

	QRectF zoomWnd = QRectF(-m_zoomOrigin
		+QPointF(m_imgSize.width(),m_imgSize.height())*(0.5-0.5/float(m_resolution)),
		QSizeF(m_imgSize)/float(m_resolution));
	float ws = 1.0f/float(m_imgSize.width());
	float hs = 1.0f/float(m_imgSize.height());

	glDisable(GL_LIGHTING);
	glColor4f(1,1,1,1);
	glEnable(GL_TEXTURE_2D);

	/////////////////////////////////////////////// render to texture
	_fbo[FBO1]->bind();
	swapToLocalMode(m_imgSize.width(), m_imgSize.height());

	for(int i=0; i<2; i++)
	{
		glDrawBuffer(*FramebufferObject::buffers(i+0));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_FLOW1+i]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_FLOW1+i]->setUniform2f("wh",ws,hs);
		_prog[P_FLOW1+i]->setUniform1i("flowSize",m_flowSize);
		_prog[P_FLOW1+i]->setUniform1i("isVertical",i%2);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_FLOW1+i]->disable();
	}

	for(int i=0; i<2; i++)
	{
		glDrawBuffer(*FramebufferObject::buffers(i+2));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_SMOOTH1+i]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_SMOOTH1+i]->setUniform2f("wh",ws,hs);
		_prog[P_SMOOTH1+i]->setUniform1i("smoothSize",m_smoothSize);
		_prog[P_SMOOTH1+i]->setUniform1i("isVertical",i%2);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_SMOOTH1+i]->disable();
	}

	for(int i=0; i<2; i++)
	{
		glDrawBuffer(*FramebufferObject::buffers(i+4));
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		_prog[P_LINE1+i]->enable();
		glEnable(GL_TEXTURE_2D);
		_prog[P_LINE1+i]->setUniform2f("wh",ws,hs);
		_prog[P_LINE1+i]->setUniform1i("lineSize",m_lineSize);
		_prog[P_LINE1+i]->setUniform1f("lineHard",float(m_lineHard));
		_prog[P_LINE1+i]->setUniform1i("isVertical",i%2);
		drawQuad(m_imgSize.width(), m_imgSize.height());
		_prog[P_LINE1+i]->disable();
	}

	glDrawBuffer(*FramebufferObject::buffers(6));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_FIN]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_FIN]->setUniform2f("wh",ws,hs);
	_prog[P_FIN]->setUniform1i("frameCurr",m_frameCurr);
	_prog[P_FIN]->setUniform1i("frameCount",m_frameCount);
	_prog[P_FIN]->setUniform1i("zoomType",m_zoomType);
	_prog[P_FIN]->setUniform1i("display",m_index);
	_prog[P_FIN]->setUniform1i("numSpot",m_numSpot);
	Mlabel *gl = MainWindow::getInstance()->getGradientLabel();
	_prog[P_FIN]->setUniform1i("nClass",gl->getPointSize());
	QColor clr = gl->getColor(0);
	_prog[P_FIN]->setUniform4f("class1",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(0));
	clr = gl->getColor(1);
	_prog[P_FIN]->setUniform4f("class2",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(1));
	clr = gl->getColor(2);
	_prog[P_FIN]->setUniform4f("class3",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(2));
	clr = gl->getColor(3);
	_prog[P_FIN]->setUniform4f("class4",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(3));
	clr = gl->getColor(4);
	_prog[P_FIN]->setUniform4f("class5",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(4));
	clr = gl->getColor(5);
	_prog[P_FIN]->setUniform4f("class6",float(clr.redF()),float(clr.greenF()),float(clr.blueF()),gl->getPosition(5));
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_FIN]->disable();

	swapToWorldMode();

	/////////////////////////////////// render to screen �� horizontal flip ��
	swapToLocalMode(m_wndSize.width(), m_wndSize.height());
	FramebufferObject::unbind();

	glEnable(GL_TEXTURE_2D);
	_tex[T_FIN]->bind();
	QColor bc = palette().color(QPalette::Window);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	QSize isz = m_imgSize*m_zoom;
	drawQuadScreen(isz.width(), isz.height(), 
		float(m_wndSize.width()-isz.width())/2.0f + m_moveOrigin.x()*m_zoom, 
		float(m_wndSize.height()-isz.height())/2.0f - m_moveOrigin.y()*m_zoom);
	glClearColor(1,1,1,0);

	swapToWorldMode();
}

void ImagePaint::nextFrame()
{
	if(m_frameCurr<0 || m_frameCurr<=m_frameCount)
	{
		/// zoom on CPU
		//if(m_bZoomInOut)
		//	setZoom (m_zoom * 1.1);
		//else
		//	setZoom (m_zoom / 1.1);
		update();
		m_frameCurr++;
	}
	else
	{
		m_frameCurr = 0;
		_timer->stop();
	}
}
