#include "vectorization.h"

namespace vectorization {

void Vectorization(const QImage &src, VectorGraph &dest)
{
	// convert a raster image into a vector graph
}

void DrawVectorGraph(const VectorGraph &vg, QImage &dest)
{
	// convert a vector graph into a raster image
}

void ExtractSkeleton(const QImage &src, vector<QPoint> &skeleton)
{
	// extract the skeleton points from the raster image
}

void ExtractSkeleton(const QImage &src, QImage &skeletonImage)
{
	vector<QPoint> skeleton;
	ExtractSkeleton(src,skeleton);
	
	//skeletonImage = QImage(src.width(),src.height(),QImage::Format_ARGB32);
	//skeletonImage.fill(0);
	//skeletonImage.setColor(255,qRgb(255, 255, 255));
	//for (int k=0; k<skeleton.size(); k++)
	//	skeletonImage.setPixel(skeleton[k],255);
	//for(int yi=0; yi<skeletonImage.height()/2; yi++)
	//{
	//	for(int xi=0; xi<skeletonImage.width(); xi++)
	//		skeletonImage.setPixel(xi,yi,255);
	//}
}

} // for namespace
