#include <exrimageio.h>

using namespace std;

#ifdef USE_EXR
#include <ImfRgba.h>
#include <ImfRgbaFile.h>
#include <ImfArray.h>
#include <ImfEnvmap.h>
#include <Iex.h>
#endif

namespace image {

  vector<string> EXRImageIO::getExtensions() {
    vector<string> ext;
  
#ifdef USE_EXR
    ext.push_back("exr");
    ext.push_back("EXR");
#endif
  
    return ext;
  }

  Image *EXRImageIO::createImage(const string &filename) {
#ifdef USE_EXR
   Imf::RgbaInputFile file(filename.c_str());
   Imf::Array2D<Imf::Rgba> pixels;

   Imath::Box2i dw = file.dataWindow();
   int width = dw.max.x - dw.min.x + 1;
   int height = dw.max.y - dw.min.y + 1;
   pixels.resizeErase(height,width);
   file.setFrameBuffer(&pixels[0][0] - dw.min.x - dw.min.y * width, 1, width);
   file.readPixels(dw.min.y,dw.max.y);

   Image *img = new Image(filename,width,height,Image::RGBA_IMAGE);

   for(int y=0;y<height;++y) {
     for(int x=0;x<width;++x) {
       const Imf::Rgba& src = pixels[y][x];
       img->setPix(x,y,0,src.r);
       img->setPix(x,y,1,src.g);
       img->setPix(x,y,2,src.b);
       img->setPix(x,y,3,src.a);
     }
   }

   return img;
   
#else 
    cerr << "Unable to create " << filename << ", LIB_EXR needed" << endl;
    return NULL;
#endif
  }

  bool EXRImageIO::saveImage(const Image &img,const string &filename) {
#ifdef USE_EXR
    cout << "TODO : saveImage " << img.getName() << "in " << filename << ", LIB_EXR needed" << endl;
    return false;
#else 
    cerr << "Unable to save " << img.getName() << "in " << filename << ", LIB_EXR needed" << endl;
    return false;
#endif
  }

} // image namespace 

