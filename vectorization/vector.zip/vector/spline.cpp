
#include "spline.h"
#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

namespace spline {

//////////////////////////////////////////////////////////////////// load & save
	ostream &operator<<(ostream &stream, const Spline &s)
	{
		stream << s.a.i << " " << s.a.j << endl;
		stream << s.b.i << " " << s.b.j << endl;
		stream << s.c.i << " " << s.c.j << endl;
#ifdef _CUBIC
		stream << s.d.i << " " << s.d.j << endl;
#endif
		return stream;
	}
	istream &operator>>(istream &stream, Spline &s)
	{
		stream >> s.a.i >> s.a.j;
		stream >> s.b.i >> s.b.j;
		stream >> s.c.i >> s.c.j;
#ifdef _CUBIC
		stream >> s.d.i >> s.d.j;
#endif
		return stream;
	}
	ostream &operator<<(ostream &stream, const divideSpot &s)
	{
		stream << "index= " << s.index << " size= "<< s.vSpot.size() << endl;
		for (int k=0; k<s.vSpot.size(); k++)
		{
			stream << s.vSpot[k].i << " "<< s.vSpot[k].j << endl;
			stream << s.vTangent[2*k].i << " "<< s.vTangent[2*k].j 
				<<" "<< s.vTangent[2*k+1].i <<" "<< s.vTangent[2*k+1].j << endl;
			stream << s.vKeySpot[k] << endl;
			stream << s.vPara[k] << endl;
			stream << s.vType[k] <<endl;
		}
		return stream;
	}
	istream &operator>>(istream &stream, divideSpot &s)
	{
		string str1, str2;
		int sz = 0;
		stream >> str1 >> s.index >> str2 >> sz;
		if(sz<=0)
			return stream;

		s.vSpot.resize(sz);
		s.vTangent.resize(sz*2);
		s.vPara.resize(sz);
		s.vKeySpot.resize(sz);
		s.vType.resize(sz);
		for(int k=0; k<sz; k++)
		{
			stream >> s.vSpot[k].i >> s.vSpot[k].j;
			stream >> s.vTangent[2*k].i >> s.vTangent[2*k].j >> 
				s.vTangent[2*k+1].i >> s.vTangent[2*k+1].j;
			bool isc;
			stream >> isc;
			s.vKeySpot[k] = isc;
			stream >> s.vPara[k];
			int ty;
			stream >> ty;
			s.vType[k] = SplineType(ty);
		}
		return stream;
	}

	////////////////////////////////////////////////////////////////////// find edges
	static posi getStartingPoint(const QImage &edgeImg)
	{
		/// the first edge point from left-top side
		const uchar *pImg = edgeImg.bits();
		for (int yi=0; yi<edgeImg.height(); yi++,pImg+=edgeImg.bytesPerLine())
		{
			const uchar *pI = pImg;
			for (int xi=0; xi<edgeImg.width(); xi++,pI++)
			{
				if(pI[0]!=0)
					return posi(xi,yi);
			}
		}
		return posi(0,0);
	}
	static bool judgeClose(int cnt, const posi &startPos, const posi &endPos)
	{
		int dist2 = (startPos.i-endPos.i)*(startPos.i-endPos.i);
		dist2 += (startPos.j-endPos.j)*(startPos.j-endPos.j);
		/// not the first 4 points? && close enough to the starting point
		if(cnt>10 && sqrtf(float(dist2)) <= 1.5f )
			return true;
		return false;
	}
	static bool checkNeighborOne(const QImage &edgeImg, QImage &record, int xx, int yy)
	{
		if(yy<0 || yy>=edgeImg.height() || xx<0 || xx>=edgeImg.width())
			return false;
		/// traverse before? && edge point?
		if(record.pixelIndex(xx,yy)==0 && edgeImg.pixelIndex(xx,yy)!=0)
			return true;
		else
			return false;
	}

	bool dfsEdge(posi currPos,const QImage &edgeImg, closeEdge &edge,closeEdge &maxEdge,QImage &record) 
	{
		int i,j;
		posi nSpot;
		record.setPixel(currPos.i,currPos.j,1);
		edge.vPoint.push_back(currPos);
		//std::cout << "in [" << currPos.i << "," << currPos.j << "]" << std::endl;
		edge.closeness=judgeClose(edge.vPoint.size(),edge.vPoint[0],currPos);
		if (edge.closeness) return true;
		for (i=-1;i<=1;i++)
			for (j=-1;j<=1;j++)
				if ((i!=0)||(j!=0))
				{
					nSpot.i=currPos.i+i;nSpot.j=currPos.j+j;
					if (checkNeighborOne(edgeImg, record, nSpot.i, nSpot.j))
					{
						edge.cnt++;
						if (edge.vPoint.size()>maxEdge.vPoint.size()) maxEdge=edge;
						bool flag=dfsEdge(nSpot,edgeImg,edge,maxEdge,record);
						if (!flag || edge.cnt>100000) 
							return false;
						//record.setPixel(nSpot.i,nSpot.j,0);
						if (edge.closeness) 
							return true;
						//std::cout << "out [" << edge.vPoint[edge.vPoint.size()-1].i << "," << edge.vPoint[edge.vPoint.size()-1].j << "]" << std::endl;
						edge.vPoint.pop_back();
					}
				}
				return true;
	}
	void findEdge(const QImage &edgeImg, closeEdge &edge)
	{
		//edgeImg.save("edge.PNG");
		posi startPos = getStartingPoint(edgeImg);
		QImage record(edgeImg.width(), edgeImg.height(), QImage::Format_Indexed8);  /// record the traserval
		record.fill(0);
		record.setColor(0,qRgb(0,0,0));
		record.setColor(1,qRgb(1,1,1));
		
		// get all points from edgeImg
		/// TODO: pop-back an endpoint when not closed 
		posi currPos = startPos;
		closeEdge maxEdge=edge;
		dfsEdge(currPos,edgeImg,edge,maxEdge,record);
		if (maxEdge.vPoint.size()>edge.vPoint.size())
			edge=maxEdge;
		/// compute angles, and decide keypoints
		const int angleGap = 10;
		const int edgesz = edge.vPoint.size();
		edge.vAngle.resize(edgesz);
		edge.vKeyPoint.resize(edgesz);
		if(edgesz<=2*angleGap)	/// not key point if the number of points is small
		{
			for (int k=0; k<edgesz; k++)
			{
				edge.vAngle[k] = -1.0;
				edge.vKeyPoint[k] = 0;
			}
		}
		else
		{
			double prevAngle = -1.0;
			int maxNo = 0;
			int potentialCount = 0;
			const int potentialCountThreshold = 3;
			bool keypointLeaving = false;
			int prevNo=-10;
			for (int k=0; k<edgesz; k++)
			{
				int a = (k+edgesz-angleGap)%edgesz;
				int b = (k+angleGap)%edgesz;
				posi di1 = posi(edge.vPoint[a].i-edge.vPoint[k].i,edge.vPoint[a].j-edge.vPoint[k].j);
				posi di2 = posi(edge.vPoint[b].i-edge.vPoint[k].i,edge.vPoint[b].j-edge.vPoint[k].j);
				/// compute cosine()
				double angle = double(di1.i*di2.i+di1.j*di2.j);
				angle /= sqrt(double(di1.i*di1.i+di1.j*di1.j));
				angle /= sqrt((double)(di2.i*di2.i+di2.j*di2.j));
				if(angle>edge.angleThres1)
				{
					edge.vAngle[k] = angle;
					edge.vKeyPoint[k] = 1;		/// potential keypoints
					if(angle>prevAngle)
					{
						maxNo = k;
						prevAngle=angle;
					}
					keypointLeaving = true;
					potentialCount ++;
				}
				else 
				{
					edge.vAngle[k] = -1.0;
					edge.vKeyPoint[k] = 0;
					/// pickup an ultimate keypoint when leaving a potential keypoint segment
					if(potentialCount>potentialCountThreshold && keypointLeaving && (maxNo-prevNo+edgesz)%edgesz>6)
					{
						edge.vKeyPoint[maxNo] = 3;
						//prevNo=maxNo;
						keypointLeaving = false;
					}
					potentialCount = 0;
					prevAngle=-1;
				}
				//prevAngle = angle;
			}
		}
		/// compute interval keypoints
		const int keypointInterval = 30;
		int keypointCount = 0;
		int prevK=-1;
		int firstK=-1;
		for (int k=0; k<edgesz; k++)
		{
			if(edge.vKeyPoint[k] >=3 )
			{
				keypointCount = 0;
				if (prevK==-1) 
				{firstK=k;prevK=k;continue;}
				int interval=(k-prevK+edgesz)%edgesz;
				if (interval>keypointInterval)
				{
					int n=(int)(interval/keypointInterval+0.8);
					for (int j=1;j<n;j++)
					{
						int tmpK=(int)(prevK+j*interval/n)%edgesz;
						edge.vKeyPoint[tmpK]=2;
					}
				}
				prevK=k;
			}
			/*else
			{
			if(keypointCount>=keypointInterval)
			{
			edge.vKeyPoint[k] = 2;
			keypointCount = 0;
			}
			else
			keypointCount ++;
			}*/
		}
		int k=0;
		int interval=(firstK-prevK-1+edgesz)%edgesz;
		if (interval>keypointInterval)
		{
			int n=(int)(interval/keypointInterval+0.8);
			for (int j=1;j<n;j++)
			{
				int tmpK=(int)(prevK+j*interval/n)%edgesz;
				edge.vKeyPoint[tmpK]=2;
			}
		}
	}
	///////////////////////////////////////////////////////////////////////// spline fitting
	static posi compute_tangent(spline::Spline v,double t)
	{
		if (t==0)
		{
#ifdef _CUBIC
			return posi(-3*v.a.i+v.b.i,-3*v.a.j+v.b.j);
		//return posi(2*v.a.i+v.b.i,2*v.a.j+v.b.j);
#else
			return posi(-2*v.a.i+v.b.i,-2*v.a.j+v.b.j);
#endif
		}
		else if (t==1)
		{
#ifdef _CUBIC
			return posi(v.c.i-3*v.d.i, v.c.j-3*v.d.j);
#else
			return posi(v.b.i-2*v.c.i, v.b.j-2*v.c.j);		
#endif
		}else
		{
			return posi(int(-3*v.a.i*pow(1-t,2)+v.b.i*(pow(1-t,2)-2*t*(1-t))+v.c.i*(2*t*(1-t)-t*t)+v.d.i*3*pow(t,2)),int(-3*v.a.j*pow(1-t,2)+v.b.j*(pow(1-t,2)-2*t*(1-t))+v.c.j*(2*t*(1-t)-t*t)+v.d.j*3*pow(t,2)));
		}
	}

	static Spline compute_spline(posi s0, posi s1, posi t0, posi t1)
	{
		double a1=0, b1=0;
		int diff = t0.i*t1.j-t0.j*t1.i;
		if(diff!=0)
		{
			a1=double( (s1.j-s0.j)*t0.i*t1.i+s0.i*t1.i*t0.j-s1.i*t0.i*t1.j );
			a1=-2.0*a1/double(diff);
			b1=double( s1.j*t1.i*t0.j-s0.j*t0.i*t1.j+s0.i*t0.j*t1.j-s1.i*t0.j*t1.j );
			b1=-2.0*b1/double(diff);
		}
		return Spline(posd(double(s0.i),double(s0.j)),posd(a1,b1),posd(double(s1.i),double(s1.j)));
	}
	
#ifndef _CUBIC
	static Spline compute_spline(const vector<posi> &pn, int prevK, int k)
	{
		double l=(k-prevK+pn.size())%pn.size();
		double a0,a1,a2;
		double b0,b1,b2;
		a0=pn[prevK].i;
		a2=pn[k].i;
		b0=pn[prevK].j;
		b2=pn[k].j;
		double dena,denb,numa,numb;
		numa=numb=dena=denb=0;
		for (int j=0;j<=l;j++)
		{
			numa+=j/l*(1-j/l)*(a0*pow(1-j/l,2)+a2*pow(j/l,2)-pn[(prevK+j-1)%pn.size()].i);
			numb+=j/l*(1-j/l)*(b0*pow(1-j/l,2)+b2*pow(j/l,2)-pn[(prevK+j-1)%pn.size()].j);
			dena+=pow(j/l,2)*pow(1-j/l,2);
		}
		a1=-numa/dena;
		b1=-numb/dena;
		return Spline(posd(a0,b0),posd(a1,b1),posd(a2,b2));
	}
#else
	static Spline compute_spline(const vector<posi> &pn, int prevK, int k)
	{
		double l=(k-prevK+pn.size())%pn.size();
		double a0,a1,a2,a3;
		double b0,b1,b2,b3;
		a0=pn[prevK].i/pow(l,3);
		a3=pn[k].i/pow(l,3);
		b0=pn[prevK].j/pow(l,3);
		b3=pn[k].j/pow(l,3);
		double a11,a12,a13,a21,a22,a23,a33,b13,b23;
		a11=a12=a13=a21=a22=a23=a33=b13=b23=0;
		for (int j=0;j<=l;j++){
			a11+=j*j*pow(l-j,4);
			a12+=pow(j*(l-j),3);
			a13+=j*pow(l-j,2)*(a0*pow(l-j,3)+a3*j*j*j-pn[(prevK+j-1)%pn.size()].i);
			b13+=j*pow(l-j,2)*(b3*j*j*j+b0*pow(l-j,3)-pn[(prevK+j-1)%pn.size()].j);
			a21+=pow(j*(l-j),3);
			a22+=j*j*j*j*pow(l-j,2);
			a23+=j*j*(l-j)*(a3*j*j*j+a0*pow(l-j,3)-pn[(prevK+j-1)%pn.size()].i);
			b23+=j*j*(l-j)*(b3*j*j*j+b0*pow(l-j,3)-pn[(prevK+j-1)%pn.size()].j);
		}

		double det=a11*a22-a12*a21;
		a1=(a12*a23-a22*a13)/det;
		a2=(a13*a21-a11*a23)/det;
		b1=(a12*b23-a22*b13)/det;
		b2=(b13*a21-a11*b23)/det;
		return Spline(posd(a0*pow(l,3),b0*pow(l,3)),posd(a1*pow(l,3),b1*pow(l,3)),posd(a2*pow(l,3),b2*pow(l,3)),posd(a3*pow(l,3),b3*pow(l,3)));
	}
#endif

	void splineFitting(const closeEdge &edge, divideSpot &spline)
	{
		const int fitStep = 5;
		int prevK = 0;
		bool prevKey = false;
		posi prevTang;
		int startK=edge.vPoint.size();
		bool hasPara = false;
		for (int k=0; k<edge.vPoint.size(); k++)
		{	
			/// get spots as keypoints in the  edge
			if(edge.vKeyPoint[k]>=2)
			{
				if (k<startK) startK=k;
				spline.vSpot.push_back(edge.vPoint[k]);
				bool trueKey = edge.vKeyPoint[k]>=3;
				spline.vKeySpot.push_back(trueKey);
				const int spotsz = spline.vSpot.size();
				posi tangLeft, tangRight;
				if(spotsz>1)		/// starting from the second spot
				{
					/// compute tangential values
					/*tangLeft = prevKey ? compute_tangent(edge.vPoint,prevK,prevK+fitStep)
					: (spotsz==2 ? compute_tangent(edge.vPoint,prevK-fitStep,prevK+fitStep) : prevTang);
					tangRight = trueKey ? compute_tangent(edge.vPoint,k-fitStep,k)
					: compute_tangent(edge.vPoint,k-fitStep,k+fitStep);*/


					/// compute the spline paramters
					//Spline sp = compute_spline(spline.vSpot[spotsz-2],spline.vSpot[spotsz-1],tangLeft,tangRight);
					Spline sp=compute_spline(edge.vPoint,prevK,k);
					spline.vPara.push_back(sp);

					tangLeft=compute_tangent(sp,0);
					tangRight=compute_tangent(sp,1);

					spline.vTangent.push_back(tangLeft);
					spline.vTangent.push_back(tangRight);

					hasPara = true;
				}
				prevK = k;
				prevTang = tangRight;
				prevKey = trueKey;
			}
		}

		if(!hasPara)
		{
			spline.vSpot.clear();
			spline.vKeySpot.clear();
		}

		/// for the last spline between the last spot and the first spot
		const int spotsz = spline.vSpot.size();
		if(spotsz<=1)
			return;
		//Spline sp = compute_spline(spline.vSpot[spotsz-1],spline.vSpot[0],tangLeft,tangRight);
		Spline sp=compute_spline(edge.vPoint,prevK,startK);
		spline.vPara.push_back(sp);
		/*posi tangLeft = prevKey ? compute_tangent(edge.vPoint,prevK,prevK+fitStep) : prevTang;
		posi tangRight = spline.vKeySpot[0] ? compute_tangent(edge.vPoint,-fitStep,0)
		: compute_tangent(edge.vPoint,-fitStep,fitStep);*/
		posi tangLeft=compute_tangent(sp,0);
		posi tangRight=compute_tangent(sp,1);

		spline.vTangent.push_back(tangLeft);
		spline.vTangent.push_back(tangRight);
		bool trueKey = edge.vKeyPoint[prevK]>=3;
		spline.vKeySpot.push_back(trueKey);

		for(int k=0; k<spline.vPara.size(); k++)
			spline.vType.push_back(INSIDE);
	}

	////////////////////////////////////////////////////////////////////// add spline

	void recomputeSpline(divideSpot &sp, int idx)
	{
		int sz = sp.vSpot.size();
		for(int k=0; k<2; k++)
		{
			int idxL = k==0 ? ((idx-1+sz)%sz) : idx;
			int idxR = (idxL+1)%sz;
#ifdef _CUBIC
			posi a=sp.vSpot[idxL];
			posi d=sp.vSpot[idxR];
			posi tanL=sp.vTangent[idxL*2];
			posi tanR=sp.vTangent[idxL*2+1];
			//tanL//(-2a.i+b.i,-2a.j+b.j)
			//tanR//(2c.i-b.i,2c.j-b.j)
			Spline v(posd(a.i,a.j),posd(tanL.i+3*a.i,tanL.j+3*a.j),posd(3*d.i+tanR.i,3*d.j+tanR.j),posd(d.i,d.j));
#else
			posi a=sp.vSpot[idxL];
			posi c=sp.vSpot[idxR];
			posi tanL=sp.vTangent[idxL*2];
			posi tanR=sp.vTangent[idxL*2+1];
			double x0=tanL.i;
			double y0=tanL.j;
			double x1=tanR.i;
			double y1=tanR.j;
			//tanL//(-2a.i+b.i,-2a.j+b.j)
			//tanR//(2c.i-b.i,2c.j-b.j)
			double det=-x1*y0+y1*x0;
			posd oldb=sp.vPara[idxL].b;
			posd b(1/det *(-x1*(-2*a.j*x0+2*a.i*y0)+x0*(2*c.i*y1-2*c.j*x1)),1/det*(-y1*(-2*a.j*x0+2*a.i*y0)+y0*(2*c.i*y1-2*c.j*x1)));
			Spline v(posd(a.i,a.j),b,posd(c.i,c.j));
#endif
			sp.vPara[idxL]=v;
		}
	}

	static void recompute_spline(divideSpot &sp, int idx,char L_R)
	{
		int sz = sp.vSpot.size();
		if (L_R=='L')
		{
			int idxL = (idx-1+sz)%sz;
			posi a=sp.vSpot[idxL];
			posi z=sp.vSpot[idx];

			if ((int)(sp.vPara[idxL].a.i-a.i+0.5)==0 && (int)(sp.vPara[idxL].a.j-a.j+0.5)==0)
			{
#ifdef _CUBIC
				Spline v(posd(a.i,a.j),sp.vPara[idxL].b,sp.vPara[idxL].c,posd(z.i,z.j));
#else
				Spline v(posd(a.i,a.j),sp.vPara[idxL].b,posd(z.i,z.j));
#endif
				sp.vPara[idxL]=v;
			}
			else sp.vPara[idxL]=Spline(posd(z.i,z.j),sp.vPara[idxL].c,sp.vPara[idxL].b,posd(a.i,a.j));
		}

		int idxR=(idx+1)%sz;
		posi a=sp.vSpot[idx];
		posi z=sp.vSpot[idxR];
		if ((int)(sp.vPara[idxR].a.i-z.i+0.5)==0 && (int)(sp.vPara[idxR].a.j-z.j+0.5)==0)
		{
#ifdef _CUBIC
			Spline v(posd(a.i,a.j),sp.vPara[idx].b,sp.vPara[idx].c,posd(z.i,z.j));
#else
			Spline v(posd(a.i,a.j),sp.vPara[idx].b,sp.posd(z.i,z.j));
#endif
			sp.vPara[idx]=v;
		}
		else sp.vPara[idx]=Spline(posd(z.i,z.j),sp.vPara[idx].c,sp.vPara[idx].b,posd(a.i,a.j));
	}

	void addSpline(vector<divideSpot> &vsp, divideSpot &sp, const QImage &img, int joinSize)
	{
		//joinSize=20;
		bool prevCombine=false;//if previous point is already combined to an old point
		int prevIdx;
		for (int k=0; k<sp.vSpot.size(); k++)
		{
			/// check previous points
			int idx2 = img.pixelIndex(sp.vSpot[k].i,sp.vSpot[k].j);
			int idx = (idx2-1)/2;
			if(idx2>vsp.size()*2)
			{
				cerr << "keypoint index " << idx <<" in joinImg is out of range!" << std::endl;
				continue;
				prevCombine=false;
			}
			if(idx2!=0 /*&& idx2%2==0*/)			/// meet a keypoint
			{
				/// move the current spot, recompute the parameters : for 'sp' only
				int minIdx = 0;
				int minDist = 1000000;
				int t;
				for (int s=0; s<vsp[idx].vSpot.size(); s++)
				{
					int nextS=(s+1)%vsp[idx].vSpot.size();
					for (int i=0;i<60;i++)
					{
					    posd samp = samplingSpline(vsp[idx].vPara[s],double(i)/double(60));
						posi sampInt(int(samp.i),int(samp.j));
						double dist=pow(double(sp.vSpot[k].i-sampInt.i),2)+pow(double(sp.vSpot[k].j-sampInt.j),2);
						if (dist<minDist)
						{
							minDist=dist;
							minIdx=s;
							t=i;
						}
					}
				}
				double dist=pow(double(sp.vSpot[k].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[k].j-vsp[idx].vSpot[minIdx].j),2);
				int nextI=(minIdx+1)%vsp[idx].vSpot.size();
				double dist2=pow(double(sp.vSpot[k].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[k].j-vsp[idx].vSpot[nextI].j),2);
				if (sp.vKeySpot[k] && dist>joinSize*joinSize && dist2>joinSize*joinSize) 
				{
					vector<posi>::iterator	vSpot;
					vSpot=vsp[idx].vSpot.begin();			
					vSpot+=minIdx+1;
					vsp[idx].vSpot.insert(vSpot,sp.vSpot[k]);
					vector<posi>::iterator	vTangent;
					vTangent=vsp[idx].vTangent.begin();		
					vTangent+=minIdx*2+1;
					int nextK=(k+1)%sp.vSpot.size();
					nextI=(minIdx+2)%vsp[idx].vSpot.size();
					//double tmpdist1=pow(double(sp.vSpot[nextK].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[nextK].j-vsp[idx].vSpot[minIdx].j),2);
					//double tmpdist2=pow(double(sp.vSpot[nextK].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[nextK].j-vsp[idx].vSpot[nextI].j),2);
					posi tang=compute_tangent(vsp[idx].vPara[minIdx],double(t)/double(60));
     				posd Spot=samplingSpline(vsp[idx].vPara[minIdx],double(t)/double(60));
					posd newSpot=posd((Spot.i+sp.vSpot[k].i)/2,(Spot.j+sp.vSpot[k].j)/2);
					sp.vSpot[k]=posi(int(newSpot.i),int(newSpot.j));
					recomputeSpline(sp,k);
					vsp[idx].vSpot[minIdx+1]=sp.vSpot[k];
					vsp[idx].vTangent.insert(vTangent,2,tang);
					/*vTangent=vsp[idx].vTangent.begin();
					vTangent+=minIdx*2+1;
					vsp[idx].vTangent.insert(vTangent,posi(-tang.i,-tang.j));*/
					vector<Spline>::iterator  vPara;
					vPara=vsp[idx].vPara.begin();		
					vPara+=minIdx;
					Spline v(posd(vsp[idx].vSpot[minIdx].i,vsp[idx].vSpot[minIdx].j),posd(0,0),posd(0,0),posd(sp.vSpot[k].i,sp.vSpot[k].j));
					vsp[idx].vPara[minIdx].a=posd(sp.vSpot[k].i,sp.vSpot[k].j);
					vsp[idx].vPara.insert(vPara,v);
					recomputeSpline(vsp[idx],minIdx+1);
					vector<bool>::iterator	vKeySpot;
					vKeySpot=vsp[idx].vKeySpot.begin();
					vKeySpot+=minIdx+1;
					vsp[idx].vKeySpot.insert(vKeySpot,true);
					/// added by jz, need to be checked by leiqi
					vector<SplineType>::iterator vType;
					vType=vsp[idx].vType.begin();			
					vType+=minIdx+1;
					vsp[idx].vType.insert(vType,INSIDE);
					/// end of adding

					//vsp[idx].vType.insert();
					
					if (prevCombine) 
					{
						int prevK=(k-1+sp.vPara.size())%sp.vPara.size();
						
						double tmpdist1=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[minIdx].j),2);
					    double tmpdist2=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[nextI].j),2);
						if (tmpdist1<2)
						{
							vsp[idx].vPara[minIdx]=sp.vPara[prevK];
						    vsp[idx].vType[minIdx]=TWOSIDE;
							sp.vType[prevK]=TWOSIDE;
						}else if (tmpdist2<2)
						{
							vsp[idx].vPara[minIdx+1]=Spline(sp.vPara[prevK].d,sp.vPara[prevK].c,sp.vPara[prevK].b,sp.vPara[prevK].a);
							vsp[idx].vType[minIdx+1]=TWOSIDE;
							sp.vType[prevK]=TWOSIDE;
						}else{
							int backwardIdx=(minIdx-1+vsp[idx].vSpot.size())%vsp[idx].vSpot.size();
							tmpdist1=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[backwardIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[backwardIdx].j),2);
							int forwardIdx=(nextI+1)%vsp[idx].vSpot.size();
							tmpdist2=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[forwardIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[forwardIdx].j),2);
							if (tmpdist1<2)
							{
								int midIdx=minIdx+1;
								//replace midIdx to minI+1
								vector<posi>::iterator	vSpot;
								vSpot=sp.vSpot.begin();			
								vSpot+=prevK+1;
								sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
								vector<posi>::iterator vTangent;
								vTangent=sp.vTangent.begin();
								vTangent+=prevK*2+1;
								sp.vTangent.insert(vTangent,vsp[idx].vTangent[prevIdx*2+1]);
								vTangent=sp.vTangent.begin()+prevK*2+2;
								sp.vTangent.insert(vTangent,vsp[idx].vTangent[midIdx*2]);
								vector<Spline>::iterator vPara;
								sp.vTangent[prevK*2]=vsp[idx].vTangent[prevIdx*2];
								sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=vsp[idx].vTangent[midIdx*2+1];
								vPara=sp.vPara.begin();
								vPara+=prevK;
								sp.vPara.insert(vPara,vsp[idx].vPara[prevIdx]);
								sp.vPara[prevK+1]=vsp[idx].vPara[midIdx];
								vector<bool>::iterator vKeySpot;
								vKeySpot=sp.vKeySpot.begin();
								vKeySpot+=prevK+1;
								sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
								vector<SplineType>::iterator vType;
								vType=sp.vType.begin()+prevK;
								sp.vType.insert(vType,TWOSIDE);
								sp.vType[prevK+1]=TWOSIDE;
								vsp[idx].vType[prevIdx]=TWOSIDE;
								vsp[idx].vType[midIdx]=TWOSIDE;
							}
							if (tmpdist2<2)
							{
								//replace midIdx to nextI
								vector<posi>::iterator	vSpot;
								vSpot=sp.vSpot.begin();			
								vSpot+=prevK+1;
								sp.vSpot.insert(vSpot,vsp[idx].vSpot[nextI]);
								vector<posi>::iterator vTangent;
								vTangent=sp.vTangent.begin();
								vTangent+=prevK*2+1;
								sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[nextI*2].i,-vsp[idx].vTangent[nextI*2].j));
								vTangent=sp.vTangent.begin()+prevK*2+2;
								sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[minIdx*2+3].i,-vsp[idx].vTangent[minIdx*2+3].j));
								sp.vTangent[prevK*2]=posi(-vsp[idx].vTangent[nextI*2+1].i,-vsp[idx].vTangent[nextI*2+1].j);
								sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=posi(-vsp[idx].vTangent[minIdx*2+2].i,-vsp[idx].vTangent[minIdx*2+2].j);
								vector<Spline>::iterator vPara;
								vPara=sp.vPara.begin();
								vPara+=prevK;
								sp.vPara.insert(vPara,Spline(vsp[idx].vPara[nextI].d,vsp[idx].vPara[nextI].c,vsp[idx].vPara[nextI].b,vsp[idx].vPara[nextI].a));
								sp.vPara[prevK+1]=Spline(vsp[idx].vPara[minIdx+1].d,vsp[idx].vPara[minIdx+1].c,vsp[idx].vPara[minIdx+1].b,vsp[idx].vPara[minIdx+1].a);
								vector<bool>::iterator vKeySpot;
								vKeySpot=sp.vKeySpot.begin();
								vKeySpot+=prevK+1;
								sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx+1]);
								vector<SplineType>::iterator vType;
								vType=sp.vType.begin()+prevK;
								sp.vType.insert(vType,TWOSIDE);
								sp.vType[prevK+1]=TWOSIDE;
								vsp[idx].vType[minIdx+1]=TWOSIDE;
								vsp[idx].vType[nextI]=TWOSIDE;
							}
						} 
					}
					prevCombine=true;
					prevIdx=minIdx+1;
					
					//prevCombine=false;
					continue;
				}
				if (dist>dist2) minIdx=nextI;
				if (prevCombine)//use previous parameter
				{
					sp.vSpot[k] = vsp[idx].vSpot[minIdx];
					int prevK=(k-1+sp.vSpot.size())%sp.vSpot.size();
						if ((minIdx+vsp[idx].vSpot.size()-prevIdx)%vsp[idx].vSpot.size()==1)
						{
						   sp.vPara[prevK]=vsp[idx].vPara[prevIdx];
						   sp.vType[prevK]=TWOSIDE;
						   vsp[idx].vType[prevIdx]=TWOSIDE;
						   recompute_spline(sp,k,'R');//R
						}
						else if ((prevIdx+vsp[idx].vSpot.size()-minIdx)%vsp[idx].vSpot.size()==1)
						{
						
	#ifdef _CUBIC
							sp.vPara[prevK]=Spline(vsp[idx].vPara[minIdx].d,vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
	#else
							sp.vPara[prevK]=Spline(vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
	#endif
							recompute_spline(sp,k,'R');//R
							sp.vType[prevK]=TWOSIDE;
							vsp[idx].vType[minIdx]=TWOSIDE;
						}
						else if ((minIdx+vsp[idx].vSpot.size()-prevIdx)%vsp[idx].vSpot.size()==2)
						{
							int midIdx=(prevIdx+1)%vsp[idx].vSpot.size();
							vector<posi>::iterator	vSpot;
							vSpot=sp.vSpot.begin();			
							vSpot+=prevK+1;
							sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
							vector<posi>::iterator vTangent;
							vTangent=sp.vTangent.begin();
							vTangent+=prevK*2+1;
							sp.vTangent.insert(vTangent,vsp[idx].vTangent[prevIdx*2+1]);
							vTangent=sp.vTangent.begin()+prevK*2+2;
							sp.vTangent.insert(vTangent,vsp[idx].vTangent[midIdx*2]);
							vector<Spline>::iterator vPara;
							sp.vTangent[prevK*2]=vsp[idx].vTangent[prevIdx*2];
							sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=vsp[idx].vTangent[midIdx*2+1];
							vPara=sp.vPara.begin();
							vPara+=prevK;
							sp.vPara.insert(vPara,vsp[idx].vPara[prevIdx]);
							sp.vPara[prevK+1]=vsp[idx].vPara[midIdx];
							vector<bool>::iterator vKeySpot;
							vKeySpot=sp.vKeySpot.begin();
							vKeySpot+=prevK+1;
							sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
							vector<SplineType>::iterator vType;
							vType=sp.vType.begin()+prevK;
							sp.vType.insert(vType,TWOSIDE);
							sp.vType[prevK+1]=TWOSIDE;
							vsp[idx].vType[prevIdx]=TWOSIDE;
							vsp[idx].vType[midIdx]=TWOSIDE;
							//recompute_spline(sp,k,'L');
						}
						else if ((prevIdx+vsp[idx].vSpot.size()-minIdx)%vsp[idx].vSpot.size()==2)
						{
							int midIdx=(minIdx+1)%vsp[idx].vSpot.size();
							vector<posi>::iterator	vSpot;
							vSpot=sp.vSpot.begin();			
							vSpot+=prevK+1;
							sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
							vector<posi>::iterator vTangent;
							vTangent=sp.vTangent.begin();
							vTangent+=prevK*2+1;
							sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[midIdx*2].i,-vsp[idx].vTangent[midIdx*2].j));
							vTangent=sp.vTangent.begin()+prevK*2+2;
							sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[minIdx*2+1].i,-vsp[idx].vTangent[minIdx*2+1].j));
							sp.vTangent[prevK*2]=posi(-vsp[idx].vTangent[midIdx*2+1].i,-vsp[idx].vTangent[minIdx*2+1].j);
							sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=posi(-vsp[idx].vTangent[minIdx*2].i,-vsp[idx].vTangent[minIdx*2].j);
							vector<Spline>::iterator vPara;
							vPara=sp.vPara.begin();
							vPara+=prevK;
							sp.vPara.insert(vPara,Spline(vsp[idx].vPara[midIdx].d,vsp[idx].vPara[midIdx].c,vsp[idx].vPara[midIdx].b,vsp[idx].vPara[midIdx].a));
							sp.vPara[prevK+1]=Spline(vsp[idx].vPara[minIdx].d,vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
							vector<bool>::iterator vKeySpot;
							vKeySpot=sp.vKeySpot.begin();
							vKeySpot+=prevK+1;
							sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
							vector<SplineType>::iterator vType;
							vType=sp.vType.begin()+prevK;
							sp.vType.insert(vType,TWOSIDE);
							sp.vType[prevK+1]=TWOSIDE;
							vsp[idx].vType[minIdx]=TWOSIDE;
							vsp[idx].vType[midIdx]=TWOSIDE;
						}
					prevCombine=true;
					prevIdx=minIdx;
				}
				else /*if (minDist<joinSize*joinSize)*/
				{
					sp.vSpot[k] = vsp[idx].vSpot[minIdx];
					/// recompute the parameters
					recompute_spline(sp,k,'L');//L
					prevCombine=true;
					prevIdx=minIdx;
				}/*
				else	// distance check
				{
					cerr << "miniDist " << minDist <<" is not near enough!" << std::endl;
					prevCombine=false;
				}*/
			}
			else {// insert a spot, move the this current spot ��for previous spots only
				prevCombine=false;
			}
		}
		/// direct adding
		vsp.push_back(sp);
	}

	void changeSpline(vector<divideSpot> &vsp, divideSpot &sp, int currIdx, const QImage &img, int joinSize)
	{
		//joinSize=20;
				bool prevCombine=false;//if previous point is already combined to an old point
		int prevIdx;
		for (int k=0; k<sp.vSpot.size(); k++)
		{
			/// check previous points
			int idx2 = img.pixelIndex(sp.vSpot[k].i,sp.vSpot[k].j);
			int idx = (idx2-1)/2;
			if(idx2>vsp.size()*2)
			{
				cerr << "keypoint index " << idx <<" in joinImg is out of range!" << std::endl;
				continue;
				prevCombine=false;
			}
			if(idx2!=0 /*&& idx2%2==0*/)			/// meet a keypoint
			{
				/// move the current spot, recompute the parameters : for 'sp' only
				int minIdx = 0;
				int minDist = 1000000;
				int t;
				for (int s=0; s<vsp[idx].vSpot.size(); s++)
				{
					int nextS=(s+1)%vsp[idx].vSpot.size();
					for (int i=0;i<60;i++)
					{
					    posd samp = samplingSpline(vsp[idx].vPara[s],double(i)/double(60));
						posi sampInt(int(samp.i),int(samp.j));
						double dist=pow(double(sp.vSpot[k].i-sampInt.i),2)+pow(double(sp.vSpot[k].j-sampInt.j),2);
						if (dist<minDist)
						{
							minDist=dist;
							minIdx=s;
							t=i;
						}
					}
				}
				double dist=pow(double(sp.vSpot[k].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[k].j-vsp[idx].vSpot[minIdx].j),2);
				int nextI=(minIdx+1)%vsp[idx].vSpot.size();
				double dist2=pow(double(sp.vSpot[k].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[k].j-vsp[idx].vSpot[nextI].j),2);
				if (sp.vKeySpot[k] && dist>joinSize*joinSize && dist2>joinSize*joinSize) 
				{
					vector<posi>::iterator	vSpot;
					vSpot=vsp[idx].vSpot.begin();			
					vSpot+=minIdx+1;
					vsp[idx].vSpot.insert(vSpot,sp.vSpot[k]);
					vector<posi>::iterator	vTangent;
					vTangent=vsp[idx].vTangent.begin();		
					vTangent+=minIdx*2+1;
					int nextK=(k+1)%sp.vSpot.size();
					nextI=(minIdx+2)%vsp[idx].vSpot.size();
					//double tmpdist1=pow(double(sp.vSpot[nextK].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[nextK].j-vsp[idx].vSpot[minIdx].j),2);
					//double tmpdist2=pow(double(sp.vSpot[nextK].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[nextK].j-vsp[idx].vSpot[nextI].j),2);
					posi tang=compute_tangent(vsp[idx].vPara[minIdx],double(t)/double(60));
     				posd Spot=samplingSpline(vsp[idx].vPara[minIdx],double(t)/double(60));
					posd newSpot=posd((Spot.i+sp.vSpot[k].i)/2,(Spot.j+sp.vSpot[k].j)/2);
					sp.vSpot[k]=posi(int(newSpot.i),int(newSpot.j));
					recomputeSpline(sp,k);
					vsp[idx].vSpot[minIdx+1]=sp.vSpot[k];
					vsp[idx].vTangent.insert(vTangent,2,tang);
					/*vTangent=vsp[idx].vTangent.begin();
					vTangent+=minIdx*2+1;
					vsp[idx].vTangent.insert(vTangent,posi(-tang.i,-tang.j));*/
					vector<Spline>::iterator  vPara;
					vPara=vsp[idx].vPara.begin();		
					vPara+=minIdx;
					Spline v(posd(vsp[idx].vSpot[minIdx].i,vsp[idx].vSpot[minIdx].j),posd(0,0),posd(0,0),posd(sp.vSpot[k].i,sp.vSpot[k].j));
					vsp[idx].vPara[minIdx].a=posd(sp.vSpot[k].i,sp.vSpot[k].j);
					vsp[idx].vPara.insert(vPara,v);
					recomputeSpline(vsp[idx],minIdx+1);
					vector<bool>::iterator	vKeySpot;
					vKeySpot=vsp[idx].vKeySpot.begin();
					vKeySpot+=minIdx+1;
					vsp[idx].vKeySpot.insert(vKeySpot,true);
					/// added by jz, need to be checked by leiqi
					vector<SplineType>::iterator vType;
					vType=vsp[idx].vType.begin();			
					vType+=minIdx+1;
					vsp[idx].vType.insert(vType,INSIDE);
					/// end of adding

					//vsp[idx].vType.insert();
					
					if (prevCombine) 
					{
						int prevK=(k-1+sp.vPara.size())%sp.vPara.size();
						
						double tmpdist1=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[minIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[minIdx].j),2);
					    double tmpdist2=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[nextI].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[nextI].j),2);
						if (tmpdist1<2)
						{
							vsp[idx].vPara[minIdx]=sp.vPara[prevK];
						    vsp[idx].vType[minIdx]=TWOSIDE;
							sp.vType[prevK]=TWOSIDE;
						}else if (tmpdist2<2)
						{
							vsp[idx].vPara[minIdx+1]=Spline(sp.vPara[prevK].d,sp.vPara[prevK].c,sp.vPara[prevK].b,sp.vPara[prevK].a);
							vsp[idx].vType[minIdx+1]=TWOSIDE;
							sp.vType[prevK]=TWOSIDE;
						}else{
							int backwardIdx=(minIdx-1+vsp[idx].vSpot.size())%vsp[idx].vSpot.size();
							tmpdist1=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[backwardIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[backwardIdx].j),2);
							int forwardIdx=(nextI+1)%vsp[idx].vSpot.size();
							tmpdist2=pow(double(sp.vSpot[prevK].i-vsp[idx].vSpot[forwardIdx].i),2)+pow(double(sp.vSpot[prevK].j-vsp[idx].vSpot[forwardIdx].j),2);
							if (tmpdist1<2)
							{
								int midIdx=minIdx+1;
								//replace midIdx to minI+1
								vector<posi>::iterator	vSpot;
								vSpot=sp.vSpot.begin();			
								vSpot+=prevK+1;
								sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
								vector<posi>::iterator vTangent;
								vTangent=sp.vTangent.begin();
								vTangent+=prevK*2+1;
								sp.vTangent.insert(vTangent,vsp[idx].vTangent[prevIdx*2+1]);
								vTangent=sp.vTangent.begin()+prevK*2+2;
								sp.vTangent.insert(vTangent,vsp[idx].vTangent[midIdx*2]);
								vector<Spline>::iterator vPara;
								sp.vTangent[prevK*2]=vsp[idx].vTangent[prevIdx*2];
								sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=vsp[idx].vTangent[midIdx*2+1];
								vPara=sp.vPara.begin();
								vPara+=prevK;
								sp.vPara.insert(vPara,vsp[idx].vPara[prevIdx]);
								sp.vPara[prevK+1]=vsp[idx].vPara[midIdx];
								vector<bool>::iterator vKeySpot;
								vKeySpot=sp.vKeySpot.begin();
								vKeySpot+=prevK+1;
								sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
								vector<SplineType>::iterator vType;
								vType=sp.vType.begin()+prevK;
								sp.vType.insert(vType,TWOSIDE);
								sp.vType[prevK+1]=TWOSIDE;
								vsp[idx].vType[prevIdx]=TWOSIDE;
								vsp[idx].vType[midIdx]=TWOSIDE;
							}
							if (tmpdist2<2)
							{
								//replace midIdx to nextI
								vector<posi>::iterator	vSpot;
								vSpot=sp.vSpot.begin();			
								vSpot+=prevK+1;
								sp.vSpot.insert(vSpot,vsp[idx].vSpot[nextI]);
								vector<posi>::iterator vTangent;
								vTangent=sp.vTangent.begin();
								vTangent+=prevK*2+1;
								sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[nextI*2].i,-vsp[idx].vTangent[nextI*2].j));
								vTangent=sp.vTangent.begin()+prevK*2+2;
								sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[minIdx*2+3].i,-vsp[idx].vTangent[minIdx*2+3].j));
								sp.vTangent[prevK*2]=posi(-vsp[idx].vTangent[nextI*2+1].i,-vsp[idx].vTangent[nextI*2+1].j);
								sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=posi(-vsp[idx].vTangent[minIdx*2+2].i,-vsp[idx].vTangent[minIdx*2+2].j);
								vector<Spline>::iterator vPara;
								vPara=sp.vPara.begin();
								vPara+=prevK;
								sp.vPara.insert(vPara,Spline(vsp[idx].vPara[nextI].d,vsp[idx].vPara[nextI].c,vsp[idx].vPara[nextI].b,vsp[idx].vPara[nextI].a));
								sp.vPara[prevK+1]=Spline(vsp[idx].vPara[minIdx+1].d,vsp[idx].vPara[minIdx+1].c,vsp[idx].vPara[minIdx+1].b,vsp[idx].vPara[minIdx+1].a);
								vector<bool>::iterator vKeySpot;
								vKeySpot=sp.vKeySpot.begin();
								vKeySpot+=prevK+1;
								sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx+1]);
								vector<SplineType>::iterator vType;
								vType=sp.vType.begin()+prevK;
								sp.vType.insert(vType,TWOSIDE);
								sp.vType[prevK+1]=TWOSIDE;
								vsp[idx].vType[minIdx+1]=TWOSIDE;
								vsp[idx].vType[nextI]=TWOSIDE;
							}
						} 
					}
					prevCombine=true;
					prevIdx=minIdx+1;
					
					//prevCombine=false;
					continue;
				}
				if (dist>dist2) minIdx=nextI;
				if (prevCombine)//use previous parameter
				{
					sp.vSpot[k] = vsp[idx].vSpot[minIdx];
					int prevK=(k-1+sp.vSpot.size())%sp.vSpot.size();
						if ((minIdx+vsp[idx].vSpot.size()-prevIdx)%vsp[idx].vSpot.size()==1)
						{
						   sp.vPara[prevK]=vsp[idx].vPara[prevIdx];
						   sp.vType[prevK]=TWOSIDE;
						   vsp[idx].vType[prevIdx]=TWOSIDE;
						   recompute_spline(sp,k,'R');//R
						}
						else if ((prevIdx+vsp[idx].vSpot.size()-minIdx)%vsp[idx].vSpot.size()==1)
						{
						
	#ifdef _CUBIC
							sp.vPara[prevK]=Spline(vsp[idx].vPara[minIdx].d,vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
	#else
							sp.vPara[prevK]=Spline(vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
	#endif
							recompute_spline(sp,k,'R');//R
							sp.vType[prevK]=TWOSIDE;
							vsp[idx].vType[minIdx]=TWOSIDE;
						}
						else if ((minIdx+vsp[idx].vSpot.size()-prevIdx)%vsp[idx].vSpot.size()==2)
						{
							int midIdx=(prevIdx+1)%vsp[idx].vSpot.size();
							vector<posi>::iterator	vSpot;
							vSpot=sp.vSpot.begin();			
							vSpot+=prevK+1;
							sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
							vector<posi>::iterator vTangent;
							vTangent=sp.vTangent.begin();
							vTangent+=prevK*2+1;
							sp.vTangent.insert(vTangent,vsp[idx].vTangent[prevIdx*2+1]);
							vTangent=sp.vTangent.begin()+prevK*2+2;
							sp.vTangent.insert(vTangent,vsp[idx].vTangent[midIdx*2]);
							vector<Spline>::iterator vPara;
							sp.vTangent[prevK*2]=vsp[idx].vTangent[prevIdx*2];
							sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=vsp[idx].vTangent[midIdx*2+1];
							vPara=sp.vPara.begin();
							vPara+=prevK;
							sp.vPara.insert(vPara,vsp[idx].vPara[prevIdx]);
							sp.vPara[prevK+1]=vsp[idx].vPara[midIdx];
							vector<bool>::iterator vKeySpot;
							vKeySpot=sp.vKeySpot.begin();
							vKeySpot+=prevK+1;
							sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
							vector<SplineType>::iterator vType;
							vType=sp.vType.begin()+prevK;
							sp.vType.insert(vType,TWOSIDE);
							sp.vType[prevK+1]=TWOSIDE;
							vsp[idx].vType[prevIdx]=TWOSIDE;
							vsp[idx].vType[midIdx]=TWOSIDE;
							//recompute_spline(sp,k,'L');
						}
						else if ((prevIdx+vsp[idx].vSpot.size()-minIdx)%vsp[idx].vSpot.size()==2)
						{
							int midIdx=(minIdx+1)%vsp[idx].vSpot.size();
							vector<posi>::iterator	vSpot;
							vSpot=sp.vSpot.begin();			
							vSpot+=prevK+1;
							sp.vSpot.insert(vSpot,vsp[idx].vSpot[midIdx]);
							vector<posi>::iterator vTangent;
							vTangent=sp.vTangent.begin();
							vTangent+=prevK*2+1;
							sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[midIdx*2].i,-vsp[idx].vTangent[midIdx*2].j));
							vTangent=sp.vTangent.begin()+prevK*2+2;
							sp.vTangent.insert(vTangent,posi(-vsp[idx].vTangent[minIdx*2+1].i,-vsp[idx].vTangent[minIdx*2+1].j));
							sp.vTangent[prevK*2]=posi(-vsp[idx].vTangent[midIdx*2+1].i,-vsp[idx].vTangent[minIdx*2+1].j);
							sp.vTangent[(prevK*2+3)%sp.vTangent.size()]=posi(-vsp[idx].vTangent[minIdx*2].i,-vsp[idx].vTangent[minIdx*2].j);
							vector<Spline>::iterator vPara;
							vPara=sp.vPara.begin();
							vPara+=prevK;
							sp.vPara.insert(vPara,Spline(vsp[idx].vPara[midIdx].d,vsp[idx].vPara[midIdx].c,vsp[idx].vPara[midIdx].b,vsp[idx].vPara[midIdx].a));
							sp.vPara[prevK+1]=Spline(vsp[idx].vPara[minIdx].d,vsp[idx].vPara[minIdx].c,vsp[idx].vPara[minIdx].b,vsp[idx].vPara[minIdx].a);
							vector<bool>::iterator vKeySpot;
							vKeySpot=sp.vKeySpot.begin();
							vKeySpot+=prevK+1;
							sp.vKeySpot.insert(vKeySpot,vsp[idx].vKeySpot[minIdx]);
							vector<SplineType>::iterator vType;
							vType=sp.vType.begin()+prevK;
							sp.vType.insert(vType,TWOSIDE);
							sp.vType[prevK+1]=TWOSIDE;
							vsp[idx].vType[minIdx]=TWOSIDE;
							vsp[idx].vType[midIdx]=TWOSIDE;
						}
					prevCombine=true;
					prevIdx=minIdx;
				}
				else /*if (minDist<joinSize*joinSize)*/
				{
					sp.vSpot[k] = vsp[idx].vSpot[minIdx];
					/// recompute the parameters
					recompute_spline(sp,k,'L');//L
					prevCombine=true;
					prevIdx=minIdx;
				}/*
				else	// distance check
				{
					cerr << "miniDist " << minDist <<" is not near enough!" << std::endl;
					prevCombine=false;
				}*/
			}
			else {// insert a spot, move the this current spot ��for previous spots only
				prevCombine=false;
			}
		}
		vsp[currIdx-1] = sp;
	}

	posd samplingSpline(const Spline &sp, double t)
	{
		double t1 = 1.0-t;
#ifdef _CUBIC
		double xx = sp.a.i*t1*t1*t1 + sp.b.i*t1*t1*t + sp.c.i*t*t*t1+sp.d.i*t*t*t;
		double yy = sp.a.j*t1*t1*t1 + sp.b.j*t1*t1*t + sp.c.j*t*t*t1+sp.d.j*t*t*t;
#else
		double xx = sp.a.i*t1*t1 + sp.b.i*t1*t + sp.c.i*t*t;
		double yy = sp.a.j*t1*t1 + sp.b.j*t1*t + sp.c.j*t*t;
#endif
		return spline::posd(xx,yy);
	}
} // namespace