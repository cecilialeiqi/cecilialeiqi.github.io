#ifndef VECTORIZATION_H
#define VECTORIZATION_H

#include <QImage>

using namespace std;

namespace vectorization
{
	// ʸ��ͼ�����ʽ���Բο�SVG��ʽ�������Լ�����
	class VectorGraph
	{
		vector<QPoint> vpn;
	};

	void ExtractSkeleton(const QImage &src, vector<QPoint> &skeleton);

	void ExtractSkeleton(const QImage &src, QImage &skeletonImage);

	void Vectorization(const QImage &src, VectorGraph &vg);

	void DrawVectorGraph(const VectorGraph &vg, QImage &dest);
}



#endif // VECTORIZATION_H