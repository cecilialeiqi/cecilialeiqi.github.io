/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDockWidget>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "vectorizationPaint.h"
#include "videocontrols.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *actionSavePNG;
    QAction *actionZoomIn;
    QAction *actionZoomOut;
    QAction *actionReset;
    QAction *actionAbout;
    QAction *actionQuit;
    QAction *actionToggle;
    QAction *actionHold;
    QAction *actionCopy;
    QAction *actionSelectDevice;
    QAction *actionRecord;
    QAction *actionToolBox;
    QAction *actionFullScreen;
    QAction *actionMenuBar;
    QAction *actionReloadShader;
    QWidget *m_centralWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *m_vbox2;
    ImagePaint *m_imagePaint;
    VideoControls *m_videoControls;
    QDockWidget *m_dockWidget;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *m_vboxTool;
    QComboBox *m_selectitem;
    QMenuBar *m_menuBar;
    QMenu *m_menuFile;
    QMenu *m_menuView;
    QMenu *m_menuHelp;
    QMenu *menu_Windows;
    QMenu *menuTool;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(875, 557);
        MainWindow->setAnimated(false);
        MainWindow->setDockNestingEnabled(false);
        MainWindow->setProperty("documentMode", QVariant(false));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        actionOpen->setShortcutContext(Qt::ApplicationShortcut);
        actionSavePNG = new QAction(MainWindow);
        actionSavePNG->setObjectName(QString::fromUtf8("actionSavePNG"));
        actionSavePNG->setShortcutContext(Qt::ApplicationShortcut);
        actionZoomIn = new QAction(MainWindow);
        actionZoomIn->setObjectName(QString::fromUtf8("actionZoomIn"));
        actionZoomIn->setShortcutContext(Qt::ApplicationShortcut);
        actionZoomOut = new QAction(MainWindow);
        actionZoomOut->setObjectName(QString::fromUtf8("actionZoomOut"));
        actionZoomOut->setShortcutContext(Qt::ApplicationShortcut);
        actionReset = new QAction(MainWindow);
        actionReset->setObjectName(QString::fromUtf8("actionReset"));
        actionReset->setShortcutContext(Qt::ApplicationShortcut);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionQuit = new QAction(MainWindow);
        actionQuit->setObjectName(QString::fromUtf8("actionQuit"));
        actionQuit->setShortcutContext(Qt::ApplicationShortcut);
        actionToggle = new QAction(MainWindow);
        actionToggle->setObjectName(QString::fromUtf8("actionToggle"));
        actionToggle->setShortcutContext(Qt::ApplicationShortcut);
        actionHold = new QAction(MainWindow);
        actionHold->setObjectName(QString::fromUtf8("actionHold"));
        actionCopy = new QAction(MainWindow);
        actionCopy->setObjectName(QString::fromUtf8("actionCopy"));
        actionSelectDevice = new QAction(MainWindow);
        actionSelectDevice->setObjectName(QString::fromUtf8("actionSelectDevice"));
        actionRecord = new QAction(MainWindow);
        actionRecord->setObjectName(QString::fromUtf8("actionRecord"));
        actionRecord->setEnabled(false);
        actionToolBox = new QAction(MainWindow);
        actionToolBox->setObjectName(QString::fromUtf8("actionToolBox"));
        actionToolBox->setCheckable(true);
        actionToolBox->setChecked(true);
        actionFullScreen = new QAction(MainWindow);
        actionFullScreen->setObjectName(QString::fromUtf8("actionFullScreen"));
        actionMenuBar = new QAction(MainWindow);
        actionMenuBar->setObjectName(QString::fromUtf8("actionMenuBar"));
        actionMenuBar->setCheckable(true);
        actionMenuBar->setChecked(true);
        actionReloadShader = new QAction(MainWindow);
        actionReloadShader->setObjectName(QString::fromUtf8("actionReloadShader"));
        m_centralWidget = new QWidget(MainWindow);
        m_centralWidget->setObjectName(QString::fromUtf8("m_centralWidget"));
        horizontalLayout = new QHBoxLayout(m_centralWidget);
        horizontalLayout->setSpacing(4);
        horizontalLayout->setContentsMargins(4, 4, 4, 4);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        m_vbox2 = new QVBoxLayout();
        m_vbox2->setSpacing(4);
        m_vbox2->setObjectName(QString::fromUtf8("m_vbox2"));
        m_imagePaint = new ImagePaint(m_centralWidget);
        m_imagePaint->setObjectName(QString::fromUtf8("m_imagePaint"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(m_imagePaint->sizePolicy().hasHeightForWidth());
        m_imagePaint->setSizePolicy(sizePolicy);
        m_imagePaint->setMinimumSize(QSize(512, 512));
        m_imagePaint->setFocusPolicy(Qt::ClickFocus);

        m_vbox2->addWidget(m_imagePaint);

        m_videoControls = new VideoControls(m_centralWidget);
        m_videoControls->setObjectName(QString::fromUtf8("m_videoControls"));
        m_videoControls->setFrameShape(QFrame::StyledPanel);
        m_videoControls->setFrameShadow(QFrame::Raised);

        m_vbox2->addWidget(m_videoControls);


        horizontalLayout->addLayout(m_vbox2);

        m_dockWidget = new QDockWidget(m_centralWidget);
        m_dockWidget->setObjectName(QString::fromUtf8("m_dockWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_dockWidget->sizePolicy().hasHeightForWidth());
        m_dockWidget->setSizePolicy(sizePolicy1);
        m_dockWidget->setMinimumSize(QSize(220, 512));
        m_dockWidget->setMaximumSize(QSize(220, 524287));
        m_dockWidget->setFloating(false);
        m_dockWidget->setFeatures(QDockWidget::NoDockWidgetFeatures);
        m_dockWidget->setAllowedAreas(Qt::NoDockWidgetArea);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout_2 = new QVBoxLayout(dockWidgetContents);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        m_vboxTool = new QVBoxLayout();
        m_vboxTool->setObjectName(QString::fromUtf8("m_vboxTool"));
        m_vboxTool->setSizeConstraint(QLayout::SetMinimumSize);
        m_vboxTool->setContentsMargins(-1, 0, -1, -1);
        m_selectitem = new QComboBox(dockWidgetContents);
        m_selectitem->setObjectName(QString::fromUtf8("m_selectitem"));
        m_selectitem->setFrame(true);

        m_vboxTool->addWidget(m_selectitem);


        verticalLayout_2->addLayout(m_vboxTool);

        m_dockWidget->setWidget(dockWidgetContents);

        horizontalLayout->addWidget(m_dockWidget);

        MainWindow->setCentralWidget(m_centralWidget);
        m_menuBar = new QMenuBar(MainWindow);
        m_menuBar->setObjectName(QString::fromUtf8("m_menuBar"));
        m_menuBar->setGeometry(QRect(0, 0, 875, 19));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(247, 247, 247, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(251, 251, 251, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(123, 123, 123, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(165, 165, 165, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush2);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush3);
        QBrush brush6(QColor(255, 255, 220, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        m_menuBar->setPalette(palette);
        m_menuFile = new QMenu(m_menuBar);
        m_menuFile->setObjectName(QString::fromUtf8("m_menuFile"));
        m_menuView = new QMenu(m_menuBar);
        m_menuView->setObjectName(QString::fromUtf8("m_menuView"));
        m_menuHelp = new QMenu(m_menuBar);
        m_menuHelp->setObjectName(QString::fromUtf8("m_menuHelp"));
        menu_Windows = new QMenu(m_menuBar);
        menu_Windows->setObjectName(QString::fromUtf8("menu_Windows"));
        menuTool = new QMenu(m_menuBar);
        menuTool->setObjectName(QString::fromUtf8("menuTool"));
        MainWindow->setMenuBar(m_menuBar);

        m_menuBar->addAction(m_menuFile->menuAction());
        m_menuBar->addAction(m_menuView->menuAction());
        m_menuBar->addAction(menuTool->menuAction());
        m_menuBar->addAction(menu_Windows->menuAction());
        m_menuBar->addAction(m_menuHelp->menuAction());
        m_menuFile->addAction(actionOpen);
        m_menuFile->addAction(actionSavePNG);
        m_menuFile->addAction(actionRecord);
        m_menuFile->addSeparator();
        m_menuFile->addAction(actionQuit);
        m_menuView->addAction(actionCopy);
        m_menuView->addSeparator();
        m_menuView->addAction(actionZoomIn);
        m_menuView->addAction(actionZoomOut);
        m_menuView->addAction(actionReset);
        m_menuView->addSeparator();
        m_menuView->addAction(actionHold);
        m_menuView->addAction(actionToggle);
        m_menuView->addSeparator();
        m_menuView->addAction(actionReloadShader);
        m_menuHelp->addAction(actionAbout);
        menu_Windows->addAction(actionToolBox);
        menu_Windows->addAction(actionFullScreen);

        retranslateUi(MainWindow);
        QObject::connect(actionQuit, SIGNAL(triggered()), MainWindow, SLOT(close()));
        QObject::connect(actionReset, SIGNAL(triggered()), m_imagePaint, SLOT(reset()));
        QObject::connect(actionZoomIn, SIGNAL(triggered()), m_imagePaint, SLOT(zoomIn()));
        QObject::connect(actionZoomOut, SIGNAL(triggered()), m_imagePaint, SLOT(zoomOut()));
        QObject::connect(actionToggle, SIGNAL(triggered()), m_imagePaint, SLOT(toggle()));
        QObject::connect(actionHold, SIGNAL(triggered()), m_imagePaint, SLOT(hold()));
        QObject::connect(actionCopy, SIGNAL(triggered()), m_imagePaint, SLOT(copy()));
        QObject::connect(actionSavePNG, SIGNAL(triggered()), m_imagePaint, SLOT(savePNG()));
        QObject::connect(actionToolBox, SIGNAL(triggered(bool)), m_dockWidget, SLOT(setVisible(bool)));
        QObject::connect(actionFullScreen, SIGNAL(triggered()), MainWindow, SLOT(setFullScreen()));
        QObject::connect(actionReloadShader, SIGNAL(triggered()), m_imagePaint, SLOT(reloadShaders()));

        m_selectitem->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Vectorization of Line Drawings", 0, QApplication::UnicodeUTF8));
        actionOpen->setText(QApplication::translate("MainWindow", "&Open...", 0, QApplication::UnicodeUTF8));
        actionOpen->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        actionSavePNG->setText(QApplication::translate("MainWindow", "Save...", 0, QApplication::UnicodeUTF8));
        actionSavePNG->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        actionZoomIn->setText(QApplication::translate("MainWindow", "Zoom In", 0, QApplication::UnicodeUTF8));
        actionZoomIn->setShortcut(QApplication::translate("MainWindow", "Ctrl+=", 0, QApplication::UnicodeUTF8));
        actionZoomOut->setText(QApplication::translate("MainWindow", "Zoom Out", 0, QApplication::UnicodeUTF8));
        actionZoomOut->setShortcut(QApplication::translate("MainWindow", "Ctrl+-", 0, QApplication::UnicodeUTF8));
        actionReset->setText(QApplication::translate("MainWindow", "Reset", 0, QApplication::UnicodeUTF8));
        actionReset->setShortcut(QApplication::translate("MainWindow", "Ctrl+1", 0, QApplication::UnicodeUTF8));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
        actionAbout->setShortcut(QApplication::translate("MainWindow", "F1", 0, QApplication::UnicodeUTF8));
        actionQuit->setText(QApplication::translate("MainWindow", "Quit", 0, QApplication::UnicodeUTF8));
        actionQuit->setShortcut(QApplication::translate("MainWindow", "Esc", 0, QApplication::UnicodeUTF8));
        actionToggle->setText(QApplication::translate("MainWindow", "Toggle", 0, QApplication::UnicodeUTF8));
        actionToggle->setShortcut(QApplication::translate("MainWindow", "\\", 0, QApplication::UnicodeUTF8));
        actionHold->setText(QApplication::translate("MainWindow", "Hold", 0, QApplication::UnicodeUTF8));
        actionHold->setShortcut(QApplication::translate("MainWindow", "Ctrl+H", 0, QApplication::UnicodeUTF8));
        actionCopy->setText(QApplication::translate("MainWindow", "Copy", 0, QApplication::UnicodeUTF8));
        actionCopy->setShortcut(QApplication::translate("MainWindow", "Ctrl+C", 0, QApplication::UnicodeUTF8));
        actionSelectDevice->setText(QApplication::translate("MainWindow", "Select CUDA Device...", 0, QApplication::UnicodeUTF8));
        actionRecord->setText(QApplication::translate("MainWindow", "Record...", 0, QApplication::UnicodeUTF8));
        actionToolBox->setText(QApplication::translate("MainWindow", "ToolBox", 0, QApplication::UnicodeUTF8));
        actionToolBox->setShortcut(QApplication::translate("MainWindow", "F10", 0, QApplication::UnicodeUTF8));
        actionFullScreen->setText(QApplication::translate("MainWindow", "FullScreen", 0, QApplication::UnicodeUTF8));
        actionFullScreen->setShortcut(QApplication::translate("MainWindow", "F11", 0, QApplication::UnicodeUTF8));
        actionMenuBar->setText(QApplication::translate("MainWindow", "MenuBar", 0, QApplication::UnicodeUTF8));
        actionReloadShader->setText(QApplication::translate("MainWindow", "Reload Shaders", 0, QApplication::UnicodeUTF8));
        actionReloadShader->setShortcut(QApplication::translate("MainWindow", "F5", 0, QApplication::UnicodeUTF8));
        m_dockWidget->setWindowTitle(QApplication::translate("MainWindow", "Toolbox", 0, QApplication::UnicodeUTF8));
        m_menuFile->setTitle(QApplication::translate("MainWindow", "&File", 0, QApplication::UnicodeUTF8));
        m_menuView->setTitle(QApplication::translate("MainWindow", "&View", 0, QApplication::UnicodeUTF8));
        m_menuHelp->setTitle(QApplication::translate("MainWindow", "Help", 0, QApplication::UnicodeUTF8));
        menu_Windows->setTitle(QApplication::translate("MainWindow", "&Windows", 0, QApplication::UnicodeUTF8));
        menuTool->setTitle(QApplication::translate("MainWindow", "Tool", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
