#ifndef MODULE_MATH_HPP
#define MODULE_MATH_HPP

//STL
#include <climits>
#include <cfloat>
#include <cmath>
#include <limits>

//math
#include <vec2.h>
#include <vec3.h>
#include <vec4.h>
#include <mat2.h>
#include <mat3.h>
#include <mat4.h>

#ifdef _WIN32
#undef min  
#undef max
#define NOMINMAX
#endif

   namespace math
   {

      //Some constants
      #ifndef INFINITY
      #define INFINITY (std::numeric_limits<float>::max())
      #endif

      #ifndef EPSILON
      #define EPSILON (100*std::numeric_limits<float>::epsilon())
      #endif

      #ifndef DBL_EPSILON
      #define DBL_EPSILON (10*std::numeric_limits<double>::epsilon())
      #endif

      template<typename T>
      class _Math
      {
         public:

         static float const PI;
         static float const TWO_PI;
         static float const FOUR_PI;
         static float const INV_PI;
         static float const INV_2PI;

         inline static T max( T v1, T v2);
         inline static T max( T v1, T v2, T v3);

         /**
          * Set  the max
          * Returns which of the three numbers is the max
          **/
         inline static unsigned int max( T v1, T v2, T v3, T & max);
         
         inline static T min( T v1, T v2);
         inline static T min( T v1, T v2, T v3);

         inline static float mean( float v1, float v2 );
         inline static float mean( float v1, float v2, float v3);

         inline static double mean( double v1, double v2 );
         inline static double mean( double v1, double v2, double v3);

	 inline static float round( float v1);
	 inline static double round( double v1 );

         static inline T sign( T a );
          
         inline static T toDegree( T a_radian_angle );
         inline static T toRadian( T a_degree_angle );


         inline static void sphericalCoord( T x, T y, T z, T & phi, T & theta, T & r);

         inline static void cartesianCoord(  T phi,
                                             T theta,
                                             T r, T & x, T & y , T & z);

         inline static int clamp( int val, int min , int max );
         inline static float clamp( float val, float min, float max);


         //This is the greatest integer < value
         inline static int intPart( float value );
         inline static int intPart( double value );

         //The fractional part of value
         inline static float fracPart( float  value );
         inline static double fracPart( double value );


         static bool intervalOverlap( T a, T b,   // First interval [a,b]
                                      T c, T d ); // Second interval [c,d]

         static bool intervalOverlap( T a,  T b,    // First interval [a,b]
                                      T c,  T d,    // Second interval [c,d]
                                      T & t1, T & t2 ); // Intersection interval
                                                        // [t1,t2]

          
          
         static inline void swap( T & a, T & b );
         static inline T absVal( T a );
      }; //end of Math Class


      typedef _Math<float>        Math;
      typedef _Math<double>       MathD;
      typedef _Math<int>          MathI;
      typedef _Math<unsigned int> MathUI;

      template<typename T>
      float const _Math<T>::PI      = 3.14159265358979323846f;

      template<typename T>
      float const _Math<T>::TWO_PI  = 6.2831853071795862f;

      template<typename T>
      float const _Math<T>::FOUR_PI = 12.566370614359172f;

      
      template<typename T>
      float const _Math<T>::INV_PI = 0.31830988618379067154f;

      template<typename T>
      float const _Math<T>::INV_2PI = 0.15915494309189533577f;

      //Methods of Math Class
	  template<typename T>
      inline T
      _Math<T>::max(T v1, T v2)
      {
         return ( (v1 > v2) ? (v1) : (v2) );
      }

      template<typename T>
      inline T
      _Math<T>::max(T v1, T v2, T v3)
      {
		  return  _Math<T>::max( _Math<T>::max( v1, v2), v3);
      }

      template<typename T>
      inline unsigned int
      _Math<T>::max( T v1, T v2, T v3, T & max)
      {
         if ( v1  > v2 )
         {
            if ( v1 > v3 )
            {
               max = v1;
               return 0;
            }
            else
            {
               max = v3;
               return 2;
            }
         }
         else
         {
            if( v2 > v3 )
            {
               max = v2;
               return 1;
            }
            else
            {
               max = v3;
               return 2;
            }
         }
         
      }
      
      template<typename T>
      inline T
      _Math<T>::min( T v1, T v2)
      {
         return ( (v1 < v2) ? (v1) : (v2) );
      }

      template<typename T>
      inline T
      _Math<T>::min( T v1, T v2, T v3)
      {
         return min( v1, min( v2, v3) );
      }


      template<typename T>
      inline float
      _Math<T>::mean( float v1, float v2 )
      {
         return  (v1 + v2) / 2.0f ;
      }

      template<typename T>
      inline float
      _Math<T>::mean( float v1, float v2, float v3 )
      {
         return (v1 + v2 + v3) / 3.0f ;
      }

      template<typename T>
      inline double
      _Math<T>::mean( double v1, double v2 )
      {
         return  (v1 + v2) / 2.0 ;
      }

      template<typename T>
      inline double
      _Math<T>::mean( double v1, double v2, double v3 )
      {
         return (v1 + v2 + v3) / 3.0 ;
      }

	  template<typename T>
      inline float
      _Math<T>::round( float v1)
      {
         return  floor( float(v1 + 0.5));
      }

	  template<typename T>
      inline double
      _Math<T>::round( double v1)
      {
         return floor( double(v1 + 0.5));
      }

       template<typename T>
       inline T
       _Math<T>::sign( T a )
       {
           if ( a < T(0) )
           {
               return T(-1);
           }
           else
           {
               return T(1);
           }
       }
       
       
      template<typename T>
      inline T
      _Math<T>::toDegree( T a_radian_angle )
      {
         return a_radian_angle * 180 / M_PI;
      }

      template<typename T>
      inline T
      _Math<T>::toRadian( T a_degree_angle )
      {
         return a_degree_angle * M_PI / 180.0f;
      }


      template<typename T>
      inline void
      _Math<T>::sphericalCoord( T x, T y, T z,
                                T & phi, T & theta, T & r)
      {
         r = static_cast<T>(sqrtf( x*x+y*y+z*z ));

         T denom = x*x+z*z;

         if ( denom != 0 )
         {
            phi = toDegree( acosf( z / sqrtf(denom) ) );
            if ( x < 0 )
            {
               phi = 360 - phi ;
            }
         }
         else
         {
            phi = 0;
         }

         theta = toDegree( acosf( y / r) );
      }

      template< typename T>
      inline void
      _Math<T>::cartesianCoord(  T phi, T theta, T r, T & x, T & y , T & z)
      {
         x = r* cos(phi) * sin(theta);
         y = r* sin(phi) * sin(theta);
         z = r*cos(theta);
      }

      template<typename T>
      inline int
      _Math<T>::clamp( int val, int min , int max )
      {
         if (val < min)
         {
            return min;
         }
         else if ( val > max )
         {
            return max;
         }
         else
         {
            return val;
         }
      }

      template<typename T>
      inline float
      _Math<T>::clamp( float val, float min, float max)
      {
         if (val < min)
         {
            return min;
         }
         else if ( val > max )
         {
            return max;
         }
         else
         {
            return val;
         }
      }

      //This is the greatest integer < value
      template<typename T>
      inline int
      _Math<T>::intPart( float value )
      {
         return static_cast<int>( floorf(value) );
      }

      template<typename T>
      inline int
      _Math<T>::intPart( double value )
      {
         return static_cast<int>( floor(value) );
      }

      //The fractional part of value
      template<typename T>
      inline float
      _Math<T>::fracPart( float  value )
      {
         return value - intPart(value);
      }

      template<typename T>
      inline double
      _Math<T>::fracPart( double value )
      {
         return value - intPart(value);
      }

      template<typename T>
      bool
      _Math<T>::intervalOverlap( T a, T b,   // First interval [a,b]
                                 T c, T d ) // Second interval [c,d]
      {
         //TODO  : TEST THIS
//          if ( ( a > d) || ( c > b ) )
//          {
//             return false
//          }
//          else
//          {
//             return true;
//          }
         return ( (a>d) || (c>b) ) ? (false) : (true);
      }

      template<typename T>
      bool
      _Math<T>::intervalOverlap( T a,  T b,
                                 T c,  T d,
                                 T & t1, T & t2 )
      {
         if ( (a>d) || (c>b) )
         {
            return false;
         }
         else // (a < d) && (c < b)
         {

            if ( c > a )
            {
               if ( d < b )
               {
                  t1 = c;
                  t2 = d;
               }
               else
               {
                  t1 = c;
                  t2 = b;
               }
            }
            else
            {
               if ( d < b )
               {
                  t1 = a;
                  t2 = d;
               }
               else
               {
                  t1 = a;
                  t2 = b;
               }
            }

            return true;
         }
      }//end of interalOverlap


      template<typename T>
      inline void
      _Math<T>::swap( T & a, T & b )
      {
         T tmp = b;
         b = a;
         a = tmp;
      }

      template<typename T>
      inline T _Math<T>::absVal( T a ){return ( a < 0 ) ? (-a) : (a);}

      //
      //
      //These are utility methods to convert Vector from LAIR to MRF format
      template< class T >
      inline Vec3<T>
      Vec4ToVec3( const Vec4<T>& _v )
      {
         return Vec3<T>( _v[0], _v[1], _v[2] );
      }

      template< class T >
      inline Vec4<T>
      Vec3ToVec4( const Vec3<T>& _v, const T& _w )
      {
         return Vec4<T>( _v[0], _v[1], _v[2], _w );
      }


   }//end of math namespace


#endif
