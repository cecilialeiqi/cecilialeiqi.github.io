#ifndef SPLINE_H
#define SPLINE_H

#include <vector>
#include <QImage>

using namespace std;

#define _CUBIC

namespace spline
{
	template <class T>
	class position
	{
	public:
		T i;
		T j;
	public:
		position(T x=0, T y=0):i(x),j(y){}
	};

	typedef position<int>		posi;
	typedef position<float>		posf;
	typedef position<double>	posd;

	class closeEdge
	{
	public: 
		vector<posi>		vPoint;		// �߽�һȦ�����λ��
		vector<double>		vAngle;		// -1 not vertex, -0.866~1 vertex in the first place, 2 ultimate vertex
		vector<int>			vKeyPoint;	// �Ƿ�Ϊ�ؼ���, 0 �ǹؼ���, 1 �ιؼ���, 2 �����ؼ��� ,3���ؼ���
		bool				closeness;	// �߽�ıպ���
		int                 cnt;
		double				angleThres1;
		double				angleThres2;

	public:
		closeEdge()  {closeness=false;
		angleThres1 = -0.866;}
		void clear()		 {vPoint.clear(); vAngle.clear(); vKeyPoint.clear(); closeness=false;}
	};

	class Spline
	{
	public:
		posd a;
		posd b;
		posd c;
	
#ifdef _CUBIC
		posd d;
		Spline(posd a0=posd(),posd b0=posd(),posd c0=posd(),posd d0=posd()):a(a0),b(b0),c(c0),d(d0){}
#else
		Spline(posd a0=posd(), posd b0=posd(), posd c0=posd()):a(a0),b(b0),c(c0){}
#endif

		friend std::ostream &operator<<(std::ostream &stream,const Spline &s);
		friend std::istream &operator>>(std::istream &stream, Spline &s);
	};

	enum SplineType {INSIDE=0x01, OUTSIDE=0x02, TWOSIDE=0x03};
	class divideSpot
	{
	public:
		vector<posi>		vSpot;			// location of spot
		vector<posi>		vTangent;		// tangential direction, double size of vSpot
		vector<Spline>		vPara;			// ����(a0,b0) (a1,b1) (a2,b2)
		vector<bool>		vKeySpot;		// true�������м�ǣ��Ĵ����ߣ�false�������Ӵ�һ����������������
		vector<SplineType>	vType;

		int				index;

	public:
		divideSpot(int i=0):index(i) {}
		void clear()
		{
			vSpot.clear();
			vTangent.clear();
			vPara.clear();
			vKeySpot.clear();
			vType.clear();
		}
		
		friend std::ostream &operator<<(std::ostream &stream,const divideSpot &s);
		friend std::istream &operator>>(std::istream &stream,divideSpot &s);
	};

	/// ˳ʱ��������е㣬���vPoint
	/// ����ÿ����ļнǣ����vAngle��ͬʱ�ж��Ƿ�Ϊ�ؼ��㣬���vKeyPoint
	void findEdge(const QImage &edgeImg, closeEdge &edge);

	/// ����closeEdge�����ؼ���
	void splineFitting(const closeEdge &edge, divideSpot &spline);

	void addSpline(vector<divideSpot> &vsp, divideSpot &sp, const QImage &img, int joinSize);

	void changeSpline(vector<divideSpot> &vsp, divideSpot &sp, int currIdx, const QImage &img, int joinSize);

	void recomputeSpline(divideSpot &sp, int idx);

	posd samplingSpline(const Spline &sp, double t);
}; 



#endif // SPLINE_H