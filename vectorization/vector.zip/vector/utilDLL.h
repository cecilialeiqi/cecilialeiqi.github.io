#ifndef UTILDLL_H
#define UTILDLL_H

#if defined _WIN32
	//#ifdef UTIL_EXPORTS
	//	#define UTIL_API __declspec(dllexport)
	//#else
	//	#define UTIL_API __declspec(dllimport)
	//#endif
	#define UTIL_API
#else
	// for all other platforms UTIL_API is defined to be "nothing"
	#define UTIL_API
#endif

#endif // UTILDLL_H