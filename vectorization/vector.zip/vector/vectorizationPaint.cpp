#include "vectorizationPaint.h"
#include <vectorizationWindow.h>
#include <fstream>


ImagePaint::ImagePaint(QWidget *parent) : QGLWidget(parent) {
	m_spacePressed = false;
	m_mode = MODE_MOVE;
//	m_toolMode = E_MOVE;
	m_index = 0;
//	m_toolMode = 0;
	m_numSpot = 0;
	m_overlay = 0;
	m_zoom = m_resolution = 1;
	m_wndSize = QSize(0,0);
	m_imgLoaded = false;
	m_moveOriginKeep = QPointF(0.0,0.0);
	m_zoomOriginKeep = QPointF(0.0,0.0);

	m_keyCtrl = false;
	_millisec = 50;
	m_frameCurr = 0;
	m_frameCount = 20;
	m_bZoomInOut = true;

	m_streamlineDrawing = false;
	m_bSkeletonDisplay = false;

	setAutoFillBackground(true);
	QPalette p = palette();
	p.setBrush(QPalette::Base, p.mid());
	setPalette(p);
	setCursor(Qt::OpenHandCursor);

	qApp->installEventFilter(this);

	_timer = new QTimer(this);
	connect(_timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
	_timer->stop();
}


ImagePaint::~ImagePaint() {
}


void ImagePaint::restoreSettings(QSettings& settings) {
	setZoom(settings.value("zoom", 1.0).toDouble());
	setResolution(settings.value("resolution", 1.0).toDouble());
	setOriginX(settings.value("originX", 0).toDouble());
	setOriginY(settings.value("originY", 0).toDouble());
}


void ImagePaint::saveSettings(QSettings& settings) {
	settings.setValue("zoom", m_zoom);
	settings.setValue("resolution", m_resolution);
	settings.setValue("originX", m_moveOrigin.x());
	settings.setValue("originY", m_moveOrigin.y());
}


QPointF ImagePaint::view2image(const QPointF& p) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	QPointF res = QPointF(
		(p.x() - m_moveOrigin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
		(p.y() - m_moveOrigin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	return res;
}

QPointF ImagePaint::image2zoom(const QPointF& p) const {
	return p;
	//QSize sz = size();
	//float z = m_zoom /** m_resolution*/;
	//QPointF res = QPointF(
	//	(p.x() - m_origin.x() * z - sz.width() / 2) / z + m_imgSize.width() / 2,
	//	(p.y() - m_origin.y() * z - sz.height() / 2) / z + m_imgSize.height() / 2	);
	//return res;
}

QPointF ImagePaint::image2view(const QPointF& q) const {
	QSize sz = size();
	float z = m_zoom /** m_resolution*/;
	return QPointF(
		(q.x() - m_imgSize.width() / 2) * z + m_moveOrigin.x() * z + sz.width() / 2,
		(q.y() - m_imgSize.height() / 2) * z + m_moveOrigin.y() * z + sz.height() / 2 );
}

QTransform ImagePaint::viewTransform(const QSizeF& sz, double zoom, const QPointF& origin) const {
	QTransform tr;
	tr.translate(sz.width()/2.0f, sz.height()/2.0f);
	tr.translate(origin.x() * zoom, origin.y() * zoom);
	tr.scale(zoom, zoom);
	tr.translate(-imageSize().width()/2.0f, -imageSize().height()/2.0f);
	return tr;
}

float ImagePaint::pt2px(float pt) const {
	return pt / (m_zoom /** m_resolution*/);
}

void ImagePaint::setOverlay(QWidget *overlay) {
	if (overlay) {
		setMouseTracking(true);
		m_overlay = overlay;
		m_overlay->setVisible(false);
	} else {
		setMouseTracking(false);
		if (m_overlay) m_overlay->setVisible(false);
		m_overlay = 0;
	}
}

void ImagePaint::onIndexChanged(int idx)
{
	m_index = idx;
	update();
}

void ImagePaint::setImage(const QImage& image) {
	m_image = image;
	imageChanged(m_image);
	m_imgSize = image.size();
	if(!m_imgLoaded)
		initGPU();
	m_imgLoaded = true;
	cleanFBO();
	initFBO();
	update();
}

void ImagePaint::setOriginX(double value) {
	double x = value;
	if (m_moveOrigin.x() != x) {
		m_moveOrigin.setX(x);
		originXChanged(x);
		update();
	}
}

void ImagePaint::setOriginY(double value) {
	double y = value;
	if (m_moveOrigin.y() != y) {
		m_moveOrigin.setY(y);
		originYChanged(y);
		update();
	}
}

void ImagePaint::setZoom(double value) {
	if (value != m_zoom) {
		m_zoom = value;
		zoomChanged(m_zoom);
		update();
	}
}

void ImagePaint::setResolution(double value) {
	if (value != m_resolution) {
		m_resolution = value;
		resolutionChanged(m_resolution);
		update();
	}
}

void ImagePaint::zoomIn() {
	setZoom(m_zoom * 2);
}

void ImagePaint::zoomOut() {
	setZoom(m_zoom / 2);
}

void ImagePaint::reset() {
	m_zoom = 1.0;
	m_resolution = 1.0;
	m_moveOrigin = QPoint(0, 0);
	m_zoomOrigin = QPoint(0, 0);
	m_moveOriginKeep = QPoint(0, 0);
	m_zoomOriginKeep = QPoint(0, 0);
	zoomChanged(1);
	resolutionChanged(1);
	originXChanged(0);
	originYChanged(0);
	update();
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
	MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
}

void ImagePaint::hold() {
	//m_images[1] = m_images[0];
	update();
}

void ImagePaint::toggle() {
	m_index = 1 - m_index;
	QString title = window()->windowTitle().replace(" -- hold", "");
	if (m_index)
		title += " -- hold";
	window()->setWindowTitle(title);
	update();
} 

void ImagePaint::copy() {
	QClipboard *clipboard = QApplication::clipboard();
	clipboard->setImage(image());
}

void ImagePaint::savePNG(const QString& text) {
	QSettings settings;
	QString inputPath = window()->windowFilePath();
	QString outputPath = settings.value("savename", inputPath).toString();

	QString filename;
	QFileInfo fi(inputPath);
	QFileInfo fo(outputPath);
	if (!fi.baseName().isEmpty()) {
		QFileInfo fn(fo.dir(), fi.baseName() + "-out.png");
		filename  = fn.absoluteFilePath();
	} else {
		filename  = fo.absolutePath();
	}

	filename = QFileDialog::getSaveFileName(this, "Save PNG", filename, 
		"PNG Format (*.png);;All files (*.*)");
	if (!filename.isEmpty()) {
		//QImage tmp(image());
		_tex[T_FIN]->bind();
		unsigned char *pData = new unsigned char[m_imgSize.width()*m_imgSize.height()*3];
		glGetTexImage(GL_TEXTURE_2D,0,GL_RGB,GL_UNSIGNED_BYTE,pData);
		QImage tmp = QImage(pData, m_imgSize.width(), m_imgSize.height(), QImage::Format_RGB888);
		
		if (!text.isEmpty()) tmp.setText("Description", text);
		if (!tmp.save(filename)) 
		{
			QMessageBox::critical(this, "Error", QString("Saving PNG '%1' failed!").arg(filename));
			return;
		}
		delete []pData;
		settings.setValue("savename", filename);
	}
}

bool ImagePaint::eventFilter( QObject *watched, QEvent *e ) {
	if (!hasFocus() && (m_mode == MODE_MOVE) && (e->type() == QEvent::KeyPress)) {
		QKeyEvent *k = (QKeyEvent*)e;
		if (k->key() == Qt::Key_Space) {
			QPoint gp = mapFromGlobal(QCursor::pos());
			if (rect().contains(gp)) {
				setFocus(Qt::OtherFocusReason);
				keyPressEvent(k);
				return true;
			}
		}
	}
	return QWidget::eventFilter(watched, e);
}


void ImagePaint::leaveEvent( QEvent *e ) {
	QWidget::leaveEvent(e);
}

void ImagePaint::keyPressEvent( QKeyEvent *e ) {
	if ((m_mode == MODE_MOVE) && (e->key() == Qt::Key_Space)) {
		if (!m_spacePressed) {
			if (m_overlay && m_overlay->isVisible()) m_overlay->setVisible(false);
			m_cursor = cursor();
		//	setCursor(Qt::OpenHandCursor);
			m_spacePressed = true;
		}
	} 
	else if(e->key() == Qt::Key_Control){
		m_keyCtrl = true;
	}
	else {
		QWidget::keyPressEvent(e);
	}
}


void ImagePaint::keyReleaseEvent( QKeyEvent *e ) {
	if (e->key() == Qt::Key_Space) {
		if (!e->isAutoRepeat()) {
			if (m_mode == MODE_MOVE) {
				setCursor(m_cursor);
				m_cursor = QCursor();
			}
			m_spacePressed = false;
		}
	}
	else if(e->key() == Qt::Key_Control){
		m_keyCtrl = false;
	}
	else {
		QWidget::keyReleaseEvent(e);
	}
}


void ImagePaint::mousePressEvent( QMouseEvent *e ) {
	m_dragButton = e->button();
	if(m_streamlineDrawing)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		update();
	}
	else if(m_keyCtrl == true && m_dragButton==Qt::LeftButton)
	{
		m_bZoomInOut = true;
		_timer->start(_millisec);
	}
	else if(m_keyCtrl == true && m_dragButton==Qt::RightButton)
	{
		m_bZoomInOut = false;
		_timer->start(_millisec);
	}
	else
	{
		if(m_dragButton == Qt::LeftButton || m_dragButton == Qt::RightButton)
		{
			setCursor(Qt::ClosedHandCursor);
			m_moveStart =  e->pos();
			update();
		}
	}
}


void ImagePaint::mouseMoveEvent( QMouseEvent *e ) {
	//if(m_toolMode == E_MOVE )
	{
		if(m_streamlineDrawing)
		{
			m_currPosWnd = e->pos();
			m_currPosImg = view2image(m_currPosWnd);
			update();
		}
		else if(m_dragButton == Qt::LeftButton)
		{
			m_moveOrigin = m_moveOriginKeep + QPointF(e->pos() - m_moveStart) / m_zoom;
			originXChanged(m_moveOrigin.x());
			originYChanged(m_moveOrigin.y());
			update();
		}
		else if(m_dragButton == Qt::RightButton)
		{
			double u = double(e->pos().y()-m_moveStart.y())/double(m_wndSize.height());
			setZoom(m_zoom * (1 + u));
			m_moveStart = e->pos();
		}
	}
	MainWindow::getInstance()->setStatusMouse(QString("| Pos: (%1,%2)").arg(m_moveOrigin.x()).arg(m_moveOrigin.y()));
}


void ImagePaint::mouseReleaseEvent( QMouseEvent *e ) {
	m_dragButton = Qt::NoButton; 
	//if(m_toolMode == E_MOVE)
	if(m_streamlineDrawing)
	{
		m_currPosWnd = e->pos();
		m_currPosImg = view2image(m_currPosWnd);
		update();
	}
	{
	//	setCursor(Qt::OpenHandCursor);
		m_moveOriginKeep = m_moveOrigin;
	}
	/*else if(m_toolMode == E_ZOOM)
	{
		setCursor(Qt::OpenHandCursor);
		m_zoomOriginKeep = m_zoomOrigin;
	}*/
}

void ImagePaint::wheelEvent(QWheelEvent *e) {
	QSize sz = size();
	double u = e->delta() / 120.0 / 4.0;
	if (u < -0.5) u = -0.5;
	if (u > 0.5) u = 0.5;

	//if(m_toolMode == E_MOVE)
	{
		setZoom(m_zoom * (1 + u));
		MainWindow::getInstance()->setStatusZoom(QString("| Zoom: %1%").arg(m_zoom*100.0));
	}
}

void ImagePaint::draw(QPainter& p, const QRectF& R, const QImage& image) {
	QRect aR = R.toAlignedRect();
	p.drawImage(aR.x(), aR.y(), image.copy(aR));
}
//////////////////////////////////////////////////////////////////////////// opengl
void ImagePaint::initGPU() {
	finalizeGPU();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_LIGHTING);

	initFBO();
	initShaders();
}
void ImagePaint::finalizeGPU() {
	cleanFBO();
	cleanShaders();
	//glPopAttrib();
}

void ImagePaint::cleanFBO() {
	for(int i=0; i<NB_FBO; i++)
	{
		delete _fbo[i];
		_fbo[i] = NULL;
	}
	for(int i=0;i<NB_TEX;++i) 
	{
		delete _tex[i];
		_tex[i] = NULL;
	}
}

void ImagePaint::cleanShaders() {
	for(int i=0;i<NB_PROG;++i) 
	{
		if(_prog[i]!=NULL) 
		{
			delete _prog[i];
			_prog[i] = NULL;
		}
	}
}
void ImagePaint::reloadShaders() {
	if(_prog[0]!=NULL)
	{
		for(int i=0; i<NB_PROG; i++)
			_prog[i]->reload();
		setShaderParameters();
		update();
		std::cout<< "Shaders have been successfully reloaded!" << std::endl;
	}
}

void ImagePaint::initializeGL() {
	/// glew initialization
	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
		fprintf(stderr, "Error: %s\n",glewGetErrorString(err));

	/// GPU initialization
	for(int i=0; i<NB_FBO; i++)
		_fbo[i] = NULL;
	for(int i=0; i<NB_TEX; i++)
		_tex[i] = NULL;
	for(int i=0; i<NB_PROG; i++)
		_prog[i] = NULL;

	if(m_imgLoaded)
		initGPU();

	/// opengl initialization
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);

	QColor bc = palette().color(QPalette::Base);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void ImagePaint::loadTexture(int tex_id, const QImage &qimg)
{
	_tex[tex_id]->bind();
	if(qimg.format()!=QImage::Format_RGB32)
		qimg.convertToFormat(QImage::Format_RGB32);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, qimg.width(), qimg.height(), 0,
		GL_BGRA, GL_UNSIGNED_BYTE, qimg.bits());
}
void ImagePaint::setTextureDefault(int tex_id, float val)
{
	float *pData = new float[m_imgSize.width()*m_imgSize.height()*4];
	for(int i=0; i<m_imgSize.width()*m_imgSize.height()*4; i++)
		pData[i] = val;
	_tex[tex_id] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(), m_imgSize.height(),
		GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT),TextureParams(GL_NEAREST,GL_NEAREST),pData);
	delete []pData;
}
void ImagePaint::initFBO() {
	if(_fbo[FBO1]==NULL)
	{
		for(int i=0; i<NB_FBO; i++)
			_fbo[i] = new FramebufferObject();

		_tex[T_ORG	] = new FloatTexture2D(TextureFormat(GL_TEXTURE_2D,m_imgSize.width(),m_imgSize.height(),
			GL_RGBA32F_ARB,GL_RGBA,GL_FLOAT), TextureParams(GL_NEAREST,GL_LINEAR));

		_tex[T_GRADIENT	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_GRADIENT_S] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_PROFILE	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_PROJECT	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		//_tex[T_PEARL	] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
		_tex[T_FIN		] = new FloatTexture2D(_tex[T_ORG]->format(),TextureParams(GL_NEAREST,GL_LINEAR));
	}

	/// load image to gpu texture	
	loadTexture(T_ORG,m_image);
	setTextureDefault(T_PEARL,0.0);

	/// bind to fbo attachment
	_fbo[FBO1]->bind();
	_fbo[FBO1]->unattachAll();
	{
		_tex[T_GRADIENT]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRADIENT]->format().target(),_tex[T_GRADIENT]->id(),GL_COLOR_ATTACHMENT0_EXT);

		_tex[T_GRADIENT_S]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_GRADIENT_S]->format().target(),_tex[T_GRADIENT_S]->id(),GL_COLOR_ATTACHMENT1_EXT);

		_tex[T_PROFILE]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_PROFILE]->format().target(),_tex[T_PROFILE]->id(),GL_COLOR_ATTACHMENT2_EXT);

		_tex[T_PROJECT]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_PROJECT]->format().target(),_tex[T_PROJECT]->id(),GL_COLOR_ATTACHMENT3_EXT);

		_tex[T_FIN]->bind();
		_fbo[FBO1]->attachTexture(_tex[T_FIN]->format().target(),_tex[T_FIN]->id(),GL_COLOR_ATTACHMENT4_EXT);
	}
	_fbo[FBO1]->isValid();
	FramebufferObject::unbind();
}

void ImagePaint::setShaderParameters() {

	_prog[P_GRADIENT]->enable();
	_prog[P_GRADIENT]->addUniform("wh");
	_prog[P_GRADIENT]->addUniform("gradSize");
	_prog[P_GRADIENT]->addUniform("txOrg");
	_prog[P_GRADIENT]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_GRADIENT]->disable();

	_prog[P_GRADIENT_S]->enable();
	_prog[P_GRADIENT_S]->addUniform("wh");
	_prog[P_GRADIENT_S]->addUniform("gradSmoothSize");
	_prog[P_GRADIENT_S]->addUniform("txGrad");
	_prog[P_GRADIENT_S]->setUniformTexture("txGrad",	0,GL_TEXTURE_2D,_tex[T_GRADIENT]->id());
	_prog[P_GRADIENT_S]->disable();

	_prog[P_PROFILE]->enable();
	_prog[P_PROFILE]->addUniform("wh");
	_prog[P_PROFILE]->addUniform("txOrg");
	_prog[P_PROFILE]->addUniform("txGradS");
	_prog[P_PROFILE]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_PROFILE]->setUniformTexture("txGradS",	1,GL_TEXTURE_2D,_tex[T_GRADIENT_S]->id());
	_prog[P_PROFILE]->disable();

	_prog[P_FIN]->enable();
	_prog[P_FIN]->addUniform("wh");
	_prog[P_FIN]->addUniform("display");
	_prog[P_FIN]->addUniform("widthf");
	_prog[P_FIN]->addUniform("txOrg");
	_prog[P_FIN]->addUniform("txGrad");
	_prog[P_FIN]->addUniform("txGradS");
	_prog[P_FIN]->addUniform("txProf");
	_prog[P_FIN]->addUniform("txPearl");
	_prog[P_FIN]->setUniformTexture("txOrg",	0,GL_TEXTURE_2D,_tex[T_ORG]->id());
	_prog[P_FIN]->setUniformTexture("txGrad",	1,GL_TEXTURE_2D,_tex[T_GRADIENT]->id());
	_prog[P_FIN]->setUniformTexture("txGradS",	2,GL_TEXTURE_2D,_tex[T_GRADIENT_S]->id());
	_prog[P_FIN]->setUniformTexture("txProf",	3,GL_TEXTURE_2D,_tex[T_PROFILE]->id());
	_prog[P_FIN]->setUniformTexture("txPearl",	4,GL_TEXTURE_2D,_tex[T_PEARL]->id());
	_prog[P_FIN]->disable();
}
void ImagePaint::initShaders() {
	static std::string SHADER_DIR = "../vectorization/shaders/";
	_prog[P_GRADIENT	]= new GPUProgram(SHADER_DIR+"default.vs",	SHADER_DIR+"gradient.fs");
	_prog[P_GRADIENT_S	]= new GPUProgram(SHADER_DIR+"default.vs",	SHADER_DIR+"gradientSmooth.fs");
	_prog[P_PROFILE		]= new GPUProgram(SHADER_DIR+"default.vs",	SHADER_DIR+"profile.fs");
	_prog[P_FIN			]= new GPUProgram(SHADER_DIR+"default.vs",	SHADER_DIR+"fin.fs");
	setShaderParameters();
}

void ImagePaint::resizeGL(int w, int h) {
	m_wndSize = QSize(w,h);
}

void ImagePaint::paintGL() {
	if(!m_imgLoaded)
		return;

	QRectF zoomWnd = QRectF(-m_zoomOrigin
		+QPointF(m_imgSize.width(),m_imgSize.height())*(0.5-0.5/float(m_resolution)),
		QSizeF(m_imgSize)/float(m_resolution));
	float ws = 1.0f/float(m_imgSize.width());
	float hs = 1.0f/float(m_imgSize.height());

	glDisable(GL_LIGHTING);
	glColor4f(1,1,1,1);
	glEnable(GL_TEXTURE_2D);

	/////////////////////////////////////////////// render to texture
	_fbo[FBO1]->bind();
	swapToLocalMode(m_imgSize.width(), m_imgSize.height());

	glDrawBuffer(*FramebufferObject::buffers(0));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_GRADIENT]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_GRADIENT]->setUniform2f("wh",ws,hs);
	_prog[P_GRADIENT]->setUniform1i("gradSize",m_gradSize);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_GRADIENT]->disable();

	glDrawBuffer(*FramebufferObject::buffers(1));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_GRADIENT_S]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_GRADIENT_S]->setUniform2f("wh",ws,hs);
	_prog[P_GRADIENT_S]->setUniform1i("gradSmoothSize",m_gradSmoothSize);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_GRADIENT_S]->disable();

	glDrawBuffers(2,FramebufferObject::buffers(2));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_PROFILE]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_PROFILE]->setUniform2f("wh",ws,hs);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_PROFILE]->disable();

	glDrawBuffer(*FramebufferObject::buffers(4));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	_prog[P_FIN]->enable();
	glEnable(GL_TEXTURE_2D);
	_prog[P_FIN]->setUniform2f("wh",ws,hs);
	_prog[P_FIN]->setUniform1f("widthf",float(m_widthf));
	_prog[P_FIN]->setUniform1i("display",m_index);
	drawQuad(m_imgSize.width(), m_imgSize.height());
	_prog[P_FIN]->disable();

	swapToWorldMode();

	/////////////////////////////////// render to screen �� horizontal flip ��
	swapToLocalMode(m_wndSize.width(), m_wndSize.height());
	FramebufferObject::unbind();

	glEnable(GL_TEXTURE_2D);
	_tex[T_FIN]->bind();
	QColor bc = palette().color(QPalette::Window);
	glClearColor(float(bc.red())/255.0f,float(bc.green())/255.0f,float(bc.blue())/255.0f,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	QSize isz = m_imgSize*m_zoom;
	drawQuadScreen(isz.width(), isz.height(), 
		float(m_wndSize.width()-isz.width())/2.0f + m_moveOrigin.x()*m_zoom, 
		float(m_wndSize.height()-isz.height())/2.0f - m_moveOrigin.y()*m_zoom);
	glClearColor(1,1,1,0);

	if(m_streamlineDrawing)
	{
		drawStreamline();
		glEnable(GL_TEXTURE_2D);
	}
	if(m_bSkeletonDisplay)
	{
		m_sktGraph.drawOpenGL(float(m_wndSize.height()), float(m_wndSize.width()-m_imgSize.width())/2.0f, 
			float(m_wndSize.height()-m_imgSize.height())/2.0f);
		glEnable(GL_TEXTURE_2D);
	}

	swapToWorldMode();
}

void ImagePaint::nextFrame()
{
	if(m_frameCurr<0 || m_frameCurr<=m_frameCount)
	{
		update();
		m_frameCurr++;
	}
	else
	{
		m_frameCurr = 0;
		_timer->stop();
	}
}
void ImagePaint::updateProfileLabel(const float *pGrad, const float *pProf, const float *pProj, 
									int proWidth, int px, int py, float dLeft, float dRight)
{
	const int w = 200;
	const int h = 200;
	QImage img = QImage(w,h,QImage::Format_RGB888);
	img.fill(Qt::white);	/// not works? 

	/// sampling source image as background
	const int offset = 5;
	const int samples = 4;
	const float step = float(proWidth)/float(samples);
	QPainter painter(&img);

	QPointF gradf(pGrad[0],pGrad[1]);
	vector<QPointF> vPos(samples*2+1);
	for(int k=-samples; k<=samples; k++)
	{
		QPoint poss = QPoint(px+int(gradf.x()*float(k)*step),py+int(gradf.y()*float(k)*step));
		if(!QRect(0,0,m_imgSize.width()-1,m_imgSize.height()-1).contains(poss) )
			vPos[k+samples] = QPointF(-1.0,-1.0);
		else
		{
			int gray = qRed(m_image.pixel(poss));
			vPos[k+samples] = QPointF((k+samples)*(w-offset)/(samples*2),h-(gray*(h-offset)/255+offset));
		}
	}

	/// draw background 
	painter.setPen(QPen(QBrush(qRgb(255,255,255)),1.0,Qt::DashLine));
	painter.drawLine(QPoint(w/2,offset),QPoint(w/2,h));		/// central vertical line
	painter.drawText(2,12,QString("[%1,%2]").arg(px).arg(py));
	
	/// plot the underline pixel intensity
	painter.setPen(QPen(QBrush(qRgb(255,255,0)),1.0,Qt::SolidLine));
	for(int k=-samples; k<samples; k++)
		painter.drawLine(vPos[k+samples],vPos[k+samples+1]);
	painter.setPen(QPen(QBrush(qRgb(255,255,0)),2.0));
	for(int k=-samples; k<=samples; k++)
		painter.drawPoint(vPos[k+samples]);

	/// draw step disance
	painter.setPen(QPen(QBrush(qRgb(0,255,0)),1.0,Qt::DashLine));
	float dl = (0.5+dLeft*0.5/float(proWidth))*float(w-offset);
	painter.drawLine(QPointF(dl,float(offset)),QPointF(dl,float(h-offset)));
	float dr = (0.5+dRight*0.5/float(proWidth))*float(w-offset);
	painter.drawLine(QPointF(dr,float(offset)),QPointF(dr,float(h-offset)));
	float dm = (dl+dr)/2.0;
	painter.drawLine(QPointF(dm,float(offset+h/3)),QPointF(dm,float(h-offset-h/3)));


	/// plot fitted profile
	painter.setPen(QPen(QBrush(qRgb(255,0,255)),1.5));
	for(int xx=0; xx<w-offset; xx++)
	{
		const float xf = (float(xx)/float(w-offset)-0.5)*float(2*proWidth);
		const int yy = int((pProf[1]*xf*xf + pProf[2]*xf + pProf[3])*float(h-offset)/1.0) + offset;
		painter.drawPoint(xx,h-yy);
	}

	/// central bar of the profile function
	painter.setPen(QPen(QBrush(qRgb(255,0,255)),1.5,Qt::DashLine));
	const float peakx = pProf[1]==0.0 ? 0.0 : 0.5*float(w-offset)+(-pProf[2]*0.5/pProf[1])*0.5*float(w-offset)/float(proWidth);
	painter.drawLine(QPointF(peakx,float(offset)),QPointF(peakx,float(h-offset)));

	/// update to the label interface
	MainWindow::getInstance()->setProfileLabel(img);
}
void ImagePaint::drawStreamlineOne(const vector<tracking::Pot3f> &pnt, const tracking::Pot3f &clr, 
								   const tracking::Pot3f &clrStart)
{
	if(pnt.empty())
		return;

	const int sz1 = int(pnt[pnt.size()-1].x);
	const int sz2 = int(pnt[pnt.size()-1].y);
	const float shiftx = float(m_wndSize.width()-m_imgSize.width())/2.0;
	const float shifty = float(m_wndSize.height()-m_imgSize.height())/2.0;

	/// draw stream line : one side
	glDisable(GL_TEXTURE_2D);
	glColor3f(clr.x,clr.y,clr.ang);
	glLineWidth(1.0f);
	glBegin(GL_LINE_STRIP);
	for(int i=0; i<sz1; i++)
		glVertex3f(pnt[sz1-1-i].x+shiftx, m_wndSize.height()-(pnt[sz1-1-i].y+shifty), 0.001);
	glEnd();

	/// draw stream line : the other side
	glBegin(GL_LINE_STRIP);
	for(int i=sz1; i<sz1+sz2; i++)
		glVertex3f(pnt[i].x+shiftx, m_wndSize.height()-(pnt[i].y+shifty), 0.001);
	glEnd();

	/// draw starting point
	if(sz1>0)
	{
		/// draw the projected peak position in green
		glColor3f(clrStart.x,clrStart.y,clrStart.ang);
		glPointSize(2.0f);
		glBegin(GL_POINTS);
		glVertex3f(pnt[0].x+shiftx, m_wndSize.height()-(pnt[0].y+shifty), 0.002);
		glEnd();
	}		
}
void ImagePaint::drawStreamline()
{
	if( !QRectF(0.0,0.0,float(m_imgSize.width()-1),float(m_imgSize.height()-1)).contains(m_currPosImg) )
		return;

	/// get information from GPU textures
	_tex[T_GRADIENT]->bind();
	float *pGrad = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGrad);

	_tex[T_GRADIENT_S]->bind();
	float *pGradS = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pGradS);

	_tex[T_PROFILE]->bind();
	float *pProf = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProf);

	_tex[T_PROJECT]->bind();
	float *pProj = new float[m_imgSize.width()*m_imgSize.height()*4];
	glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_FLOAT,pProj);

	/////////////////////////////////////////////// tracing along the vector field
#if 1
	/// trace starting from the mouse position
	vector<tracking::Pot3f> pnt = tracking::streamline(m_currPosImg.x(), m_currPosImg.y(), 
		m_imgSize.width(), m_imgSize.height(), 4, pGradS, 0.0, m_trackingLength);
#else	
	/// trace starting from the projected peak position 
	vector<tracking::Pot3f> pnt = tracking::trackingProj(m_currPosImg.x(), m_currPosImg.y(), 
		m_imgSize.width(), m_imgSize.height(), 4, pGradS, pProj, 0.0, m_trackingLength);
#endif

	/// get starting position on the left and right steps : using a fitting in the future
	float stepPos[8];
	const int proWidth = 12;
	tracking::findStepPosition(stepPos,m_currPosImg.x(),m_currPosImg.y(),m_imgSize.width(),
		m_imgSize.height(),proWidth, pGrad,pGradS);

	/// trace starting from left step
	vector<tracking::Pot3f> pntLeft = tracking::streamline(stepPos[0],stepPos[1],
		m_imgSize.width(), m_imgSize.height(), 4, pGradS, 0.0, m_trackingLength);

	/// trace starting from right step
	vector<tracking::Pot3f> pntRight = tracking::streamline(stepPos[4],stepPos[5],
		m_imgSize.width(), m_imgSize.height(), 4, pGradS, 0.0, m_trackingLength);

	/// update the profile label on the right of the interface
	const int idx = 4*(m_currPosImg.y()*m_imgSize.width()+m_currPosImg.x());
	updateProfileLabel(pGradS+idx, pProf+idx, pProj+idx, proWidth, 
		m_currPosImg.x(), m_currPosImg.y(), stepPos[2], stepPos[6]);

	float tx = pProj[idx], ty = pProj[idx+1];
	
	/// delete texture information
	delete []pGrad;
	delete []pGradS;
	delete []pProf;
	delete []pProj;

	/// draw streamlines: centeral, left, and right
	drawStreamlineOne(pnt,		tracking::Pot3f(1.0,0.0,0.0),tracking::Pot3f(0.0,1.0,0.0));
	drawStreamlineOne(pntLeft,	tracking::Pot3f(1.0,0.0,0.0),tracking::Pot3f(0.0,1.0,0.0));
	drawStreamlineOne(pntRight,	tracking::Pot3f(1.0,0.0,0.0),tracking::Pot3f(0.0,1.0,0.0));

	/// draw sampling line (tragential direction)
	glColor3f(1,1,0);
	glLineWidth(1.0f);
	glDisable(GL_TEXTURE_2D);
	glBegin(GL_LINES);
	glVertex3f(m_currPosWnd.x()+tx*12.0,m_wndSize.height()-m_currPosWnd.y()-ty*12.0,0.001);
	glVertex3f(m_currPosWnd.x()-tx*12.0,m_wndSize.height()-m_currPosWnd.y()+ty*12.0,0.001);
	glEnd();

	/// draw the mouse position in yellow
	glColor3f(1,0,1);
	glPointSize(1.5f);
	glBegin(GL_POINTS);		
	glVertex3f(m_currPosWnd.x(), m_wndSize.height()-m_currPosWnd.y(), 0.002);
	glEnd();

	glColor3f(1,1,1);
}
void ImagePaint::setStreamline(bool isChecked)
{
	m_streamlineDrawing = isChecked;
	if(m_streamlineDrawing)
		setCursor(Qt::ArrowCursor);
	else
		setCursor(Qt::OpenHandCursor);
	refresh();
}
void ImagePaint::ComputeSkeletonChicked(bool isChecked)
{
	m_bSkeletonDisplay = isChecked;
	if(m_bSkeletonDisplay)
	{
		/// ��ȡ��ʼ��
		QPoint startPnt = skeleton::getStartingPoint(m_image);

		/// ����Skeleton graph
		m_sktGraph.clear();
		/// ���������Ҫʲô�������Լ��ӣ�GPU�������ݵĻ�ȡ�����drawStreamline��ǰ�벿��
		/// ע�⣺Ϊ�˻�ȡ��Ա�������ú�������ΪImagePaint�ĳ�Ա�������䶨����vectorizationPaint2.cpp��
		m_sktGraph.m_vVertex.push_back(skeleton::Vertex(startPnt,false));
		computeSkeletonGraph(m_sktGraph);
		
		/// draw the skeleton in paintGL() function if drawing is fast enough

	}
	refresh();
}
