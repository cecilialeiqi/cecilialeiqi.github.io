#include <pipeline.h>

using namespace std;

namespace gpu {

  Pipeline::Pipeline(unsigned int nbPass,const TextureFormat &tf,const TextureParams &tp,int depthMode) 
    : _nbPass(nbPass),
      _nbFBOs(0),
      _nbTexs(0),
      _tf(tf),
      _tp(tp),
      _depthMode(depthMode),
      _currentFbo(-1) {
  
    _pass = vector<Pass *>(_nbPass);

    for(unsigned int i=0;i<_nbPass;++i) {
      _pass[i] = NULL;
    }

  }

  Pipeline::~Pipeline() {
    for(unsigned int i=0;i<_nbPass;++i) {
      if(_pass[i]!=NULL) {
        delete _pass[i];
      }
    }

    _pass.clear();

    for(unsigned int i=0;i<_nbFBOs;++i) {
      if(_fbos[i]!=NULL) {
        delete _fbos[i];
      }
    }
    
    _fbos.clear();

    for(unsigned int i=0;i<_nbTexs;++i) {
      if(_texs[i]!=NULL) {
        delete _texs[i];
      }
    }
    
    _texs.clear();
  }

  bool Pipeline::setPass(unsigned int i,unsigned int nbTexOutput,GPUProgram *prog) {
    assert(i<_nbPass);
  
    GLint maxdr;
    glGetIntegerv(GL_MAX_DRAW_BUFFERS,&maxdr);

    if(nbTexOutput>(unsigned int)maxdr) {
      cout << "Warning : function : " << __FUNCTION__ << ", unable to write more than " << maxdr << " textures in one pass !" << endl;
      return false;
    }

    if(_pass[i]!=NULL) {
      delete _pass[i];
      _pass[i] = NULL;
    }

    _pass[i] = new Pass(prog,nbTexOutput);
  
    return true;
  }

  bool Pipeline::init() {
    // test if each pass has been build
    for(unsigned int i=0;i<_nbPass;++i) {
      if(_pass[i]==NULL) {
        cout << "Pipeline initialization failed: _pass[" << i << "]==NULL" << endl;
        return false;
      }
    }

    // clear fbos and textures 
    for(unsigned int i=0;i<_nbFBOs;++i) {
      delete _fbos[i];
      _fbos[i] = NULL;
    }
  
    _fbos.clear();

    for(unsigned int i=0;i<_nbTexs;++i) {
      delete _texs[i];
      _texs[i] = NULL;
    }

    _texs.clear();

    _nbFBOs = 0;
    _nbTexs = 0;
  
    // count nb textures and FBOs
    int maxAttachments   = FramebufferObject::getMaxColorAttachments();
    unsigned int currentAttachment = 0;

    for(unsigned int i=0;i<_nbPass;++i) {
      if(_pass[i]->nbTexOutput()>0) {
        _nbFBOs ++;
        break;
      }
    }

    for(unsigned int i=0;i<_nbPass;++i) {
      for(unsigned int j=0;j<_pass[i]->nbTexOutput();++j) {
        _pass[i]->addTexId(_nbTexs);
        _nbTexs ++;
      }

      if((currentAttachment+_pass[i]->nbTexOutput()) > (unsigned int)maxAttachments) {
        _nbFBOs ++;
        currentAttachment = 0;
      }

      if(_pass[i]->nbTexOutput()>0) {
        _pass[i]->setFboNum((int)_nbFBOs-1);
        for(unsigned int j=0;j<_pass[i]->nbTexOutput();++j) {
          _pass[i]->addAttachment(currentAttachment);
          currentAttachment ++;
        }
      }
    }

    createFBOs();

    // depth textures 
    if(!_fbos.empty() && _depthMode==USE_ONE_DEPTH_BUFFER) {
      _nbTexs ++;
    } else if(!_fbos.empty() && _depthMode==USE_MULT_DEPTH_BUFFER) {
      _nbTexs += _nbFBOs;
    }
  
    createTextures();

    return attachTexturesToFBOs();
  }

  void Pipeline::createFBOs() {
    // FBOs creation 
    _fbos = vector<FramebufferObject *>(_nbFBOs);
    for(unsigned int i=0;i<_nbFBOs;++i) {
      _fbos[i] = new FramebufferObject();
    }  
  }

  void Pipeline::createTextures() {
    if(_nbTexs>0) {
      // Texture creation
      _texs = vector<FloatTexture2D *>(_nbTexs);
  
      TextureFormat tfd;

      if(_depthMode==USE_NO_DEPTH_BUFFER) {
    
        // no depth buffer
        for(unsigned int i=0;i<_nbTexs;++i) {
          _texs[i] = new FloatTexture2D(_tf,_tp);
        }
      } else if(_depthMode==USE_ONE_DEPTH_BUFFER) {

        // one depth buffer (only on the first FBO)
        for(unsigned int i=0;i<_nbTexs-1;++i) {
          _texs[i] = new FloatTexture2D(_tf,_tp);
        }
    
        tfd = _tf;
        tfd.setInternalformat(GL_DEPTH_COMPONENT24);
        tfd.setFormat(GL_DEPTH_COMPONENT);
  
        _texs[_nbTexs-1] = new FloatTexture2D(tfd,_tp);

      } else if(_depthMode==USE_MULT_DEPTH_BUFFER) {

        // multiple depth buffer (one per FBO)
        for(unsigned int i=0;i<_nbTexs-_nbFBOs;++i) {
          _texs[i] = new FloatTexture2D(_tf,_tp);
        }
    
        tfd = _tf;
        tfd.setInternalformat(GL_DEPTH_COMPONENT24);
        tfd.setFormat(GL_DEPTH_COMPONENT);
    
        for(unsigned int i=_nbTexs-_nbFBOs;i<_nbTexs;++i) {
          _texs[i] = new FloatTexture2D(tfd,_tp);
        }
      } 
    }
  }

  bool Pipeline::attachTexturesToFBOs() {

    // unattach all
    for(unsigned int i=0;i<_nbFBOs;++i) {
      _fbos[i]->bind();
      _fbos[i]->unattachAll();
    }

    // color attachments 
    for(unsigned int i=0;i<_nbPass;++i) {
      if(_pass[i]->nbTexOutput()>0) {
        _fbos[_pass[i]->fboNum()]->bind();
      
        for(unsigned int j=0;j<_pass[i]->nbTexOutput();++j) {
          _texs[_pass[i]->texId(j)]->bind();
          _fbos[_pass[i]->fboNum()]->attachTexture(_texs[_pass[i]->texId(j)]->format().target(),
                                                   _texs[_pass[i]->texId(j)]->id(),
                                                   GL_COLOR_ATTACHMENT0_EXT+_pass[i]->attachment(j));
        }
      }
    }
  
    // depth attachments 
    if(!_fbos.empty() && _depthMode==USE_ONE_DEPTH_BUFFER) {
      _fbos[0]->bind();
      _fbos[0]->attachTexture(_texs[_nbTexs-1]->format().target(),
                              _texs[_nbTexs-1]->id(),
                              GL_DEPTH_ATTACHMENT_EXT);
    
    } else if(!_fbos.empty() && _depthMode==USE_MULT_DEPTH_BUFFER) {
      for(unsigned int j=0;j<_nbFBOs;++j) {
        _fbos[j]->bind();
        _fbos[j]->attachTexture(_texs[_nbTexs-_nbFBOs+j]->format().target(),
                                _texs[_nbTexs-_nbFBOs+j]->id(),
                                GL_DEPTH_ATTACHMENT_EXT);
      }
    }
  
    // test validity
    bool valid = true;
    for(unsigned int i=0;i<_nbFBOs;++i) {
      _fbos[i]->bind();
      if(!_fbos[i]->isValid())
        valid = false;
    }

    FramebufferObject::unbind();

    // --- debug --- 
    //printInfo();

    return valid;
  }

  void Pipeline::setTextureSize(unsigned int w,unsigned int h) {
    _tf.setWidth(w);
    _tf.setHeight(h);

    for(unsigned int i=0;i<_nbTexs;++i) {
      if(_texs[i]!=NULL) {
        delete _texs[i];
        _texs[i] = NULL;
      }
    }
  
    _texs.clear();

    createTextures();
    attachTexturesToFBOs();
  }

  void Pipeline::setTextureData(const TextureFormat &tf,const TextureParams &tp) {
    _tf = tf;
    _tp = tp;

    for(unsigned int i=0;i<_nbTexs;++i) {
      if(_texs[i]!=NULL) {
        delete _texs[i];
        _texs[i] = NULL;
      }
    }
  
    _texs.clear();

    createTextures();
    attachTexturesToFBOs();
  }

  void Pipeline::printInfo() {
    cout << endl << "PIPELINE STATE:" << endl;
    cout << "nb passes : " << _nbPass << endl;
    cout << "nb fbos   : " << _nbFBOs << endl;
    cout << "nb texs   : " << _nbTexs << endl;

    for(unsigned int i=0;i<_nbPass;++i) {
      cout << "pass " << i << " : fbo = " << _pass[i]->fboNum() << " & nb tex = " << _pass[i]->nbTexOutput() << endl;
      for(unsigned int j=0;j<_pass[i]->nbTexOutput();++j) {
        cout << "----- texture " << j << " : attachment " << _pass[i]->attachment(j) <<  ", tex id = " << _texs[_pass[i]->texId(j)]->id() << endl;
      }
    }

    cout << "---------------" << endl << endl;
  }

} // gpu namespace 
