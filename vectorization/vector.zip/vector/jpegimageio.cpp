#include <jpegimageio.h>

#include <Qt/qimage.h>
#include <QtCore/QString>

using namespace std;

#ifdef USE_JPEG

#endif

namespace image {

  vector<string> JPEGImageIO::getExtensions() {
    vector<string> ext;
  
#ifdef USE_JPEG
    ext.push_back("jpeg");
    ext.push_back("JPEG");
    ext.push_back("jpg");
    ext.push_back("JPG");
#endif
  
    return ext;
  }

  Image *JPEGImageIO::createImage(const string &filename) {
#ifdef USE_JPEG
   // cout << "TODO createImage " << filename << ", LIB_JPEG needed" << endl;
	{
		QImage qimg;
		if( !qimg.load(QString(filename.c_str()), "JPG") )
		{
			cout << "Cannot load image: " << filename << endl;
			return NULL;
		}
		else
		{
			Image *img;
			int w=qimg.width(), h=qimg.height();

			// if(!qimg.hasAlphaChannel())
			{
				float color[3];
				QRgb rgb;
				img = new Image(filename, w, h, Image::RGB_IMAGE);
				for(unsigned int yi=0; yi<h; yi++)
					for(unsigned int xi=0; xi<w; xi++)
					{
						rgb = qimg.pixel(xi,yi);
						color[0] = float(qRed(rgb))/255.f;
						color[1] = float(qGreen(rgb))/255.f;
						color[2] = float(qBlue(rgb))/255.f;
						img->setPix(xi, yi, 3, color);
					}
			}
			return img;
		}
	}
    return NULL;
#else 
    cerr << "Unable to create " << filename << ", LIB_JPEG needed" << endl;
    return NULL;
#endif
  }

  bool JPEGImageIO::saveImage(const Image &img,const string &filename) {
#ifdef USE_JPEG
   // cout << "TODO : saveImage " << img.getName() << "in " << filename << ", LIB_JPEG needed" << endl;
	  if(img.isLoaded())
	  {
		  int w=img.getWidth(), h=img.getHeight();
		  QImage qimg;
		  if(img.pixelSize()==4)
			   qimg = QImage(w,h,QImage::Format_ARGB32);
		  else 
			   qimg = QImage(w,h,QImage::Format_RGB32);

		  QRgb rgb;
		  for(unsigned int yi=0; yi<h; yi++)
		  {
			  for (unsigned int xi=0; xi<w; xi++)
			  {
				  rgb = qRgb(int( (img.getPix(xi,yi,0)*255.f) +0.5), int( (img.getPix(xi,yi,1)*255.f) +0.5), int( (img.getPix(xi,yi,2)*255.f) +0.5));
				  qimg.setPixel(xi,yi,rgb);
			  }
		  }
		  qimg.save(QString(filename.c_str()),"JPG");
	  }

    return false;
#else 
    cerr << "Unable to save " << img.getName() << "in " << filename << ", LIB_JPEG needed" << endl;

    return false;
#endif
  }

} // image namespace 
