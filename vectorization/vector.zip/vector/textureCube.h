#ifndef TEXTURE_CUBE_H
#define TEXTURE_CUBE_H

#include "gpuDLL.h"
#include <glew.h>
#include <gl.h>
#include <glu.h>

#include <string>
#include <image.h>
#include <imageio.h>
#include <texture2D.h>
#include <textureFormat.h>
#include <textureParams.h>

using namespace image;

namespace gpu {
  
  template<typename T = float> 
    class TextureCube {
  public:

  TextureCube(const TextureFormat &tf=TextureFormat(),
	      const TextureParams &tp=TextureParams(),
	      bool genCubeFaces=false,
	      int  indexMode=GL_NORMAL_MAP,
	      T* map[6]=NULL,
	      int id=-1);
  
  TextureCube(const TextureCube &tex);

  ~TextureCube();
  
  inline GLuint         id    () const;
  inline TextureFormat  format() const;
  inline TextureParams  params() const;
  inline void           bind  () const;
  inline bool cubeFacesCreated() const;
  inline int      getIndexMode() const;

  inline void drawCube(float halfSize);

  inline static TextureCube<float> *fromImage(Image *img[6]          ,const TextureFormat &tf,const TextureParams &tp,bool genCubeFaces=false,int indexMode=GL_NORMAL_MAP);
  inline static TextureCube<float> *fromImage(std::string filename[6],const TextureFormat &tf,const TextureParams &tp,bool genCubeFaces=false,int indexMode=GL_NORMAL_MAP);

  static GLenum _targets[6];

  protected:
  GLuint        _id;
  TextureFormat _format;
  TextureParams _params;

  bool          _facesCreated;
  Texture2D<T>  _faces[6];
  int           _indexMode;
  
  };

  template<typename T>
    GLenum TextureCube<T>::_targets[6] = {
    GL_TEXTURE_CUBE_MAP_POSITIVE_X, // right
    GL_TEXTURE_CUBE_MAP_NEGATIVE_X, // left
    GL_TEXTURE_CUBE_MAP_POSITIVE_Y, // top
    GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, // bottom
    GL_TEXTURE_CUBE_MAP_POSITIVE_Z, // front
    GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, // back
  };

  template<typename T>
    inline GLuint TextureCube<T>::id() const {
    return _id;
  }

  template<typename T>
    inline TextureFormat TextureCube<T>::format() const {
    return _format;
  }

  template<typename T>
    inline TextureParams TextureCube<T>::params() const {
    return _params;
  }

  template<typename T>
    inline void TextureCube<T>::bind() const {

    glBindTexture(_format.target(),_id);
  }

  template<typename T>
    TextureCube<T>::TextureCube(const TextureCube<T> &tex)
    : _id(tex.id()),
    _format(tex.format()),
    _params(tex.params()),
    _facesCreated(tex.cubeFacesCreated()),
    _indexMode(tex.getIndexMode()) {

  }

  template<typename T>
    inline bool TextureCube<T>::cubeFacesCreated() const {
    return _facesCreated;
  }

  template<typename T>
    inline int TextureCube<T>::getIndexMode() const {
    return _indexMode;
  }

  template<typename T>
    TextureCube<T>::TextureCube(const TextureFormat &tf,const TextureParams &tp,bool genCubeFaces,int  indexMode,T* map[6],int id)
    : _id(id),
    _format(tf),
    _params(tp),
    _facesCreated(genCubeFaces),
    _indexMode(indexMode) {

      assert(_format.target()==GL_TEXTURE_CUBE_MAP);
      glEnable(GL_TEXTURE_CUBE_MAP);
      
      if(id<0 || glIsTexture(id)==GL_FALSE) {
        glGenTextures(1,&_id);
      } else {
        _id = id;
      }

      // cube map generation
      glBindTexture(_format.target(),_id);
    
      for(unsigned int i=0;i<6;i++) {

        if(_format.mipmapmode()==TextureFormat::MIPMAP_GLU_AUTOM) {
      
          gluBuild2DMipmaps(_targets[i],
                            _format.internalformat(),
                            _format.width(),
                            _format.height(),
                            _format.format(),
                            _format.type(),
                            (const GLvoid *)map[i]);
        } else {
    
          glTexImage2D(_targets[i],
                       _format.level(),
                       _format.internalformat(),
                       _format.width(),
                       _format.height(),
                       _format.border(),
                       _format.format(),
                       _format.type(),
                       (const GLvoid *)map[i]);
        }

      }

      glTexParameteri(_format.target(),GL_TEXTURE_MIN_FILTER,_params.minfilter());
      glTexParameteri(_format.target(),GL_TEXTURE_MAG_FILTER,_params.maxfilter());
      glTexParameteri(_format.target(),GL_TEXTURE_WRAP_S,_params.wraps());
      glTexParameteri(_format.target(),GL_TEXTURE_WRAP_T,_params.wrapt());

      glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,_indexMode);
      glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,_indexMode);
      glTexGeni(GL_R,GL_TEXTURE_GEN_MODE,_indexMode);

      // cube faces generation
      if(_facesCreated) {
        TextureFormat f = tf;
        f.setTarget(GL_TEXTURE_2D);
        for(unsigned int i=0;i<6;++i) {
          _faces[i] = Texture2D<T>(f,tp,map[i]);
        }
      }
    }
  
  template<typename T>
    TextureCube<T>::~TextureCube() {	
    glDeleteTextures(1,&_id);
  }

  template<typename T>
    inline void TextureCube<T>::drawCube(float halfSize) {

    if(!_facesCreated) {
      return;
    }

    _faces[0].bind(); // right
    glEnable(_faces[0].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(1.0,1.0); glVertex3f(halfSize,-halfSize,-halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(halfSize,-halfSize,halfSize);
    glTexCoord2f(0.0,0.0); glVertex3f(halfSize,halfSize,halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(halfSize,halfSize,-halfSize);
    glEnd();

    _faces[1].bind(); // left
    glEnable(_faces[1].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(1.0,1.0); glVertex3f(-halfSize,-halfSize,halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(0.0,0.0); glVertex3f(-halfSize,halfSize,-halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(-halfSize,halfSize,halfSize);
    glEnd();

    _faces[2].bind(); // top
    glEnable(_faces[2].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(0.0,0.0); glVertex3f(-halfSize,halfSize,-halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(halfSize,halfSize,-halfSize);
    glTexCoord2f(1.0,1.0); glVertex3f(halfSize,halfSize,halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(-halfSize,halfSize,halfSize);
    glEnd();

    _faces[3].bind(); // bottom
    glEnable(_faces[3].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(0.0,0.0); glVertex3f(-halfSize,-halfSize,halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(halfSize,-halfSize,halfSize);
    glTexCoord2f(1.0,1.0); glVertex3f(halfSize,-halfSize,-halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glEnd();

    _faces[4].bind(); // front
    glEnable(_faces[4].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(1.0,1.0); glVertex3f(halfSize,-halfSize,halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(-halfSize,-halfSize,halfSize);
    glTexCoord2f(0.0,0.0); glVertex3f(-halfSize,halfSize,halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(halfSize,halfSize,halfSize);
    glEnd();

    _faces[5].bind(); // back
    glEnable(_faces[5].format().target());
    glBegin(GL_QUADS);
    glTexCoord2f(1.0,1.0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(0.0,1.0); glVertex3f(halfSize,-halfSize,-halfSize);
    glTexCoord2f(0.0,0.0); glVertex3f(halfSize,halfSize,-halfSize);
    glTexCoord2f(1.0,0.0); glVertex3f(-halfSize,halfSize,-halfSize);
    glEnd();
  }

  template<typename T>
    inline TextureCube<float> *TextureCube<T>::fromImage(Image *img[6],const TextureFormat &tf,const TextureParams &tp,bool genCubeFaces,int indexMode) {
    
    float *ptrs[6];
    for(unsigned int i=0;i<6;++i) {
      ptrs[i] = img[i]->ptr();
    }

    return new TextureCube<float>(tf,tp,genCubeFaces,indexMode,ptrs);
  }

  template<typename T>
    inline TextureCube<float> *TextureCube<T>::fromImage(std::string filename[6],const TextureFormat &tf,const TextureParams &tp,bool genCubeFaces,int indexMode) {
    
    Image *img[6];
    for(unsigned int i=0;i<6;++i) {
      img[i] = ImageIO::createImage(filename[i]);
      assert(!ImageIO::error());
    }

    tf.setWidth(img[0]->getWidth());
    tf.setHeight(img[0]->getHeight());
    tf.setFormat(img[0]->glFormat());

    TextureCube<float> *tex = fromImage(img,tf,tp,genCubeFaces,indexMode);

    for(unsigned int i=0;i<6;++i) {    
      delete img[i];
    }
    
    return tex;
  }

  typedef TextureCube<float>         FloatTextureCube;
  typedef TextureCube<unsigned char> UbyteTextureCube;
  typedef TextureCube<unsigned int>  UintTextureCube;

} // gpu namespace 

#endif // TEXTURE_CUBE_H
