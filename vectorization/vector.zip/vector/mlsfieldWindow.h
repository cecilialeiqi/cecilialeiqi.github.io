
#pragma once

#include "ui_mainwindow.h"
#include "mlsfieldPaint.h"
#include "videoplayer.h"

enum TOOL_MODE	{E_MOVE=0, E_ZOOM, E_ROTO };

const QStringList displayList = (QStringList()
								 << "Flow"	
								 << "Input Flow"
								 << "Error"	
								 << "Estimated gradient"	
								 << "Input(with noises)"	
								 << "Input image"		);


class MainWindow : public QMainWindow, protected Ui_MainWindow {
    Q_OBJECT
public:
    MainWindow();
    ~MainWindow();

	static MainWindow* getInstance() 
	{
		if(_mainWindow==NULL)
			_mainWindow = new MainWindow();
		return _mainWindow;
	}

	static void deleteInstance() 
	{
		if(_mainWindow!=NULL) {
			delete _mainWindow;
			_mainWindow = NULL;
		}
	}

    void restoreSettings();
    void closeEvent(QCloseEvent *e);

    const QImage& image() const { return m_result; }
 
//	void setCurrentTool(const QString &name);

	/// status bar
	void setStatusMessage(const QString &txt) {statusBar()->showMessage(txt);}
	void setStatusMouse(const QString& txt) {m_statusMouseLabel->setText(txt);}
	void setStatusZoom(const QString& txt) {m_statusZoomLabel->setText(txt);}
	void setStatusResolution(const QString& txt) {m_statusReslLabel->setText(txt);}
//	void setStatusTool(const int idx);

protected slots:
    void on_actionOpen_triggered();
    void on_actionAbout_triggered();
    void on_actionRecord_triggered();
	void setFullScreen();

	void setDirty();
	void setDirty2();
	void process();
	void process2();
    
    void onVideoChanged(int nframes);
	void objectButtonClicked();
	void cpuButtonClicked(bool);
	void computeFullButtonClicked();
	void batchButtonClicked();
	void errorButtonClicked();

signals:
    void imageChanged(const QImage&);

protected:
    virtual void draw(ImagePaint *view, QPainter &p, const QRectF& R, const QImage& image);

    VideoPlayer *m_player;
    //cpu_image<float4> m_st;
    //cpu_image<float4> m_tfm;
    QImage m_result;
    bool m_dirty;

private:
	static MainWindow*	_mainWindow;

	QLabel		*m_statusMouseLabel;
	QLabel		*m_statusZoomLabel;
	QLabel		*m_statusReslLabel;
};