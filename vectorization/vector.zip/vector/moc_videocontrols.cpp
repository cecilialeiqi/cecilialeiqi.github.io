/****************************************************************************
** Meta object code from reading C++ file 'videocontrols.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../util/videocontrols.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'videocontrols.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_VideoControls[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x05,
      29,   14,   14,   14, 0x05,
      46,   40,   14,   14, 0x05,
      71,   40,   14,   14, 0x05,
     104,   96,   14,   14, 0x05,
     126,   14,   14,   14, 0x05,
     144,   14,   14,   14, 0x05,
     170,  161,   14,   14, 0x05,
     192,   14,   14,   14, 0x05,
     210,   14,   14,   14, 0x05,

 // slots: signature, parameters, type, tag, flags
     236,  228,   14,   14, 0x0a,
     255,   40,   14,   14, 0x0a,
     276,   96,   14,   14, 0x0a,
     294,   14,   14,   14, 0x0a,
     301,   14,   14,   14, 0x0a,
     309,   14,   14,   14, 0x0a,
     318,   14,   14,   14, 0x09,
     340,   14,   14,   14, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_VideoControls[] = {
    "VideoControls\0\0stepForward()\0stepBack()\0"
    "frame\0currentFrameChanged(int)\0"
    "currentFrameTracked(int)\0playing\0"
    "playbackChanged(bool)\0playbackStarted()\0"
    "playbackPaused()\0tracking\0"
    "trackingChanged(bool)\0trackingStarted()\0"
    "trackingStopped()\0nframes\0setFrameCount(int)\0"
    "setCurrentFrame(int)\0setPlayback(bool)\0"
    "play()\0pause()\0toogle()\0handleSliderPressed()\0"
    "handleSliderReleased()\0"
};

void VideoControls::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        VideoControls *_t = static_cast<VideoControls *>(_o);
        switch (_id) {
        case 0: _t->stepForward(); break;
        case 1: _t->stepBack(); break;
        case 2: _t->currentFrameChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->currentFrameTracked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->playbackChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->playbackStarted(); break;
        case 6: _t->playbackPaused(); break;
        case 7: _t->trackingChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->trackingStarted(); break;
        case 9: _t->trackingStopped(); break;
        case 10: _t->setFrameCount((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setCurrentFrame((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->setPlayback((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->play(); break;
        case 14: _t->pause(); break;
        case 15: _t->toogle(); break;
        case 16: _t->handleSliderPressed(); break;
        case 17: _t->handleSliderReleased(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData VideoControls::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject VideoControls::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_VideoControls,
      qt_meta_data_VideoControls, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &VideoControls::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *VideoControls::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *VideoControls::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_VideoControls))
        return static_cast<void*>(const_cast< VideoControls*>(this));
    return QFrame::qt_metacast(_clname);
}

int VideoControls::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void VideoControls::stepForward()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void VideoControls::stepBack()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void VideoControls::currentFrameChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void VideoControls::currentFrameTracked(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void VideoControls::playbackChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void VideoControls::playbackStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void VideoControls::playbackPaused()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void VideoControls::trackingChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void VideoControls::trackingStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void VideoControls::trackingStopped()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}
QT_END_MOC_NAMESPACE
